const http = require('http');
const path = require('path');
const fs = require('fs');
const { spawn, execFileSync } = require('child_process');
const express = require('express');
const cors = require('cors');
const multer = require('multer');
const { WebSocketServer } = require('ws');

const { findChromeExecutable, probeCdpPort, hideChromeWindowByPort } = require('./src/chromeLauncher');
const { AccountManager } = require('./src/accountManager');
const { CdpEngine } = require('./src/cdpEngine');
const { BatchScheduler } = require('./src/batchScheduler');
const {
  FILM_GENRES,
  CINEMA_VOICE_PRESETS,
  CINEMA_LIGHTING_PRESETS,
  ACTING_STYLE_PRESETS,
  COMBAT_INTENSITY_PRESETS,
  CHARACTER_SHEET_MODES,
  SHOT_SIZE_PRESETS,
  CAMERA_MOVE_PRESETS,
  splitScriptIntoScenesLocally
} = require('./src/cinemaDirector');
const {
  TRANSITION_EFFECTS,
  COLOR_GRADE_PRESETS,
  renderFullCinemaMaster,
  resolveSceneVideoDiskPath
} = require('./src/videoEditor');
const {
  POSTER_THEME_PRESETS,
  POSTER_SOURCE_MODES,
  POSTER_BADGE_PRESETS,
  renderPromoPack
} = require('./src/promoBuilder');
const { LicenseManager } = require('./src/licenseManager');
const { checkForUpdate, performSelfUpdate } = require('./src/autoUpdater');

const APP_ROOT = __dirname;
const APP_VERSION = '2.8';
const PORT = Number(process.env.PORT) || 3890;
const PUBLIC_DIR = path.join(APP_ROOT, 'public');
const OPEN_FOLDER_HELPER_EXE = path.join(APP_ROOT, 'src', 'MfsOpenFolder.exe');

const CHROME_PROFILE_DIR = path.join(APP_ROOT, 'ChromeProfile_Data');
const UPLOADS_DIR = path.join(APP_ROOT, 'Project_Data', 'uploads');
const OUTPUT_VIDEOS_DIR = path.join(APP_ROOT, 'Output_Videos');

[CHROME_PROFILE_DIR, UPLOADS_DIR, OUTPUT_VIDEOS_DIR].forEach((dir) => {
  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir, { recursive: true });
  }
});

function isFrontendAssetsReady() {
  return (
    fs.existsSync(path.join(PUBLIC_DIR, 'index.html')) &&
    fs.existsSync(path.join(PUBLIC_DIR, 'app.js')) &&
    fs.existsSync(path.join(PUBLIC_DIR, 'styles.css'))
  );
}

const app = express();
const server = http.createServer(app);
const wss = new WebSocketServer({ server });

app.use(cors());
app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ extended: true, limit: '50mb' }));

app.get(['/', '/index.html'], (req, res) => {
  const htmlPath = path.join(PUBLIC_DIR, 'index.html');
  res.setHeader('Cache-Control', 'no-store, no-cache, must-revalidate');
  if (fs.existsSync(htmlPath)) {
    res.setHeader('Content-Type', 'text/html; charset=utf-8');
    return res.status(200).send(fs.readFileSync(htmlPath, 'utf8'));
  }
  return res.status(503).send('Missing public/index.html');
});

app.get('/styles.css', (req, res) => {
  const cssPath = path.join(PUBLIC_DIR, 'styles.css');
  res.setHeader('Cache-Control', 'no-cache');
  if (fs.existsSync(cssPath)) {
    res.setHeader('Content-Type', 'text/css; charset=utf-8');
    return res.status(200).send(fs.readFileSync(cssPath, 'utf8'));
  }
  return res.status(404).end();
});

app.get('/app.js', (req, res) => {
  const jsPath = path.join(PUBLIC_DIR, 'app.js');
  res.setHeader('Cache-Control', 'no-cache');
  if (fs.existsSync(jsPath)) {
    res.setHeader('Content-Type', 'application/javascript; charset=utf-8');
    return res.status(200).send(fs.readFileSync(jsPath, 'utf8'));
  }
  return res.status(404).end();
});

app.get('/api/health', (req, res) => {
  const htmlReady = isFrontendAssetsReady();
  res.status(htmlReady ? 200 : 503).json({
    ok: htmlReady,
    app: 'MUSE_CINEMA_STUDIO',
    version: APP_VERSION,
    pid: process.pid,
    port: PORT,
    appRootDir: APP_ROOT,
    htmlReady
  });
});

app.use(express.static(PUBLIC_DIR, { dotfiles: 'allow' }));
app.use('/uploads', express.static(UPLOADS_DIR, { dotfiles: 'allow' }));
app.use('/outputs', express.static(OUTPUT_VIDEOS_DIR, { dotfiles: 'allow' }));

/* ================= MULTER UPLOAD HANDLERS ================= */

const charImgStorage = multer.diskStorage({
  destination: (req, file, cb) => {
    const accId = req.params.accountId || 'default';
    const dest = path.join(UPLOADS_DIR, accId, 'characters');
    fs.mkdirSync(dest, { recursive: true });
    cb(null, dest);
  },
  filename: (req, file, cb) => {
    const ext = path.extname(file.originalname || '.png').toLowerCase() || '.png';
    const safeExt = ['.png', '.jpg', '.jpeg', '.webp'].includes(ext) ? ext : '.png';
    cb(null, `cast_${req.params.charId || 'actor'}_s${req.params.slot || 0}_${Date.now()}${safeExt}`);
  }
});
const uploadCharImg = multer({ storage: charImgStorage, limits: { fileSize: 30 * 1024 * 1024 } });

const locImgStorage = multer.diskStorage({
  destination: (req, file, cb) => {
    const accId = req.params.accountId || 'default';
    const dest = path.join(UPLOADS_DIR, accId, 'locations');
    fs.mkdirSync(dest, { recursive: true });
    cb(null, dest);
  },
  filename: (req, file, cb) => {
    const ext = path.extname(file.originalname || '.png').toLowerCase() || '.png';
    const safeExt = ['.png', '.jpg', '.jpeg', '.webp'].includes(ext) ? ext : '.png';
    cb(null, `loc_${req.params.locId || 'set'}_${Date.now()}${safeExt}`);
  }
});
const uploadLocImg = multer({ storage: locImgStorage, limits: { fileSize: 30 * 1024 * 1024 } });

const sceneImgStorage = multer.diskStorage({
  destination: (req, file, cb) => {
    const accId = req.params.accountId || 'default';
    const dest = path.join(UPLOADS_DIR, accId, 'scenes');
    fs.mkdirSync(dest, { recursive: true });
    cb(null, dest);
  },
  filename: (req, file, cb) => {
    const ext = path.extname(file.originalname || '.png').toLowerCase() || '.png';
    const safeExt = ['.png', '.jpg', '.jpeg', '.webp'].includes(ext) ? ext : '.png';
    cb(null, `scene_${req.params.rowIndex || 1}_s${req.params.slot || 0}_${Date.now()}${safeExt}`);
  }
});
const uploadSceneImg = multer({ storage: sceneImgStorage, limits: { fileSize: 30 * 1024 * 1024 } });

const bgmStorage = multer.diskStorage({
  destination: (req, file, cb) => {
    const accId = req.params.accountId || 'default';
    const dest = path.join(UPLOADS_DIR, accId, 'bgm');
    fs.mkdirSync(dest, { recursive: true });
    cb(null, dest);
  },
  filename: (req, file, cb) => {
    const ext = path.extname(file.originalname || '.mp3').toLowerCase() || '.mp3';
    const safeExt = ['.mp3', '.wav', '.m4a', '.aac', '.ogg', '.flac'].includes(ext) ? ext : '.mp3';
    const base = path
      .basename(file.originalname || 'bgm', ext)
      .replace(/[^a-zA-Z0-9_-]/g, '_')
      .slice(0, 40);
    cb(null, `bgm_${Date.now()}_${base}${safeExt}`);
  }
});
const uploadBgm = multer({ storage: bgmStorage, limits: { fileSize: 120 * 1024 * 1024 } });

/* ================= WEBSOCKET & CORE MANAGERS ================= */

function broadcast(event, payload) {
  const msg = JSON.stringify({ event, payload, ts: Date.now() });
  wss.clients.forEach((client) => {
    if (client.readyState === 1) {
      try {
        client.send(msg);
      } catch (_) {}
    }
  });
}

const licenseManager = new LicenseManager(APP_ROOT);
const accountManager = new AccountManager(APP_ROOT);
const cdpEngine = new CdpEngine({
  appRootDir: APP_ROOT,
  accountManager,
  skillManager: null,
  onEvent: (event, payload) => broadcast(event, payload)
});
const batchScheduler = new BatchScheduler({
  accountManager,
  cdpEngine,
  onEvent: (event, payload) => broadcast(event, payload)
});

async function autoConnectSavedAccounts() {
  if (!licenseManager.getLicenseStatus().valid) return;
  const connectedPorts = new Set();
  for (const acc of accountManager.getAllAccounts()) {
    if (connectedPorts.has(acc.port)) continue;
    try {
      const probe = await probeCdpPort(acc.port, 1200);
      if (probe.alive && !acc.proxy) {
        await cdpEngine.connectToRunningChrome(acc.id, probe.versionInfo);
        connectedPorts.add(acc.port);
        if (acc.settings?.backgroundMode !== false && acc.loginVerified) {
          hideChromeWindowByPort(acc.port);
        }
      } else if (acc.savedAccount || acc.loginVerified) {
        await cdpEngine.launchAndConnect(acc.id, { forceVisibleWindow: false });
        connectedPorts.add(acc.port);
      }
    } catch (_) {}
  }
}

function requireValidLicense(req, res, next) {
  const st = licenseManager.getLicenseStatus();
  if (!st.valid) {
    return res.status(403).json({
      ok: false,
      licenseRequired: true,
      error: st.reason || 'Vui lòng kích hoạt bản quyền để sử dụng tính năng sản xuất phim!'
    });
  }
  next();
}

/* ================= LICENSE ENDPOINTS ================= */

app.get('/api/license/status', (req, res) => {
  res.json({ ok: true, license: licenseManager.getLicenseStatus() });
});

app.post('/api/license/activate', (req, res) => {
  try {
    const { licenseKey } = req.body || {};
    const status = licenseManager.activateLicense(licenseKey);
    broadcast('license_updated', { license: status });
    autoConnectSavedAccounts().catch(() => {});
    res.json({
      ok: true,
      license: status,
      message: `Kích hoạt bản quyền thành công! Hạn dùng: ${status.expiresAtFormatted}`
    });
  } catch (err) {
    res.status(400).json({
      ok: false,
      error: err.message,
      license: licenseManager.getLicenseStatus()
    });
  }
});

app.post('/api/license/deactivate', (req, res) => {
  const status = licenseManager.deactivateLicense();
  broadcast('license_updated', { license: status });
  res.json({ ok: true, license: status });
});

app.post('/api/license/payment/create-order', async (req, res) => {
  try {
    const { planId } = req.body || {};
    const order = await licenseManager.createPaymentOrder(planId);
    res.json({ ok: true, order });
  } catch (err) {
    res.status(400).json({ ok: false, error: err.message });
  }
});

app.post('/api/license/payment/check', async (req, res) => {
  try {
    const { planId, orderCode } = req.body || {};
    const result = await licenseManager.checkPaymentAndAutoActivate({ planId, orderCode });
    if (result.paid && result.license) {
      broadcast('license_updated', { license: result.license });
      autoConnectSavedAccounts().catch(() => {});
    }
    res.json({ ok: true, ...result });
  } catch (err) {
    res.status(400).json({ ok: false, error: err.message });
  }
});

/* ================= AUTO-UPDATE OTA ENDPOINTS (GITHUB) ================= */

app.get('/api/update/check', async (req, res) => {
  try {
    const info = await checkForUpdate(APP_ROOT, APP_VERSION);
    res.json(info);
  } catch (err) {
    res.json({
      ok: false,
      configured: true,
      currentVersion: APP_VERSION,
      updateAvailable: false,
      error: err.message
    });
  }
});

let isApplyingUpdate = false;
app.post('/api/update/apply', async (req, res) => {
  if (isApplyingUpdate) {
    return res.status(409).json({ ok: false, error: 'Đang tiến hành cập nhật phiên bản mới, vui lòng đợi...' });
  }
  isApplyingUpdate = true;
  try {
    const result = await performSelfUpdate(APP_ROOT, APP_VERSION, (stage, message) => {
      broadcast('update_progress', { stage, message });
    });
    res.json(result);
  } catch (err) {
    isApplyingUpdate = false;
    res.status(400).json({ ok: false, error: err.message });
  }
});

/* ================= MAIN STATE & ACCOUNT / MOVIE PROJECT ENDPOINTS ================= */

app.get('/api/state', (req, res) => {
  try {
    const chromePath = findChromeExecutable();
    const accounts = accountManager.getAllAccounts();
    const requestedId = typeof req.query.accountId === 'string' ? req.query.accountId.trim() : '';
    const activeAccount =
      (requestedId && accountManager.getAccount(requestedId)) || accountManager.getActiveAccount();
    res.json({
      ok: true,
      app: 'MUSE_CINEMA_STUDIO',
      version: APP_VERSION,
      appRootDir: APP_ROOT,
      chromeInstalled: Boolean(chromePath),
      chromePath: chromePath || null,
      license: licenseManager.getLicenseStatus(),
      filmGenres: FILM_GENRES,
      voicePresets: CINEMA_VOICE_PRESETS,
      lightingPresets: CINEMA_LIGHTING_PRESETS,
      actingStylePresets: ACTING_STYLE_PRESETS,
      combatIntensityPresets: COMBAT_INTENSITY_PRESETS,
      characterSheetModes: CHARACTER_SHEET_MODES,
      transitionEffects: TRANSITION_EFFECTS,
      shotSizePresets: SHOT_SIZE_PRESETS.map(({ id, label }) => ({ id, label })),
      cameraMovePresets: CAMERA_MOVE_PRESETS.map(({ id, label }) => ({ id, label })),
      colorGradePresets: COLOR_GRADE_PRESETS.map(({ id, label }) => ({ id, label })),
      posterThemePresets: POSTER_THEME_PRESETS,
      posterSourceModes: POSTER_SOURCE_MODES,
      posterBadgePresets: POSTER_BADGE_PRESETS,
      accounts,
      activeAccount,
      batchStats: activeAccount ? batchScheduler.getJobState(activeAccount.id) : null
    });
  } catch (err) {
    res.status(500).json({ ok: false, error: err.message });
  }
});

app.post('/api/accounts', requireValidLicense, (req, res) => {
  try {
    const { name, proxy } = req.body || {};
    const created = accountManager.addAccount({ name, proxy });
    res.json({
      ok: true,
      accounts: accountManager.getAllAccounts(),
      activeAccount: created,
      batchStats: batchScheduler.getJobState(created.id)
    });
  } catch (err) {
    res.status(400).json({ ok: false, error: err.message });
  }
});

app.post('/api/accounts/:accountId/clone-episode', requireValidLicense, (req, res) => {
  try {
    const { name } = req.body || {};
    const cloned = accountManager.cloneProjectForNextEpisode(req.params.accountId, name);
    res.json({
      ok: true,
      accounts: accountManager.getAllAccounts(),
      activeAccount: cloned,
      batchStats: batchScheduler.getJobState(cloned.id)
    });
  } catch (err) {
    res.status(400).json({ ok: false, error: err.message });
  }
});

app.post('/api/accounts/select', (req, res) => {
  try {
    const { accountId } = req.body || {};
    const active = accountManager.setActiveAccount(accountId);
    res.json({
      ok: true,
      activeAccount: active,
      accounts: accountManager.getAllAccounts(),
      batchStats: batchScheduler.getJobState(active.id)
    });
  } catch (err) {
    res.status(400).json({ ok: false, error: err.message });
  }
});

app.put('/api/accounts/:accountId/name', (req, res) => {
  try {
    const updated = accountManager.updateAccountName(req.params.accountId, req.body?.name);
    res.json({
      ok: true,
      account: updated,
      accounts: accountManager.getAllAccounts()
    });
  } catch (err) {
    res.status(400).json({ ok: false, error: err.message });
  }
});

app.put('/api/accounts/:accountId/proxy', requireValidLicense, (req, res) => {
  try {
    const { account } = accountManager.updateAccountProxy(req.params.accountId, req.body?.proxy);
    res.json({ ok: true, account, accounts: accountManager.getAllAccounts() });
  } catch (err) {
    res.status(400).json({ ok: false, error: err.message });
  }
});

app.put('/api/accounts/:accountId/settings', (req, res) => {
  try {
    const updated = accountManager.updateAccountSettings(req.params.accountId, req.body || {});
    res.json({ ok: true, account: updated });
  } catch (err) {
    res.status(400).json({ ok: false, error: err.message });
  }
});

app.delete('/api/accounts/:accountId', async (req, res) => {
  try {
    const id = req.params.accountId;
    const wipeProfile = req.query.wipeProfile !== 'false';
    batchScheduler.abortAllForAccount(id);
    await cdpEngine.disconnectAndKillAccountChrome(id, { forceKillPort: true });
    const active = accountManager.deleteOrResetAccount(id, { wipeProfileDir: wipeProfile });
    res.json({
      ok: true,
      accounts: accountManager.getAllAccounts(),
      activeAccount: active,
      batchStats: batchScheduler.getJobState(active.id)
    });
  } catch (err) {
    res.status(400).json({ ok: false, error: err.message });
  }
});

app.post('/api/accounts/:accountId/reset-project', (req, res) => {
  try {
    const id = req.params.accountId;
    batchScheduler.abortAllForAccount(id);
    const prevEpoch = cdpEngine.projectResetEpochs.get(id) || 0;
    cdpEngine.projectResetEpochs.set(id, prevEpoch + 1);
    const updated = accountManager.resetProjectRows(id);
    res.json({
      ok: true,
      account: updated,
      batchStats: batchScheduler.getJobState(id)
    });
  } catch (err) {
    res.status(400).json({ ok: false, error: err.message });
  }
});

app.post('/api/accounts/:accountId/wipe-all', (req, res) => {
  try {
    const id = req.params.accountId;
    batchScheduler.abortAllForAccount(id);
    cdpEngine.stopFilmStoryboardGeneration(id);
    cdpEngine.stopCharacterPortraitGeneration(id);
    if (typeof cdpEngine.stopCharacterWeaponGeneration === 'function') {
      cdpEngine.stopCharacterWeaponGeneration(id);
    }
    cdpEngine.stopLocationPlateGeneration(id);

    const prevEpoch = cdpEngine.projectResetEpochs.get(id) || 0;
    cdpEngine.projectResetEpochs.set(id, prevEpoch + 1);

    const updated = accountManager.wipeEntireProjectData(id);
    res.json({
      ok: true,
      account: updated,
      accounts: accountManager.getAllAccounts(),
      batchStats: batchScheduler.getJobState(id)
    });
  } catch (err) {
    res.status(400).json({ ok: false, error: err.message });
  }
});

app.post('/api/accounts/:accountId/wipe-cast-locations', (req, res) => {
  try {
    const id = req.params.accountId;
    cdpEngine.stopCharacterPortraitGeneration(id);
    if (typeof cdpEngine.stopCharacterWeaponGeneration === 'function') {
      cdpEngine.stopCharacterWeaponGeneration(id);
    }
    cdpEngine.stopLocationPlateGeneration(id);

    const updated = accountManager.wipeCastAndLocationsOnly(id);
    res.json({
      ok: true,
      account: updated,
      accounts: accountManager.getAllAccounts()
    });
  } catch (err) {
    res.status(400).json({ ok: false, error: err.message });
  }
});

/* ================= IN-APP MUSE.AI LOGIN, LOGOUT & QUOTA ================= */

app.post('/api/accounts/:accountId/logout', requireValidLicense, async (req, res) => {
  try {
    const id = req.params.accountId;
    const acc = accountManager.getAccount(id);
    if (!acc) throw new Error('Không tìm thấy dự án phim.');

    batchScheduler.abortAllForAccount(id);
    await cdpEngine.logoutAndWipePort(acc.port);
    const updated = accountManager.logoutAccountOnly(id);

    let freshState = null;
    if (req.body?.openLoginNow !== false) {
      const inspected = await cdpEngine.inspectInAppLoginState(id, { resetToStart: true });
      freshState = inspected.state;
    }

    broadcast('account_status_changed', {
      accountId: id,
      connected: Boolean(updated.connected),
      loginVerified: false,
      account: accountManager.getAccount(id)
    });

    res.json({
      ok: true,
      state: freshState,
      account: accountManager.getAccount(id),
      accounts: accountManager.getAllAccounts(),
      activeAccount: accountManager.getActiveAccount()
    });
  } catch (err) {
    res.status(400).json({ ok: false, error: err.message });
  }
});

app.post('/api/accounts/:accountId/inapp-login/inspect', requireValidLicense, async (req, res) => {
  try {
    const result = await cdpEngine.inspectInAppLoginState(req.params.accountId, {
      resetToStart: Boolean(req.body?.resetToStart)
    });
    res.json({
      ok: true,
      ...result,
      accounts: accountManager.getAllAccounts()
    });
  } catch (err) {
    res.status(400).json({ ok: false, error: err.message });
  }
});

app.post('/api/accounts/:accountId/inapp-login/submit', requireValidLicense, async (req, res) => {
  try {
    const result = await cdpEngine.submitInAppLoginStep(req.params.accountId, req.body || {});
    res.json({
      ok: true,
      ...result,
      accounts: accountManager.getAllAccounts()
    });
  } catch (err) {
    res.status(400).json({ ok: false, error: err.message });
  }
});

app.post('/api/accounts/:accountId/refresh-quota', requireValidLicense, async (req, res) => {
  try {
    const updated = await cdpEngine.syncAccountQuotaAndProfile(req.params.accountId, { forceConnect: true });
    res.json({
      ok: true,
      account: updated,
      accounts: accountManager.getAllAccounts()
    });
  } catch (err) {
    res.status(400).json({ ok: false, error: err.message });
  }
});

app.put('/api/accounts/:accountId/custom-login-name', (req, res) => {
  try {
    const updated = accountManager.updateAccountCustomLoginName(req.params.accountId, req.body?.loginName || '');
    res.json({
      ok: true,
      account: updated,
      accounts: accountManager.getAllAccounts()
    });
  } catch (err) {
    res.status(400).json({ ok: false, error: err.message });
  }
});

/* ================= ĐOÀN DIỄN VIÊN (CAST VAULT) ================= */

app.post('/api/accounts/:accountId/characters', (req, res) => {
  try {
    const ch = accountManager.upsertFilmCharacter(req.params.accountId, req.body || {});
    res.json({
      ok: true,
      character: ch,
      account: accountManager.getAccount(req.params.accountId)
    });
  } catch (err) {
    res.status(400).json({ ok: false, error: err.message });
  }
});

app.delete('/api/accounts/:accountId/characters/:charId', (req, res) => {
  try {
    const acc = accountManager.deleteFilmCharacter(req.params.accountId, req.params.charId);
    res.json({ ok: true, account: acc });
  } catch (err) {
    res.status(400).json({ ok: false, error: err.message });
  }
});

app.post(
  '/api/accounts/:accountId/characters/:charId/image/:slot',
  uploadCharImg.single('image'),
  (req, res) => {
    try {
      if (!req.file) throw new Error('Vui lòng chọn file ảnh chân dung!');
      const { accountId, charId, slot } = req.params;
      const publicUrl = `/uploads/${accountId}/characters/${req.file.filename}`;
      const ch = accountManager.setFilmCharacterImage(accountId, charId, Number(slot) || 0, {
        fileName: req.file.originalname,
        savedName: req.file.filename,
        filePath: req.file.path,
        publicUrl,
        uploadedAt: new Date().toISOString()
      });
      res.json({
        ok: true,
        character: ch,
        account: accountManager.getAccount(accountId)
      });
    } catch (err) {
      res.status(400).json({ ok: false, error: err.message });
    }
  }
);

app.delete('/api/accounts/:accountId/characters/:charId/image/:slot', (req, res) => {
  try {
    const { accountId, charId, slot } = req.params;
    const ch = accountManager.setFilmCharacterImage(accountId, charId, Number(slot) || 0, null);
    res.json({
      ok: true,
      character: ch,
      account: accountManager.getAccount(accountId)
    });
  } catch (err) {
    res.status(400).json({ ok: false, error: err.message });
  }
});

app.post('/api/accounts/:accountId/characters/:charId/extract-dna', requireValidLicense, async (req, res) => {
  try {
    const ch = await cdpEngine.extractCharacterDnaWithAi({
      accountId: req.params.accountId,
      characterId: req.params.charId,
      targetSlot: Number(req.body?.targetSlot) || 0
    });
    res.json({
      ok: true,
      character: ch,
      account: accountManager.getAccount(req.params.accountId)
    });
  } catch (err) {
    res.status(400).json({ ok: false, error: err.message });
  }
});

app.post('/api/accounts/:accountId/characters/:charId/ai-portrait', requireValidLicense, async (req, res) => {
  try {
    const ch = await cdpEngine.generateCharacterPortraitWithAi({
      accountId: req.params.accountId,
      characterId: req.params.charId,
      sheetMode: req.body?.sheetMode || null
    });
    res.json({
      ok: true,
      character: ch,
      account: accountManager.getAccount(req.params.accountId)
    });
  } catch (err) {
    res.status(400).json({ ok: false, error: err.message });
  }
});

app.post('/api/accounts/:accountId/characters/:charId/ai-weapon', requireValidLicense, async (req, res) => {
  try {
    const ch = await cdpEngine.generateCharacterWeaponWithAi({
      accountId: req.params.accountId,
      characterId: req.params.charId
    });
    res.json({
      ok: true,
      character: ch,
      account: accountManager.getAccount(req.params.accountId)
    });
  } catch (err) {
    res.status(400).json({ ok: false, error: err.message });
  }
});

app.post('/api/accounts/:accountId/characters/stop-portrait', (req, res) => {
  const stopped = cdpEngine.stopCharacterPortraitGeneration(req.params.accountId);
  res.json({ ok: true, stopped });
});

app.post('/api/accounts/:accountId/characters/stop-weapon', (req, res) => {
  const stopped =
    typeof cdpEngine.stopCharacterWeaponGeneration === 'function'
      ? cdpEngine.stopCharacterWeaponGeneration(req.params.accountId)
      : false;
  res.json({ ok: true, stopped });
});

/* ================= KHO BỐI CẢNH CỐ ĐỊNH (LOCATION VAULT) ================= */

app.post('/api/accounts/:accountId/locations', (req, res) => {
  try {
    const loc = accountManager.upsertFilmLocation(req.params.accountId, req.body || {});
    res.json({
      ok: true,
      location: loc,
      account: accountManager.getAccount(req.params.accountId)
    });
  } catch (err) {
    res.status(400).json({ ok: false, error: err.message });
  }
});

app.delete('/api/accounts/:accountId/locations/:locId', (req, res) => {
  try {
    const acc = accountManager.deleteFilmLocation(req.params.accountId, req.params.locId);
    res.json({ ok: true, account: acc });
  } catch (err) {
    res.status(400).json({ ok: false, error: err.message });
  }
});

app.post(
  '/api/accounts/:accountId/locations/:locId/image',
  uploadLocImg.single('image'),
  (req, res) => {
    try {
      if (!req.file) throw new Error('Vui lòng chọn file ảnh bối cảnh!');
      const { accountId, locId } = req.params;
      const publicUrl = `/uploads/${accountId}/locations/${req.file.filename}`;
      const loc = accountManager.setFilmLocationImage(accountId, locId, {
        fileName: req.file.originalname,
        savedName: req.file.filename,
        filePath: req.file.path,
        publicUrl,
        uploadedAt: new Date().toISOString()
      });
      res.json({
        ok: true,
        location: loc,
        account: accountManager.getAccount(accountId)
      });
    } catch (err) {
      res.status(400).json({ ok: false, error: err.message });
    }
  }
);

app.delete('/api/accounts/:accountId/locations/:locId/image', (req, res) => {
  try {
    const { accountId, locId } = req.params;
    const loc = accountManager.setFilmLocationImage(accountId, locId, null);
    res.json({
      ok: true,
      location: loc,
      account: accountManager.getAccount(accountId)
    });
  } catch (err) {
    res.status(400).json({ ok: false, error: err.message });
  }
});

app.post('/api/accounts/:accountId/locations/:locId/ai-plate', requireValidLicense, async (req, res) => {
  try {
    const loc = await cdpEngine.generateLocationPlateWithAi({
      accountId: req.params.accountId,
      locationId: req.params.locId
    });
    res.json({
      ok: true,
      location: loc,
      account: accountManager.getAccount(req.params.accountId)
    });
  } catch (err) {
    res.status(400).json({ ok: false, error: err.message });
  }
});

app.post('/api/accounts/:accountId/locations/stop-plate', (req, res) => {
  const stopped = cdpEngine.stopLocationPlateGeneration(req.params.accountId);
  res.json({ ok: true, stopped });
});

/* ================= KỊCH BẢN & BẢNG PHÂN CẢNH (STORYBOARD & SCENES) ================= */

app.post('/api/accounts/:accountId/storyboard/local-split', (req, res) => {
  try {
    const accId = req.params.accountId;
    const acc = accountManager.getAccount(accId);
    if (!acc) throw new Error('Không tìm thấy bộ phim.');

    const storyText = String(req.body?.storyText ?? acc.settings?.filmConfig?.storyDraft ?? '').trim();
    if (!storyText) {
      throw new Error('Vui lòng nhập Kịch bản hoặc Cốt truyện trước khi bấm Tách Phân Cảnh!');
    }

    accountManager.updateAccountSettings(accId, {
      filmConfig: {
        ...(acc.settings?.filmConfig || {}),
        storyDraft: storyText
      }
    });

    const latest = accountManager.getAccount(accId);
    const fc = latest.settings?.filmConfig || {};
    const splitRes = splitScriptIntoScenesLocally({
      storyText,
      existingCharacters: latest.characters || [],
      existingLocations: latest.locations || [],
      targetMovieSeconds: fc.targetMovieSeconds || 180,
      sceneDurationSeconds: fc.sceneDurationSeconds || 10,
      audioMode: fc.audioMode || 'mixed',
      actingStyle: fc.actingStyle || 'subtle_realistic'
    });

    if (splitRes.extractedCharacters.length > 0) {
      accountManager.mergeExtractedCharacters(accId, splitRes.extractedCharacters);
    }
    if (splitRes.extractedLocations && splitRes.extractedLocations.length > 0) {
      accountManager.mergeExtractedLocations(accId, splitRes.extractedLocations);
    }
    const updatedAcc = accountManager.applyStoryboardScenesToRows(accId, splitRes.scenes, {
      append: Boolean(req.body?.append)
    });

    res.json({
      ok: true,
      sceneCount: splitRes.scenes.length,
      extractedCharacterCount: splitRes.extractedCharacters.length,
      extractedLocationCount: (splitRes.extractedLocations || []).length,
      account: updatedAcc
    });
  } catch (err) {
    res.status(400).json({ ok: false, error: err.message });
  }
});

app.post('/api/accounts/:accountId/storyboard/ai-generate', requireValidLicense, async (req, res) => {
  try {
    const accId = req.params.accountId;
    const acc = accountManager.getAccount(accId);
    if (!acc) throw new Error('Không tìm thấy bộ phim.');

    const storyText = String(req.body?.storyText ?? acc.settings?.filmConfig?.storyDraft ?? '').trim();
    if (!storyText) {
      throw new Error('Vui lòng nhập Ý tưởng hoặc Cốt truyện trước khi bấm AI Đạo Diễn Triển Khai!');
    }

    accountManager.updateAccountSettings(accId, {
      filmConfig: {
        ...(acc.settings?.filmConfig || {}),
        storyDraft: storyText
      }
    });

    const updatedAcc = await cdpEngine.generateFilmStoryboardWithAi({
      accountId: accId,
      storyText,
      append: Boolean(req.body?.append)
    });

    res.json({
      ok: true,
      account: updatedAcc
    });
  } catch (err) {
    res.status(400).json({ ok: false, error: err.message });
  }
});

app.post('/api/accounts/:accountId/storyboard/stop', (req, res) => {
  const stopped = cdpEngine.stopFilmStoryboardGeneration(req.params.accountId);
  res.json({ ok: true, stopped });
});

app.post('/api/accounts/:accountId/scenes/add', (req, res) => {
  try {
    const row = accountManager.addScene(req.params.accountId, req.body || {});
    res.json({
      ok: true,
      row,
      account: accountManager.getAccount(req.params.accountId)
    });
  } catch (err) {
    res.status(400).json({ ok: false, error: err.message });
  }
});

app.delete('/api/accounts/:accountId/scenes/:rowIndex', (req, res) => {
  try {
    const acc = accountManager.deleteScene(req.params.accountId, Number(req.params.rowIndex));
    res.json({ ok: true, account: acc });
  } catch (err) {
    res.status(400).json({ ok: false, error: err.message });
  }
});

app.put('/api/accounts/:accountId/rows/:rowIndex', (req, res) => {
  try {
    const allowed = {};
    const body = req.body || {};
    if (body.sceneTitle !== undefined) allowed.sceneTitle = String(body.sceneTitle || '').slice(0, 100);
    if (body.prompt !== undefined) allowed.prompt = String(body.prompt || '');
    if (body.dialogue !== undefined) allowed.dialogue = String(body.dialogue || '');
    if (body.sceneCharacterIds !== undefined) allowed.sceneCharacterIds = body.sceneCharacterIds;
    if (body.sceneLocationId !== undefined) allowed.sceneLocationId = String(body.sceneLocationId || '');
    if (body.continueFromPrevScene !== undefined) allowed.continueFromPrevScene = Boolean(body.continueFromPrevScene);
    if (body.includeInExport !== undefined) allowed.includeInExport = Boolean(body.includeInExport);
    if (body.trimStartSec !== undefined) allowed.trimStartSec = Number(body.trimStartSec) || 0;
    if (body.trimEndSec !== undefined) allowed.trimEndSec = Number(body.trimEndSec) || 0;
    if (body.weaponMode !== undefined) allowed.weaponMode = String(body.weaponMode || 'auto');
    if (body.shotSize !== undefined) allowed.shotSize = String(body.shotSize || 'auto');
    if (body.cameraMove !== undefined) allowed.cameraMove = String(body.cameraMove || 'auto');

    const row = accountManager.updateRow(req.params.accountId, Number(req.params.rowIndex), allowed);
    res.json({ ok: true, row });
  } catch (err) {
    res.status(400).json({ ok: false, error: err.message });
  }
});

app.post(
  '/api/accounts/:accountId/rows/:rowIndex/image/:slot',
  uploadSceneImg.single('image'),
  (req, res) => {
    try {
      if (!req.file) throw new Error('Vui lòng chọn ảnh bối cảnh/đạo cụ!');
      const { accountId, rowIndex, slot } = req.params;
      const publicUrl = `/uploads/${accountId}/scenes/${req.file.filename}`;
      const row = accountManager.setRowReferenceImage(accountId, Number(rowIndex), Number(slot) || 0, {
        fileName: req.file.originalname,
        savedName: req.file.filename,
        filePath: req.file.path,
        publicUrl,
        uploadedAt: new Date().toISOString()
      });
      res.json({ ok: true, row });
    } catch (err) {
      res.status(400).json({ ok: false, error: err.message });
    }
  }
);

app.delete('/api/accounts/:accountId/rows/:rowIndex/image/:slot', (req, res) => {
  try {
    const { accountId, rowIndex, slot } = req.params;
    const row = accountManager.setRowReferenceImage(accountId, Number(rowIndex), Number(slot) || 0, null);
    res.json({ ok: true, row });
  } catch (err) {
    res.status(400).json({ ok: false, error: err.message });
  }
});

/* ================= QUAY PHIM ĐƠN LẺ & ĐA LUỒNG ================= */

app.post('/api/accounts/:accountId/rows/:rowIndex/run', requireValidLicense, async (req, res) => {
  try {
    const { accountId, rowIndex } = req.params;
    batchScheduler
      .runSingleRow(accountId, Number(rowIndex), false)
      .catch((err) => {
        broadcast('row_error', { accountId, rowIndex: Number(rowIndex), error: err.message });
      });
    res.json({ ok: true, started: true });
  } catch (err) {
    res.status(400).json({ ok: false, error: err.message });
  }
});

app.post('/api/accounts/:accountId/rows/:rowIndex/regenerate', requireValidLicense, async (req, res) => {
  try {
    const { accountId, rowIndex } = req.params;
    batchScheduler
      .runSingleRow(accountId, Number(rowIndex), true)
      .catch((err) => {
        broadcast('row_error', { accountId, rowIndex: Number(rowIndex), error: err.message });
      });
    res.json({ ok: true, started: true });
  } catch (err) {
    res.status(400).json({ ok: false, error: err.message });
  }
});

app.post('/api/accounts/:accountId/batch/start', requireValidLicense, async (req, res) => {
  try {
    const accId = req.params.accountId;
    const body = req.body || {};
    const acc = accountManager.getAccount(accId);
    if (acc && (body.continuityMode || body.concurrency)) {
      const nextFilmCfg = { ...(acc.settings?.filmConfig || {}) };
      if (['parallel_fast', 'smart_chain', 'sequential_chain'].includes(body.continuityMode)) {
        nextFilmCfg.continuityMode = body.continuityMode;
      }
      if (Number(body.concurrency) >= 1) {
        nextFilmCfg.concurrency = Math.max(1, Math.min(16, Math.round(Number(body.concurrency))));
      }
      accountManager.updateAccountSettings(accId, {
        filmConfig: nextFilmCfg,
        concurrency: nextFilmCfg.concurrency
      });
    }
    const stats = await batchScheduler.runAllInBatchesOfSix(accId, {
      forceAll: Boolean(body.forceAll),
      continuityMode: body.continuityMode || null,
      concurrency: body.concurrency ? Number(body.concurrency) : null
    });
    res.json({ ok: true, stats, account: accountManager.getAccount(accId) });
  } catch (err) {
    res.status(400).json({ ok: false, error: err.message });
  }
});

app.post('/api/accounts/:accountId/batch/stop', (req, res) => {
  const stopped = batchScheduler.stopBatch(req.params.accountId);
  res.json({ ok: true, stopped });
});

/* ================= DỰNG HẬU KỲ & XUẤT BỘ PHIM HOÀN CHỈNH ================= */

app.post('/api/accounts/:accountId/bgm', uploadBgm.single('bgm'), (req, res) => {
  try {
    if (!req.file) throw new Error('Vui lòng chọn tệp âm thanh nhạc nền (.mp3, .wav, .m4a)!');
    const { accountId } = req.params;
    const publicUrl = `/uploads/${accountId}/bgm/${req.file.filename}`;
    const acc = accountManager.setProjectBgm(accountId, {
      fileName: req.file.originalname,
      savedName: req.file.filename,
      filePath: req.file.path,
      publicUrl,
      uploadedAt: new Date().toISOString()
    });
    res.json({ ok: true, account: acc });
  } catch (err) {
    res.status(400).json({ ok: false, error: err.message });
  }
});

app.delete('/api/accounts/:accountId/bgm', (req, res) => {
  try {
    const acc = accountManager.setProjectBgm(req.params.accountId, null);
    res.json({ ok: true, account: acc });
  } catch (err) {
    res.status(400).json({ ok: false, error: err.message });
  }
});

app.post('/api/accounts/:accountId/export-movie', requireValidLicense, async (req, res) => {
  try {
    const accountId = req.params.accountId;
    const body = req.body || {};
    broadcast('export_progress', { accountId, running: true, message: '🎬 Đang khởi tạo bàn dựng hậu kỳ...' });

    const acc = accountManager.getAccount(accountId);
    const result = await renderFullCinemaMaster({
      appRootDir: APP_ROOT,
      accountManager,
      accountId,
      sceneIndices: Array.isArray(body.sceneIndices) ? body.sceneIndices : null,
      movieTitle: body.movieTitle || '',
      aspectMode: body.aspectMode || 'auto',
      transitionEffect: body.transitionEffect || acc?.settings?.transitionEffect || 'director_smart',
      bgmVolume: body.bgmVolume,
      autoDuckBgm: body.autoDuckBgm !== undefined ? Boolean(body.autoDuckBgm) : acc?.settings?.autoDuckBgm !== false,
      burnSubtitles: Boolean(body.burnSubtitles),
      colorGrade: body.colorGrade || acc?.settings?.colorGrade || 'auto_match',
      onProgress: (message) => {
        broadcast('export_progress', { accountId, running: true, message });
      }
    });

    broadcast('export_progress', {
      accountId,
      running: false,
      completed: true,
      message: `🏆 Đã xuất phim hoàn chỉnh (${result.duration}s)!`
    });

    res.json({
      ok: true,
      exportResult: result,
      account: accountManager.getAccount(accountId)
    });
  } catch (err) {
    broadcast('export_progress', {
      accountId: req.params.accountId,
      running: false,
      error: err.message
    });
    res.status(400).json({ ok: false, error: err.message });
  }
});

/* ================= v2.0: XƯỞNG POSTER TRUYỀN HÌNH & TRAILER TỰ ĐỘNG ================= */

let promoRenderingAccounts = new Set();
app.post('/api/accounts/:accountId/export-promo', requireValidLicense, async (req, res) => {
  const accountId = req.params.accountId;
  if (promoRenderingAccounts.has(accountId)) {
    return res.status(409).json({ ok: false, error: 'Đang thiết kế Ảnh bìa / Trailer cho bộ phim này, vui lòng đợi...' });
  }
  promoRenderingAccounts.add(accountId);
  try {
    const body = req.body || {};
    const acc = accountManager.getAccount(accountId);
    const makeThumbnail = body.makeThumbnail !== false;
    const makeTrailer = body.makeTrailer !== false;
    broadcast('promo_progress', {
      accountId,
      running: true,
      message: makeTrailer ? '🎬 Đang thiết kế Bộ 3 Poster Truyền Hình & dựng Trailer...' : '🎨 Đang thiết kế Bộ 3 Poster Ảnh Bìa Phim Truyền Hình...'
    });
    const result = await renderPromoPack({
      appRootDir: APP_ROOT,
      accountManager,
      cdpEngine,
      accountId,
      movieTitle: body.movieTitle || acc?.settings?.exportMovieTitle || acc?.name || '',
      tagline: body.tagline || '',
      badgeText: body.badgeText || 'TRAILER CHÍNH THỨC',
      posterTheme: body.posterTheme || 'auto',
      posterSourceMode: body.posterSourceMode || 'smart_pack',
      trailerSeconds: Number(body.trailerSeconds) || 30,
      colorGrade: body.colorGrade || acc?.settings?.colorGrade || 'auto_match',
      makeThumbnail,
      makeTrailer,
      onProgress: (message) => broadcast('promo_progress', { accountId, running: true, message })
    });
    broadcast('promo_progress', {
      accountId,
      running: false,
      completed: true,
      message: makeTrailer ? '✅ Đã hoàn tất Bộ 3 Poster Ảnh Bìa & Trailer!' : '✅ Đã thiết kế xong Bộ 3 Poster Ảnh Bìa Truyền Hình!'
    });
    res.json({ ok: true, promo: result, account: accountManager.getAccount(accountId) });
  } catch (err) {
    broadcast('promo_progress', { accountId, running: false, error: err.message });
    res.status(400).json({ ok: false, error: err.message });
  } finally {
    promoRenderingAccounts.delete(accountId);
  }
});

/* ================= v1.8: NHIỀU BẢN QUAY & KIỂM TRA CHẤT LƯỢNG ================= */

app.post('/api/accounts/:accountId/rows/:rowIndex/takes/:takeId/select', (req, res) => {
  try {
    const row = accountManager.selectSceneTake(req.params.accountId, Number(req.params.rowIndex), req.params.takeId);
    broadcast('row_updated', { accountId: req.params.accountId, rowIndex: Number(req.params.rowIndex), row });
    res.json({ ok: true, row });
  } catch (err) {
    res.status(400).json({ ok: false, error: err.message });
  }
});

app.delete('/api/accounts/:accountId/rows/:rowIndex/takes/:takeId', (req, res) => {
  try {
    const row = accountManager.deleteSceneTake(req.params.accountId, Number(req.params.rowIndex), req.params.takeId);
    broadcast('row_updated', { accountId: req.params.accountId, rowIndex: Number(req.params.rowIndex), row });
    res.json({ ok: true, row });
  } catch (err) {
    res.status(400).json({ ok: false, error: err.message });
  }
});

app.post('/api/accounts/:accountId/rows/:rowIndex/qc', async (req, res) => {
  try {
    const qc = await batchScheduler.runQcForRow(req.params.accountId, Number(req.params.rowIndex));
    if (!qc) throw new Error('Cảnh này chưa có video để kiểm tra.');
    const acc = accountManager.getAccount(req.params.accountId);
    const row = (acc?.rows || []).find((r) => Number(r.index) === Number(req.params.rowIndex));
    res.json({ ok: true, qc, row });
  } catch (err) {
    res.status(400).json({ ok: false, error: err.message });
  }
});

app.get('/api/download-file', (req, res) => {
  try {
    const rawRel = String(req.query.url || '').split('?')[0].replace(/^\/+/, '');
    if (!rawRel.startsWith('outputs/')) {
      return res.status(400).send('Đường dẫn tệp tải về không hợp lệ.');
    }
    const segs = rawRel
      .slice('outputs/'.length)
      .split('/')
      .filter(Boolean)
      .map((s) => decodeURIComponent(s));
    const fullPath = path.resolve(OUTPUT_VIDEOS_DIR, ...segs);
    if (!fullPath.toLowerCase().startsWith(path.resolve(OUTPUT_VIDEOS_DIR).toLowerCase()) || !fs.existsSync(fullPath)) {
      return res.status(404).send('Không tìm thấy tệp trên ổ cứng.');
    }
    return res.download(fullPath, path.basename(fullPath));
  } catch (err) {
    return res.status(500).send(err.message);
  }
});

function openPathInWindowsExplorer(targetPath, selectFile = false) {
  if (!targetPath || !fs.existsSync(targetPath)) return false;
  if (fs.existsSync(OPEN_FOLDER_HELPER_EXE)) {
    try {
      const args = selectFile ? ['--select', targetPath] : [targetPath];
      execFileSync(OPEN_FOLDER_HELPER_EXE, args, { windowsHide: true, timeout: 5000 });
      return true;
    } catch (_) {}
  }
  try {
    const expArgs = selectFile ? [`/select,${targetPath}`] : [targetPath];
    const child = spawn('explorer.exe', expArgs, { detached: true, stdio: 'ignore' });
    child.unref();
    return true;
  } catch (_) {
    return false;
  }
}

app.post('/api/open-output-folder', (req, res) => {
  try {
    const accountId = req.body?.accountId;
    const targetDir = accountId
      ? accountManager.ensureAccountOutputDir(accountId, { create: true })
      : OUTPUT_VIDEOS_DIR;
    if (!fs.existsSync(targetDir)) fs.mkdirSync(targetDir, { recursive: true });
    openPathInWindowsExplorer(targetDir, false);
    res.json({ ok: true, folderPath: targetDir });
  } catch (err) {
    res.status(400).json({ ok: false, error: err.message });
  }
});

app.post('/api/open-output-file', (req, res) => {
  try {
    const { accountId, rowIndex, masterExport } = req.body || {};
    const acc = accountManager.getAccount(accountId);
    if (masterExport && acc?.settings?.lastMasterExport?.filePath && fs.existsSync(acc.settings.lastMasterExport.filePath)) {
      openPathInWindowsExplorer(acc.settings.lastMasterExport.filePath, true);
      return res.json({ ok: true, filePath: acc.settings.lastMasterExport.filePath });
    }
    if (acc && rowIndex) {
      const row = (acc.rows || []).find((r) => Number(r.index) === Number(rowIndex));
      const diskPath = resolveSceneVideoDiskPath(APP_ROOT, row);
      if (diskPath && fs.existsSync(diskPath)) {
        openPathInWindowsExplorer(diskPath, true);
        return res.json({ ok: true, filePath: diskPath });
      }
    }
    const dir = accountId ? accountManager.ensureAccountOutputDir(accountId, { create: true }) : OUTPUT_VIDEOS_DIR;
    openPathInWindowsExplorer(dir, false);
    return res.json({ ok: true, folderPath: dir });
  } catch (err) {
    res.status(400).json({ ok: false, error: err.message });
  }
});

server.listen(PORT, '127.0.0.1', () => {
  console.log(`\n=============================================================`);
  console.log(`🎬 MUSE CINEMA STUDIO v${APP_VERSION} — ĐÃ KHỞI ĐỘNG THÀNH CÔNG!`);
  console.log(`🌐 Địa chỉ Studio: http://127.0.0.1:${PORT}`);
  console.log(`=============================================================\n`);
  setTimeout(() => {
    autoConnectSavedAccounts().catch(() => {});
  }, 1000);
});
