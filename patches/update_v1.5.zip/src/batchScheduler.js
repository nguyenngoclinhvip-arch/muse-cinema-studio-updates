const { resolveSceneCharacters } = require('./cinemaDirector');

class BatchScheduler {
  constructor({ accountManager, cdpEngine, onEvent }) {
    this.accountManager = accountManager;
    this.cdpEngine = cdpEngine;
    this.onEvent = typeof onEvent === 'function' ? onEvent : () => {};
    this.jobs = new Map();
    this.singleRowControllers = new Map();
  }

  emit(event, payload) {
    try {
      this.onEvent(event, payload);
    } catch (_) {}
  }

  getJobState(accountId) {
    const job = this.jobs.get(accountId);
    const acc = this.accountManager.getAccount(accountId);
    const defaultConcurrency = Math.max(
      1,
      Math.min(16, Number(acc?.settings?.filmConfig?.concurrency || acc?.settings?.concurrency) || 4)
    );
    if (!job) {
      return {
        running: false,
        batchSize: defaultConcurrency,
        currentBatchIndex: 0,
        totalBatches: 0,
        activeThreads: 0,
        completedInCurrentBatch: 0,
        currentBatchTargetCount: 0,
        totalCompleted: 0,
        totalFailed: 0,
        totalTargetRows: 0,
        currentBatchRows: []
      };
    }
    return job.stats;
  }

  async runSingleRow(accountId, rowIndex, isRegenerate = false) {
    const account = this.accountManager.getAccount(accountId);
    if (!account) throw new Error('Không tìm thấy bộ phim.');

    if (isRegenerate) {
      this.accountManager.updateRow(accountId, rowIndex, {
        status: 'queued',
        statusMessage: 'Đang chuẩn bị quay lại phân cảnh...',
        videoUrl: null,
        videoFilePath: null,
        remoteVideoUrl: null,
        error: null
      });
    }

    const rowKey = `${accountId}::${Number(rowIndex)}`;
    const prevCtrl = this.singleRowControllers.get(rowKey);
    if (prevCtrl) {
      try {
        prevCtrl.abort();
      } catch (_) {}
    }
    const ctrl = new AbortController();
    this.singleRowControllers.set(rowKey, ctrl);

    try {
      return await this.cdpEngine.executeRow({
        accountId,
        rowIndex: Number(rowIndex),
        abortSignal: ctrl.signal
      });
    } finally {
      if (this.singleRowControllers.get(rowKey) === ctrl) {
        this.singleRowControllers.delete(rowKey);
      }
    }
  }

  async runAllInBatchesOfSix(accountId, { forceAll = false } = {}) {
    const existingJob = this.jobs.get(accountId);
    if (existingJob && existingJob.running) {
      throw new Error('Đoàn làm phim đang quay hàng loạt. Vui lòng đợi hoặc bấm Dừng Quay!');
    }

    const account = this.accountManager.getAccount(accountId);
    if (!account) {
      throw new Error('Không tìm thấy bộ phim.');
    }

    const filmCfg = account.settings?.filmConfig || {};
    const isSequentialChain = filmCfg.continuityMode === 'sequential_chain';
    const configuredConcurrency = Math.max(
      1,
      Math.min(16, Number(filmCfg.concurrency || account.settings?.concurrency) || 4)
    );
    const batchSize = isSequentialChain ? 1 : configuredConcurrency;

    const allCharacters = Array.isArray(account.characters) ? account.characters : [];
    const allHasData = (account.rows || []).filter((r) => {
      const hasPrompt = Boolean(r.prompt && r.prompt.trim().length > 0);
      const hasDialogue = Boolean(r.dialogue && r.dialogue.trim().length > 0);
      const hasImages = Array.isArray(r.referenceImages) && r.referenceImages.some((img) => img && img.filePath);
      const hasSceneCast = resolveSceneCharacters(r, allCharacters).length > 0;
      return hasPrompt || hasDialogue || hasImages || hasSceneCast;
    });

    let eligibleRows;
    if (forceAll) {
      eligibleRows = allHasData;
    } else {
      const nonErrorPending = allHasData.filter((r) => r.status !== 'completed' && r.status !== 'error');
      eligibleRows =
        nonErrorPending.length > 0
          ? nonErrorPending
          : allHasData.filter((r) => r.status !== 'completed');
    }

    if (eligibleRows.length === 0) {
      throw new Error(
        'Chưa có phân cảnh nào có nội dung (Cảnh quay / Lời thoại) để bấm máy, hoặc toàn bộ các cảnh đã quay xong!'
      );
    }

    // Nếu một cảnh bật "🔗 Nối cảnh trước", tự động tách ranh giới lô để cảnh trước quay xong mới lấy khung cuối cho cảnh sau
    const batches = [];
    let currentBucket = [];
    for (const row of eligibleRows) {
      if (isSequentialChain) {
        batches.push([row]);
        continue;
      }
      const prevSceneInCurrentBucket =
        row.continueFromPrevScene &&
        currentBucket.some((prevR) => Number(prevR.index) === Number(row.index) - 1);

      if (currentBucket.length >= batchSize || prevSceneInCurrentBucket) {
        if (currentBucket.length > 0) batches.push(currentBucket);
        currentBucket = [row];
      } else {
        currentBucket.push(row);
      }
    }
    if (currentBucket.length > 0) {
      batches.push(currentBucket);
    }

    batches.forEach((batchRows, bIdx) => {
      batchRows.forEach((r) => {
        this.accountManager.updateRow(accountId, r.index, {
          status: 'queued',
          statusMessage: isSequentialChain
            ? `Chờ bấm máy nối mạch (${bIdx + 1}/${batches.length})...`
            : `Chờ lượt quay ${bIdx + 1}/${batches.length}...`,
          error: null
        });
      });
    });

    const abortController = new AbortController();
    const stats = {
      running: true,
      batchSize,
      continuityMode: isSequentialChain ? 'sequential_chain' : 'parallel_fast',
      currentBatchIndex: 0,
      totalBatches: batches.length,
      activeThreads: 0,
      completedInCurrentBatch: 0,
      currentBatchTargetCount: 0,
      totalCompleted: 0,
      totalFailed: 0,
      totalTargetRows: eligibleRows.length,
      currentBatchRows: []
    };

    this.jobs.set(accountId, {
      running: true,
      abortController,
      stats
    });

    this.emit('batch_progress', { accountId, stats });

    (async () => {
      try {
        for (let bIndex = 0; bIndex < batches.length; bIndex++) {
          if (abortController.signal.aborted) break;

          const currentBatch = batches[bIndex];
          stats.currentBatchIndex = bIndex + 1;
          stats.completedInCurrentBatch = 0;
          stats.currentBatchTargetCount = currentBatch.length;
          stats.activeThreads = currentBatch.length;
          stats.currentBatchRows = currentBatch.map((r) => r.index);

          this.emit('batch_progress', { accountId, stats });

          const workerPromises = currentBatch.map(async (rowItem) => {
            try {
              await this.cdpEngine.executeRow({
                accountId,
                rowIndex: rowItem.index,
                abortSignal: abortController.signal
              });
              stats.totalCompleted += 1;
            } catch (err) {
              if (abortController.signal.aborted) return;
              stats.totalFailed += 1;
              const errMsg = err?.message || 'Không tạo được phân cảnh';
              const updatedRow = this.accountManager.updateRow(accountId, rowItem.index, {
                status: 'error',
                statusMessage: `Lỗi (Đã bỏ qua): ${errMsg}`,
                error: errMsg
              });
              this.emit('row_updated', {
                accountId,
                rowIndex: rowItem.index,
                row: updatedRow
              });
              this.emit('row_error_skipped', {
                accountId,
                rowIndex: rowItem.index,
                error: errMsg
              });
            } finally {
              stats.completedInCurrentBatch += 1;
              stats.activeThreads = Math.max(0, stats.activeThreads - 1);
              this.emit('batch_progress', { accountId, stats });
            }
          });

          await Promise.allSettled(workerPromises);
        }
      } finally {
        stats.running = false;
        stats.activeThreads = 0;
        this.jobs.set(accountId, {
          running: false,
          abortController: null,
          stats
        });
        this.emit('batch_progress', { accountId, stats });
      }
    })();

    return stats;
  }

  stopBatch(accountId) {
    const job = this.jobs.get(accountId);
    if (job && job.running && job.abortController) {
      job.abortController.abort();
      job.running = false;
      job.stats.running = false;
      this.emit('batch_progress', { accountId, stats: job.stats });
      return true;
    }
    return false;
  }

  abortAllForAccount(accountId) {
    this.stopBatch(accountId);
    const prefix = `${accountId}::`;
    for (const [k, ctrl] of Array.from(this.singleRowControllers.entries())) {
      if (k.startsWith(prefix)) {
        try {
          ctrl.abort();
        } catch (_) {}
        this.singleRowControllers.delete(k);
      }
    }
  }
}

module.exports = {
  BatchScheduler
};
