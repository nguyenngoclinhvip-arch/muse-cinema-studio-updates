/**
 * MUSE CINEMA STUDIO v1.8 — Tự động tạo Ảnh Bìa (Thumbnail) & Trailer giới thiệu phim
 * - Ảnh bìa: quét khung hình đẹp nhất trong các cảnh đã quay (sắc nét, đủ sáng, có nhân vật) rồi in tên phim.
 * - Trailer: chọn các khoảnh khắc nổi bật trải đều câu chuyện (hành động, cảm xúc, cảnh hoành tráng),
 *   cắt nhịp nhanh, chuyển cảnh dip-to-black, lồng nhạc nền và kết thúc bằng khung tên phim.
 */
const fs = require('fs');
const path = require('path');
const {
  getFfmpegExecutable,
  runFfmpeg,
  probeMediaFile,
  resolveSceneVideoDiskPath,
  mergeNormalizedSegmentsWithTransition,
  measureClipColorStats,
  computeColorGradeFiltersForClips,
  COLOR_GRADE_PRESETS
} = require('./videoEditor');

const FONT_CANDIDATES = [
  'C:\\Windows\\Fonts\\arialbd.ttf',
  'C:\\Windows\\Fonts\\segoeuib.ttf',
  'C:\\Windows\\Fonts\\tahomabd.ttf',
  'C:\\Windows\\Fonts\\arial.ttf'
];

const ACTION_WORDS = [
  'chiến đấu', 'giao chiến', 'chém', 'lao tới', 'lao vào', 'bay vút', 'phi thân', 'bùng nổ', 'nổ tung', 'sấm sét',
  'rượt', 'đuổi theo', 'gào', 'hét', 'xuất chiêu', 'kiếm khí', 'rồng', 'ngọn lửa', 'bão', 'truy đuổi', 'tấn công',
  'quyết chiến', 'phép thuật', 'pháp lực', 'nhảy', 'bỏ chạy', 'battle', 'fight', 'explosion', 'chase'
];
const EMOTION_WORDS = [
  'khóc', 'nước mắt', 'ôm chầm', 'tuyệt vọng', 'xúc động', 'sững sờ', 'thì thầm', 'giận dữ', 'hoảng sợ', 'mỉm cười',
  'nghẹn ngào', 'bàng hoàng'
];
const SPECTACLE_WORDS = [
  'toàn cảnh', 'bầu trời', 'hoàng hôn', 'bình minh', 'cung điện', 'kinh thành', 'đỉnh núi', 'thần long', 'chiến trường',
  'đoàn quân', 'thành trì', 'vũ trụ', 'tầng mây', 'thung lũng'
];

function countHits(text, words) {
  const low = String(text || '').toLowerCase();
  return words.reduce((n, w) => (low.includes(w) ? n + 1 : n), 0);
}

function resolvePromoSize(acc, purpose = 'video') {
  const fc = acc.settings?.filmConfig || {};
  const aspect = fc.aspectRatio || '16:9';
  const isFullHd = (fc.resolution || acc.settings?.resolution) === '1080p';
  if (purpose === 'thumbnail') {
    if (aspect === '9:16') return { w: 1080, h: 1920 };
    if (aspect === '1:1') return { w: 1080, h: 1080 };
    return { w: 1280, h: 720 };
  }
  if (aspect === '9:16') return isFullHd ? { w: 1080, h: 1920 } : { w: 720, h: 1280 };
  if (aspect === '1:1') return { w: 1080, h: 1080 };
  if (aspect === '21:9') return isFullHd ? { w: 1920, h: 816 } : { w: 1280, h: 544 };
  return isFullHd ? { w: 1920, h: 1080 } : { w: 1280, h: 720 };
}

function prepareFont(tempDir) {
  for (const f of FONT_CANDIDATES) {
    try {
      if (fs.existsSync(f)) {
        fs.copyFileSync(f, path.join(tempDir, 'font.ttf'));
        return 'font.ttf';
      }
    } catch (_) {}
  }
  return null;
}

function wrapTitleLines(title, maxChars) {
  const words = String(title || '').trim().split(/\s+/).filter(Boolean);
  if (words.join(' ').length <= maxChars) return [words.join(' ')];
  const lines = [];
  let cur = '';
  for (const w of words) {
    if ((cur ? `${cur} ${w}` : w).length > maxChars && cur) {
      lines.push(cur);
      cur = w;
    } else {
      cur = cur ? `${cur} ${w}` : w;
    }
  }
  if (cur) lines.push(cur);
  if (lines.length > 3) {
    const head = lines.slice(0, 2);
    head.push(lines.slice(2).join(' '));
    return head;
  }
  return lines;
}

/** Dựng chuỗi drawtext (tên phim + dòng phụ) đặt ở phần dưới khung hình. Trả về '' nếu không có font. */
function buildTitleDrawtext({ fontFile, tempDir, title, tagline, w, h, prefix = 'thumb', alphaExpr = '' }) {
  if (!fontFile || !title) return '';
  const isPortrait = h > w;
  const upper = String(title).trim().toLocaleUpperCase('vi-VN');
  const lines = wrapTitleLines(upper, isPortrait ? 14 : 24);
  const longest = Math.max(...lines.map((l) => l.length), 1);
  const fsTitle = Math.round(Math.min(h * (isPortrait ? 0.07 : 0.12), (w * 0.9) / (longest * 0.6)));
  const lineGap = Math.round(fsTitle * 0.18);
  const fsTag = Math.max(18, Math.round(fsTitle * 0.42));
  const titleBlockH = lines.length * fsTitle + (lines.length - 1) * lineGap;
  const tagH = tagline ? fsTag + Math.round(fsTag * 0.6) : 0;
  const bottomMargin = Math.round(h * (isPortrait ? 0.1 : 0.08));
  const titleY = Math.max(Math.round(h * 0.45), h - bottomMargin - tagH - titleBlockH);

  const titleFile = `${prefix}_title.txt`;
  fs.writeFileSync(path.join(tempDir, titleFile), lines.join('\n'), 'utf8');
  const alpha = alphaExpr ? `:alpha='${alphaExpr}'` : '';
  const parts = [
    `drawtext=fontfile=${fontFile}:textfile=${titleFile}:expansion=none:fontcolor=white:fontsize=${fsTitle}:line_spacing=${lineGap}:borderw=${Math.max(
      2,
      Math.round(fsTitle * 0.05)
    )}:bordercolor=black@0.85:shadowcolor=black@0.7:shadowx=3:shadowy=4:x=(w-text_w)/2:y=${titleY}${alpha}`
  ];
  if (tagline) {
    const tagFile = `${prefix}_tag.txt`;
    fs.writeFileSync(path.join(tempDir, tagFile), String(tagline).trim(), 'utf8');
    parts.push(
      `drawtext=fontfile=${fontFile}:textfile=${tagFile}:expansion=none:fontcolor=0xFBBF24:fontsize=${fsTag}:borderw=2:bordercolor=black@0.8:x=(w-text_w)/2:y=${
        titleY + titleBlockH + Math.round(fsTag * 0.6)
      }${alpha}`
    );
  }
  return parts.join(',');
}

function lookFilterOf(colorGrade) {
  const p = (COLOR_GRADE_PRESETS || []).find((x) => x.id === colorGrade);
  return p && p.filter ? p.filter : '';
}

function collectEligibleRows(appRootDir, acc) {
  return (acc.rows || [])
    .filter((r) => r.includeInExport !== false)
    .map((r) => ({ row: r, filePath: resolveSceneVideoDiskPath(appRootDir, r) }))
    .filter((x) => x.filePath && fs.existsSync(x.filePath))
    .sort((a, b) => Number(a.row.index) - Number(b.row.index));
}

function scoreSceneForTrailer(row, isLast) {
  const text = `${row.sceneTitle || ''}\n${row.prompt || ''}\n${row.dialogue || ''}`;
  let score = 1;
  score += Math.min(3, countHits(text, ACTION_WORDS)) * 2.2;
  score += Math.min(2, countHits(text, EMOTION_WORDS)) * 1.6;
  score += Math.min(2, countHits(text, SPECTACLE_WORDS)) * 1.2;
  if (String(row.dialogue || '').trim()) score += 0.4;
  if (['close_up', 'low_angle', 'extreme_wide', 'aerial', 'extreme_close'].includes(row.shotSize)) score += 0.8;
  if (row.qc && Number.isFinite(row.qc.score)) score += (row.qc.score - 70) / 30;
  if (row.qc && row.qc.verdict === 'fail') score -= 4;
  if (isLast) score -= 1.5; // tránh lộ cái kết
  return score;
}

/* ================= ẢNH BÌA ================= */

async function buildThumbnail({ appRootDir, acc, eligible, tempDir, promoDir, baseName, title, tagline, colorGrade, report }) {
  const ffmpegBin = getFfmpegExecutable(appRootDir);
  const { w, h } = resolvePromoSize(acc, 'thumbnail');
  const sampled =
    eligible.length <= 10
      ? eligible
      : Array.from({ length: 10 }, (_, k) => eligible[Math.round((k * (eligible.length - 1)) / 9)]);

  report('🖼️ Đang tìm khung hình đẹp nhất làm ảnh bìa...');
  const candidates = [];
  for (let i = 0; i < sampled.length; i++) {
    const { row, filePath } = sampled[i];
    const info = await probeMediaFile(ffmpegBin, filePath);
    const dur = Math.max(1, info.duration || 5);
    for (const frac of [0.42, 0.68]) {
      const t = Math.max(0.2, Math.min(dur - 0.25, dur * frac));
      const candPath = path.join(tempDir, `cand_${i}_${Math.round(frac * 100)}.jpg`);
      try {
        await runFfmpeg(ffmpegBin, ['-y', '-ss', t.toFixed(3), '-i', filePath, '-frames:v', '1', '-vf', 'scale=640:-2', '-q:v', '3', candPath]);
        if (!fs.existsSync(candPath)) continue;
        const sizeKb = fs.statSync(candPath).size / 1024;
        const stats = await measureClipColorStats(ffmpegBin, candPath).catch(() => null);
        const y = stats ? stats.y : 110;
        const brightness = Math.max(0.25, 1 - Math.abs(y - 118) / 140);
        const hasCast = Array.isArray(row.sceneCharacterIds) && row.sceneCharacterIds.length > 0;
        const shotBonus = ['close_up', 'medium_close', 'low_angle', 'medium'].includes(row.shotSize) ? 1.12 : 1;
        const qcPenalty = row.qc && row.qc.verdict === 'fail' ? 0.4 : 1;
        candidates.push({
          row,
          filePath,
          t,
          score: sizeKb * brightness * (hasCast ? 1.15 : 1) * shotBonus * qcPenalty
        });
      } catch (_) {}
    }
  }
  if (candidates.length === 0) throw new Error('Không trích được khung hình nào để làm ảnh bìa.');
  const best = candidates.reduce((a, b) => (b.score > a.score ? b : a));

  const look = lookFilterOf(colorGrade);
  const basePng = path.join(tempDir, 'thumb_base.png');
  await runFfmpeg(ffmpegBin, [
    '-y', '-ss', best.t.toFixed(3), '-i', best.filePath, '-frames:v', '1',
    '-vf', `scale=${w}:${h}:force_original_aspect_ratio=increase:flags=lanczos,crop=${w}:${h}${look ? `,${look}` : ''}`,
    basePng
  ]);

  const cleanName = `${baseName}_anh_bia_goc.jpg`;
  const cleanPath = path.join(promoDir, cleanName);
  await runFfmpeg(ffmpegBin, ['-y', '-i', basePng, '-q:v', '2', cleanPath]);

  report('🖼️ Đang in tên phim lên ảnh bìa...');
  const fontFile = prepareFont(tempDir);
  const textFilter = buildTitleDrawtext({ fontFile, tempDir, title, tagline, w, h, prefix: 'thumb' });
  const styleFilter = [
    'eq=contrast=1.06:saturation=1.1',
    'vignette=PI/5',
    textFilter ? `drawbox=x=0:y=ih*0.55:w=iw:h=ih*0.45:color=black@0.30:t=fill` : '',
    textFilter ? `drawbox=x=0:y=ih*0.72:w=iw:h=ih*0.28:color=black@0.35:t=fill` : '',
    textFilter
  ]
    .filter(Boolean)
    .join(',');

  const thumbName = `${baseName}_anh_bia.jpg`;
  const thumbPath = path.join(promoDir, thumbName);
  try {
    await runFfmpeg(ffmpegBin, ['-y', '-i', 'thumb_base.png', '-vf', styleFilter, '-frames:v', '1', '-q:v', '2', thumbPath], { cwd: tempDir });
  } catch (_) {
    // Dự phòng: nếu in chữ lỗi vẫn xuất ảnh bìa không chữ
    await runFfmpeg(ffmpegBin, ['-y', '-i', basePng, '-vf', 'eq=contrast=1.06:saturation=1.1,vignette=PI/5', '-frames:v', '1', '-q:v', '2', thumbPath]);
  }

  return {
    thumbName,
    thumbPath,
    cleanName,
    cleanPath,
    sourceSceneIndex: best.row.index,
    sourceTimeSec: Number(best.t.toFixed(2)),
    width: w,
    height: h
  };
}

/* ================= TRAILER ================= */

async function buildTrailer({ appRootDir, acc, eligible, tempDir, promoDir, baseName, title, tagline, colorGrade, trailerSeconds, report }) {
  const ffmpegBin = getFfmpegExecutable(appRootDir);
  const { w, h } = resolvePromoSize(acc, 'video');
  const target = Math.max(10, Math.min(90, Number(trailerSeconds) || 30));
  const endCardSec = 3;
  const transSec = 0.35;

  // 1. Chấm điểm & chọn các khoảnh khắc nổi bật trải đều câu chuyện (mở đầu - phát triển - cao trào)
  const scored = eligible.map((x, i) => ({ ...x, score: scoreSceneForTrailer(x.row, i === eligible.length - 1 && eligible.length > 2) }));
  const k = Math.max(1, Math.min(scored.length, 12, Math.max(3, Math.round((target - endCardSec) / 3))));
  const picks = [];
  for (let b = 0; b < k; b++) {
    const from = Math.floor((b * scored.length) / k);
    const to = Math.max(from + 1, Math.floor(((b + 1) * scored.length) / k));
    const bucket = scored.slice(from, to);
    picks.push(bucket.reduce((a, c) => (c.score > a.score ? c : a)));
  }

  const segLenTarget = Math.max(1.6, Math.min(5, (target - endCardSec + k * transSec) / k));
  const look = lookFilterOf(colorGrade);

  // 2. Đo màu đúng đoạn sẽ cắt để cân màu đồng đều cả trailer
  const segPlans = [];
  for (const p of picks) {
    const info = await probeMediaFile(ffmpegBin, p.filePath);
    const dur = Math.max(1, info.duration || 5);
    const trimStart = Math.max(0, Number(p.row.trimStartSec) || 0);
    const trimEnd = Math.max(0, Number(p.row.trimEndSec) || 0);
    const usableStart = Math.min(trimStart, Math.max(0, dur - 1.2));
    const usableEnd = Math.max(usableStart + 1, dur - trimEnd);
    const usable = usableEnd - usableStart;
    const segLen = Math.max(1.2, Math.min(segLenTarget, usable - 0.1));
    const start = Math.max(usableStart + 0.1, Math.min(usableEnd - segLen - 0.05, usableStart + usable * 0.4 - segLen / 2));
    segPlans.push({ ...p, start, segLen, hasAudio: info.hasAudio });
  }
  const gradeFilters = await computeColorGradeFiltersForClips(
    ffmpegBin,
    segPlans.map((s) => ({ filePath: s.filePath, startSec: s.start, durSec: s.segLen, label: s.row.index })),
    colorGrade,
    report
  );

  // 3. Cắt & chuẩn hóa từng đoạn
  const segFiles = [];
  for (let i = 0; i < segPlans.length; i++) {
    const s = segPlans[i];
    report(`🎞️ Đang cắt khoảnh khắc nổi bật ${i + 1}/${segPlans.length} (Cảnh ${s.row.index})...`);
    const out = path.join(tempDir, `seg_${String(i).padStart(2, '0')}.mp4`);
    const baseV = `scale=${w}:${h}:force_original_aspect_ratio=increase:flags=lanczos,crop=${w}:${h},setsar=1,fps=30,format=yuv420p`;
    const vf = gradeFilters[i] ? `${baseV},${gradeFilters[i]}` : baseV;
    const common = [
      '-c:v', 'libx264', '-preset', 'fast', '-crf', '17', '-pix_fmt', 'yuv420p',
      '-c:a', 'aac', '-b:a', '192k', '-ar', '44100', '-ac', '2'
    ];
    if (s.hasAudio) {
      await runFfmpeg(ffmpegBin, [
        '-y', '-ss', s.start.toFixed(3), '-t', s.segLen.toFixed(3), '-i', s.filePath,
        '-vf', vf, '-af', 'aresample=44100,aformat=sample_fmts=fltp:channel_layouts=stereo',
        ...common, out
      ]);
    } else {
      await runFfmpeg(ffmpegBin, [
        '-y', '-ss', s.start.toFixed(3), '-t', s.segLen.toFixed(3), '-i', s.filePath,
        '-f', 'lavfi', '-t', s.segLen.toFixed(3), '-i', 'anullsrc=channel_layout=stereo:sample_rate=44100',
        '-map', '0:v:0', '-map', '1:a:0', '-vf', vf, ...common, '-shortest', out
      ]);
    }
    if (fs.existsSync(out) && fs.statSync(out).size > 5000) segFiles.push(out);
  }
  if (segFiles.length === 0) throw new Error('Không cắt được đoạn nào cho trailer.');

  // 4. Khung kết thúc hiện tên phim
  report('🎬 Đang dựng khung tên phim kết thúc trailer...');
  const fontFile = prepareFont(tempDir);
  const endText = buildTitleDrawtext({
    fontFile,
    tempDir,
    title,
    tagline,
    w,
    h,
    prefix: 'end',
    alphaExpr: 'min(1,t/0.8)'
  });
  const endCard = path.join(tempDir, 'end_card.mp4');
  const endVf = [`vignette=PI/4`, endText ? endText.replace(/:y=(\d+)/g, (m, y) => `:y=${Math.round(Number(y) - h * 0.22)}`) : '']
    .filter(Boolean)
    .join(',');
  try {
    await runFfmpeg(
      ffmpegBin,
      [
        '-y',
        '-f', 'lavfi', '-i', `color=c=0x07090f:s=${w}x${h}:r=30:d=${endCardSec}`,
        '-f', 'lavfi', '-t', String(endCardSec), '-i', 'anullsrc=channel_layout=stereo:sample_rate=44100',
        '-map', '0:v:0', '-map', '1:a:0', '-vf', `${endVf},format=yuv420p`,
        '-c:v', 'libx264', '-preset', 'fast', '-crf', '17', '-pix_fmt', 'yuv420p',
        '-c:a', 'aac', '-b:a', '192k', '-ar', '44100', '-ac', '2', '-shortest',
        'end_card.mp4'
      ],
      { cwd: tempDir }
    );
    if (fs.existsSync(endCard)) segFiles.push(endCard);
  } catch (_) {}

  // 5. Nối nhanh với chuyển cảnh dip-to-black kiểu trailer
  report('🎞️ Đang nối các khoảnh khắc thành trailer...');
  const stitched = path.join(tempDir, 'trailer_stitched.mp4');
  try {
    await mergeNormalizedSegmentsWithTransition(ffmpegBin, segFiles, stitched, 'fadeblack', transSec);
  } catch (_) {
    const listPath = path.join(tempDir, 'concat.txt');
    fs.writeFileSync(listPath, segFiles.map((p) => `file '${p.replace(/\\/g, '/').replace(/'/g, "'\\''")}'`).join('\n'), 'utf8');
    await runFfmpeg(ffmpegBin, ['-y', '-f', 'concat', '-safe', '0', '-i', listPath, '-c', 'copy', stitched]);
  }

  // 6. Lồng nhạc nền + fade đầu/cuối
  const stitchedInfo = await probeMediaFile(ffmpegBin, stitched);
  const total = Math.max(2, stitchedInfo.duration || target);
  const fadeOutSt = Math.max(0, total - 1.2).toFixed(3);
  const vFade = `fade=t=in:st=0:d=0.5,fade=t=out:st=${Math.max(0, total - 0.8).toFixed(3)}:d=0.8`;
  const bgm = acc.settings?.bgmAudio?.filePath && fs.existsSync(acc.settings.bgmAudio.filePath) ? acc.settings.bgmAudio.filePath : null;
  const trailerName = `${baseName}_trailer_${Math.round(total)}s.mp4`;
  const trailerPath = path.join(promoDir, trailerName);
  const encode = ['-c:v', 'libx264', '-preset', 'fast', '-crf', '17', '-pix_fmt', 'yuv420p', '-c:a', 'aac', '-b:a', '192k', '-ar', '44100', '-ac', '2', '-movflags', '+faststart'];

  report(bgm ? '🎵 Đang lồng nhạc nền trailer...' : '🎵 Đang hoàn thiện âm thanh trailer...');
  if (bgm) {
    await runFfmpeg(ffmpegBin, [
      '-y', '-i', stitched, '-stream_loop', '-1', '-i', bgm,
      '-filter_complex',
      `[0:v]${vFade}[vout];[0:a]volume=0.65[vo];[1:a]aresample=44100,aformat=sample_fmts=fltp:channel_layouts=stereo,volume=0.85,afade=t=in:st=0:d=1[bg];[vo][bg]amix=inputs=2:duration=first:dropout_transition=0:normalize=0,afade=t=out:st=${fadeOutSt}:d=1.2[aout]`,
      '-map', '[vout]', '-map', '[aout]', ...encode, '-shortest', trailerPath
    ]);
  } else {
    await runFfmpeg(ffmpegBin, [
      '-y', '-i', stitched, '-vf', vFade, '-af', `afade=t=in:st=0:d=0.3,afade=t=out:st=${fadeOutSt}:d=1.2`, ...encode, trailerPath
    ]);
  }

  const finalInfo = await probeMediaFile(ffmpegBin, trailerPath);
  return {
    trailerName,
    trailerPath,
    duration: Number((finalInfo.duration || total).toFixed(2)),
    sceneIndices: segPlans.map((s) => s.row.index),
    width: w,
    height: h
  };
}

/* ================= HÀM CHÍNH ================= */

async function renderPromoPack({
  appRootDir,
  accountManager,
  accountId,
  movieTitle = '',
  tagline = '',
  trailerSeconds = 30,
  colorGrade = null,
  makeThumbnail = true,
  makeTrailer = true,
  onProgress = null
}) {
  const report = (msg) => {
    if (typeof onProgress === 'function') {
      try {
        onProgress(msg);
      } catch (_) {}
    }
  };
  const acc = accountManager.getAccount(accountId);
  if (!acc) throw new Error('Không tìm thấy dự án phim.');
  const eligible = collectEligibleRows(appRootDir, acc);
  if (eligible.length === 0) {
    throw new Error('Chưa có phân cảnh nào quay xong để tạo Ảnh bìa / Trailer!');
  }

  const title = String(movieTitle || acc.settings?.exportMovieTitle || acc.name || 'Bộ Phim AI').trim().slice(0, 80);
  const grade = colorGrade || acc.settings?.colorGrade || 'auto_match';
  const safeBase =
    title
      .normalize('NFD')
      .replace(/[\u0300-\u036f]/g, '')
      .replace(/đ/g, 'd')
      .replace(/Đ/g, 'D')
      .replace(/[^a-zA-Z0-9_-]+/g, '_')
      .replace(/^_+|_+$/g, '')
      .slice(0, 45) || 'MuseCinema';
  const baseName = `${safeBase}_${Date.now()}`;

  const outAccountDir = accountManager.ensureAccountOutputDir(accountId, { create: true });
  const promoDir = path.join(outAccountDir, 'Master_Movies', 'Promo');
  const tempDir = path.join(appRootDir, 'Project_Data', 'temp_editor', `promo_${Date.now()}`);
  [promoDir, tempDir].forEach((d) => fs.mkdirSync(d, { recursive: true }));

  try {
    const result = { title, tagline: String(tagline || '').trim(), createdAt: new Date().toISOString() };

    if (makeThumbnail) {
      const th = await buildThumbnail({
        appRootDir, acc, eligible, tempDir, promoDir, baseName, title, tagline: result.tagline, colorGrade: grade, report
      });
      Object.assign(result, {
        thumbnailFileName: th.thumbName,
        thumbnailFilePath: th.thumbPath,
        thumbnailUrl: accountManager.buildAccountOutputPublicUrl(accountId, 'Master_Movies', 'Promo', th.thumbName),
        thumbnailCleanFilePath: th.cleanPath,
        thumbnailCleanUrl: accountManager.buildAccountOutputPublicUrl(accountId, 'Master_Movies', 'Promo', th.cleanName),
        thumbnailSourceScene: th.sourceSceneIndex,
        thumbnailSize: `${th.width}x${th.height}`
      });
    }

    if (makeTrailer) {
      const tr = await buildTrailer({
        appRootDir, acc, eligible, tempDir, promoDir, baseName, title, tagline: result.tagline, colorGrade: grade, trailerSeconds, report
      });
      Object.assign(result, {
        trailerFileName: tr.trailerName,
        trailerFilePath: tr.trailerPath,
        trailerUrl: accountManager.buildAccountOutputPublicUrl(accountId, 'Master_Movies', 'Promo', tr.trailerName),
        trailerDuration: tr.duration,
        trailerSceneIndices: tr.sceneIndices,
        trailerSize: `${tr.width}x${tr.height}`
      });
    }

    const fresh = accountManager.getAccount(accountId);
    fresh.settings.lastPromoExport = result;
    accountManager.save();
    return { ok: true, ...result };
  } finally {
    try {
      fs.rmSync(tempDir, { recursive: true, force: true });
    } catch (_) {}
  }
}

module.exports = {
  renderPromoPack,
  scoreSceneForTrailer,
  wrapTitleLines
};
