const fs = require('fs');
const path = require('path');

const MAX_FILM_CHARACTERS = 50;
const MAX_CHAR_REF_IMAGES = 2;
const MAX_FILM_LOCATIONS = 20;

const FILM_GENRES = [
  {
    id: '3d_pixar',
    icon: '🧸',
    shortName: 'Hoạt Hình 3D Pixar',
    subDesc: 'Nhân vật 3D sống động, ánh sáng rạp chiếu',
    label: '🧸 Hoạt Hình 3D (Pixar / Disney)',
    defaultAspect: '16:9',
    eraGuard: false,
    styleDirective:
      'High-end 3D CGI feature animation in Pixar / Walt Disney Animation Studios style: appealing stylized 3D character sculpts with consistent proportions, expressive eyes and subtle facial micro-expressions, rich subsurface skin scattering, tactile fabric and hair grooming, warm cinematic key-and-rim lighting, and cohesive theatrical color grading.'
  },
  {
    id: '2d_anime',
    icon: '🌸',
    shortName: 'Hoạt Hình 2D Anime',
    subDesc: 'Nét vẽ Ghibli / Shinkai giàu cảm xúc',
    label: '🌸 Hoạt Hình 2D Anime (Ghibli / Shinkai)',
    defaultAspect: '16:9',
    eraGuard: false,
    styleDirective:
      'Theatrical 2D Japanese anime feature film aesthetic inspired by Studio Ghibli and Makoto Shinkai: crisp hand-drawn character linework, consistent cel-shaded facial geometry and outfits, painterly atmospheric backgrounds, luminous volumetric sky and sunlight, and fluid 2D character animation.'
  },
  {
    id: 'historical_epic',
    icon: '⚔️',
    shortName: 'Lịch Sử & Cổ Trang',
    subDesc: 'Hào khí cổ đại, giáp trụ & thành quách xưa',
    label: '⚔️ Phim Lịch Sử / Cổ Trang Hào Hùng',
    defaultAspect: '16:9',
    eraGuard: true,
    styleDirective:
      'Grand historical period epic cinema: authentic period-accurate traditional garments, armor, textiles, hairstyles, props, and ancient architecture; natural sunlight, firelight/torchlight, atmospheric mist, anamorphic 35mm theatrical color grading. STRICT HISTORICAL PURITY: ZERO modern buildings, ZERO electricity/wires/streetlights, ZERO cars/plastics/watches/modern signage.'
  },
  {
    id: 'cinema_35mm',
    icon: '🎥',
    shortName: 'Điện Ảnh Đời Thực',
    subDesc: 'Quay máy phim 35mm chân thực như người thật',
    label: '🎥 Phim Điện Ảnh Đời Thực (35mm Live-Action)',
    defaultAspect: '16:9',
    eraGuard: false,
    styleDirective:
      'Photorealistic live-action theatrical cinema shot on ARRI Alexa Mini LF with 35mm anamorphic prime lenses: authentic human skin texture, natural film grain, shallow cinematic depth of field, motivated three-point dramatic lighting, and cohesive Hollywood color grading.'
  },
  {
    id: 'xianxia_fantasy',
    icon: '🐉',
    shortName: 'Tiên Hiệp / Huyền Huyễn',
    subDesc: 'Cổ phong kỳ ảo, kiếm hiệp & thần thoại',
    label: '🐉 Tiên Hiệp / Huyền Huyễn Kỳ Ảo',
    defaultAspect: '16:9',
    eraGuard: true,
    styleDirective:
      'High-budget photorealistic live-action Eastern Xianxia & Wuxia theatrical cinema shot on ARRI Alexa 65 with 35mm anamorphic lenses (aesthetic of Zhang Yimou\'s Hero / Shadow, Ever Night, and Brotherhood of Blades): real human skin texture, heavy layered silk robes & battle-worn metal armor with authentic fabric weight, mist-shrouded ancient peaks and weathered stone pavilions, natural motivated dramatic lighting, and grounded Hollywood practical VFX (real dust, rain, sparks, air distortion — NEVER glossy plastic 3D game CGI or cheap neon overlays). STRICT ANCIENT FANTASY PURITY: ZERO modern objects or contemporary clothing.'
  },
  {
    id: 'fairy_tale_kids',
    icon: '🧚',
    shortName: 'Cổ Tích Thiếu Nhi',
    subDesc: 'Màu sắc rực rỡ, ngụ ngôn & kể chuyện bé nghe',
    label: '🧚 Cổ Tích / Ngụ Ngôn Thiếu Nhi',
    defaultAspect: '16:9',
    eraGuard: true,
    styleDirective:
      'Enchanting storybook fairy-tale feature film: vibrant warm magical color palette, wholesome expressive characters, charming village/forest/kingdom environments, soft golden-hour glow, and clear family-friendly visual storytelling with zero modern clutter.'
  },
  {
    id: 'buddhist_spiritual',
    icon: '🪷',
    shortName: 'Phật Giáo & Tâm Linh',
    subDesc: 'Truyện nhân quả, thiền định trang nghiêm',
    label: '🪷 Phật Giáo / Tâm Linh Nhân Quả',
    defaultAspect: '16:9',
    eraGuard: true,
    styleDirective:
      'Reverent Eastern spiritual & karmic parable cinema: serene ancient temple, lotus pond, and traditional Asian village settings, warm golden incense and morning sunbeams, peaceful compassionate character expressions, dignified traditional attire, zero modern distractions.'
  },
  {
    id: 'horror_thriller',
    icon: '🕯️',
    shortName: 'Kinh Dị & Trinh Thám',
    subDesc: 'Bầu không khí u tối, bí ẩn hồi hộp',
    label: '🕯️ Kinh Dị / Trinh Thám Bí Ẩn',
    defaultAspect: '16:9',
    eraGuard: false,
    styleDirective:
      'Suspenseful psychological thriller & mystery horror cinema: moody low-key chiaroscuro lighting, deep shadows, desaturated cold teal-and-amber palette, subtle volumetric mist, and tense controlled camera movement.'
  },
  {
    id: 'scifi_cyberpunk',
    icon: '🚀',
    shortName: 'Khoa Học Viễn Tưởng',
    subDesc: 'Vũ trụ, thế giới tương lai & Cyberpunk',
    label: '🚀 Khoa Học Viễn Tưởng (Sci-Fi)',
    defaultAspect: '21:9',
    eraGuard: false,
    styleDirective:
      'AAA theatrical science-fiction cinema: detailed futuristic architecture, spacecraft/cybernetic props, volumetric neon and holographic illumination, sleek atmospheric fog, anamorphic lens flares, and crisp futuristic costume design.'
  },
  {
    id: 'survival_prehistoric',
    icon: '🦖',
    shortName: 'Sinh Tồn & Tiền Sử',
    subDesc: 'Rừng rậm nguyên sinh, phiêu lưu hoang dã',
    label: '🦖 Sinh Tồn / Tiền Sử Hoang Dã',
    defaultAspect: '16:9',
    eraGuard: true,
    styleDirective:
      'Epic wilderness survival & prehistoric cinema: untouched primeval jungle, caves, rivers, and rugged natural terrain, tactile earth/rain/fire textures, dramatic natural daylight and campfire lighting, zero modern man-made structures.'
  },
  {
    id: 'family_drama',
    icon: '💔',
    shortName: 'Tâm Lý & Gia Đình',
    subDesc: 'Phim ngắn cảm xúc, đời thường, tổng tài',
    label: '💔 Tâm Lý Xã Hội / Drama Gia Đình',
    defaultAspect: '9:16',
    eraGuard: false,
    styleDirective:
      'Polished contemporary Asian drama & emotional cinema: crisp intimate close-ups and two-shots, refined interiors and wardrobe, flattering cinematic lighting, and authentic restrained naturalistic acting.'
  },
  {
    id: 'documentary_story',
    icon: '🌍',
    shortName: 'Tài Liệu Đời Sống',
    subDesc: 'Kể chuyện lịch sử, thiên nhiên & ký sự',
    label: '🌍 Phim Tài Liệu / Ký Sự Đời Sống',
    defaultAspect: '16:9',
    eraGuard: false,
    styleDirective:
      'Poetic cinematic documentary realism: authentic real-world environments, natural golden-hour and window lighting, grounded human expressions, smooth gimbal camera intimacy, and rich documentary color tone.'
  },
  {
    id: 'custom',
    icon: '✨',
    shortName: 'Phong Cách Tùy Chỉnh',
    subDesc: 'Tự định nghĩa nét vẽ / chất phim riêng',
    label: '✨ Phong Cách Điện Ảnh Tự Định Nghĩa',
    defaultAspect: '16:9',
    eraGuard: false,
    styleDirective:
      'Cohesive theatrical filmmaking aesthetic with 100% consistent visual art direction, lighting, color palette, and character design across every scene.'
  }
];

const CINEMA_VOICE_PRESETS = [
  {
    id: 'auto',
    label: '🎭 Tự khớp giới tính & độ tuổi nhân vật',
    directive: 'Natural expressive Vietnamese character voice matching the character age, gender, and emotion.'
  },
  {
    id: 'vi_storyteller_cinema',
    label: '🎧 Người Kể Chuyện Điện Ảnh — Trầm lắng, truyền cảm',
    directive:
      'Deep, resonant, emotionally captivating Vietnamese cinematic narrator voice (giọng kể chuyện điện ảnh trầm ấm, sâu lắng, ngắt nghỉ giàu cảm xúc).'
  },
  {
    id: 'vi_mc_professional',
    label: '🎙️ Thuyết Minh Phim / Tài Liệu — Hùng hồn, rõ chữ',
    directive:
      'Authoritative, crystal-clear professional Vietnamese documentary/history narrator voice (giọng thuyết minh phim lịch sử chuẩn mực, hào sảng, rõ từng chữ).'
  },
  {
    id: 'vi_male_hero_epic',
    label: '🦁 Nam Chính / Tướng Quân — Trầm hùng, uy nghiêm',
    directive:
      'Commanding, resonant, heroic Vietnamese adult male voice (giọng nam trầm hùng, uy lực, đĩnh đạc của bậc tướng quân / nam chính).'
  },
  {
    id: 'vi_male_young_bright',
    label: '👦 Nam Trẻ / Thiếu Niên — Trẻ trung, nhiệt huyết',
    directive:
      'Youthful, energetic, sincere Vietnamese young man voice (20-26 years old, giọng nam trẻ nhiệt huyết, rõ nét).'
  },
  {
    id: 'vi_male_elder_wise',
    label: '👴 Ông Lão / Bậc Trưởng Bối — Trầm khàn, từng trải',
    directive:
      'Wise, warm, slightly gravelly elderly Vietnamese grandfather/sage voice (65+ years old, giọng cụ già hiền từ, từng trải, chậm rãi).'
  },
  {
    id: 'vi_female_lead_gentle',
    label: '👩 Nữ Chính — Dịu dàng, trong trẻo, giàu cảm xúc',
    directive:
      'Clear, graceful, emotionally expressive young Vietnamese female lead voice (22-28 years old, giọng nữ chính trong trẻo, truyền cảm).'
  },
  {
    id: 'vi_female_noble_warm',
    label: '👑 Nữ Vương / Người Mẹ — Đằm thắm, uy nghi',
    directive:
      'Warm, dignified, mature Vietnamese woman voice (35-48 years old, giọng phụ nữ trưởng thành đằm thắm, sâu sắc).'
  },
  {
    id: 'vi_female_elder_kind',
    label: '👵 Bà Lão Hiền Từ — Ấm áp, kể chuyện xưa',
    directive:
      'Gentle, affectionate elderly Vietnamese grandmother voice (65+ years old, giọng bà cụ hiền hậu, ấm áp).'
  },
  {
    id: 'vi_child_boy',
    label: '🧒 Bé Trai (6–11 tuổi) — Hồn nhiên, lanh lợi',
    directive:
      'Authentic, innocent, bright Vietnamese young boy child voice (7-10 years old, giọng bé trai hồn nhiên, trong sáng).'
  },
  {
    id: 'vi_child_girl',
    label: '👧 Bé Gái (6–11 tuổi) — Trong veo, đáng yêu',
    directive:
      'Sweet, pure, cheerful Vietnamese young girl child voice (7-10 years old, giọng bé gái trong veo, dễ thương).'
  },
  {
    id: 'vi_male_south_warm',
    label: '🌴 Nam Miền Nam — Gần gũi, hào sảng',
    directive:
      'Warm, authentic Southern Vietnamese (Saigon) male voice, natural and expressive.'
  },
  {
    id: 'vi_female_south_sweet',
    label: '🌸 Nữ Miền Nam — Ngọt ngào, tự nhiên',
    directive:
      'Sweet, natural Southern Vietnamese (Saigon) female voice, clear emotional delivery.'
  },
  {
    id: 'en_male_cinema',
    label: '🌐 Tiếng Anh (Nam) — Hollywood Cinema',
    directive: 'Deep expressive international English cinematic male voice.'
  },
  {
    id: 'en_female_cinema',
    label: '🌐 Tiếng Anh (Nữ) — International Storytelling',
    directive: 'Warm, articulate international English cinematic female voice.'
  },
  {
    id: 'custom',
    label: '✍️ Tự mô tả chất giọng riêng...',
    directive: 'Expressive studio-clear character voice.'
  }
];

const CINEMA_LIGHTING_PRESETS = [
  {
    id: 'auto',
    label: '🎬 Tự động theo thể loại & bối cảnh từng cảnh (Mặc định)',
    directive: ''
  },
  {
    id: 'golden_hour',
    label: '🌅 Nắng Vàng Hoàng Hôn / Bình Minh Ấm Áp (Golden Hour)',
    directive:
      'Warm cinematic golden-hour sunlight, soft long atmospheric shadows, glowing amber-gold rim light on characters, rich nostalgic color warmth.'
  },
  {
    id: 'bright_daylight',
    label: '☀️ Ban Ngày Trong Trẻo & Tươi Sáng (Natural Daylight)',
    directive:
      'Crisp bright natural daylight illumination, clear sky light, clean vibrant true-to-life colors, soft balanced fill light on faces.'
  },
  {
    id: 'soft_studio_3d',
    label: '✨ Ánh Sáng Rạp Chiếu 3D Mềm Mại (Soft Studio Cinema)',
    directive:
      'Polished theatrical three-point key-fill-rim lighting, gentle volumetric glow, smooth flattering facial illumination, vibrant cinema grading.'
  },
  {
    id: 'volumetric_godrays',
    label: '🌤️ Tia Nắng Xuyên Sương Sớm / Tán Rừng (Volumetric Sunbeams)',
    directive:
      'Poetic volumetric sunbeams (god-rays) piercing through gentle morning mist or foliage, luminous atmospheric depth, warm highlights and soft shadows.'
  },
  {
    id: 'moonlight_night',
    label: '🌙 Đêm Trăng Thanh & Sương Mờ Huyền Ảo (Moonlit Night)',
    directive:
      'Silvery-blue cinematic moonlight illumination, gentle night mist, deep atmospheric shadows with clear facial visibility and cool rim highlights.'
  },
  {
    id: 'firelight_lantern',
    label: '🏮 Ánh Lửa Trại / Đèn Dầu / Đèn Lồng Cổ Xưa (Warm Fire & Lantern)',
    directive:
      'Warm flickering firelight, candle/oil-lamp or traditional lantern glow against rich dark surroundings, authentic period warmth on faces and garments.'
  },
  {
    id: 'dramatic_chiaroscuro',
    label: '🎭 Tương Phản Điện Ảnh Sâu & Gay Cấn (Dramatic High-Contrast)',
    directive:
      'Dramatic high-contrast chiaroscuro cinema lighting, sculpted directional key light, deep moody shadows, intense theatrical atmosphere.'
  },
  {
    id: 'dark_mystery_fog',
    label: '🕯️ U Tối, Sương Mù & Bí Ẩn Hồi Hộp (Low-Key Mystery)',
    directive:
      'Low-key suspenseful dark mystery lighting, cold desaturated teal-grey shadows, eerie volumetric fog, subtle practical light sources.'
  },
  {
    id: 'rainy_nostalgic',
    label: '🌧️ Chiều Mưa Trầm Buồn & Mặt Đường Phản Chiếu (Rainy Mood)',
    directive:
      'Overcast rainy cinematic mood, diffused melancholic cool daylight mixed with warm interior/window reflections on wet surfaces.'
  },
  {
    id: 'neon_cyber',
    label: '🔮 Đèn Neon Phố Đêm / Tương Lai Rực Rỡ (Neon Night)',
    directive:
      'Vibrant cyan, magenta, and warm neon night illumination, glossy street reflections, sleek atmospheric haze, crisp futuristic rim lighting.'
  },
  {
    id: 'custom',
    label: '✍️ Tự mô tả ánh sáng riêng...',
    directive: ''
  }
];

const VALID_GENRE_IDS = new Set(FILM_GENRES.map((g) => g.id));
const VALID_VOICE_IDS = new Set(CINEMA_VOICE_PRESETS.map((v) => v.id));
const VALID_LIGHTING_IDS = new Set(CINEMA_LIGHTING_PRESETS.map((l) => l.id));
const VALID_AUDIO_MODES = new Set(['mixed', 'narrator', 'dialogue', 'ambient_only']);
const VALID_CONTINUITY_MODES = new Set(['parallel_fast', 'smart_chain', 'sequential_chain']);

function stripVietnameseAccents(str) {
  return String(str || '')
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/đ/g, 'd')
    .replace(/Đ/g, 'D');
}

function sanitizeCharacterTag(rawTagOrName, fallbackIndex = 1) {
  const raw = String(rawTagOrName || '').trim().replace(/^@+/, '');
  const words = stripVietnameseAccents(raw)
    .replace(/[^a-zA-Z0-9\s_]+/g, ' ')
    .trim()
    .split(/\s+/)
    .filter(Boolean);
  if (words.length === 0) return `@NhanVat${fallbackIndex}`;
  const pascal = words
    .map((w) => w.charAt(0).toUpperCase() + w.slice(1))
    .join('')
    .slice(0, 28);
  return `@${pascal || `NhanVat${fallbackIndex}`}`;
}

function sanitizeLocationTag(rawTagOrName, fallbackIndex = 1) {
  const raw = String(rawTagOrName || '').trim().replace(/^[#@]+/, '');
  const words = stripVietnameseAccents(raw)
    .replace(/[^a-zA-Z0-9\s_]+/g, ' ')
    .trim()
    .split(/\s+/)
    .filter(Boolean);
  if (words.length === 0) return `#BoiCanh${fallbackIndex}`;
  const pascal = words
    .map((w) => w.charAt(0).toUpperCase() + w.slice(1))
    .join('')
    .slice(0, 28);
  return `#${pascal || `BoiCanh${fallbackIndex}`}`;
}

/**
 * Tự động suy luận và khóa cứng mã Giọng đọc cụ thể cho nhân vật (tránh để 'auto' mơ hồ gây lệch tông giọng giữa các cảnh xa)
 */
function inferLockedVoicePreset({ name = '', tag = '', appearanceDna = '', voiceHint = '' } = {}) {
  const combined = stripVietnameseAccents(`${voiceHint} ${name} ${tag} ${appearanceDna}`.toLowerCase());
  if (/be\s*gai|co\s*be|em\s*gai\s*nho|thieu\s*nhi\s*nu|girl|little\s*daughter/.test(combined)) {
    return 'vi_child_girl';
  }
  if (/be\s*trai|cau\s*be|chu\s*be|cun\s*nho|thieu\s*nhi|nho\s*tuoi|boy|kid|lac\s*lac/.test(combined)) {
    return 'vi_child_boy';
  }
  if (/ba\s*lao|cu\s*ba|ba\s*cu|ba\s*tien|ba\s*noi|ba\s*ngoai|old\s*woman|grandmother/.test(combined)) {
    return 'vi_female_elder_kind';
  }
  if (/ong\s*lao|cu\s*ong|gia\s*lang|bac\s*cu| su\s*phu|thay\s*gia|elder|old\s*man|grandfather|sage/.test(combined)) {
    return 'vi_male_elder_wise';
  }
  if (/di\s*ghe|hoang\s*hau|phu\s*nhan|nguoi\s*me|nu\s*vuong|mature\s*woman|mother|queen/.test(combined)) {
    return 'vi_female_noble_warm';
  }
  if (/tuong\s*quan|hoang\s*de|nha\s*vua|anh\s*hung|trang\s*si|dai\s*ca|tong\s*tai|hero|king|general/.test(combined)) {
    return 'vi_male_hero_epic';
  }
  if (
    /\b(co|nang|nu|chi|em|tam|cam|lan|mai|linh|huong|hoa|thao|ngoc|trang|cong\s*chua|female|woman|lady)\b/.test(
      combined
    )
  ) {
    return 'vi_female_lead_gentle';
  }
  if (
    /\b(anh|chang|nam|minh|hung|dung|tuan|nam\s*chinh|hoang\s*tu|thieu\s*nien|male|man|prince)\b/.test(
      combined
    )
  ) {
    return 'vi_male_young_bright';
  }
  // Hash ổn định từ @Tag để cùng 1 nhân vật luôn cố định 1 giọng duy nhất
  let hash = 0;
  const seed = String(tag || name || 'actor');
  for (let i = 0; i < seed.length; i++) {
    hash = (hash * 31 + seed.charCodeAt(i)) >>> 0;
  }
  const fallbackPool = [
    'vi_male_young_bright',
    'vi_female_lead_gentle',
    'vi_male_hero_epic',
    'vi_female_noble_warm'
  ];
  return fallbackPool[hash % fallbackPool.length];
}

function getCinemaVoiceDirective(presetId = 'auto', customNote = '', characterContext = null) {
  let effectiveId = presetId;
  if ((!effectiveId || effectiveId === 'auto') && characterContext) {
    effectiveId = inferLockedVoicePreset({
      name: characterContext.name,
      tag: characterContext.tag,
      appearanceDna: characterContext.appearanceDna
    });
  }
  const found = CINEMA_VOICE_PRESETS.find((v) => v.id === effectiveId) || CINEMA_VOICE_PRESETS[0];
  const note = String(customNote || '').trim();
  const timbreLock = characterContext
    ? ` [VOICE TIMBRE LOCK FOR ${characterContext.tag || characterContext.name}: Keep identical vocal pitch, resonance, speaking pace (~130 WPM), and accent across every scene].`
    : '';
  if (effectiveId === 'custom' && note) {
    return `Custom locked character voice: ${note}.${timbreLock}`;
  }
  if (note) {
    return `${found.directive} Additional voice nuance: ${note}.${timbreLock}`;
  }
  return `${found.directive}${timbreLock}`;
}

function getFilmGenreInfo(genreId = '3d_pixar', customStylePrompt = '') {
  const found = FILM_GENRES.find((g) => g.id === genreId) || FILM_GENRES[0];
  const customClean = String(customStylePrompt || '').trim();
  const fullStyleDirective =
    found.id === 'custom' && customClean
      ? `${customClean}. Maintain 100% consistent visual style, lighting, and character aesthetics across all scenes.`
      : customClean
      ? `${found.styleDirective} Additional director style note: ${customClean}`
      : found.styleDirective;
  return {
    ...found,
    fullStyleDirective
  };
}

function getCinemaLightingDirective(lightingPreset = 'auto', customLightingNote = '') {
  const found = CINEMA_LIGHTING_PRESETS.find((l) => l.id === lightingPreset) || CINEMA_LIGHTING_PRESETS[0];
  const customClean = String(customLightingNote || '').trim();
  if (found.id === 'custom') {
    return customClean;
  }
  if (found.directive && customClean) {
    return `${found.directive} Additional director lighting note: ${customClean}`;
  }
  return found.directive || customClean;
}

function createDefaultFilmConfig() {
  return {
    genreId: '3d_pixar',
    customStylePrompt: '',
    worldLock: '',
    lightingPreset: 'auto',
    customLightingNote: '',
    actingStyle: 'subtle_realistic',
    combatIntensity: 'epic_donghua',
    aspectRatio: '16:9',
    resolution: '720p',
    audioMode: 'mixed',
    narratorVoicePreset: 'vi_storyteller_cinema',
    narratorVoiceNote: '',
    continuityMode: 'parallel_fast',
    targetMovieSeconds: 180,
    sceneDurationSeconds: 10,
    concurrency: 4,
    storyDraft: ''
  };
}

/* ================= v1.9: KHÓA DIỄN XUẤT TỰ NHIÊN — CHỐNG BIỂU CẢM QUÁ ĐÀ ================= */
const ACTING_STYLE_PRESETS = [
  {
    id: 'subtle_realistic',
    label: '🔒 Khóa Chặt Tự Nhiên Tiết Chế — Cấm khóc giàn giụa, cười vô lý, nhăn nhó, cau trán (Mặc định)'
  },
  {
    id: 'balanced',
    label: '🙂 Cân Bằng Điện Ảnh — Cảm xúc rõ nét hơn nhưng vẫn khóa chống làm lố & cấm cười sau thoại'
  },
  {
    id: 'expressive',
    label: '🎭 Biểu Cảm Sinh Động — Dành riêng cho Phim hài / Hoạt hình thiếu nhi vui nhộn'
  }
];
const VALID_ACTING_STYLES = new Set(ACTING_STYLE_PRESETS.map((a) => a.id));

/**
 * Làm dịu các mô tả biểu cảm quá đà trong phần mô tả cảnh quay (KHÔNG đụng tới lời thoại được nói ra)
 * để Muse.ai không diễn khóc giàn giụa, cười phá lên, nhăn nhó, cau có quá mức.
 */
const OVERACTING_SOFTEN_RULES = [
  [
    /(?:(?:khóc\s+(?:nức nở|rống|lóc(?:\s+thảm thiết)?|thét|như mưa|òa|sướt mướt|ngất|giàn giụa|dàn dụa|ràn rụa|đầm đìa)|gào khóc|òa khóc)(?:[\s,]*(?:nước mắt\s*)?(?:giàn giụa|dàn dụa|ràn rụa|đầm đìa|lã chã|tuôn trào|tuôn rơi|chảy dài)|\s+nước mắt)?|(?:giàn giụa|dàn dụa|ràn rụa|đầm đìa)\s+nước mắt|nước mắt\s+(?:giàn giụa|dàn dụa|ràn rụa|đầm đìa|lã chã|tuôn trào|tuôn rơi|chảy dài))(?:\s+(?:quá mức|quá đà|thảm thiết))?/giu,
    'mắt khẽ rưng rưng, kìm nén cảm xúc tự nhiên'
  ],
  [
    /(?:nói xong\s+cười(?:\s+vô lý|\s+vô cớ)?|cười\s+(?:vô lý|vô cớ|sằng sặc|hô hố|như điên|điên dại|khanh khách))/giu,
    'giữ nét mặt điềm tĩnh tự nhiên'
  ],
  [
    /(?:cười\s+(?:phá lên|ha hả|ngặt nghẽo|lớn|to|nghiêng ngả|rộ lên))(?:\s+(?:quá mức|quá đà))?/giu,
    'khẽ thoáng mỉm cười nhẹ'
  ],
  [
    /(?:mặt\s+(?:nhăn nhó|méo xệch|nhăn như khỉ|co rúm|biến dạng|đỏ gay(?:\s+gắt)?)|nhăn nhó|méo xệch|trán\s+nhăn(?:\s+tít|\s+nhíu|\s+cau có)?|nhăn\s+trán(?:\s+cau có)?|cau\s+mày(?:\s+nhăn\s+trán)?|cau\s+có(?:\s+dữ tợn)?|trợn\s+(?:mắt|trừng|ngược)|nghiến\s+răng(?:\s+ken két)?|nhe\s+răng|biểu cảm\s+(?:quá mức|quá đà|cường điệu))(?:\s+(?:quá mức|quá đà|dữ tợn|không chân thực))?/giu,
    'ánh mắt trầm tĩnh, trán và cơ mặt thả lỏng tự nhiên'
  ],
  [
    /(?:gào\s+thét(?:\s+thảm thiết|\s+đau đớn|\s+điên cuồng)?|quằn\s+quại|vật\s+vã)(?:\s+(?:quá mức|quá đà))?/giu,
    'kìm nén cảm xúc trong ánh mắt, hơi thở chậm lại'
  ],
  [
    /\b(sobbing uncontrollably|sobbing|bursts? into tears|streaming tears|floods? of tears|wailing|bawling|hysterical(?:ly)?|laughs? maniacally|laughs? hysterically|roaring with laughter|bursts? out laughing|grimac\w*|scowl\w*|furrowed brow\w*|wrinkled forehead|contorted face|exaggerated expression\w*|overacting)\b/giu,
    'restrained natural cinema expression'
  ]
];

function softenOveractingText(text = '', actingStyle = 'subtle_realistic') {
  if (!text || actingStyle === 'expressive') return String(text || '');
  const preservedQuotes = [];
  let out = String(text).replace(/(?:"[^"\r\n]{1,300}"|“[^”\r\n]{1,300}”)/g, (m) => {
    const idx = preservedQuotes.length;
    preservedQuotes.push(m);
    return `__MCS_QUOTE_${idx}__`;
  });
  for (const [re, rep] of OVERACTING_SOFTEN_RULES) {
    out = out.replace(re, rep);
  }
  return out.replace(/__MCS_QUOTE_(\d+)__/g, (_, i) => preservedQuotes[Number(i)] || '');
}

function buildActingDirectionBlock({
  actingStyle = 'subtle_realistic',
  sceneText = '',
  hasSpokenLines = false,
  isCombatScene = false
} = {}) {
  const style = VALID_ACTING_STYLES.has(actingStyle) ? actingStyle : 'subtle_realistic';
  const low = String(sceneText || '');
  const wantsSmile =
    /(?<!không\s|chẳng\s|chưa\s|cấm\s|đừng\s|no\s|never\s|without\s)(?:mỉm cười|nở nụ cười|vui vẻ|hạnh phúc|gentle smile|warm smile)/iu.test(
      low
    );
  const wantsTears =
    /(?<!không\s|chẳng\s|chưa\s|cấm\s|đừng\s|no\s|never\s|without\s)(?:khóc|nước mắt|rưng rưng|glistening eyes|single quiet tear)/iu.test(
      low
    );

  const common = [
    `• POST-DIALOGUE & SMILE LOCK (STRICT): ${
      wantsSmile && !isCombatScene
        ? 'Allow ONLY a brief, subtle closed-lip micro-smile at the exact joyful beat — NEVER a wide toothy laugh or unnatural grin.'
        : 'STRICTLY ZERO SMILING, ZERO GRINNING, AND ZERO LAUGHING anywhere in this shot.'
    } NEVER smile or laugh right after finishing a spoken sentence — as soon as the last word ends, close the mouth softly into a calm, neutral, composed expression matching the scene mood.`,
    `• FOREHEAD & FACIAL MUSCLE LOCK: Keep the forehead smooth and relaxed, eyebrows calm, and mouth/cheeks natural at all times — NEVER wrinkle or crease the forehead, NEVER scrunch brows into an angry scowl, and NEVER contort or twist the mouth.`,
    `• EYELINE & MICRO-ACTING: No eyebrow wiggling, no exaggerated blinking, no head bobbing, and NEVER look or mug into the camera lens. Characters keep sharp, locked eye contact with the person they are speaking to or fighting.`
  ];

  if (style === 'expressive') {
    return [
      `[ACTING STYLE — EXPRESSIVE BUT CONTROLLED]`,
      `• Clear, readable emotions suitable for comedy / family animation, while keeping faces on-model and appealing (no distorted or grotesque faces, no random smiling after dialogue).`,
      common[0],
      common[2]
    ].join('\n');
  }

  const lines = [
    style === 'balanced'
      ? `[ACTING & FACIAL EXPRESSION LOCK — NATURAL, CLEARLY READABLE, NEVER OVER-THE-TOP]`
      : `[ACTING & FACIAL EXPRESSION LOCK — RESTRAINED, REALISTIC CINEMA PERFORMANCE (HIGHEST PRIORITY)]`,
    isCombatScene
      ? `• COMBAT FOCUS & BODY DYNAMICS: Keep facial features sharp, noble, and on-model (ZERO grotesque contorted grimaces, ZERO bulging eyes, ZERO random smiling), while unleashing 100% EXPLOSIVE, HIGH-SPEED, AGGRESSIVE MARTIAL BODY ENERGY, laser-focused gaze locked straight onto the opponent, and dynamic athletic movement!`
      : style === 'balanced'
      ? `• Natural screen acting with moderate, believable emotions; facial muscles and forehead stay calm and realistic.`
      : `• Understated, naturalistic cinema acting (prestige live-action / high-end film standard): convey emotion 80% through quiet eyes, subtle breathing, micro-pauses, and body posture while keeping facial muscles calm and composed.`,
    `• FORBIDDEN EXPRESSIONS (ZERO TOLERANCE): NO sobbing or streaming/flooding tears, NO random smiling or laughing after speaking, NO grimacing, NO contorted/scrunched faces, NO deeply furrowed or wrinkled foreheads, NO bared teeth or bulging eyes, NO melodramatic theatrical over-acting.`,
    wantsTears && !isCombatScene
      ? `• SADNESS / TEARS CAP: Express grief with quiet dignity — at most faintly glistening eyes or ONE silent tear while keeping the forehead, brows, nose, and mouth calm and composed (NEVER crying rivers of tears, red swollen face, or open-mouth sobbing).`
      : !isCombatScene
      ? `• SADNESS / TENSION: Express through a quiet lowered gaze, stillness, and measured breath — ZERO tears and ZERO crying face.`
      : '',
    !isCombatScene
      ? `• ANGER / RESOLVE: Express through a cold, steady, unblinking gaze and controlled stillness — NEVER scowl, snarl, bare teeth, or wrinkle the forehead.`
      : '',
    hasSpokenLines
      ? `• LIP-SYNC RESTRAINT: Open the mouth naturally and modestly only as needed for Vietnamese speech; keep forehead, brows, and cheeks relaxed while speaking, then rest in a calm neutral closed-mouth expression.`
      : '',
    ...common
  ];
  return lines.filter(Boolean).join('\n');
}

function normalizeActingStyle(v) {
  return VALID_ACTING_STYLES.has(v) ? v : 'subtle_realistic';
}

/* ================= v2.2: KHÓA ÁNH MẮT ĐỐI THOẠI & ĐẠO DIỄN CHIẾN ĐẤU THỰC CHIẾN — KỸ XẢO ĐIỆN ẢNH HOLLYWOOD ================= */
const COMBAT_INTENSITY_PRESETS = [
  {
    id: 'epic_donghua',
    label: '⚔️ Tiên Hiệp Điện Ảnh Thực Tế — Vật lý nặng đô, tia lửa thật, sóng khí khúc xạ (Khuyên dùng — Không giả CGI)'
  },
  {
    id: 'grounded_martial',
    label: '🥋 Kiếm Hiệp Thuần Thực Chiến (Đẳng cấp Tú Xuân Đao / Diệp Vấn — 100% thép & võ thuật thật)'
  },
  {
    id: 'mythic_vfx',
    label: '🔥 Đại Chiến Thần Ma (Kỹ xảo năng lượng quy mô lớn chuẩn rạp chiếu — Ánh sáng tương tác thật)'
  },
  {
    id: 'restrained',
    label: '🌿 Đối Đầu Tiết Chế (Thiên về uy áp tâm lý, ít hành động)'
  }
];
const VALID_COMBAT_INTENSITIES = new Set(COMBAT_INTENSITY_PRESETS.map((c) => c.id));

function normalizeCombatIntensity(v) {
  return VALID_COMBAT_INTENSITIES.has(v) ? v : 'epic_donghua';
}

const CHEAP_VFX_REFINE_RULES = [
  [
    /(?:vòng\s*(?:tròn\s*)?(?:pháp\s*trận|ma\s*pháp|phép\s*thuật|linh\s*lực)\s*(?:phát\s*sáng\s*rực\s*rỡ|sáng\s*chói|đủ\s*màu|rực\s*rỡ)?|hào\s*quang\s*(?:bảy\s*màu|cầu\s*vồng|chói\s*lòa|đủ\s*màu|rực\s*rỡ))/giu,
    'luồng áp suất khí kình khúc xạ không khí làm cuộn tung bụi đá và sương mù'
  ],
  [
    /(?:tia\s*laser|tia\s*sáng\s*(?:đủ\s*màu|cầu\s*vồng|chói\s*lòa|neon)|phát\s*sáng\s*(?:chói\s*lòa|rực\s*rỡ\s*đủ\s*màu))/giu,
    'vệt khí sắc lạnh xé toạc màn sương kèm tia lửa nóng chảy'
  ],
  [
    /(?:bay\s*lơ\s*lửng\s*(?:trên\s*không|giữa\s*trời)|lơ\s*lửng\s*giữa\s*không\s*trung)/giu,
    'bật nhảy mạnh bằng lực chân đạp vỡ nền đá, thân pháp nặng đô có trọng lực thật'
  ]
];

/**
 * Thay thế các cụm mô tả dễ khiến Video AI vẽ kỹ xảo neon giả / bay lơ lửng mất trọng lực
 * bằng mô tả vật lý & ánh sáng điện ảnh chân thực (giữ nguyên 100% lời thoại trong dấu ngoặc kép).
 */
function refineCheapVfxText(text = '', combatIntensity = 'epic_donghua') {
  if (!text || normalizeCombatIntensity(combatIntensity) === 'mythic_vfx') return String(text || '');
  const preservedQuotes = [];
  let out = String(text).replace(/(?:"[^"\r\n]{1,300}"|“[^”\r\n]{1,300}”)/g, (m) => {
    const idx = preservedQuotes.length;
    preservedQuotes.push(m);
    return `__MCS_VFXQ_${idx}__`;
  });
  for (const [re, rep] of CHEAP_VFX_REFINE_RULES) {
    out = out.replace(re, rep);
  }
  return out.replace(/__MCS_VFXQ_(\d+)__/g, (_, i) => preservedQuotes[Number(i)] || '');
}

const COMBAT_ACTION_RE =
  /(?:giao\s*chiến|chiến\s*đấu|quyết\s*chiến|đánh\s*nhau|đại\s*chiến|tử\s*chiến|tấn\s*công|ra\s*chiêu|xuất\s*chiêu|thi\s*triển|kiếm\s*khí|đao\s*khí|chưởng\s*lực|đối\s*chưởng|tung\s*chưởng|pháp\s*quyết|linh\s*lực\s*bùng|công\s*kích|đỡ\s*đòn|gạt\s*đòn|phản\s*công|đấu\s*pháp|phi\s*kiếm|truy\s*sát|vây\s*đánh|né\s*đòn|va\s*chạm\s*mạnh|lôi\s*kiếp|hỏa\s*diễm|xé\s*gió|bùng\s*nổ|chém\s*tới|đâm\s*tới|vung\s*(?:kiếm|đao|thương|côn|trượng|xích)|kích\s*đấu|luận\s*võ|tỷ\s*thí|đánh\s*úp|ám\s*sát|\b(?:combat|battle|duel|swordfight|swordplay|clash|clashing|parry|strike|striking|slash|slashing|martial\s*arts\s*fight|qi\s*blast|energy\s*clash)\b)/iu;

const EYELINE_AVOID_RE =
  /(?:quay\s*lưng|quay\s*mặt\s*đi|ngoảnh\s*mặt|nhìn\s*ra\s*xa|nhìn\s*lên\s*trời|nhìn\s*xuống\s*đất|cúi\s*gằm|tránh\s*né\s*ánh\s*mắt|không\s*dám\s*nhìn|nhìn\s*vào\s*khoảng\s*không|nhìn\s*ra\s*ngoài|nhìn\s*vầng\s*trăng|ngước\s*nhìn\s*(?:trời|mây|trăng|núi)|turns?\s*away|looks?\s*away|staring\s*(?:at\s*the\s*sky|into\s*the\s*distance)|avoids?\s*eye\s*contact)/iu;

function isCombatSceneText(text = '') {
  return COMBAT_ACTION_RE.test(String(text || ''));
}

/**
 * Khóa chặt tư thế đối mặt & trục ánh mắt khi nhân vật đối thoại (chấm dứt lỗi nói chuyện mà nhìn đi chỗ khác)
 */
function buildDialogueBlockingBlock({
  onScreenChars = [],
  parsedLines = [],
  sceneActionText = '',
  hasCombat = false,
  audioMode = 'mixed'
} = {}) {
  if (hasCombat || audioMode === 'ambient_only') return '';
  if (EYELINE_AVOID_RE.test(String(sceneActionText || ''))) return '';

  const speakerNames = [];
  const seenSp = new Set();
  for (const ln of parsedLines) {
    if (ln.type === 'character') {
      const nm = ln.character?.name || ln.speakerLabel;
      if (nm && !seenSp.has(nm.toLowerCase())) {
        seenSp.add(nm.toLowerCase());
        speakerNames.push(nm);
      }
    } else if (ln.type === 'default' && audioMode !== 'narrator' && onScreenChars[0]) {
      const nm = onScreenChars[0].name;
      if (nm && !seenSp.has(nm.toLowerCase())) {
        seenSp.add(nm.toLowerCase());
        speakerNames.push(nm);
      }
    }
  }

  const hasCharSpeech = speakerNames.length > 0;
  if (!hasCharSpeech && onScreenChars.length < 2) return '';

  if (onScreenChars.length >= 2) {
    const allNames = onScreenChars.map((c) => `"${c.name}"`).join(' and ');
    const primarySpeaker = speakerNames[0] || onScreenChars[0].name;
    const listeners = onScreenChars
      .filter((c) => c.name.toLowerCase() !== primarySpeaker.toLowerCase())
      .map((c) => `"${c.name}"`);
    const listenerStr = listeners.length > 0 ? listeners.join(' / ') : 'the other character';

    const lines = [
      `[DIALOGUE BLOCKING & DIRECT EYE-CONTACT LOCK (MANDATORY — ZERO LOOKING AWAY)]`,
      `• FACE-TO-FACE STAGING: Position ${allNames} DIRECTLY FACING EACH OTHER across the frame (left character angled toward right, right character angled toward left, heads & shoulders turned toward one another). STRICTLY FORBID placing conversing characters standing side-by-side facing forward or staring outward in parallel directions!`,
      `• LOCKED DIRECT EYE-TO-EYE GAZE: While speaking, "${primarySpeaker}" turns their head directly toward ${listenerStr} and locks steady, unbroken eye contact STRAIGHT INTO ${listenerStr}'s face and eyes — NEVER staring off into empty space, at the sky, at the ground, or away from the person they are talking to!`,
      `• ATTENTIVE LISTENER RESPONSE: ${listenerStr} faces "${primarySpeaker}" directly with steady attentive eye contact${
        speakerNames.length >= 2
          ? ', and immediately looks straight back into the other speaker\'s eyes when answering'
          : ''
      }.`,
      `• CLEAR INTERSECTING EYELINES: Frame as an angled face-to-face two-shot or crisp over-the-shoulder shot where both characters' gaze vectors clearly meet eye-to-eye.`
    ];
    return lines.join('\n');
  }

  if (hasCharSpeech && onScreenChars.length === 1) {
    const sp = onScreenChars[0];
    return [
      `[SINGLE-SPEAKER DIALOGUE EYELINE LOCK (MANDATORY — ZERO WANDERING GAZE)]`,
      `• FIXED CONVERSATION EYELINE: "${sp.name}" turns their head and shoulders in a crisp 3/4 angle toward their off-screen conversation partner, keeping a steady, unbroken eye-level gaze locked onto ONE consistent point just beside the camera lens (where the listener stands) throughout the entire spoken line.`,
      `• STRICTLY NO LOOKING AWAY: NEVER let "${sp.name}" stare aimlessly off to the empty side, up at the sky, or down at the ground while speaking to someone, and do NOT look directly into the camera lens.`
    ].join('\n');
  }

  return '';
}

/**
 * Khối Đạo Diễn Chiến Đấu Thực Chiến & Kỹ Xảo Điện Ảnh Hollywood (v2.2)
 * Chống triệt để kỹ xảo neon giả, bay lơ lửng mất trọng lực và đánh trượt không khí;
 * Ưu tiên trọng lượng vật lý thật, 1–2 nhịp va chạm chí mạng, tia lửa hàn rơi theo trọng lực & sóng khí khúc xạ.
 */
function buildCombatChoreographyBlock({
  combatIntensity = 'epic_donghua',
  genreId = 'xianxia_fantasy',
  onScreenChars = [],
  anyWeaponDrawn = false,
  partDurSec = 10
} = {}) {
  const mode = normalizeCombatIntensity(combatIntensity);
  const isXianxia = genreId === 'xianxia_fantasy';
  const fightersStr =
    onScreenChars.length >= 2
      ? onScreenChars.map((c) => `"${c.name}"`).join(' vs ')
      : onScreenChars.length === 1
      ? `"${onScreenChars[0].name}"`
      : 'the combatants';

  if (mode === 'restrained') {
    return [
      `[CONTROLLED MARTIAL CONFRONTATION DIRECTION — ${partDurSec}s SHOT]`,
      `• Direct ${fightersStr} with grounded human biomechanics, tense footwork, crisp decisive blade guard, and razor-sharp eye contact locked on the opponent. ZERO artificial glowing CGI.`
    ].join('\n');
  }

  const antiFakeGuard =
    `• STRICT ANTI-FAKE & ANTI-CHEAP-VFX GUARD (ZERO TOLERANCE): ABSOLUTELY FORBID cheap flat neon laser beams, glowing cartoon aura outlines, colorful video-game magic circles/rune rings, weightless wire-fu floating in mid-air, rubbery bending swords, or stiff air-swinging without real physical contact!`;

  if (mode === 'grounded_martial') {
    return [
      `[GRITTY PHOTOREALISTIC WUXIA / MARTIAL ARTS COMBAT — ${partDurSec}s LIVE-ACTION CINEMA]`,
      `• REALISTIC WEIGHT & CONTACT (BROTHERHOOD OF BLADES / IP MAN STANDARD): Direct ${fightersStr} with 100% physically grounded live-action stunt choreography — real gravity, rooted footwork kicking up dust/gravel, heavy torso torque, and lethal close-quarters blade/fist precision.`,
      `• FOCUSED 2-BEAT IMPACT (NO CHAOTIC PHYSICS BREAKDOWN): Execute ONE explosive forward rush into a brutal steel-on-steel parry lock (visible muscular strain & recoil as real rigid blades grind together showering tiny hot orange sparks that fall naturally with gravity) followed by a razor-fast counter-slash that slices cloth/wood/stone and forces the opponent skidding backward.`,
      antiFakeGuard,
      `• ZERO MAGIC VFX — 100% PRACTICAL PHYSICS: Dust clouds, sweat, whipping wet/heavy silk robes, splintered wood, natural 35mm cinema shutter clarity (180-degree motion blur, crisp faces), and raw metallic clang + heavy footstep + breath foley.`
    ].join('\n');
  }

  if (mode === 'mythic_vfx') {
    return [
      `[HIGH-BUDGET THEATRICAL MYTHIC BATTLE & INTERACTIVE LIGHTING VFX — ${partDurSec}s SHOT]`,
      `• HOLLYWOOD-GRADE VFX REALISM: Direct ${fightersStr} in a monumental high-stakes Xianxia/mythic clash with physically simulated volumetric smoke, realistic crackling lightning or roaring embers/fire that CAST REAL INTERACTIVE LIGHT onto skin, eyes, metallic armor, and wet stone ground.`,
      `• FOCUSED 2-BEAT CLIMAX (WEIGHTY PHYSICS): (1) Coiled stance shattering stone flagstones beneath rooted boots as heavy atmospheric wind pulls debris inward; (2) One colossal decisive weapon/qi collision unleashing a roaring concussive shockwave that blasts real stone chunks, dust plumes, and glowing embers outward past the camera lens!`,
      `• ANTI-CHEAP-CGI RULE: NEVER draw flat 2D neon stickers, rainbow beams, or cartoon glow outlines — every energy effect must have rich volumetric depth, natural motion blur, realistic particles, and genuine physical light bounce on surrounding surfaces.`,
      `• CINEMA CAMERA & SOUND: Grounded low-angle anamorphic camera tracking the momentum with a sharp visceral micro-jolt right at collision; thunderous sub-bass shockwave boom, crackling arcs, steel ring, and crashing stone debris.`
    ].join('\n');
  }

  // epic_donghua (Mặc định v2.2 — Tiên Hiệp Điện Ảnh Thực Tế, chuẩn Trương Nghệ Mưu / Tương Dạ / Hollywood Practical-First VFX)
  return [
    `[PHOTOREALISTIC HIGH-BUDGET XIANXIA / WUXIA COMBAT & PRACTICAL HOLLYWOOD VFX — ${partDurSec}s SHOT (HIGHEST PRIORITY)]`,
    `• REALISTIC WEIGHT, GRAVITY & LETHAL TENSION: Direct ${fightersStr} like a big-budget live-action theatrical martial-arts film (Zhang Yimou's Hero / Shadow / Ever Night aesthetic — real human biomechanics, heavy gravity, real momentum, and visceral physical stakes).`,
    antiFakeGuard,
    `• FOCUSED 2-BEAT HIGH-IMPACT CHOREOGRAPHY (CLEAN, WEIGHTY, NEVER CHAOTIC):`,
    `  1) 0.0s–4.2s EXPLOSIVE GROUNDED ADVANCE: Rooted powerful footstep cracking dust/stone underfoot into a blinding horizontal burst dash (heavy silk robes & hair whipped realistically by air drag), driving ${
      anyWeaponDrawn ? 'the rigid steel signature weapon(s)' : 'a concentrated martial strike'
    } straight into the opponent's guard.`,
    `  2) 4.2s–${partDurSec}.0s BRUTAL DIRECT COLLISION & RECOIL: Hard physical weapon-on-weapon impact with visible muscular weight and resistance — blinding white-orange molten welding sparks erupting from the exact contact point (falling in natural gravity arcs and lighting up both fighters' faces!), followed by an explosive counter-shove sending boots skidding across broken stone tiles amidst billowing dust and debris.`,
    isXianxia
      ? `• PRACTICAL-FIRST XIANXIA QI VFX (80% REAL PHYSICS, 20% SUBTLE ATMOSPHERIC FORCE): Represent sword-qi and inner power NOT as cheap glowing neon beams, but through VISCERAL PHYSICAL FORCES — supersonic transparent air-ripple / heat-haze distortion tearing through mist, rain, or dust; explosive clouds of crushed stone & swirling dry leaves blasted radially outward; subtle pale silver-gold/ember sparks & physically-lit mist glowing naturally on faces and steel blades!`
      : `• PRACTICAL HOLLYWOOD IMPACT PHYSICS: Real incandescent sparks, shattered wood/stone fragments flying across foreground depth-of-field, swirling dust/rain/leaves violently parted by strike pressure, and authentic fabric/hair wind physics.`,
    `• GRITTY ANAMORPHIC ACTION CAMERA: Grounded low-angle 35mm cinema camera moving briskly alongside the fighters' momentum with crisp shutter clarity (no muddy plastic blur, no artificial 360 drone spins), adding a single visceral micro-jolt at the exact millisecond of steel collision while keeping faces sharp and dramatic.`,
    `• VISCERAL REAL-WORLD COMBAT SOUND: Razor-sharp resonant steel clang and blade scrape, heavy whistling air-cut, deep cinematic sub-bass concussive thump on impact, cracking stone, scattering gravel, and whipping wind.`
  ].join('\n');
}

function normalizeFilmConfig(raw = {}) {
  const def = createDefaultFilmConfig();
  if (!raw || typeof raw !== 'object') return def;
  const genreId = VALID_GENRE_IDS.has(raw.genreId) ? raw.genreId : def.genreId;
  const lightingPreset = VALID_LIGHTING_IDS.has(raw.lightingPreset) ? raw.lightingPreset : def.lightingPreset;
  const audioMode = VALID_AUDIO_MODES.has(raw.audioMode) ? raw.audioMode : def.audioMode;
  const continuityMode = VALID_CONTINUITY_MODES.has(raw.continuityMode) ? raw.continuityMode : def.continuityMode;
  const aspectRatio = ['16:9', '21:9', '9:16', '1:1'].includes(raw.aspectRatio) ? raw.aspectRatio : def.aspectRatio;
  const resolution = raw.resolution === '1080p' ? '1080p' : '720p';
  const targetMovieSeconds = Math.max(20, Math.min(7200, Math.round(Number(raw.targetMovieSeconds) || 180)));
  const sceneDurationSeconds = Math.max(5, Math.min(60, Math.round(Number(raw.sceneDurationSeconds) || 10)));
  const concurrency = Math.max(1, Math.min(16, Math.round(Number(raw.concurrency) || 4)));

  return {
    genreId,
    customStylePrompt: typeof raw.customStylePrompt === 'string' ? raw.customStylePrompt.trim().slice(0, 600) : '',
    worldLock: typeof raw.worldLock === 'string' ? raw.worldLock.trim().slice(0, 1000) : '',
    lightingPreset,
    customLightingNote:
      typeof raw.customLightingNote === 'string' ? raw.customLightingNote.trim().slice(0, 500) : '',
    actingStyle: normalizeActingStyle(raw.actingStyle),
    combatIntensity: normalizeCombatIntensity(raw.combatIntensity),
    aspectRatio,
    resolution,
    audioMode,
    narratorVoicePreset: VALID_VOICE_IDS.has(raw.narratorVoicePreset)
      ? raw.narratorVoicePreset
      : def.narratorVoicePreset,
    narratorVoiceNote: typeof raw.narratorVoiceNote === 'string' ? raw.narratorVoiceNote.trim().slice(0, 260) : '',
    continuityMode,
    targetMovieSeconds,
    sceneDurationSeconds,
    concurrency,
    storyDraft: typeof raw.storyDraft === 'string' ? raw.storyDraft.slice(0, 60000) : ''
  };
}

function normalizeCharacterRefImages(rawImages) {
  if (!Array.isArray(rawImages)) return [];
  const bySlot = new Map();
  for (let i = 0; i < rawImages.length; i++) {
    const im = rawImages[i];
    if (!im || typeof im !== 'object' || !im.filePath) continue;
    const explicitSlot = Number(im.slot) === 1 || im.kind === 'weapon' ? 1 : 0;
    const targetSlot = bySlot.has(explicitSlot) && explicitSlot === 0 && !bySlot.has(1) ? 1 : explicitSlot;
    if (targetSlot < MAX_CHAR_REF_IMAGES && !bySlot.has(targetSlot)) {
      bySlot.set(targetSlot, {
        ...im,
        slot: targetSlot,
        kind: targetSlot === 1 ? 'weapon' : 'portrait'
      });
    }
  }
  return Array.from(bySlot.values()).sort((a, b) => a.slot - b.slot);
}

const VALID_WEAPON_LOCK_MODES = new Set(['smart_context', 'always_carry', 'off']);

function normalizeFilmCharacters(rawList) {
  if (!Array.isArray(rawList)) return [];
  const usedTags = new Set();
  const out = [];

  for (let i = 0; i < Math.min(MAX_FILM_CHARACTERS, rawList.length); i++) {
    const item = rawList[i];
    if (!item || typeof item !== 'object') continue;
    const id =
      typeof item.id === 'string' && item.id.trim()
        ? item.id.trim()
        : `char_${Date.now().toString(36)}_${i + 1}`;
    const name = String(item.name || `Nhân vật ${i + 1}`).trim().slice(0, 60) || `Nhân vật ${i + 1}`;
    let tag = sanitizeCharacterTag(item.tag || name, i + 1);
    if (usedTags.has(tag.toLowerCase())) {
      tag = `${tag}_${i + 1}`;
    }
    usedTags.add(tag.toLowerCase());

    const rawWeaponDna = typeof item.weaponDna === 'string' ? item.weaponDna.trim().slice(0, 600) : '';
    const cleanedWeaponDna = /^(none|khong\s*co|không\s*có)$/i.test(rawWeaponDna) ? '' : rawWeaponDna;

    out.push({
      id,
      name,
      tag,
      roleType: item.roleType === 'narrator' ? 'narrator' : 'character',
      appearanceDna: typeof item.appearanceDna === 'string' ? item.appearanceDna.trim().slice(0, 650) : '',
      weaponDna: cleanedWeaponDna,
      weaponLockMode: VALID_WEAPON_LOCK_MODES.has(item.weaponLockMode) ? item.weaponLockMode : 'smart_context',
      voicePreset: VALID_VOICE_IDS.has(item.voicePreset) ? item.voicePreset : 'auto',
      voiceCustomNote: typeof item.voiceCustomNote === 'string' ? item.voiceCustomNote.trim().slice(0, 260) : '',
      referenceImages: normalizeCharacterRefImages(item.referenceImages)
    });
  }
  return out;
}

function detectCharactersInSceneText(text = '', allCharacters = []) {
  if (!text || !Array.isArray(allCharacters) || allCharacters.length === 0) return [];
  const hay = String(text);
  const hayLower = hay.toLowerCase();
  const hayAscii = stripVietnameseAccents(hayLower);
  const matched = [];

  for (const ch of allCharacters) {
    if (!ch) continue;
    const tagLower = String(ch.tag || '').toLowerCase();
    if (tagLower && hayLower.includes(tagLower)) {
      matched.push(ch);
      continue;
    }
    const cleanName = String(ch.name || '').trim();
    if (cleanName.length >= 2) {
      const nameLower = cleanName.toLowerCase();
      if (hayLower.includes(nameLower)) {
        matched.push(ch);
        continue;
      }
      const nameAscii = stripVietnameseAccents(nameLower).trim();
      if (nameAscii.length >= 4 && hayAscii.includes(nameAscii)) {
        matched.push(ch);
      }
    }
  }
  return matched;
}

function normalizeFilmLocations(rawList) {
  if (!Array.isArray(rawList)) return [];
  const usedTags = new Set();
  const out = [];

  for (let i = 0; i < Math.min(MAX_FILM_LOCATIONS, rawList.length); i++) {
    const item = rawList[i];
    if (!item || typeof item !== 'object') continue;
    const id =
      typeof item.id === 'string' && item.id.trim()
        ? item.id.trim()
        : `loc_${Date.now().toString(36)}_${i + 1}`;
    const name = String(item.name || `Bối cảnh ${i + 1}`).trim().slice(0, 70) || `Bối cảnh ${i + 1}`;
    let tag = sanitizeLocationTag(item.tag || name, i + 1);
    if (usedTags.has(tag.toLowerCase())) {
      tag = `${tag}_${i + 1}`;
    }
    usedTags.add(tag.toLowerCase());

    const refList = Array.isArray(item.referenceImages)
      ? item.referenceImages.filter((im) => im && typeof im === 'object' && im.filePath)
      : [];
    const singleRef =
      item.referenceImage && typeof item.referenceImage === 'object' && item.referenceImage.filePath
        ? { ...item.referenceImage, slot: 0 }
        : null;
    const finalRefs = refList.length > 0 ? refList.slice(0, 1).map((im) => ({ ...im, slot: 0 })) : singleRef ? [singleRef] : [];
    const descText = String(item.descriptionDna || item.description || '').trim().slice(0, 700);

    out.push({
      id,
      name,
      tag,
      description: descText,
      descriptionDna: descText,
      referenceImages: finalRefs,
      referenceImage: finalRefs[0] || null
    });
  }
  return out;
}

/* ================= BỘ NHẬN DIỆN VŨ KHÍ THEO NGỮ CẢNH (v1.6) =================
 * Bản cũ bỏ dấu tiếng Việt rồi dò các từ ngắn như "cung", "con", "ten", "no", "dao", "thuong", "kiem"...
 * nên "cùng", "con người", "tên", "nó", "đạo", "thường", "tìm kiếm" đều bị hiểu nhầm là có vũ khí
 * -> gần như cảnh nào nhân vật cũng cầm vũ khí. Bản mới GIỮ NGUYÊN DẤU và chỉ bật vũ khí khi:
 *   (a) có hành động cầm/rút/vung + tên binh khí (VD: "rút thanh kiếm", "vung cây đại đao"), hoặc
 *   (b) có từ chiến đấu rõ ràng (giao chiến, xuất chiêu, chém, giương cung...), hoặc
 *   (c) nhắc đúng tên riêng của vũ khí trong mô tả vũ khí cố định.
 * Các cụm cất vũ khí / tay không ("cất kiếm", "tra kiếm vào vỏ", "hạ vũ khí", "tay không") được loại ra trước.
 */
const WEAPON_STATE_DRAWN = 'drawn';
const WEAPON_STATE_CARRIED = 'carried';
const WEAPON_STATE_NONE = 'none';
const VALID_SCENE_WEAPON_MODES = new Set(['auto', 'drawn', 'none']);

/** v1.7: Tính năng Vũ khí / Pháp bảo CHỈ dùng cho thể loại Tiên Hiệp / Huyền Huyễn. Thể loại khác bỏ qua hoàn toàn. */
const WEAPON_ENABLED_GENRES = new Set(['xianxia_fantasy']);
function isWeaponGenre(genreId) {
  return WEAPON_ENABLED_GENRES.has(String(genreId || '').trim());
}

const VI_L = '\\p{L}\\p{N}';
const viBound = (inner) => `(?<![${VI_L}])(?:${inner})(?![${VI_L}])`;

const WEAPON_NOUNS =
  'bảo kiếm|thần kiếm|tiên kiếm|trường kiếm|đoản kiếm|song kiếm|kiếm|đại đao|bảo đao|loan đao|trường đao|đao|mã tấu|' +
  'trường thương|ngân thương|thương|giáo|mác|kích|trường côn|côn|thiền trượng|trượng|gậy|' +
  'cung(?!\\s+(?:điện|nữ|đình|thành|cấm|phi|tần|kính|cấp|đường|khai|ứng|cấp|tử|chủ|văn|trăng|đàn))|' +
  'nỏ|búa|rìu|cự xích|xích|roi|khiên|chủy thủ|dao găm|vũ khí|binh khí|pháp bảo|thần binh|ám khí|phi tiêu|thiết phiến|lưỡi hái|súng';
const WEAPON_VERBS =
  'rút ra|rút|tuốt|vung|múa|cầm lấy|cầm chặt|cầm|nắm chặt|nắm|siết chặt|siết|giơ|chĩa|kề|vác|giương|kéo căng|' +
  'luyện|tế ra|tế|triệu hồi|gọi ra|lấy ra|chém|đâm|bổ|phóng|ném|quất|xoay|lăm lăm|thủ thế với';
const WEAPON_FILLERS =
  'thanh|cây|chiếc|ngọn|cặp|đôi|bộ|cái|mũi|lưỡi|lá|cánh|của|mình|hắn|nàng|chàng|y|gã|ra|lên|chặt|lấy|mạnh|nhanh|vội|' +
  'thật|vào|bên|hông|sau|lưng|trong|trên|tay|ở|sẵn|một|hai';

const WEAPON_HANDLE_RE = new RegExp(
  viBound(`(?:${WEAPON_VERBS})(?:\\s+(?:${WEAPON_FILLERS})){0,3}\\s+(?:${WEAPON_NOUNS})`),
  'iu'
);
const WEAPON_STRONG_TERMS_RE = new RegExp(
  viBound(
    [
      'vũ khí', 'binh khí', 'pháp bảo', 'thần binh', 'ám khí', 'phi tiêu', 'chủy thủ', 'dao găm', 'binh đao',
      'chém(?!\\s+gió)', 'giao chiến', 'chiến đấu', 'quyết chiến', 'tử chiến', 'ác chiến', 'huyết chiến', 'kịch chiến',
      'đại chiến', 'xung trận', 'ra trận', 'xuất chiêu', 'tung chiêu', 'ra chiêu', 'xuất kiếm', 'kiếm chiêu',
      'kiếm pháp', 'đao pháp', 'thương pháp', 'côn pháp', 'kiếm khí', 'đao khí', 'kiếm quang', 'đao quang',
      'tấn công', 'công kích', 'phản công', 'đỡ đòn', 'gạt đòn', 'chặn đòn', 'đỡ chiêu', 'đấu kiếm', 'so kiếm',
      'tỉ thí', 'tỷ thí', 'giao đấu', 'giao thủ', 'lôi đài', 'múa kiếm', 'luyện kiếm', 'mũi tên', 'bắn tên',
      'phóng tên', 'giương cung', 'kéo cung', 'cung tên', 'bắn cung', 'nổ súng', 'bóp cò'
    ].join('|')
  ),
  'iu'
);
const WEAPON_STRONG_EN_RE =
  /\b(weapons?|swords?|spears?|daggers?|axes?|arrows?|unsheath\w*|draws? (?:his|her|the|a) (?:sword|blade|weapon|bow|spear|saber)|wield\w*|brandish\w*|slash\w*|stab\w*|parr(?:y|ies|ied)|duel\w*|battle|combat|sword ?fight\w*|attack\w*|fights?|fighting)\b/i;
const WEAPON_AWAY_RE = new RegExp(
  viBound(
    [
      `(?:cất|tra|thu|buông|hạ|vứt|bỏ|ném bỏ|giấu)(?:\\s+(?:${WEAPON_FILLERS})){0,3}\\s+(?:${WEAPON_NOUNS})(?:\\s+vào\\s+vỏ)?`,
      'tay không(?:\\s+tấc\\s+sắt)?',
      'không (?:mang|cầm|dùng|đeo|có) (?:theo )?(?:vũ khí|binh khí|kiếm|đao)',
      'tra vào vỏ'
    ].join('|')
  ),
  'giu'
);
const WEAPON_AWAY_EN_RE = /\b(sheath(?:e|es|ed|ing)?\b(?! ?off)|puts? away (?:his|her|the) \w+|unarmed|empty[- ]handed|bare[- ]handed)/gi;

function splitSceneSentences(text = '') {
  return String(text || '')
    .split(/[.!?;…\n]+|\s\/\s/)
    .map((s) => s.trim())
    .filter(Boolean);
}

function characterHasSignatureWeapon(character) {
  if (!character || character.roleType === 'narrator') return false;
  if ((character.weaponLockMode || 'smart_context') === 'off') return false;
  const weaponDna = String(character.weaponDna || '').trim();
  const hasWeaponRefImg = Array.isArray(character.referenceImages)
    ? character.referenceImages.some((im) => im && Number(im.slot) === 1 && im.filePath)
    : false;
  return Boolean(weaponDna || hasWeaponRefImg);
}

/** Các cụm tên riêng của vũ khí (giữ nguyên dấu) để nhận ra khi kịch bản gọi đích danh vũ khí. */
function extractWeaponNamePhrases(weaponDna = '') {
  const dna = String(weaponDna || '').toLowerCase();
  if (!dna) return [];
  const stop = new Set([
    'thanh', 'cây', 'chiếc', 'ngọn', 'đôi', 'cặp', 'màu', 'đen', 'trắng', 'xanh', 'vàng', 'bạc', 'đỏ', 'dài', 'rộng',
    'bản', 'mũi', 'chuôi', 'cán', 'thân', 'hình', 'không', 'nhọn', 'kim', 'loại', 'ánh', 'sáng', 'của', 'cầm', 'tay',
    'một', 'hai', 'có', 'cố', 'định', 'duy', 'nhất', 'và', 'với', 'bằng', 'được', 'khắc', 'vân', 'gỗ', 'sắt', 'thép',
    'đồng', 'phẳng', 'cong', 'thẳng', 'nhám', 'bóng', 'khoảng', 'mét', 'cm', 'lưỡi', 'là', 'rất', 'nặng', 'nhẹ'
  ]);
  const words = dna
    .replace(/[^\p{L}\p{N}\s]+/gu, ' ')
    .split(/\s+/)
    .filter(Boolean);
  const phrases = [];
  for (let i = 0; i < words.length - 1; i++) {
    const a = words[i];
    const b = words[i + 1];
    if (stop.has(a) || stop.has(b) || a.length < 2 || b.length < 2) continue;
    if (/^\d/.test(a) || /^\d/.test(b)) continue;
    phrases.push(`${a} ${b}`);
  }
  return Array.from(new Set(phrases)).slice(0, 24);
}

function sentenceMentionsCharacter(sentence, character) {
  if (!sentence || !character) return false;
  const low = sentence.toLowerCase();
  const tagLower = String(character.tag || '').toLowerCase();
  if (tagLower && low.includes(tagLower)) return true;
  const nameLower = String(character.name || '').trim().toLowerCase();
  if (nameLower.length >= 2 && low.includes(nameLower)) return true;
  return false;
}

/**
 * Xác định trạng thái vũ khí của TỪNG nhân vật trong 1 phân cảnh:
 *  - 'drawn'   : đang cầm / sử dụng vũ khí (đính kèm ảnh vũ khí + khóa hình học)
 *  - 'carried' : chỉ mang theo nhưng KHÔNG cầm trên tay (vỏ kiếm ở hông / sau lưng)
 *  - 'none'    : hoàn toàn không xuất hiện vũ khí, tay để tự nhiên
 * sceneWeaponMode (đặt riêng trên từng thẻ cảnh): 'auto' | 'drawn' | 'none'
 */
function resolveSceneWeaponStates({ sceneText = '', sceneCharacters = [], sceneWeaponMode = 'auto', genreId = null } = {}) {
  const states = {};
  // genreId được truyền vào mà không phải Tiên Hiệp / Huyền Huyễn -> tắt hoàn toàn vũ khí
  if (genreId !== null && genreId !== undefined && !isWeaponGenre(genreId)) return states;
  const armedChars = (Array.isArray(sceneCharacters) ? sceneCharacters : []).filter(characterHasSignatureWeapon);
  if (armedChars.length === 0) return states;

  const idleStateFor = (ch) => (ch.weaponLockMode === 'always_carry' ? WEAPON_STATE_CARRIED : WEAPON_STATE_NONE);
  const mode = VALID_SCENE_WEAPON_MODES.has(sceneWeaponMode) ? sceneWeaponMode : 'auto';

  if (mode === 'drawn') {
    for (const ch of armedChars) states[ch.id] = WEAPON_STATE_DRAWN;
    return states;
  }
  if (mode === 'none') {
    for (const ch of armedChars) states[ch.id] = idleStateFor(ch);
    return states;
  }

  // Loại bỏ các cụm "cất kiếm / tay không / hạ vũ khí" trước khi dò hành động rút vũ khí
  const cleanedText = String(sceneText || '')
    .replace(WEAPON_AWAY_RE, ' ')
    .replace(WEAPON_AWAY_EN_RE, ' ');

  const isCombatText = (s) => WEAPON_HANDLE_RE.test(s) || WEAPON_STRONG_TERMS_RE.test(s) || WEAPON_STRONG_EN_RE.test(s);
  const sentences = splitSceneSentences(cleanedText);

  // Tên riêng vũ khí (VD: "Huyền Trọng Xích") nhắc trong cảnh -> chủ nhân rút vũ khí
  const namedWeaponOwners = new Set();
  const lowAll = cleanedText.toLowerCase();
  for (const ch of armedChars) {
    const phrases = extractWeaponNamePhrases(ch.weaponDna);
    if (phrases.some((p) => lowAll.includes(p))) namedWeaponOwners.add(ch.id);
  }

  // Gán đúng người dùng vũ khí theo từng vế câu: "Lâm Phong rút kiếm lao tới, Tô Nguyệt lùi lại quan sát"
  // -> chỉ Lâm Phong cầm vũ khí. Vế không nêu tên sẽ kế thừa chủ ngữ của vế trước trong cùng câu.
  // Nếu không câu chiến đấu nào nêu tên ai (thường là cảnh 1 người) -> áp dụng cho mọi nhân vật có vũ khí.
  const mentionedFighters = new Set();
  let anyCombat = false;
  for (const s of sentences) {
    const clauses = s.split(/,|\s(?:rồi|và|nhưng|trong khi|còn|thì)\s/).map((c) => c.trim()).filter(Boolean);
    let subject = [];
    for (const clause of clauses) {
      const mentioned = armedChars.filter((ch) => sentenceMentionsCharacter(clause, ch));
      const mentionedAny = (Array.isArray(sceneCharacters) ? sceneCharacters : []).some((ch) =>
        sentenceMentionsCharacter(clause, ch)
      );
      if (mentionedAny) subject = mentioned;
      if (isCombatText(clause)) {
        anyCombat = true;
        for (const ch of subject) mentionedFighters.add(ch.id);
      }
    }
  }

  for (const ch of armedChars) {
    let drawn = namedWeaponOwners.has(ch.id);
    if (!drawn && anyCombat) {
      drawn = mentionedFighters.size > 0 ? mentionedFighters.has(ch.id) : true;
    }
    states[ch.id] = drawn ? WEAPON_STATE_DRAWN : idleStateFor(ch);
  }
  return states;
}

/** Giữ tương thích ngược: true khi nhân vật thực sự CẦM vũ khí trong cảnh này. */
function doesSceneInvolveCharacterWeapon(sceneText = '', character = null, sceneCharacters = null, sceneWeaponMode = 'auto') {
  if (!characterHasSignatureWeapon(character)) return false;
  const pool = Array.isArray(sceneCharacters) && sceneCharacters.length > 0 ? sceneCharacters : [character];
  const states = resolveSceneWeaponStates({ sceneText, sceneCharacters: pool, sceneWeaponMode });
  return states[character.id] === WEAPON_STATE_DRAWN;
}

function detectLocationInSceneText(text, allLocations = []) {
  if (!text || !Array.isArray(allLocations) || allLocations.length === 0) return null;
  const hay = stripVietnameseAccents(String(text || '').toLowerCase());

  for (const loc of allLocations) {
    if (!loc) continue;
    const tagNorm = loc.tag.toLowerCase();
    if (hay.includes(tagNorm)) return loc;
    const nameNorm = stripVietnameseAccents(loc.name.toLowerCase()).trim();
    if (nameNorm.length >= 4 && hay.includes(nameNorm)) {
      return loc;
    }
  }
  return null;
}

function resolveSceneLocation(row, allLocations = []) {
  if (!Array.isArray(allLocations) || allLocations.length === 0) return null;
  if (row?.sceneLocationId) {
    const found = allLocations.find((l) => l.id === row.sceneLocationId);
    if (found) return found;
  }
  return detectLocationInSceneText(`${row?.sceneTitle || ''}\n${row?.prompt || ''}`, allLocations);
}

function resolveSceneCharacters(row, allCharacters = []) {
  if (!Array.isArray(allCharacters) || allCharacters.length === 0) return [];
  const byId = new Map(allCharacters.map((c) => [c.id, c]));
  const ordered = [];
  const seen = new Set();

  const explicitIds = Array.isArray(row?.sceneCharacterIds)
    ? row.sceneCharacterIds
    : Array.isArray(row?.characterIds)
    ? row.characterIds
    : [];

  for (const cid of explicitIds) {
    const found = byId.get(cid);
    if (found && !seen.has(found.id)) {
      seen.add(found.id);
      ordered.push(found);
    }
  }

  const combinedText = `${row?.prompt || ''}\n${row?.dialogue || ''}`;
  const autoFound = detectCharactersInSceneText(combinedText, allCharacters);
  for (const ch of autoFound) {
    if (!seen.has(ch.id)) {
      seen.add(ch.id);
      ordered.push(ch);
    }
  }
  return ordered;
}

function parseSceneMultiSpeakerLines(rawDialogue, allCharacters = []) {
  const clean = String(rawDialogue || '').trim();
  if (!clean) return [];

  const lines = clean
    .split(/\r?\n|\s+\/\s+(?=(?:\[[^\]]+\]|@[a-zA-Z0-9_]+)\s*:)/)
    .map((l) => l.trim())
    .filter(Boolean);

  const parsed = [];
  for (const line of lines) {
    const m = line.match(/^(?:\[([^\]]+)\]|(@[a-zA-Z0-9_]+)|([^:"“”]{1,28}))\s*:\s*(.+)$/);
    if (m) {
      const rawSpeaker = String(m[1] || m[2] || m[3] || '').trim();
      const text = String(m[4] || '')
        .replace(/^[“"«]+|[”"»]+$/g, '')
        .trim();
      if (!text) continue;

      const speakerNorm = stripVietnameseAccents(rawSpeaker.toLowerCase()).replace(/^@+/, '').trim();
      const isNarrator =
        /^(dan\s*chuyen|nguoi\s*dan|nguoi\s*ke|thuyet\s*minh|narrator|voiceover|vo|ke\s*chuyen)$/i.test(
          speakerNorm
        );

      if (isNarrator) {
        parsed.push({ type: 'narrator', speakerLabel: 'Người dẫn chuyện', character: null, text });
        continue;
      }

      let matchedChar = null;
      for (const ch of allCharacters) {
        const chTagClean = stripVietnameseAccents(ch.tag.toLowerCase()).replace(/^@+/, '');
        const chNameClean = stripVietnameseAccents(ch.name.toLowerCase()).trim();
        if (speakerNorm === chTagClean || speakerNorm === chNameClean || chNameClean.includes(speakerNorm)) {
          matchedChar = ch;
          break;
        }
      }

      if (matchedChar && matchedChar.roleType === 'narrator') {
        parsed.push({ type: 'narrator', speakerLabel: matchedChar.name, character: matchedChar, text });
      } else {
        parsed.push({
          type: 'character',
          speakerLabel: matchedChar ? matchedChar.name : rawSpeaker,
          character: matchedChar,
          text
        });
      }
    } else {
      const cleanSpeech = line.replace(/^[“"«]+|[”"»]+$/g, '').trim();
      if (cleanSpeech) {
        parsed.push({ type: 'default', speakerLabel: '', character: null, text: cleanSpeech });
      }
    }
  }
  return parsed;
}

function buildSceneCastReferenceImages({
  sceneCharacters = [],
  sceneLocation = null,
  rowReferenceImages = [],
  prevSceneLastFramePath = null,
  scenePrompt = '',
  sceneTitle = '',
  sceneDialogue = '',
  sceneWeaponMode = 'auto',
  weaponStates = null,
  genreId = null,
  tempDir = null,
  rowIndex = 1
}) {
  const maxTotalSlots = 5;
  const needPrevSceneSlot = Boolean(prevSceneLastFramePath && fs.existsSync(prevSceneLastFramePath));
  const maxCastAndRowSlots = needPrevSceneSlot ? maxTotalSlots - 1 : maxTotalSlots;
  const combinedSceneText = `${sceneTitle || ''}\n${scenePrompt || ''}\n${sceneDialogue || ''}`;
  const weaponsEnabled = genreId === null || genreId === undefined || isWeaponGenre(genreId);
  const resolvedWeaponStates = !weaponsEnabled
    ? {}
    : weaponStates && typeof weaponStates === 'object'
    ? weaponStates
    : resolveSceneWeaponStates({ sceneText: combinedSceneText, sceneCharacters, sceneWeaponMode });
  const isWeaponDrawn = (ch) => resolvedWeaponStates[ch.id] === WEAPON_STATE_DRAWN;

  const selected = [];
  const usedFilePaths = new Set();

  // 1. Ưu tiên ảnh bối cảnh riêng gắn trực tiếp trên cảnh (nếu có)
  const validRowImgs = (Array.isArray(rowReferenceImages) ? rowReferenceImages : []).filter(
    (im) => im && im.filePath && fs.existsSync(im.filePath)
  );
  for (const rim of validRowImgs) {
    if (selected.length >= Math.min(1, maxCastAndRowSlots)) break;
    const norm = path.resolve(rim.filePath).toLowerCase();
    if (!usedFilePaths.has(norm)) {
      usedFilePaths.add(norm);
      selected.push({ ...rim, role: 'scene_environment_or_prop' });
    }
  }

  // 2. Nếu chưa gắn ảnh bối cảnh lẻ mà cảnh này thuộc 1 Bối Cảnh Khóa Chung (Location Lock) có ảnh phim trường gốc -> tự động đính kèm!
  const locImgCandidate =
    sceneLocation?.referenceImages?.[0] || sceneLocation?.referenceImage || null;
  if (
    validRowImgs.length === 0 &&
    locImgCandidate &&
    locImgCandidate.filePath &&
    fs.existsSync(locImgCandidate.filePath) &&
    selected.length < maxCastAndRowSlots
  ) {
    const locImg = locImgCandidate;
    const normLoc = path.resolve(locImg.filePath).toLowerCase();
    if (!usedFilePaths.has(normLoc)) {
      let locTargetPath = locImg.filePath;
      let locTargetName = locImg.savedName || locImg.fileName || `Set_${sceneLocation.tag.replace('#', '')}.png`;
      if (tempDir && fs.existsSync(tempDir)) {
        const ext = path.extname(locImg.filePath) || '.png';
        const cleanLocTag = sceneLocation.tag.replace(/[^a-zA-Z0-9_]/g, '');
        locTargetName = `MasterSet_${cleanLocTag}_Scene${String(rowIndex).padStart(2, '0')}${ext}`;
        const copyDest = path.join(tempDir, locTargetName);
        try {
          fs.copyFileSync(locImg.filePath, copyDest);
          locTargetPath = copyDest;
        } catch (_) {}
      }
      usedFilePaths.add(normLoc);
      selected.push({
        filePath: locTargetPath,
        savedName: locTargetName,
        fileName: locTargetName,
        publicUrl: locImg.publicUrl,
        role: 'locked_film_location',
        locationId: sceneLocation.id,
        locationName: sceneLocation.name,
        locationTag: sceneLocation.tag,
        locationDesc: sceneLocation.descriptionDna || sceneLocation.description || ''
      });
    }
  }

  // 3. Đính kèm Ảnh Nhân Vật Gốc (Slot 0) cho từng diễn viên xuất hiện trong cảnh
  const onScreenChars = sceneCharacters.filter((c) => c && c.roleType !== 'narrator');
  for (const ch of onScreenChars) {
    if (selected.length >= maxCastAndRowSlots) break;
    const charImgs = Array.isArray(ch.referenceImages)
      ? ch.referenceImages.filter((im) => im && im.filePath && fs.existsSync(im.filePath))
      : [];
    const primaryImg = charImgs.find((im) => Number(im.slot || 0) === 0) || null;
    if (!primaryImg) continue;

    const weaponActive = isWeaponDrawn(ch);
    const weaponState = resolvedWeaponStates[ch.id] || WEAPON_STATE_NONE;
    const resolvedPrimary = path.resolve(primaryImg.filePath).toLowerCase();
    if (!usedFilePaths.has(resolvedPrimary)) {
      let targetPath = primaryImg.filePath;
      let targetName = primaryImg.savedName || primaryImg.fileName || `${ch.tag.replace('@', '')}.png`;
      if (tempDir && fs.existsSync(tempDir)) {
        const ext = path.extname(primaryImg.filePath) || '.png';
        const cleanTag = ch.tag.replace(/[^a-zA-Z0-9_]/g, '');
        targetName = `Cast_${selected.length + 1}_${cleanTag}_Scene${String(rowIndex).padStart(2, '0')}${ext}`;
        const copyDest = path.join(tempDir, targetName);
        try {
          fs.copyFileSync(primaryImg.filePath, copyDest);
          targetPath = copyDest;
        } catch (_) {}
      }
      usedFilePaths.add(resolvedPrimary);
      selected.push({
        filePath: targetPath,
        savedName: targetName,
        fileName: targetName,
        publicUrl: primaryImg.publicUrl,
        role: 'film_cast_character',
        characterId: ch.id,
        characterName: ch.name,
        characterTag: ch.tag,
        characterDna: ch.appearanceDna || '',
        weaponDna: ch.weaponDna || '',
        weaponActive,
        weaponState
      });
    }
  }

  // 4. Đính kèm Ảnh Vũ Khí / Pháp Bảo Cố Định (Slot 1) CHỈ KHI nhân vật thực sự cầm / dùng vũ khí trong cảnh này
  if (selected.length < maxCastAndRowSlots) {
    for (const ch of onScreenChars) {
      if (selected.length >= maxCastAndRowSlots) break;
      if (!isWeaponDrawn(ch)) continue;

      const charImgs = Array.isArray(ch.referenceImages)
        ? ch.referenceImages.filter((im) => im && im.filePath && fs.existsSync(im.filePath))
        : [];
      const weaponImg = charImgs.find((im) => Number(im.slot) === 1) || null;
      if (!weaponImg) continue;

      const resolvedWep = path.resolve(weaponImg.filePath).toLowerCase();
      if (!usedFilePaths.has(resolvedWep)) {
        let wepTargetPath = weaponImg.filePath;
        let wepTargetName = weaponImg.savedName || weaponImg.fileName || `Weapon_${ch.tag.replace('@', '')}.png`;
        if (tempDir && fs.existsSync(tempDir)) {
          const ext = path.extname(weaponImg.filePath) || '.png';
          const cleanTag = ch.tag.replace(/[^a-zA-Z0-9_]/g, '');
          wepTargetName = `Weapon_${selected.length + 1}_${cleanTag}_Scene${String(rowIndex).padStart(2, '0')}${ext}`;
          const copyDest = path.join(tempDir, wepTargetName);
          try {
            fs.copyFileSync(weaponImg.filePath, copyDest);
            wepTargetPath = copyDest;
          } catch (_) {}
        }
        usedFilePaths.add(resolvedWep);
        selected.push({
          filePath: wepTargetPath,
          savedName: wepTargetName,
          fileName: wepTargetName,
          publicUrl: weaponImg.publicUrl,
          role: 'character_signature_weapon',
          characterId: ch.id,
          characterName: ch.name,
          characterTag: ch.tag,
          weaponDna: ch.weaponDna || ''
        });
      }
    }
  }

  if (needPrevSceneSlot) {
    selected.push({
      filePath: prevSceneLastFramePath,
      savedName: path.basename(prevSceneLastFramePath),
      fileName: path.basename(prevSceneLastFramePath),
      role: 'prev_scene_last_frame'
    });
  }

  return selected;
}

/* ================= NGÔN NGỮ MÁY QUAY THEO TỪNG CẢNH (v1.8) ================= */
const SHOT_SIZE_PRESETS = [
  { id: 'auto', label: '🤖 Tự động (Đạo diễn chọn)', directive: '' },
  { id: 'extreme_wide', label: '🏔️ Toàn cảnh rộng (mở đầu)', directive: 'EXTREME WIDE ESTABLISHING SHOT — characters appear small inside the vast environment; clearly establish geography, scale, and atmosphere.' },
  { id: 'wide', label: '🌄 Toàn cảnh (thấy cả người)', directive: 'WIDE SHOT — full bodies visible head-to-toe with generous surrounding environment.' },
  { id: 'medium_wide', label: '🧍 Trung toàn (từ gối)', directive: 'MEDIUM WIDE SHOT — framed from the knees up, leaving room for body language, movement, and action.' },
  { id: 'medium', label: '👤 Trung cảnh (từ thắt lưng)', directive: 'MEDIUM SHOT — framed from the waist up, natural conversational framing.' },
  { id: 'medium_close', label: '🙂 Cận trung (từ ngực)', directive: 'MEDIUM CLOSE-UP — framed from the chest up, focus on facial expression while keeping some costume visible.' },
  { id: 'close_up', label: '😮 Cận mặt (cảm xúc)', directive: 'CLOSE-UP — the face fills most of the frame; capture subtle, restrained emotion mainly in the eyes, with relaxed natural facial muscles and shallow depth of field.' },
  { id: 'extreme_close', label: '👁️ Đặc tả (mắt / tay / vật)', directive: 'EXTREME CLOSE-UP — isolate one powerful detail (eyes, trembling hand, key object) filling the frame.' },
  { id: 'over_shoulder', label: '🗣️ Qua vai (đối thoại)', directive: 'OVER-THE-SHOULDER SHOT — shoot past the blurred foreground shoulder of the listener straight toward the face of the speaker; the speaker looks directly past the camera edge straight into the foreground listener\'s eyes with tight locked eye-to-eye alignment (NEVER gazing off to empty side space).' },
  { id: 'two_shot', label: '👥 Hai người cùng khung', directive: 'FACE-TO-FACE TWO-SHOT — frame both characters angled DIRECTLY TOWARD EACH OTHER (left character facing right, right character facing left) making steady direct eye-to-eye contact as they interact (NEVER standing parallel side-by-side staring off into empty space).' },
  { id: 'pov', label: '👀 Góc nhìn nhân vật (POV)', directive: 'POINT-OF-VIEW SHOT — the camera is the eyes of the main character, natural eye-level perspective.' },
  { id: 'low_angle', label: '⬆️ Góc thấp (uy lực)', directive: 'LOW-ANGLE SHOT — camera below eye level looking up, making the subject look powerful, heroic, or threatening.' },
  { id: 'high_angle', label: '⬇️ Góc cao (nhỏ bé)', directive: 'HIGH-ANGLE SHOT — camera above looking down, making the subject look small, vulnerable, or overwhelmed.' },
  { id: 'aerial', label: '🚁 Flycam trên cao', directive: 'AERIAL DRONE SHOT — high bird\'s-eye view over the landscape or location.' }
];

const CAMERA_MOVE_PRESETS = [
  { id: 'auto', label: '🤖 Tự động', directive: '' },
  { id: 'static', label: '📌 Máy đứng yên', directive: 'LOCKED-OFF STATIC CAMERA on a tripod — no camera movement, let the acting carry the shot.' },
  { id: 'slow_push_in', label: '➡️ Đẩy máy chậm vào', directive: 'SLOW PUSH-IN — the camera dollies gently toward the subject to build intensity or intimacy.' },
  { id: 'pull_out', label: '⬅️ Lùi máy ra (hé lộ)', directive: 'SLOW PULL-OUT — the camera dollies back to gradually reveal the wider surroundings.' },
  { id: 'pan', label: '↔️ Lia ngang', directive: 'SMOOTH HORIZONTAL PAN — stabilized pan across the scene, following the action or revealing the space.' },
  { id: 'tilt', label: '↕️ Lia dọc', directive: 'SMOOTH VERTICAL TILT — tilt up or down to reveal height, scale, or a character from feet to face.' },
  { id: 'tracking', label: '🏃 Bám theo nhân vật', directive: 'TRACKING SHOT — the camera moves alongside / behind the character on a stabilized gimbal, matching their motion.' },
  { id: 'dynamic_action', label: '⚡ Hành động thực chiến (bám lực đánh + rung chấn)', directive: 'GRITTY LIVE-ACTION CINEMA TRACKING — grounded low-angle 35mm camera moving dynamically alongside the fighters\' physical momentum with crisp shutter clarity and a single visceral micro-jolt right at heavy steel impact (NEVER dizzying 360 drone spins or weightless video-game camera).' },
  { id: 'orbit', label: '🔄 Xoay quanh nhân vật', directive: 'ORBITING ARC SHOT — the camera circles smoothly around the subject for a dramatic hero moment.' },
  { id: 'handheld', label: '✋ Cầm tay (căng thẳng)', directive: 'HANDHELD CAMERA — subtle organic shake for urgency, tension, or chaos (never nauseating).' },
  { id: 'crane_up', label: '🏗️ Cần cẩu nâng lên', directive: 'CRANE UP — the camera rises smoothly upward revealing the epic scale of the scene.' },
  { id: 'drone_glide', label: '🚁 Flycam lướt', directive: 'DRONE GLIDE — slow, majestic forward aerial glide over the environment.' },
  { id: 'subtle_drift', label: '🌫️ Trôi nhẹ tự nhiên', directive: 'SUBTLE CINEMATIC DRIFT — very slow, barely noticeable floating camera movement that keeps the frame alive.' }
];

const SHOT_SIZE_MAP = new Map(SHOT_SIZE_PRESETS.map((s) => [s.id, s]));
const CAMERA_MOVE_MAP = new Map(CAMERA_MOVE_PRESETS.map((m) => [m.id, m]));

function normalizeShotSize(v) {
  return SHOT_SIZE_MAP.has(v) ? v : 'auto';
}
function normalizeCameraMove(v) {
  return CAMERA_MOVE_MAP.has(v) ? v : 'auto';
}

const SHOT_EMOTION_RE = new RegExp(
  viBound(
    'khóc|nước mắt|rưng rưng|nghẹn ngào|thì thầm|run rẩy|tuyệt vọng|xúc động|đau đớn|mỉm cười|ôm chầm|ôm lấy|nhìn nhau|ánh mắt|sững sờ|bàng hoàng|hoảng sợ|giận dữ|nghiến răng|thổn thức|tim đập'
  ),
  'iu'
);
const SHOT_SCENIC_RE = new RegExp(
  viBound(
    'toàn cảnh|bầu trời|núi non|đỉnh núi|dãy núi|biển cả|mặt biển|thành phố|kinh thành|cánh đồng|hoàng hôn|bình minh|khu rừng|thung lũng|sông|vũ trụ|tầng mây|cung điện|thành trì|làng quê|đoàn quân|chiến trường'
  ),
  'iu'
);
const SHOT_ACTION_RE = new RegExp(
  viBound('chạy|lao tới|lao vào|lao lên|rượt|đuổi theo|bay vút|phi thân|nhảy|né|tung người|xông|truy đuổi|bỏ chạy|vội vã'),
  'iu'
);
const SHOT_POWER_RE = new RegExp(
  viBound('uy nghiêm|bá khí|uy áp|đăng cơ|xuất hiện|giáng lâm|hiên ngang|ngạo nghễ|thống lĩnh|sừng sững|khổng lồ|ma vương|thần long'),
  'iu'
);
const SHOT_PEOPLE_HINT_RE = new RegExp(
  viBound(
    'người|cô gái|chàng trai|thiếu nữ|thiếu niên|cô bé|cậu bé|cô ấy|anh ấy|nàng|chàng|hắn|lão|ông lão|bà lão|nhân vật|đứa trẻ|em bé|vị|tướng quân|hoàng tử|công chúa|vua|sư phụ|đệ tử|hai người|cả nhóm|he|she|they|man|woman|girl|boy'
  ),
  'iu'
);

/**
 * Đạo diễn tự chọn cỡ cảnh & chuyển động máy cho cảnh để bộ phim có nhịp điệu điện ảnh
 * (toàn cảnh mở đầu -> trung cảnh đối thoại -> cận mặt khi cảm xúc dâng -> bám theo khi hành động).
 */
function inferAutoShotPlan({
  sceneText = '',
  onScreenCount = 0,
  dialogueLineCount = 0,
  hasCharacterDialogue = false,
  isFirstScene = false,
  isNewSetup = false,
  hasCombat = false,
  prevShotSize = '',
  sceneIndex = 1
} = {}) {
  const text = String(sceneText || '');
  let shotSize = 'medium';
  let cameraMove = 'subtle_drift';
  let reason = 'Trung cảnh mặc định';

  if (onScreenCount === 0) {
    shotSize = SHOT_SCENIC_RE.test(text) ? 'aerial' : 'extreme_wide';
    cameraMove = shotSize === 'aerial' ? 'drone_glide' : 'pan';
    reason = 'Cảnh không có nhân vật → toàn cảnh / flycam';
  } else if (hasCombat || SHOT_ACTION_RE.test(text)) {
    // Luân phiên 3 góc quay thực chiến điện ảnh chắc tay (tránh orbit/xoay 360 dễ làm trôi chân & giả vật lý trên AI)
    const combatCycle = [
      { shot: 'medium_wide', move: 'dynamic_action', note: 'Chiến đấu → trung toàn + máy bám lực đánh & rung chấn' },
      { shot: 'low_angle', move: 'handheld', note: 'Chiến đấu → góc thấp cầm tay tăng sức nặng đòn đánh' },
      { shot: 'medium_close', move: 'tracking', note: 'Chiến đấu → cận trung bám sát thép chạm nhau tóe lửa' }
    ];
    let picked = combatCycle[Math.abs(Number(sceneIndex) - 1) % combatCycle.length];
    if (prevShotSize && prevShotSize === picked.shot) {
      picked = combatCycle[Math.abs(Number(sceneIndex)) % combatCycle.length];
    }
    shotSize = picked.shot;
    cameraMove = hasCombat ? picked.move : 'tracking';
    reason = picked.note;
  } else if (SHOT_EMOTION_RE.test(text)) {
    shotSize = 'close_up';
    cameraMove = 'slow_push_in';
    reason = 'Cảm xúc dâng cao → cận mặt + đẩy máy chậm';
  } else if (SHOT_POWER_RE.test(text)) {
    shotSize = 'low_angle';
    cameraMove = 'crane_up';
    reason = 'Khoảnh khắc uy lực → góc thấp';
  } else if (onScreenCount >= 2 && hasCharacterDialogue && !isFirstScene) {
    // Ưu tiên góc đối mặt trực tiếp khi 2+ nhân vật đối thoại (không để từ khóa núi/cung điện kéo máy ra xa)
    shotSize = prevShotSize === 'over_shoulder' ? 'two_shot' : dialogueLineCount >= 2 ? 'over_shoulder' : 'two_shot';
    cameraMove = 'subtle_drift';
    reason = 'Đối thoại đối mặt → qua vai / hai người nhìn thẳng nhau';
  } else if (onScreenCount === 1 && hasCharacterDialogue && !isFirstScene) {
    shotSize = 'medium_close';
    cameraMove = 'slow_push_in';
    reason = 'Một nhân vật đối thoại → cận trung giữ trục ánh mắt';
  } else if (isFirstScene || isNewSetup || SHOT_SCENIC_RE.test(text)) {
    shotSize = isFirstScene ? 'extreme_wide' : 'wide';
    cameraMove = isFirstScene ? 'pull_out' : 'pan';
    reason = 'Mở đầu / sang bối cảnh mới → toàn cảnh giới thiệu không gian';
  } else if (onScreenCount >= 2 && dialogueLineCount >= 1) {
    shotSize = dialogueLineCount >= 2 ? 'over_shoulder' : 'two_shot';
    cameraMove = 'static';
    reason = 'Đối thoại nhiều người → qua vai / hai người cùng khung';
  } else if (onScreenCount === 1 && dialogueLineCount >= 1) {
    shotSize = 'medium_close';
    cameraMove = 'slow_push_in';
    reason = 'Một nhân vật nói → cận trung';
  }

  // Tránh 2 cảnh liền nhau cùng một cỡ cảnh (trừ cảnh hành động đã luân phiên ở trên) để phim có nhịp
  if (prevShotSize && prevShotSize === shotSize && !hasCombat) {
    const alt = {
      medium: 'medium_close',
      medium_close: 'medium',
      close_up: 'medium_close',
      wide: 'medium',
      extreme_wide: 'wide',
      over_shoulder: 'two_shot',
      two_shot: 'over_shoulder',
      low_angle: 'medium',
      aerial: 'wide'
    }[shotSize];
    if (alt) {
      shotSize = alt;
      reason += ' (đổi cỡ cảnh để tránh lặp với cảnh trước)';
    }
  }
  return { shotSize, cameraMove, reason };
}

/** Dựng khối lệnh ngôn ngữ máy quay gửi lên Muse.ai cho 1 cảnh. */
function resolveRowShotPlan({ row, prevRow = null, allCharacters = [], hasCombat = false, audioMode = 'mixed' } = {}) {
  if (!row) return null;
  const sceneChars = resolveSceneCharacters(row, allCharacters);
  let onScreenCount = sceneChars.filter((c) => c && c.roleType !== 'narrator').length;
  const parsedLines = parseSceneMultiSpeakerLines(row.dialogue || '', allCharacters);
  const dialogueLineCount = parsedLines.length;
  const hasCharacterDialogue =
    audioMode !== 'ambient_only' &&
    parsedLines.some((p) => p.type === 'character' || (p.type === 'default' && audioMode !== 'narrator'));
  const actionOnlyText = `${row.sceneTitle || ''}\n${row.prompt || ''}`;
  const text = `${actionOnlyText}\n${row.dialogue || ''}`;
  // Chưa gán diễn viên cho cảnh -> đoán có người trên hình từ lời thoại nhân vật / mô tả hành động
  if (onScreenCount === 0) {
    const speakerCount = new Set(parsedLines.filter((p) => p.type === 'character').map((p) => p.speakerLabel)).size;
    if (speakerCount > 0) onScreenCount = speakerCount;
    else if (
      SHOT_PEOPLE_HINT_RE.test(text) ||
      WEAPON_STRONG_TERMS_RE.test(actionOnlyText) ||
      isCombatSceneText(actionOnlyText) ||
      SHOT_EMOTION_RE.test(actionOnlyText)
    ) {
      onScreenCount = 1;
    }
  }
  const isFirstScene = Number(row.index) === 1;
  const isNewSetup =
    !row.continueFromPrevScene && (!prevRow || String(row.sceneLocationId || '') !== String(prevRow.sceneLocationId || ''));
  let prevShot = '';
  if (prevRow) {
    if (prevRow.shotSize && prevRow.shotSize !== 'auto') prevShot = prevRow.shotSize;
    else if (prevRow.lastShotPlan?.shotSize) prevShot = prevRow.lastShotPlan.shotSize;
  }
  const autoPlan = inferAutoShotPlan({
    sceneText: actionOnlyText,
    onScreenCount,
    dialogueLineCount,
    hasCharacterDialogue,
    isFirstScene,
    isNewSetup,
    hasCombat: Boolean(hasCombat) || isCombatSceneText(actionOnlyText) || WEAPON_STRONG_TERMS_RE.test(actionOnlyText),
    prevShotSize: prevShot,
    sceneIndex: Number(row.index) || 1
  });
  const shotSize = normalizeShotSize(row.shotSize);
  const cameraMove = normalizeCameraMove(row.cameraMove);
  return {
    shotSize,
    cameraMove,
    autoPlan,
    effectiveShot: shotSize !== 'auto' ? shotSize : autoPlan.shotSize,
    effectiveMove: cameraMove !== 'auto' ? cameraMove : autoPlan.cameraMove,
    reason: shotSize !== 'auto' || cameraMove !== 'auto' ? 'Chọn thủ công trên thẻ cảnh' : autoPlan.reason
  };
}

/** Dựng khối lệnh ngôn ngữ máy quay gửi lên Muse.ai cho 1 cảnh. */
function buildCameraLanguageBlock({ shotSize = 'auto', cameraMove = 'auto', autoPlan = null, partIdx = 1, totalParts = 1 } = {}) {
  const finalShot = shotSize && shotSize !== 'auto' ? shotSize : autoPlan?.shotSize || '';
  const finalMove = cameraMove && cameraMove !== 'auto' ? cameraMove : autoPlan?.cameraMove || '';
  const shotDef = SHOT_SIZE_MAP.get(finalShot);
  const moveDef = CAMERA_MOVE_MAP.get(finalMove);
  if (!shotDef?.directive && !moveDef?.directive) return '';
  const lines = [`[DIRECTOR CAMERA LANGUAGE FOR THIS SHOT]`];
  if (shotDef?.directive) lines.push(`• SHOT SIZE / ANGLE: ${shotDef.directive}`);
  if (moveDef?.directive) lines.push(`• CAMERA MOVEMENT: ${moveDef.directive}`);
  if (totalParts > 1) {
    lines.push(
      partIdx > 1
        ? `• Continue the exact same framing and camera movement direction from Part ${partIdx - 1} (no sudden re-framing).`
        : `• Keep this framing consistent across all ${totalParts} parts of the scene.`
    );
  }
  lines.push(`• Keep faces sharp, never crop through the eyes, and keep the character identity locked even when framing changes.`);
  return lines.join('\n');
}

function buildFilmmakingPromptBlocks({
  filmConfig = {},
  sceneCharacters = [],
  sceneLocation = null,
  prevSceneSummary = '',
  nextSceneSummary = '',
  attachedImages = [],
  rawPartDialogue = '',
  sceneActionText = '',
  sceneWeaponMode = 'auto',
  weaponStates = null,
  rowSceneTitle = '',
  rowIndex = 1,
  partIdx = 1,
  totalParts = 1,
  partDurSec = 10
}) {
  const cfg = normalizeFilmConfig(filmConfig);
  const genre = getFilmGenreInfo(cfg.genreId, cfg.customStylePrompt);
  const fullSceneContext = `${rowSceneTitle || ''}\n${sceneActionText || ''}\n${rawPartDialogue || ''}`;

  const bibleLines = [
    `[CINEMATIC FILM PRODUCTION — SCENE #${String(rowIndex).padStart(2, '0')}${
      rowSceneTitle ? ` ("${rowSceneTitle}")` : ''
    }${totalParts > 1 ? ` • PART ${partIdx}/${totalParts}` : ''}]`,
    `• FILM GENRE & VISUAL ART DIRECTION: ${genre.fullStyleDirective}`
  ];

  if (cfg.worldLock) {
    bibleLines.push(`• MANDATORY WORLD, ERA & ENVIRONMENT BIBLE (LOCKED ACROSS ALL SCENES): ${cfg.worldLock}`);
  }
  if (sceneLocation) {
    bibleLines.push(
      `• LOCKED RECURRING FILM LOCATION ("${sceneLocation.name}" ${sceneLocation.tag}): ${
        sceneLocation.descriptionDna || sceneLocation.description || sceneLocation.name
      }. Keep architectural layout, props, and spatial geometry 100% identical to other scenes shot at "${
        sceneLocation.name
      }".`
    );
  }
  const lightingDirective = getCinemaLightingDirective(cfg.lightingPreset, cfg.customLightingNote);
  if (lightingDirective) {
    bibleLines.push(
      `• MANDATORY CINEMATIC LIGHTING & COLOR MOOD (LOCKED ACROSS ALL SCENES): ${lightingDirective}`
    );
  }
  if (genre.eraGuard) {
    bibleLines.push(
      `• ERA CONTINUITY GUARD: Strictly forbid any anachronistic modern items, modern text/logos, smartphones, cars, power lines, or contemporary clothing.`
    );
  }
  bibleLines.push(
    `• NO ON-SCREEN SUBTITLES OR WATERMARKS: Clean theatrical frame with ZERO burned-in text, captions, or UI overlays.`
  );

  if (prevSceneSummary || nextSceneSummary) {
    bibleLines.push(`[DIRECTOR SHOT-TO-SHOT CONTINUITY & EYELINE MATCH]`);
    if (prevSceneSummary) {
      bibleLines.push(`• PRECEDING SCENE #${rowIndex - 1} CONTEXT: ${prevSceneSummary}`);
    }
    if (nextSceneSummary) {
      bibleLines.push(
        `• UPCOMING SCENE #${rowIndex + 1} CONTEXT: ${nextSceneSummary} (Conclude this shot smoothly in motion without freezing at the end).`
      );
    }
  }

  const castLines = [];
  const onScreenChars = sceneCharacters.filter((c) => c && c.roleType !== 'narrator');
  const weaponsEnabled = isWeaponGenre(cfg.genreId);
  const actionSceneText = `${rowSceneTitle || ''}\n${sceneActionText || ''}`;
  const weaponDetectText = String(sceneActionText || '').trim() ? actionSceneText : fullSceneContext;
  const resolvedWeaponStates = !weaponsEnabled
    ? {}
    : weaponStates && typeof weaponStates === 'object'
    ? weaponStates
    : resolveSceneWeaponStates({ sceneText: weaponDetectText, sceneCharacters: onScreenChars, sceneWeaponMode });
  const weaponStateOf = (charId) => resolvedWeaponStates[charId] || WEAPON_STATE_NONE;
  const anyWeaponDrawn = onScreenChars.some((c) => weaponStateOf(c.id) === WEAPON_STATE_DRAWN);
  const hasPrevFrameAttached = attachedImages.some((im) => im.role === 'prev_scene_last_frame');
  if (onScreenChars.length > 0 || attachedImages.length > 0) {
    castLines.push(
      `[MULTI-CHARACTER CAST${anyWeaponDrawn ? ', WEAPON' : ''} & LOCATION SET MAPPING — ZERO IDENTITY SWAP]`
    );
    attachedImages.forEach((im, idx) => {
      const slotNum = idx + 1;
      if (im.role === 'film_cast_character') {
        const charHasWeapon =
          weaponsEnabled && characterHasSignatureWeapon(onScreenChars.find((c) => c.id === im.characterId));
        const isDrawn = weaponsEnabled && im.characterId ? weaponStateOf(im.characterId) === WEAPON_STATE_DRAWN : false;
        const wepInline =
          isDrawn && im.weaponDna
            ? ` | LOCKED SIGNATURE WEAPON IN THIS SHOT: ${im.weaponDna}`
            : charHasWeapon
            ? ` | USE THIS IMAGE FOR IDENTITY ONLY: if it shows a weapon or prop in hand, IGNORE that object — "${im.characterName}" is NOT holding any weapon in this shot`
            : '';
        castLines.push(
          `• Attached Image #${slotNum} = CHARACTER "${im.characterName}" (${im.characterTag}): Lock 100% of this character's face, hair, age, build, and signature costume${
            im.characterDna ? ` (${im.characterDna})` : ''
          }${wepInline}.`
        );
      } else if (im.role === 'character_signature_weapon') {
        castLines.push(
          `• Attached Image #${slotNum} = LOCKED SIGNATURE WEAPON / PROP OF "${im.characterName}" (${im.characterTag}): Reproduce 100% of this EXACT weapon's physical geometry, blade/shaft length & width, tip shape, crossguard/hilt, material, and color${
            im.weaponDna ? ` (${im.weaponDna})` : ''
          }. ZERO WEAPON MORPHING — "${im.characterName}" MUST wield this exact weapon and NEVER swap it into a generic sword, spear, or stick!`
        );
      } else if (im.role === 'film_cast_character_extra_angle') {
        castLines.push(
          `• Attached Image #${slotNum} = Supplementary angle of CHARACTER "${im.characterName}" (${im.characterTag}) — SAME person, do NOT duplicate into a second clone.`
        );
      } else if (im.role === 'locked_film_location') {
        castLines.push(
          `• Attached Image #${slotNum} = LOCKED MASTER FILM SET / LOCATION "${im.locationName}" (${im.locationTag}): Reproduce 100% of this exact architecture, room/courtyard layout, colors, and props, and stage the scene's characters naturally inside this space.`
        );
      } else if (im.role === 'scene_environment_or_prop') {
        castLines.push(`• Attached Image #${slotNum} = Scene environment / visual reference for this shot.`);
      } else if (im.role === 'prev_scene_last_frame') {
        castLines.push(
          `• Attached Image #${slotNum} = Ending frame of Previous Scene #${rowIndex - 1}: Maintain smooth spatial, lighting, pose, and costume continuity from this exact moment${
            anyWeaponDrawn ? ' (including weapon geometry)' : ''
          }.`
        );
      }
    });

    for (const ch of onScreenChars) {
      const hasAttached = attachedImages.some((im) => im.characterId === ch.id && im.role === 'film_cast_character');
      if (!hasAttached) {
        castLines.push(
          `• CHARACTER "${ch.name}" (${ch.tag}) IN THIS SCENE: ${
            ch.appearanceDna || 'Maintain consistent character face, hair, and outfit across all scenes.'
          }`
        );
      }
    }

    if (onScreenChars.length >= 2) {
      castLines.push(
        `• MULTI-CHARACTER SEPARATION RULE: This scene features ${onScreenChars.length} distinct characters (${onScreenChars
          .map((c) => `"${c.name}"`)
          .join(', ')}). Keep each character visually distinct — NEVER blend faces or swap outfits${
          anyWeaponDrawn ? ', and NEVER mix up weapons between characters' : ''
        }!`
      );
    }

    // Khối khóa vũ khí theo ngữ cảnh: CHỈ cầm vũ khí khi cảnh cần, còn lại tay không / vũ khí cất trong vỏ
    const weaponRules = [];
    for (const ch of onScreenChars) {
      if (!weaponsEnabled || !characterHasSignatureWeapon(ch)) continue;
      const wDna = String(ch.weaponDna || '').trim();
      const st = weaponStateOf(ch.id);
      if (st === WEAPON_STATE_DRAWN) {
        weaponRules.push(
          `• STRICT WEAPON GEOMETRY LOCK FOR "${ch.name}" (${ch.tag}): "${ch.name}" uses the weapon in this shot. Keep it 100% rigid, solid, and geometrically identical from 0.0s to ${partDurSec}.0s — ${
            wDna || 'exact weapon design shown in the attached weapon reference image'
          }. NEVER morph blade width/length, NEVER alter hilt/color mid-swing, and NEVER substitute a generic sword, katana, or spear!`
        );
      } else {
        const carryNote =
          st === WEAPON_STATE_CARRIED
            ? `The weapon may only be visible stowed in its sheath at the waist or strapped on the back — it is NEVER drawn or held.`
            : `Do NOT show the weapon at all in this shot.`;
        const putAwayNote = hasPrevFrameAttached
          ? ` If the previous scene's ending frame shows the weapon in hand, have "${ch.name}" naturally sheathe / put it away within the first second.`
          : '';
        weaponRules.push(
          `• NO WEAPON IN HAND FOR "${ch.name}" (${ch.tag}): This is a non-combat moment — "${ch.name}" keeps both hands empty and relaxed (or naturally busy with the scene action). ${carryNote} Ignore any weapon visible in the identity reference image or mentioned in the costume description.${putAwayNote}`
        );
      }
    }
    if (weaponRules.length > 0) {
      castLines.push(
        anyWeaponDrawn
          ? `[SIGNATURE WEAPON CONTINUITY GUARD — WEAPONS ONLY FOR CHARACTERS IN ACTION]`
          : `[WEAPON CONTEXT RULE — PEACEFUL SCENE, NO WEAPONS DRAWN]`,
        ...weaponRules
      );
    }
  }

  const isCombatScene = Boolean(anyWeaponDrawn || isCombatSceneText(actionSceneText));
  const cleanDlg = String(rawPartDialogue || '').trim();
  const parsedDialogueLines =
    cfg.audioMode === 'ambient_only' || !cleanDlg ? [] : parseSceneMultiSpeakerLines(cleanDlg, sceneCharacters);

  let filmDialogueBlock = '';
  if (cfg.audioMode === 'ambient_only' || !cleanDlg) {
    filmDialogueBlock = [
      `[CINEMATIC FOLEY & AMBIENT SOUNDTRACK — NO SPOKEN DIALOGUE]`,
      isCombatScene
        ? `• Explosive blockbuster combat foley: sharp ringing steel weapon clashes, whistling blade air-cuts, deep sub-bass qi shockwave booms, crackling elemental energy, shattering stone debris, rushing wind, and driving epic battle percussion.`
        : `• Rich natural cinematic environment audio, footsteps, wind, cloth movement, and subtle atmospheric score matching the genre.`,
      `• Characters do NOT speak in this shot (natural closed-mouth acting, zero random mumbling).`
    ].join('\n');
  } else {
    const parsedLines = parsedDialogueLines;
    const narratorVoiceSpec = getCinemaVoiceDirective(cfg.narratorVoicePreset, cfg.narratorVoiceNote);

    if (cfg.audioMode === 'narrator' && parsedLines.every((l) => l.type === 'default' || l.type === 'narrator')) {
      const fullVoText = parsedLines.map((l) => l.text).join(' ');
      filmDialogueBlock = [
        `[OFF-SCREEN CINEMATIC NARRATION (VOICEOVER) — DO NOT LIP-SYNC ON-SCREEN CHARACTERS]`,
        `• NARRATOR VOICE PROFILE: ${narratorVoiceSpec}`,
        `• EXACT VOICEOVER SCRIPT (${partDurSec}s): "${fullVoText}"`,
        `• ACTING RULE: This is off-screen storytelling narration. On-screen characters act naturally with restrained, realistic body language and calm faces WITHOUT moving their lips to the narrator's voiceover (no smiling or laughing unless the scene calls for it). ${
          isCombatScene
            ? 'Layer intense battle sound effects (weapon clashes, qi shockwaves, wind blasts) underneath the narration.'
            : 'Mix gentle cinematic background ambiance underneath.'
        }`
      ].join('\n');
    } else {
      const speechDirectives = [
        `[MULTI-SPEAKER CINEMATIC DIALOGUE & NARRATION DIRECTION — ${partDurSec}s SHOT]`
      ];
      parsedLines.forEach((item, idx) => {
        if (item.type === 'narrator') {
          const voSpec = item.character
            ? getCinemaVoiceDirective(item.character.voicePreset, item.character.voiceCustomNote, item.character)
            : narratorVoiceSpec;
          speechDirectives.push(
            `• Line #${idx + 1} [OFF-SCREEN NARRATOR — ${voSpec}]: "${item.text}" (Off-screen voiceover ONLY; on-screen actors do NOT lip-sync this line).`
          );
        } else if (item.type === 'character') {
          const charVoice = item.character
            ? getCinemaVoiceDirective(item.character.voicePreset, item.character.voiceCustomNote, item.character)
            : getCinemaVoiceDirective('auto', '', { name: item.speakerLabel, tag: item.speakerLabel });
          speechDirectives.push(
            `• Line #${idx + 1} [ON-SCREEN SPEAKER "${item.speakerLabel}"${
              item.character ? ` (${item.character.tag})` : ''
            } — Voice: ${charVoice}]: "${item.text}" (ONLY "${item.speakerLabel}" moves their lips in accurate lip-sync while looking directly at the person they are addressing; other characters react naturally with closed mouths and direct eye contact).`
          );
        } else {
          const primaryOnScreen = onScreenChars[0] || null;
          if (primaryOnScreen && cfg.audioMode !== 'narrator') {
            const cVoice = getCinemaVoiceDirective(
              primaryOnScreen.voicePreset,
              primaryOnScreen.voiceCustomNote,
              primaryOnScreen
            );
            speechDirectives.push(
              `• Line #${idx + 1} [ON-SCREEN SPEAKER "${primaryOnScreen.name}" (${primaryOnScreen.tag}) — Voice: ${cVoice}]: "${item.text}" (Accurate lip-sync on "${primaryOnScreen.name}" while maintaining steady eye contact toward the listener).`
            );
          } else {
            speechDirectives.push(`• Line #${idx + 1} [CINEMATIC NARRATION — ${narratorVoiceSpec}]: "${item.text}"`);
          }
        }
      });
      speechDirectives.push(
        `• AUDIO CLARITY RULE: Speak 100% of every quoted word clearly before ${Math.max(
          3.5,
          partDurSec - 0.8
        ).toFixed(1)}s with clean studio voice clarity${
          isCombatScene
            ? ' layered over intense combat foley (weapon clashes, qi blasts, rushing wind)'
            : ' and natural cinematic ambiance'
        }.`,
        `• POST-SPEECH COMPOSURE RULE: Immediately after finishing a spoken line, each speaker closes their mouth naturally into a calm, composed expression matching the scene mood — NEVER break into an unprompted smile or laugh; listening characters keep smooth, un-furrowed foreheads and direct face-to-face eye contact.`
      );
      filmDialogueBlock = speechDirectives.join('\n');
    }
  }

  // v2.1: Khóa tư thế đối mặt & ánh mắt trực diện khi đối thoại (chấm dứt lỗi nói chuyện nhìn hướng khác)
  const dialogueBlockingBlock = buildDialogueBlockingBlock({
    onScreenChars,
    parsedLines: parsedDialogueLines,
    sceneActionText,
    hasCombat: isCombatScene,
    audioMode: cfg.audioMode
  });

  // v2.1: Đạo diễn chiến đấu kịch tính đa nhịp & kỹ xảo Tiên Hiệp / Võ Hiệp
  const combatBlock = isCombatScene
    ? buildCombatChoreographyBlock({
        combatIntensity: cfg.combatIntensity,
        genreId: cfg.genreId,
        onScreenChars,
        anyWeaponDrawn,
        partDurSec
      })
    : '';

  // v1.9 + v2.1: Khóa diễn xuất tự nhiên (mặt chuẩn điện ảnh không làm lố, nhưng mở khóa năng lượng cơ thể khi chiến đấu)
  const actingBlock = buildActingDirectionBlock({
    actingStyle: cfg.actingStyle,
    sceneText: fullSceneContext,
    hasSpokenLines: Boolean(cleanDlg) && cfg.audioMode !== 'ambient_only',
    isCombatScene
  });

  return {
    bibleBlock: bibleLines.join('\n'),
    castBlock: [castLines.join('\n'), dialogueBlockingBlock, combatBlock, actingBlock].filter(Boolean).join('\n'),
    filmDialogueBlock
  };
}

/**
 * Tạo Prompt thiết kế Chân dung Nhân vật đồng bộ đúng thể loại phim trên Muse.ai
 * v1.6: Ảnh chân dung gốc LUÔN ĐỂ TAY KHÔNG (không cầm vũ khí). Ảnh này được gửi kèm MỌI phân cảnh để khóa khuôn mặt,
 * nếu nhân vật cầm vũ khí trong ảnh thì Muse.ai sẽ chép vũ khí vào cả những cảnh uống trà / trò chuyện.
 * Vũ khí được khóa riêng bằng Ảnh Vũ Khí rời (Slot #2) và chỉ gửi kèm khi cảnh thực sự cần dùng.
 */
function buildCharacterPortraitPrompt({ character, filmConfig = {}, uniqueTag = 'mfs_portrait' }) {
  const cfg = normalizeFilmConfig(filmConfig);
  const genre = getFilmGenreInfo(cfg.genreId, cfg.customStylePrompt);
  const dna =
    character?.appearanceDna ||
    `Character named "${character?.name || 'Main Character'}", distinctive memorable face and signature period-appropriate outfit`;
  const hasSignatureWeapon = character?.weaponLockMode !== 'off' && String(character?.weaponDna || '').trim();

  return [
    `[CHARACTER MASTER REFERENCE DESIGN SHEET — ID: ${uniqueTag}]`,
    `Create a crystal-clear, well-lit waist-up portrait (facing forward with slight 3/4 heroic angle, neutral clean atmospheric background) of ONLY ONE SINGLE CHARACTER:`,
    `• Character Name: "${character?.name || 'Character'}"`,
    `• Visual Appearance & Costume DNA: ${dna}`,
    `• HANDS RULE: Both hands relaxed, visible and EMPTY — absolutely NO weapon, sword, staff, bow, fan, prop, or object in hands or drawn in frame${
      hasSignatureWeapon ? ' (this character\'s weapon is stored as a separate reference image — ignore any weapon mentioned in the description above)' : ''
    }.`,
    `• Film Art Style: ${genre.fullStyleDirective}`,
    cfg.worldLock ? `• World / Era Context: ${cfg.worldLock}` : '',
    getCinemaLightingDirective(cfg.lightingPreset, cfg.customLightingNote)
      ? `• Harmonized Film Lighting Tone (keep face clearly lit & visible): ${getCinemaLightingDirective(
          cfg.lightingPreset,
          cfg.customLightingNote
        )}`
      : '',
    `• Reference Sheet Rules: Single solo character centered clearly in frame, sharp eyes and facial features, calm neutral relaxed facial expression (no smile, no frown, no wrinkled forehead), full costume visible down to the waist, zero text/watermarks, calm steady stance ideal for master reference.`
  ]
    .filter(Boolean)
    .join('\n');
}

/**
 * Tạo Prompt thiết kế riêng Bảng Vũ Khí / Pháp Bảo Cố Định (ISOLATED WEAPON PROP SHEET — KHÔNG NGƯỜI) lưu vào Slot #1
 */
function buildCharacterWeaponSheetPrompt({ character, filmConfig = {}, uniqueTag = 'mcs_wep' }) {
  const cfg = normalizeFilmConfig(filmConfig);
  const genre = getFilmGenreInfo(cfg.genreId, cfg.customStylePrompt);
  const weaponDna =
    String(character?.weaponDna || '').trim() ||
    `Signature ancient hero weapon belonging to "${character?.name || 'Main Hero'}", distinctive silhouette, ornate hilt and blade`;

  return [
    `[ISOLATED SIGNATURE WEAPON / PROP MASTER SHEET — ID: ${uniqueTag}]`,
    `Create a crystal-clear product/prop concept reference shot of ONLY ONE SINGLE WEAPON / ARTIFACT placed diagonally in full length from pommel/hilt to tip against a clean dark neutral slate background (STRICTLY ZERO PEOPLE, ZERO HANDS, ZERO CHARACTERS IN FRAME):`,
    `• Owner Character: "${character?.name || 'Character'}" (${character?.tag || '@Hero'})`,
    `• Exact Weapon Physical Geometry, Size, Material & Color DNA: ${weaponDna}`,
    `• Film Art Style: ${genre.fullStyleDirective}`,
    `• Weapon Reference Rules: Show 100% of the entire weapon from handle/hilt to tip with sharp clean edges, true proportions, clear material textures and subtle aura, zero text/labels/watermarks, static locked camera.`
  ].join('\n');
}

/**
 * Tạo Prompt thiết kế Phim trường / Bối cảnh gốc (EMPTY SET PLATE — KHÔNG CÓ NGƯỜI) để khóa không gian xuyên suốt phim
 */
function buildLocationPlatePrompt({ location, filmConfig = {}, uniqueTag = 'mcs_loc' }) {
  const cfg = normalizeFilmConfig(filmConfig);
  const genre = getFilmGenreInfo(cfg.genreId, cfg.customStylePrompt);
  const lightingDir = getCinemaLightingDirective(cfg.lightingPreset, cfg.customLightingNote);
  const desc =
    location?.descriptionDna ||
    location?.description ||
    `Master cinematic environment set for "${location?.name || 'Main Film Set'}", rich architectural & environmental detail`;

  return [
    `[EMPTY CINEMATIC ENVIRONMENT / MASTER SET PLATE — ID: ${uniqueTag}]`,
    `Create a wide establishing master environment shot of ONLY THE LOCATION / ARCHITECTURE / SCENERY (STRICTLY ZERO PEOPLE, ZERO CHARACTERS, ZERO ANIMALS IN FRAME):`,
    `• Location Name: "${location?.name || 'Film Location'}" (${location?.tag || '#BoiCanh'})`,
    `• Architectural & Spatial Design: ${desc}`,
    `• Film Art Style: ${genre.fullStyleDirective}`,
    cfg.worldLock ? `• World / Era Context: ${cfg.worldLock}` : '',
    lightingDir ? `• Cinematic Lighting & Atmosphere: ${lightingDir}` : '',
    `• Master Set Rules: 100% empty uninhabited film set ready for staging actors, crisp spatial depth, zero text/watermarks, steady locked camera.`
  ]
    .filter(Boolean)
    .join('\n');
}

/**
 * v2.0: Tạo Prompt thiết kế Ảnh Bìa Key Art Đa Nhân Vật chuẩn Poster Phim Truyền Hình (NO TEXT — chữ sẽ do hệ thống đồ họa in riêng nét căng)
 */
function buildMoviePosterKeyArtPrompt({
  characters = [],
  location = null,
  filmConfig = {},
  storySummary = '',
  attachedMeta = [],
  aspectRatio = '16:9',
  uniqueTag = 'mcs_keyart'
}) {
  const cfg = normalizeFilmConfig(filmConfig);
  const genre = getFilmGenreInfo(cfg.genreId, cfg.customStylePrompt);
  const lightingDir = getCinemaLightingDirective(cfg.lightingPreset, cfg.customLightingNote);
  const leads = (Array.isArray(characters) ? characters : [])
    .filter((c) => c && c.roleType !== 'narrator')
    .slice(0, 3);

  const castDescLines = leads.map((ch, idx) => {
    const rolePos =
      idx === 0
        ? 'CENTRAL HERO / PROTAGONIST IN FOREGROUND (largest focal presence, chest-up dramatic 3/4 angle)'
        : idx === 1
        ? 'SECOND CO-LEAD CHARACTER (framed slightly behind & to the left shoulder in dramatic ensemble hierarchy)'
        : 'THIRD SUPPORTING LEAD CHARACTER (framed slightly behind & to the right shoulder balancing the composition)';
    return `• Lead #${idx + 1} "${ch.name}" (${ch.tag}) — ${rolePos}: ${
      ch.appearanceDna || 'Preserve 100% identical face, hairstyle, and signature outfit.'
    }`;
  });

  const attachLines = (Array.isArray(attachedMeta) ? attachedMeta : []).map((m, i) => {
    if (m.kind === 'location') {
      return `• ATTACHED IMAGE #${i + 1} (${m.fileName}) = MASTER FILM ENVIRONMENT / SET "${m.name}": Use as the dramatic atmospheric background setting.`;
    }
    return `• ATTACHED IMAGE #${i + 1} (${m.fileName}) = MASTER FACE & COSTUME LOCK FOR "${m.name}": Lock 100% identical facial identity, hairstyle, and costume!`;
  });

  const isVertical = aspectRatio === '9:16';

  return [
    `[OFFICIAL TELEVISION DRAMA & STREAMING SERIES KEY ART POSTER — ID: ${uniqueTag}]`,
    `Design an ultra-cinematic, prestige TV drama / Netflix / iQIYI flagship promotional KEY ART POSTER (${
      isVertical ? 'vertical 9:16 poster composition' : 'widescreen 16:9 trailer poster composition'
    }) with classic multi-character ensemble hierarchy:`,
    `• Film Art Direction & Style: ${genre.fullStyleDirective}`,
    cfg.worldLock ? `• World & Era Setting: ${cfg.worldLock}` : '',
    location
      ? `• Signature Background Environment ("${location.name}"): ${
          location.descriptionDna || location.description || location.name
        }`
      : '',
    storySummary ? `• Dramatic Story Mood & Theme: ${String(storySummary).slice(0, 360)}` : '',
    lightingDir
      ? `• Poster Rim-Lighting & Color Contrast: ${lightingDir}, sculpted volumetric rim light separating characters from the atmospheric backdrop.`
      : `• Poster Rim-Lighting & Color Contrast: High-end theatrical key-fill-rim lighting, warm-vs-cool cinema contrast, atmospheric mist, bokeh and subtle volumetric rays.`,
    ...castDescLines,
    ...(attachLines.length > 0 ? [`[ATTACHED CAST & LOCATION IDENTITY ANCHORS]`, ...attachLines] : []),
    `• ACTING & FACIAL EXPRESSION RULE (CRITICAL): Deep, composed, natural cinematic gaze with quiet emotional intensity in the eyes — smooth relaxed foreheads, natural closed lips, ZERO exaggerated grimacing, ZERO random grinning, ZERO crying rivers of tears.`,
    `• NEGATIVE SPACE FOR TITLE TYPOGRAPHY: Keep the Main Characters' faces clearly framed in the UPPER 68% of the composition, and naturally darken / vignette the BOTTOM 28% with rich moody shadow/mist so the studio's title logo can be overlaid cleanly later.`,
    `• STRICTLY ZERO TEXT IN IMAGE: Do NOT render any letters, words, movie titles, logos, subtitles, or watermarks anywhere in the image!`
  ]
    .filter(Boolean)
    .join('\n');
}

function shouldAutoChainScene({ prevPrompt = '', curPrompt = '', prevLocTag = '', curLocTag = '', prevCharTags = [], curCharTags = [] }) {
  const curNorm = stripVietnameseAccents(String(curPrompt || '').toLowerCase());
  // Nếu đầu cảnh mới có từ khóa nhảy thời gian hoặc chuyển địa điểm rõ rệt -> NGẮT (CUT)
  if (
    /(?:\b|^)(hom\s*sau|sang\s*hom\s*sau|dem\s*hom\s*ay|dem\s*hoi|nhieu\s*nam\s*sau|vai\s*ngay\s*sau|trong\s*khi\s*do|o\s*mot\s*noi\s*khac|chuyen\s*canh|tai\s*cung\s*dien|tai\s*kinh\s*thanh|buoi\s*toi\s*hom\s*do|nam\s*thang\s*troi\s*qua)/.test(
      curNorm.slice(0, 110)
    )
  ) {
    return false;
  }
  if (prevLocTag && curLocTag) {
    return prevLocTag.toLowerCase() === curLocTag.toLowerCase();
  }
  // Nếu 2 cảnh liên tiếp có chung diễn viên đang tương tác tại chỗ -> NỐI MẠCH (CHAIN)
  if (prevCharTags.length > 0 && curCharTags.length > 0) {
    const shared = curCharTags.some((t) => prevCharTags.includes(t));
    if (shared) return true;
  }
  return false;
}

function splitScriptIntoScenesLocally({
  storyText = '',
  existingCharacters = [],
  existingLocations = [],
  targetMovieSeconds = 180,
  sceneDurationSeconds = 10,
  audioMode = 'mixed',
  actingStyle = 'subtle_realistic'
}) {
  const cleanStory = String(storyText || '').replace(/\r\n/g, '\n').trim();
  if (!cleanStory) return { extractedCharacters: [], scenes: [] };

  const targetSceneCount = Math.max(
    1,
    Math.min(200, Math.round(Number(targetMovieSeconds || 180) / Math.max(5, Number(sceneDurationSeconds || 10))))
  );
  const maxWordsPerScene = Math.max(16, Math.round(sceneDurationSeconds * 2.2));

  const explicitSceneRegex =
    /(?:^|\n)\s*(?=(?:cảnh|phân\s*cảnh|scene|shot|đoạn)\s*\d+\s*[:.\-–])/i;
  let rawBlocks = [];

  if (explicitSceneRegex.test(cleanStory)) {
    rawBlocks = cleanStory
      .split(/(?:^|\n)\s*(?:cảnh|phân\s*cảnh|scene|shot|đoạn)\s*\d+\s*[:.\-–]\s*/i)
      .map((b) => b.trim())
      .filter(Boolean);
  } else {
    const paragraphs = cleanStory
      .split(/\n\s*\n+/)
      .map((p) => p.trim())
      .filter(Boolean);

    if (paragraphs.length >= 2) {
      for (const para of paragraphs) {
        const words = para.split(/\s+/).filter(Boolean);
        if (words.length <= maxWordsPerScene * 1.45) {
          rawBlocks.push(para);
        } else {
          const sentences = para
            .split(/(?<=[.!?…])\s+/)
            .map((s) => s.trim())
            .filter(Boolean);
          let buf = [];
          let wCount = 0;
          for (const sent of sentences) {
            const sw = sent.split(/\s+/).filter(Boolean).length;
            if (buf.length > 0 && wCount + sw > maxWordsPerScene * 1.25) {
              rawBlocks.push(buf.join(' '));
              buf = [sent];
              wCount = sw;
            } else {
              buf.push(sent);
              wCount += sw;
            }
          }
          if (buf.length > 0) rawBlocks.push(buf.join(' '));
        }
      }
    } else {
      const sentences = cleanStory
        .split(/(?<=[.!?…\n])\s+/)
        .map((s) => s.trim())
        .filter(Boolean);
      const dynamicTarget = Math.max(1, Math.min(targetSceneCount, sentences.length));
      const totalW = cleanStory.split(/\s+/).filter(Boolean).length;
      const perSceneW = Math.max(14, Math.min(maxWordsPerScene, Math.ceil(totalW / dynamicTarget)));

      let buf = [];
      let wCount = 0;
      for (const sent of sentences) {
        const sw = sent.split(/\s+/).filter(Boolean).length;
        if (buf.length > 0 && wCount + sw > perSceneW) {
          rawBlocks.push(buf.join(' '));
          buf = [sent];
          wCount = sw;
        } else {
          buf.push(sent);
          wCount += sw;
        }
      }
      if (buf.length > 0) rawBlocks.push(buf.join(' '));
    }
  }

  rawBlocks = rawBlocks.slice(0, 200);

  const autoDiscoveredMap = new Map();
  const speakerScanRe = /(?:^\s*|\n\s*)(?:\[([^\]]{1,40})\]|(@[a-zA-Z0-9_]{2,32}))\s*:/g;
  let spMatch;
  while ((spMatch = speakerScanRe.exec(cleanStory)) !== null) {
    const rawSpeaker = String(spMatch[1] || spMatch[2] || '').trim();
    if (!rawSpeaker) continue;
    if (
      /^(?:dẫn\s*chuyện|người\s*dẫn|người\s*kể|thuyết\s*minh|narrator|voiceover|vo|cảnh\s*\d+|scene\s*\d+|tập\s*\d+|phần\s*\d+|hình\s*ảnh|visual|prompt)$/i.test(
        rawSpeaker
      )
    ) {
      continue;
    }
    const cleanName = rawSpeaker.replace(/^@+/, '').trim();
    if (!cleanName) continue;
    const normTag = sanitizeCharacterTag(rawSpeaker, existingCharacters.length + autoDiscoveredMap.size + 1);
    const alreadyExists = (existingCharacters || []).some(
      (c) =>
        c.tag.toLowerCase() === normTag.toLowerCase() ||
        c.name.trim().toLowerCase() === cleanName.toLowerCase()
    );
    if (!alreadyExists && !autoDiscoveredMap.has(normTag.toLowerCase())) {
      autoDiscoveredMap.set(normTag.toLowerCase(), {
        name: cleanName,
        tag: normTag,
        roleType: 'character',
        appearanceDna: '',
        voicePreset: inferLockedVoicePreset({ name: cleanName, tag: normTag })
      });
    }
  }
  const extractedCharacters = Array.from(autoDiscoveredMap.values());
  const combinedCharacters = [
    ...(Array.isArray(existingCharacters) ? existingCharacters : []),
    ...extractedCharacters.map((ec, i) => ({ id: `__ext_${i}`, ...ec }))
  ];

  // Quét các thẻ [#TenBoiCanh] hoặc #TenBoiCanh trong kịch bản (nếu có)
  const autoLocMap = new Map();
  const locScanRe = /(?:\[#([^\]\r\n]{2,40})\]|(?<=^|\s)#([a-zA-Z0-9_]{3,32}))/g;
  let lMatch;
  while ((lMatch = locScanRe.exec(cleanStory)) !== null) {
    const rawLoc = String(lMatch[1] || lMatch[2] || '').trim();
    if (!rawLoc) continue;
    const locTag = sanitizeLocationTag(rawLoc, (existingLocations?.length || 0) + autoLocMap.size + 1);
    const existsLoc = (existingLocations || []).some(
      (l) => l.tag.toLowerCase() === locTag.toLowerCase() || l.name.toLowerCase() === rawLoc.toLowerCase()
    );
    if (!existsLoc && !autoLocMap.has(locTag.toLowerCase())) {
      autoLocMap.set(locTag.toLowerCase(), {
        name: rawLoc,
        tag: locTag,
        description: `Không gian bối cảnh ${rawLoc} đồng nhất xuyên suốt bộ phim.`
      });
    }
  }
  const extractedLocations = Array.from(autoLocMap.values());
  const combinedLocations = [
    ...(Array.isArray(existingLocations) ? existingLocations : []),
    ...extractedLocations.map((el, i) => ({ id: `__extloc_${i}`, ...el }))
  ];

  const cameraCycle = [
    'Wide cinematic establishing shot, slow smooth camera push-in',
    'Medium cinematic shot at eye-level, gentle gimbal tracking',
    'Intimate medium close-up shot, shallow depth of field, calm natural facial expression',
    'Dynamic two-shot / over-the-shoulder cinematic framing, subtle camera pan'
  ];

  const scenes = rawBlocks.map((block, idx) => {
    let visualPart = '';
    let dialoguePart = '';

    if (block.includes('||')) {
      const sp = block.split('||');
      visualPart = sp[0].trim();
      dialoguePart = sp.slice(1).join(' ').trim();
    } else {
      const lines = block
        .split('\n')
        .map((l) => l.trim())
        .filter(Boolean);
      const actionLines = [];
      const speechLines = [];

      for (const ln of lines) {
        if (/^(?:\[[^\]]+\]|@[a-zA-Z0-9_]+|(?:dẫn\s*chuyện|thuyết\s*minh|thoại|narrator))\s*:/i.test(ln)) {
          speechLines.push(ln);
        } else if (/^(?:hình\s*ảnh|bối\s*cảnh|hành\s*động|visual|prompt|camera)\s*:/i.test(ln)) {
          actionLines.push(ln.replace(/^[^:]+:\s*/, '').trim());
        } else {
          actionLines.push(ln);
        }
      }

      if (speechLines.length > 0 && actionLines.length > 0) {
        visualPart = actionLines.join(' ');
        dialoguePart = speechLines.join('\n');
      } else if (speechLines.length > 0) {
        visualPart = `${cameraCycle[idx % cameraCycle.length]}. Nhân vật diễn xuất điềm tĩnh, tiết chế tự nhiên khớp lời thoại trong bối cảnh phim (không cười vô cớ, không nhăn nhó quá mức).`;
        dialoguePart = speechLines.join('\n');
      } else if (audioMode === 'ambient_only') {
        visualPart = block.replace(/\s+/g, ' ').trim();
        dialoguePart = '';
      } else {
        const cleanNarrative = block.replace(/\s+/g, ' ').trim();
        visualPart = `${cameraCycle[idx % cameraCycle.length]}. Diễn tả sống động phân cảnh: ${cleanNarrative}`;
        if (audioMode === 'narrator' || audioMode === 'mixed') {
          dialoguePart = `[Dẫn chuyện]: ${cleanNarrative}`;
        } else {
          dialoguePart = cleanNarrative;
        }
      }
    }

    visualPart = softenOveractingText(visualPart, normalizeActingStyle(actingStyle));

    const matchedChars = detectCharactersInSceneText(`${visualPart}\n${dialoguePart}`, combinedCharacters);
    const matchedLoc = detectLocationInSceneText(visualPart, combinedLocations);
    const curCharTags = matchedChars.map((c) => c.tag);
    const curLocTag = matchedLoc ? matchedLoc.tag : '';

    return {
      sceneNumber: idx + 1,
      sceneTitle: `Cảnh ${idx + 1}`,
      characterIds: matchedChars.filter((c) => !String(c.id).startsWith('__ext_')).map((c) => c.id),
      characterTags: curCharTags,
      locationId: matchedLoc && !String(matchedLoc.id).startsWith('__extloc_') ? matchedLoc.id : '',
      locationTag: curLocTag,
      continueFromPrevScene: false,
      prompt: visualPart,
      dialogue: dialoguePart
    };
  });

  // Tự động đánh dấu 🔗 Nối cảnh trước thông minh cho các cảnh diễn ra liên tiếp cùng chỗ
  for (let i = 1; i < scenes.length; i++) {
    scenes[i].continueFromPrevScene = shouldAutoChainScene({
      prevPrompt: scenes[i - 1].prompt,
      curPrompt: scenes[i].prompt,
      prevLocTag: scenes[i - 1].locationTag,
      curLocTag: scenes[i].locationTag,
      prevCharTags: scenes[i - 1].characterTags,
      curCharTags: scenes[i].characterTags
    });
  }

  return { extractedCharacters, extractedLocations, scenes };
}

function buildAiStoryboardBreakdownPrompt({
  storyText = '',
  genreId = '3d_pixar',
  customStylePrompt = '',
  worldLock = '',
  lightingPreset = 'auto',
  customLightingNote = '',
  actingStyle = 'subtle_realistic',
  combatIntensity = 'epic_donghua',
  audioMode = 'mixed',
  existingCharacters = [],
  existingLocations = [],
  batchStartScene = 1,
  batchEndScene = 12,
  totalTargetScenes = 12,
  sceneDurationSeconds = 10,
  uniqueTag = 'mfs_sb_01',
  doneMarker = 'MFS_SB_DONE_01'
}) {
  const genre = getFilmGenreInfo(genreId, customStylePrompt);
  const lightingDir = getCinemaLightingDirective(lightingPreset, customLightingNote);
  const maxWordsPerScene = Math.max(15, Math.round(sceneDurationSeconds * 2.1));
  const weaponsEnabled = isWeaponGenre(genreId);

  const existingCharBlock =
    existingCharacters.length > 0
      ? [
          `EXISTING CAST (MUST REUSE THESE EXACT @TAGS${weaponsEnabled ? ' & SIGNATURE WEAPONS' : ''} WHEN THEY APPEAR):`,
          ...existingCharacters.map(
            (c) =>
              `- ${c.tag} | ${c.name} | ${c.roleType} | ${c.appearanceDna || 'Recurring character'}${
                weaponsEnabled && c.weaponDna ? ` | Vũ khí cố định: ${c.weaponDna}` : ''
              }`
          )
        ].join('\n')
      : `NO PRE-DEFINED CAST YET: Extract up to 6 key recurring characters from the story and output CHAR lines first.`;

  const existingLocBlock =
    existingLocations.length > 0
      ? [
          `EXISTING RECURRING LOCATIONS (MUST REUSE THESE EXACT #TAGS WHEN SHOOTING AT THESE PLACES):`,
          ...existingLocations.map((l) => `- ${l.tag} | ${l.name} | ${l.descriptionDna || l.description || l.name}`)
        ].join('\n')
      : `NO PRE-DEFINED LOCATIONS YET: Extract 1 to 4 key recurring film locations/sets and output LOC lines right after CHAR lines.`;

  const audioInstruction =
    audioMode === 'ambient_only'
      ? `AUDIO MODE = AMBIENT ONLY: Leave <Dialogue> as NONE for every scene.`
      : audioMode === 'narrator'
      ? `AUDIO MODE = NARRATOR VOICEOVER: Write <Dialogue> as "[Dẫn chuyện]: <Vietnamese narration max ${maxWordsPerScene} words>".`
      : audioMode === 'dialogue'
      ? `AUDIO MODE = CHARACTER DIALOGUE: Write <Dialogue> using "[@CharacterTag]: <Vietnamese line>" (total max ${maxWordsPerScene} words per scene).`
      : `AUDIO MODE = MIXED CINEMA: Combine "[Dẫn chuyện]: <short narration>" and/or "[@CharacterTag]: <character speech>" (total max ${maxWordsPerScene} words per ${sceneDurationSeconds}s scene). Separate multiple speaker lines in one scene with " / ".`;

  return [
    `[TEXT-ONLY FILM DIRECTOR & STORYBOARD ARCHITECT — ID: ${uniqueTag}]`,
    `[CRITICAL SYSTEM RULE: DO NOT GENERATE ANY VIDEO OR IMAGE IN THIS STEP! REPLY WITH STRUCTURED PLAIN TEXT ONLY!]`,
    `You are an award-winning Cinema Director adapting the following Vietnamese story/script into a seamless, cohesive ${totalTargetScenes}-scene movie (${sceneDurationSeconds}s per scene).`,
    `• Film Genre: ${genre.label} (${genre.fullStyleDirective})`,
    worldLock ? `• Locked World / Era Setting: ${worldLock}` : '',
    lightingDir ? `• Locked Cinematic Lighting & Atmosphere: ${lightingDir}` : '',
    `• ${audioInstruction}`,
    weaponsEnabled
      ? `• WEAPON CONTINUITY RULE: If a character owns a signature weapon/artifact, define its exact physical shape, length, blade width, tip shape, hilt, and color in the weapon column (NEVER vague poetic names alone, and NEVER inside the appearance/costume column).`
      : '',
    weaponsEnabled
      ? `• WEAPON USAGE RULE (VERY IMPORTANT): Characters draw/hold their weapon ONLY in scenes where the story truly requires it (combat, threat, training, ceremony). In peaceful scenes (talking, eating, drinking tea, walking, resting, emotional moments) write NOTHING about weapons. When a weapon is used, write the explicit action in Vietnamese (VD: "rút kiếm", "vung đao", "giương cung"); when the fight ends, write "cất kiếm" / "tra kiếm vào vỏ".`
      : '',
    `• CAMERA LANGUAGE RULE: Act like a real cinematographer and vary the shots to create cinematic rhythm (establishing wide shot when entering a new place, medium/over-shoulder for dialogue, close-up for strong emotion, tracking for action, low angle for powerful moments). NEVER use the same shot size for many scenes in a row. Start the visual prompt column of EVERY scene with a tag [SHOT=<id>; MOVE=<id>].`,
    `  Allowed SHOT ids: ${SHOT_SIZE_PRESETS.filter((s) => s.id !== 'auto').map((s) => s.id).join(', ')}.`,
    `  Allowed MOVE ids: ${CAMERA_MOVE_PRESETS.filter((m) => m.id !== 'auto').map((m) => m.id).join(', ')}.`,
    normalizeActingStyle(actingStyle) !== 'expressive'
      ? `• ACTING RULE (VERY IMPORTANT): Write emotions in a restrained, realistic film style (VD: "mắt rưng rưng", "khẽ cúi đầu", "ánh mắt trầm xuống", "khẽ mỉm cười", "siết chặt tay"). NEVER write over-the-top acting such as "khóc nức nở", "gào khóc", "nước mắt giàn giụa", "cười phá lên", "cười ha hả", "mặt nhăn nhó", "cau có dữ tợn", "trợn mắt". Only mention smiling when the story truly calls for it.`
      : '',
    `• DIALOGUE EYELINE & FACE-TO-FACE RULE (VERY IMPORTANT): In EVERY dialogue/conversation scene, explicitly describe the characters standing/sitting FACING EACH OTHER and looking straight into each other's eyes while speaking (VD: "@A xoay người đối diện, nhìn thẳng vào mắt @B nói...", "@B quay mặt sang đối diện @A lắng nghe và đáp lại..."), and use [SHOT=over_shoulder; MOVE=subtle_drift] or [SHOT=two_shot; MOVE=subtle_drift] — NEVER write characters standing side-by-side looking off into empty space unless the story explicitly demands turning away.`,
    normalizeCombatIntensity(combatIntensity) !== 'restrained'
      ? `• PHOTOREALISTIC COMBAT & PRACTICAL VFX RULE (CRITICAL FOR FIGHT SCENES): NEVER write cheap glowing magic circles, rainbow aura beams, or weightless floating in mid-air (those look fake on video AI)! Instead, write gritty, weighty 1-to-2-beat live-action martial arts clashes in Vietnamese: (1) đạp vỡ nền đá bứt tốc lao sát mặt đất, áo bào quật gió mạnh; (2) hai lưỡi binh khí va chạm ghìm chặt nặng đô tóe tia lửa hàn cam-trắng chiếu sáng lên mặt${
          weaponsEnabled ? ', luồng sóng khí khúc xạ không khí xé toạc màn sương làm rạn nứt cột đá và cuộn tung bụi khói' : ', kình lực đánh bật đối thủ trượt dài trên đá vỡ'
        }! Vary grounded action camera tags across fight scenes: [SHOT=medium_wide; MOVE=dynamic_action], [SHOT=low_angle; MOVE=handheld], [SHOT=medium_close; MOVE=tracking].`
      : '',
    existingCharBlock,
    existingLocBlock,
    ``,
    `--- SOURCE STORY / SCRIPT ---`,
    String(storyText || '').trim().slice(0, 14000),
    `--- END SOURCE STORY ---`,
    ``,
    `TASK FOR THIS BATCH: Write scenes from SCENE_${batchStartScene} through SCENE_${batchEndScene} (out of ${totalTargetScenes} total scenes covering the story arc chronologically).`,
    batchStartScene === 1 && existingCharacters.length === 0
      ? weaponsEnabled
        ? `First, output 1 to 6 character definition lines:\nCHAR | @Tag | Tên nhân vật | GenderAgeVoiceHint | Mô tả ngoại hình & trang phục cố định bằng tiếng Việt (KHÔNG nhắc vũ khí ở cột này) | Mô tả hình học Vũ khí / Pháp bảo cố định rõ hình dáng, kích thước, màu sắc, chất liệu (ghi NONE nếu nhân vật không dùng vũ khí)`
        : `First, output 1 to 6 character definition lines:\nCHAR | @Tag | Tên nhân vật | GenderAgeVoiceHint | Mô tả ngoại hình & trang phục cố định bằng tiếng Việt`
      : '',
    batchStartScene === 1 && existingLocations.length === 0
      ? `Next, output 1 to 4 recurring film set/location lines (EMPTY SET description without people):\nLOC | #LocTag | Tên bối cảnh | Mô tả kiến trúc, đồ vật, không gian cố định bằng tiếng Việt (không tả người)`
      : '',
    `Then output EVERY scene from ${batchStartScene} to ${batchEndScene} in this exact single-line pipe-separated format (NO markdown code fences):`,
    `SCENE_<N> | <Short Vietnamese Scene Title> | <Comma-separated @Tags or NONE> | <#LocTag or NONE> | <CHAIN if continuous moment at same spot as previous scene, or CUT if new location/time> | <[SHOT=<id>; MOVE=<id>] + Detailed Visual Camera + Environment + Character Action Prompt in Vietnamese${weaponsEnabled ? ' (mention a weapon ONLY if it is actually drawn or used in this exact scene)' : ''}> | <Vietnamese Dialogue/Narration or NONE>`,
    `End your response with the exact token: ${doneMarker}`
  ]
    .filter(Boolean)
    .join('\n');
}

function mapVoiceHintToPreset(hint = '', name = '', tag = '', dna = '') {
  const h = stripVietnameseAccents(String(hint || '').toLowerCase());
  if (/tre\s*em|be\s*trai|cau\s*be|boy/.test(h)) return 'vi_child_boy';
  if (/be\s*gai|co\s*be|girl/.test(h)) return 'vi_child_girl';
  if (/ong\s*lao|cu\s*ong|gia\s*lang|elder\s*male|old\s*man/.test(h)) return 'vi_male_elder_wise';
  if (/ba\s*lao|cu\s*ba|ba\s*tien|old\s*woman/.test(h)) return 'vi_female_elder_kind';
  if (/tuong|vua|anh\s*hung|hero|uy\s*nghiem/.test(h)) return 'vi_male_hero_epic';
  if (/nam|male|man|trai/.test(h)) return 'vi_male_young_bright';
  if (/nu|female|woman|gai/.test(h)) return 'vi_female_lead_gentle';
  return inferLockedVoicePreset({ name, tag, appearanceDna: dna, voiceHint: hint });
}

function parseAiStoryboardBreakdownReply(replyText = '', actingStyle = 'subtle_realistic') {
  const lines = String(replyText || '')
    .replace(/```[a-z]*\n?/gi, '')
    .replace(/```/g, '')
    .split(/\r?\n/)
    .map((l) => l.trim())
    .filter(Boolean);

  const extractedCharacters = [];
  const extractedLocations = [];
  const scenes = [];

  for (const line of lines) {
    const cleanLine = line.replace(/^[-*•\d.)\s]+(?=(?:CHAR|LOC|SCENE_\d+)\b)/i, '').trim();

    if (/^CHAR\s*\|/i.test(cleanLine)) {
      const parts = cleanLine.split('|').map((p) => p.trim());
      if (parts.length >= 3) {
        const rawTag = parts[1];
        const name = parts[2] || rawTag.replace(/^@/, '');
        const voiceHint = parts[3] || '';
        const dna = parts[4] || voiceHint;
        const rawWep = parts.slice(5).join(' | ').trim();
        const cleanWep = /^(none|khong\s*co|không\s*có|-)$/i.test(rawWep) ? '' : rawWep;
        const cleanTag = sanitizeCharacterTag(rawTag || name, extractedCharacters.length + 1);
        extractedCharacters.push({
          tag: cleanTag,
          name,
          roleType: /narrator|dan\s*chuyen|thuyet\s*minh/i.test(stripVietnameseAccents(name))
            ? 'narrator'
            : 'character',
          voicePreset: mapVoiceHintToPreset(voiceHint, name, cleanTag, dna),
          appearanceDna: dna,
          weaponDna: cleanWep,
          weaponLockMode: 'smart_context'
        });
      }
      continue;
    }

    if (/^LOC\s*\|/i.test(cleanLine)) {
      const parts = cleanLine.split('|').map((p) => p.trim());
      if (parts.length >= 3) {
        const rawLocTag = parts[1];
        const locName = parts[2] || rawLocTag.replace(/^#+/, '');
        const locDesc = parts.slice(3).join(' | ').trim() || locName;
        extractedLocations.push({
          tag: sanitizeLocationTag(rawLocTag || locName, extractedLocations.length + 1),
          name: locName,
          description: locDesc,
          descriptionDna: locDesc
        });
      }
      continue;
    }

    const scMatch = cleanLine.match(/^SCENE_(\d+)\s*\|\s*(.+)$/i);
    if (scMatch) {
      const sceneNum = Number(scMatch[1]);
      const restParts = scMatch[2].split('|').map((p) => p.trim());
      let sceneTitle = `Cảnh ${sceneNum}`;
      let tagsRaw = '';
      let locTagRaw = '';
      let chainModeRaw = '';
      let visualPrompt = '';
      let dialogueRaw = '';

      if (restParts.length >= 6) {
        sceneTitle = restParts[0] || sceneTitle;
        tagsRaw = restParts[1] || '';
        locTagRaw = restParts[2] || '';
        chainModeRaw = restParts[3] || '';
        visualPrompt = restParts[4] || '';
        dialogueRaw = restParts.slice(5).join(' | ').trim();
      } else if (restParts.length === 5) {
        sceneTitle = restParts[0] || sceneTitle;
        tagsRaw = restParts[1] || '';
        if (/^(chain|cut)$/i.test(restParts[2])) {
          chainModeRaw = restParts[2];
        } else {
          locTagRaw = restParts[2];
        }
        visualPrompt = restParts[3] || '';
        dialogueRaw = restParts[4] || '';
      } else if (restParts.length === 4) {
        sceneTitle = restParts[0] || sceneTitle;
        tagsRaw = restParts[1] || '';
        visualPrompt = restParts[2] || '';
        dialogueRaw = restParts[3] || '';
      } else if (restParts.length === 3) {
        sceneTitle = restParts[0] || sceneTitle;
        visualPrompt = restParts[1] || '';
        dialogueRaw = restParts[2] || '';
      } else {
        visualPrompt = restParts[0] || '';
        dialogueRaw = restParts[1] || '';
      }

      const characterTags =
        !tagsRaw || /^none$/i.test(tagsRaw)
          ? []
          : tagsRaw
              .split(/[,;\s]+/)
              .map((t) => t.trim())
              .filter((t) => t && !/^none$/i.test(t))
              .map((t) => sanitizeCharacterTag(t));

      const locationTag =
        !locTagRaw || /^none$/i.test(locTagRaw) ? '' : sanitizeLocationTag(locTagRaw);

      const hasExplicitChain = /^(chain|cut)$/i.test(chainModeRaw);
      const continueFromPrevScene =
        sceneNum > 1 && hasExplicitChain ? /^chain$/i.test(chainModeRaw) : null;

      const cleanDialogue =
        !dialogueRaw || /^none$/i.test(dialogueRaw)
          ? ''
          : dialogueRaw
              .split(/\s+\/\s+/)
              .map((s) => s.trim())
              .filter(Boolean)
              .join('\n');

      // Trích thẻ ngôn ngữ máy quay [SHOT=close_up; MOVE=slow_push_in] do AI Đạo Diễn chọn
      let shotSize = 'auto';
      let cameraMove = 'auto';
      const shotTagRe = /\[\s*SHOT\s*[=:]\s*([a-z_]+)\s*(?:[;,/]\s*MOVE\s*[=:]\s*([a-z_]+)\s*)?\]/i;
      const shotTagMatch = visualPrompt.match(shotTagRe);
      if (shotTagMatch) {
        shotSize = normalizeShotSize(String(shotTagMatch[1] || '').toLowerCase());
        cameraMove = normalizeCameraMove(String(shotTagMatch[2] || '').toLowerCase());
        visualPrompt = visualPrompt.replace(shotTagRe, '').replace(/^\s*[-–:]\s*/, '').trim();
      } else {
        const moveOnly = visualPrompt.match(/\[\s*MOVE\s*[=:]\s*([a-z_]+)\s*\]/i);
        if (moveOnly) {
          cameraMove = normalizeCameraMove(String(moveOnly[1] || '').toLowerCase());
          visualPrompt = visualPrompt.replace(moveOnly[0], '').trim();
        }
      }

      visualPrompt = softenOveractingText(visualPrompt, normalizeActingStyle(actingStyle));

      if (visualPrompt) {
        scenes.push({
          sceneNumber: sceneNum,
          sceneTitle,
          characterTags,
          locationTag,
          continueFromPrevScene,
          shotSize,
          cameraMove,
          prompt: visualPrompt,
          dialogue: cleanDialogue
        });
      }
    }
  }

  // Fallback suy luận nối mạch thông minh nếu AI không ghi rõ CHAIN/CUT ở cảnh nào đó
  for (let i = 0; i < scenes.length; i++) {
    if (scenes[i].continueFromPrevScene === null || scenes[i].continueFromPrevScene === undefined) {
      if (i === 0 || scenes[i].sceneNumber <= 1) {
        scenes[i].continueFromPrevScene = false;
      } else {
        scenes[i].continueFromPrevScene = shouldAutoChainScene({
          prevPrompt: scenes[i - 1].prompt,
          curPrompt: scenes[i].prompt,
          prevLocTag: scenes[i - 1].locationTag,
          curLocTag: scenes[i].locationTag,
          prevCharTags: scenes[i - 1].characterTags,
          curCharTags: scenes[i].characterTags
        });
      }
    }
  }

  return { extractedCharacters, extractedLocations, scenes };
}

module.exports = {
  FILM_GENRES,
  CINEMA_VOICE_PRESETS,
  CINEMA_LIGHTING_PRESETS,
  ACTING_STYLE_PRESETS,
  COMBAT_INTENSITY_PRESETS,
  softenOveractingText,
  refineCheapVfxText,
  buildActingDirectionBlock,
  normalizeActingStyle,
  normalizeCombatIntensity,
  isCombatSceneText,
  buildDialogueBlockingBlock,
  buildCombatChoreographyBlock,
  MAX_FILM_CHARACTERS,
  MAX_CHAR_REF_IMAGES,
  MAX_FILM_LOCATIONS,
  sanitizeCharacterTag,
  sanitizeLocationTag,
  inferLockedVoicePreset,
  getCinemaVoiceDirective,
  getCinemaLightingDirective,
  getFilmGenreInfo,
  createDefaultFilmConfig,
  normalizeFilmConfig,
  normalizeFilmCharacters,
  normalizeFilmLocations,
  doesSceneInvolveCharacterWeapon,
  resolveSceneWeaponStates,
  characterHasSignatureWeapon,
  isWeaponGenre,
  WEAPON_ENABLED_GENRES,
  SHOT_SIZE_PRESETS,
  CAMERA_MOVE_PRESETS,
  normalizeShotSize,
  normalizeCameraMove,
  inferAutoShotPlan,
  resolveRowShotPlan,
  buildCameraLanguageBlock,
  VALID_SCENE_WEAPON_MODES,
  detectCharactersInSceneText,
  detectLocationInSceneText,
  resolveSceneCharacters,
  resolveSceneLocation,
  parseSceneMultiSpeakerLines,
  buildSceneCastReferenceImages,
  buildFilmmakingPromptBlocks,
  buildCharacterPortraitPrompt,
  buildCharacterWeaponSheetPrompt,
  buildLocationPlatePrompt,
  buildMoviePosterKeyArtPrompt,
  shouldAutoChainScene,
  splitScriptIntoScenesLocally,
  buildAiStoryboardBreakdownPrompt,
  parseAiStoryboardBreakdownReply
};
