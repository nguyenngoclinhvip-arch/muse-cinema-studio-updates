const { resolveSceneCharacters } = require('./cinemaDirector');
const { analyzeClipQuality } = require('./videoEditor');

class BatchScheduler {
  constructor({ accountManager, cdpEngine, onEvent }) {
    this.accountManager = accountManager;
    this.cdpEngine = cdpEngine;
    this.onEvent = typeof onEvent === 'function' ? onEvent : () => {};
    this.jobs = new Map();
    this.singleRowControllers = new Map();
  }

  emit(event, payload) {
    try {
      this.onEvent(event, payload);
    } catch (_) {}
  }

  _getRow(accountId, rowIndex) {
    const acc = this.accountManager.getAccount(accountId);
    return { acc, row: (acc?.rows || []).find((r) => Number(r.index) === Number(rowIndex)) || null };
  }

  /** v1.8: Kiểm tra chất lượng clip vừa quay (khung đen, đứng hình, mất tiếng, thiếu thời lượng) & lưu vào bản quay. */
  async runQcForRow(accountId, rowIndex) {
    const { acc, row } = this._getRow(accountId, rowIndex);
    if (!acc || !row || !row.videoFilePath) return null;
    const fc = acc.settings?.filmConfig || {};
    const expectedSec = Math.max(5, Number(fc.sceneDurationSeconds) || 10);
    const expectDialogue = Boolean(String(row.dialogue || '').trim()) && fc.audioMode !== 'ambient_only';
    const checkingRow = this.accountManager.updateRow(accountId, rowIndex, {
      statusMessage: '🛡️ Đang kiểm tra chất lượng clip (khung đen, đứng hình, mất tiếng)...'
    });
    this.emit('row_updated', { accountId, rowIndex: Number(rowIndex), row: checkingRow });

    const qc = await analyzeClipQuality({
      appRootDir: this.accountManager.appRootDir,
      filePath: row.videoFilePath,
      expectedSec,
      expectDialogue
    });
    this.accountManager.setSceneTakeQc(accountId, rowIndex, row.videoFilePath, qc);
    const label =
      qc.verdict === 'pass'
        ? `Hoàn tất • QC đạt ${qc.score}/100`
        : qc.verdict === 'warn'
        ? `Hoàn tất • QC ${qc.score}/100 — ${qc.issues.join(', ')}`
        : `QC lỗi ${qc.score}/100 — ${qc.issues.join(', ')}`;
    const updated = this.accountManager.updateRow(accountId, rowIndex, { statusMessage: label });
    this.emit('row_updated', { accountId, rowIndex: Number(rowIndex), row: updated });
    return qc;
  }

  /**
   * Quay 1 cảnh + tự kiểm tra chất lượng. Nếu clip lỗi nặng và đang bật "Tự quay lại cảnh lỗi"
   * -> tự quay thêm 1 bản mới rồi giữ lại bản có điểm QC cao nhất.
   */
  async _executeRowWithQc({ accountId, rowIndex, abortSignal }) {
    const result = await this.cdpEngine.executeRow({ accountId, rowIndex, abortSignal });
    if (abortSignal?.aborted) return result;

    let qc = null;
    try {
      qc = await this.runQcForRow(accountId, rowIndex);
    } catch (_) {}

    const { acc, row } = this._getRow(accountId, rowIndex);
    if (!qc || qc.verdict !== 'fail' || !acc || !row) return result;
    if (acc.settings?.autoQcRetry === false || (row.qcRetryCount || 0) >= 1) return result;

    const retryRow = this.accountManager.updateRow(accountId, rowIndex, {
      qcRetryCount: (row.qcRetryCount || 0) + 1,
      status: 'queued',
      statusMessage: `🛡️ QC phát hiện lỗi (${qc.issues.join(', ')}) — đang tự quay lại bản mới...`,
      videoUrl: null,
      videoFilePath: null,
      remoteVideoUrl: null,
      qc: null,
      error: null
    });
    this.emit('row_updated', { accountId, rowIndex: Number(rowIndex), row: retryRow });

    try {
      await this.cdpEngine.executeRow({ accountId, rowIndex, abortSignal });
      if (!abortSignal?.aborted) await this.runQcForRow(accountId, rowIndex);
    } catch (err) {
      if (abortSignal?.aborted) throw err;
    }

    // Giữ bản quay có điểm QC cao nhất làm bản chính
    try {
      const best = this.accountManager.selectBestSceneTake(accountId, rowIndex);
      const sc = best?.qc?.score;
      const finalRow = this.accountManager.updateRow(accountId, rowIndex, {
        statusMessage: `Hoàn tất • Đã tự chọn bản quay tốt nhất${Number.isFinite(sc) ? ` (QC ${sc}/100)` : ''}`
      });
      this.emit('row_updated', { accountId, rowIndex: Number(rowIndex), row: finalRow });
    } catch (_) {}
    return result;
  }

  getJobState(accountId) {
    const job = this.jobs.get(accountId);
    const acc = this.accountManager.getAccount(accountId);
    const defaultConcurrency = Math.max(
      1,
      Math.min(16, Number(acc?.settings?.filmConfig?.concurrency || acc?.settings?.concurrency) || 4)
    );
    if (!job) {
      return {
        running: false,
        batchSize: defaultConcurrency,
        currentBatchIndex: 0,
        totalBatches: 0,
        activeThreads: 0,
        completedInCurrentBatch: 0,
        currentBatchTargetCount: 0,
        totalCompleted: 0,
        totalFailed: 0,
        totalTargetRows: 0,
        currentBatchRows: []
      };
    }
    return job.stats;
  }

  async runSingleRow(accountId, rowIndex, isRegenerate = false) {
    const account = this.accountManager.getAccount(accountId);
    if (!account) throw new Error('Không tìm thấy bộ phim.');

    if (isRegenerate) {
      this.accountManager.updateRow(accountId, rowIndex, {
        status: 'queued',
        statusMessage: 'Đang chuẩn bị quay thêm bản mới cho phân cảnh (bản cũ vẫn được giữ)...',
        videoUrl: null,
        videoFilePath: null,
        remoteVideoUrl: null,
        qc: null,
        qcRetryCount: 0,
        error: null
      });
    }

    const rowKey = `${accountId}::${Number(rowIndex)}`;
    const prevCtrl = this.singleRowControllers.get(rowKey);
    if (prevCtrl) {
      try {
        prevCtrl.abort();
      } catch (_) {}
    }
    const ctrl = new AbortController();
    this.singleRowControllers.set(rowKey, ctrl);

    try {
      return await this._executeRowWithQc({
        accountId,
        rowIndex: Number(rowIndex),
        abortSignal: ctrl.signal
      });
    } catch (err) {
      // Quay bản mới thất bại -> khôi phục bản quay tốt nhất trước đó (nếu có)
      const { row } = this._getRow(accountId, rowIndex);
      if (isRegenerate && row && Array.isArray(row.takes) && row.takes.length > 0 && !ctrl.signal.aborted) {
        try {
          const restored = this.accountManager.selectBestSceneTake(accountId, rowIndex);
          const r2 = this.accountManager.updateRow(accountId, rowIndex, {
            statusMessage: `Quay bản mới lỗi (${err.message}) — đã giữ lại bản quay trước`
          });
          this.emit('row_updated', { accountId, rowIndex: Number(rowIndex), row: r2 || restored });
        } catch (_) {}
      }
      throw err;
    } finally {
      if (this.singleRowControllers.get(rowKey) === ctrl) {
        this.singleRowControllers.delete(rowKey);
      }
    }
  }

  async runAllInBatchesOfSix(accountId, { forceAll = false } = {}) {
    const existingJob = this.jobs.get(accountId);
    if (existingJob && existingJob.running) {
      throw new Error('Đoàn làm phim đang quay hàng loạt. Vui lòng đợi hoặc bấm Dừng Quay!');
    }

    const account = this.accountManager.getAccount(accountId);
    if (!account) {
      throw new Error('Không tìm thấy bộ phim.');
    }

    const filmCfg = account.settings?.filmConfig || {};
    const isSequentialChain = filmCfg.continuityMode === 'sequential_chain';
    const configuredConcurrency = Math.max(
      1,
      Math.min(16, Number(filmCfg.concurrency || account.settings?.concurrency) || 4)
    );
    const batchSize = isSequentialChain ? 1 : configuredConcurrency;

    const allCharacters = Array.isArray(account.characters) ? account.characters : [];
    const allHasData = (account.rows || []).filter((r) => {
      const hasPrompt = Boolean(r.prompt && r.prompt.trim().length > 0);
      const hasDialogue = Boolean(r.dialogue && r.dialogue.trim().length > 0);
      const hasImages = Array.isArray(r.referenceImages) && r.referenceImages.some((img) => img && img.filePath);
      const hasSceneCast = resolveSceneCharacters(r, allCharacters).length > 0;
      return hasPrompt || hasDialogue || hasImages || hasSceneCast;
    });

    let eligibleRows;
    if (forceAll) {
      eligibleRows = allHasData;
    } else {
      const nonErrorPending = allHasData.filter((r) => r.status !== 'completed' && r.status !== 'error');
      eligibleRows =
        nonErrorPending.length > 0
          ? nonErrorPending
          : allHasData.filter((r) => r.status !== 'completed');
    }

    if (eligibleRows.length === 0) {
      throw new Error(
        'Chưa có phân cảnh nào có nội dung (Cảnh quay / Lời thoại) để bấm máy, hoặc toàn bộ các cảnh đã quay xong!'
      );
    }

    // Nếu một cảnh bật "🔗 Nối cảnh trước", tự động tách ranh giới lô để cảnh trước quay xong mới lấy khung cuối cho cảnh sau
    const batches = [];
    let currentBucket = [];
    for (const row of eligibleRows) {
      if (isSequentialChain) {
        batches.push([row]);
        continue;
      }
      const prevSceneInCurrentBucket =
        row.continueFromPrevScene &&
        currentBucket.some((prevR) => Number(prevR.index) === Number(row.index) - 1);

      if (currentBucket.length >= batchSize || prevSceneInCurrentBucket) {
        if (currentBucket.length > 0) batches.push(currentBucket);
        currentBucket = [row];
      } else {
        currentBucket.push(row);
      }
    }
    if (currentBucket.length > 0) {
      batches.push(currentBucket);
    }

    batches.forEach((batchRows, bIdx) => {
      batchRows.forEach((r) => {
        this.accountManager.updateRow(accountId, r.index, {
          status: 'queued',
          statusMessage: isSequentialChain
            ? `Chờ bấm máy nối mạch (${bIdx + 1}/${batches.length})...`
            : `Chờ lượt quay ${bIdx + 1}/${batches.length}...`,
          qcRetryCount: 0,
          error: null
        });
      });
    });

    const abortController = new AbortController();
    const stats = {
      running: true,
      batchSize,
      continuityMode: isSequentialChain ? 'sequential_chain' : 'parallel_fast',
      currentBatchIndex: 0,
      totalBatches: batches.length,
      activeThreads: 0,
      completedInCurrentBatch: 0,
      currentBatchTargetCount: 0,
      totalCompleted: 0,
      totalFailed: 0,
      totalTargetRows: eligibleRows.length,
      currentBatchRows: []
    };

    this.jobs.set(accountId, {
      running: true,
      abortController,
      stats
    });

    this.emit('batch_progress', { accountId, stats });

    (async () => {
      try {
        for (let bIndex = 0; bIndex < batches.length; bIndex++) {
          if (abortController.signal.aborted) break;

          const currentBatch = batches[bIndex];
          stats.currentBatchIndex = bIndex + 1;
          stats.completedInCurrentBatch = 0;
          stats.currentBatchTargetCount = currentBatch.length;
          stats.activeThreads = currentBatch.length;
          stats.currentBatchRows = currentBatch.map((r) => r.index);

          this.emit('batch_progress', { accountId, stats });

          const workerPromises = currentBatch.map(async (rowItem) => {
            try {
              await this._executeRowWithQc({
                accountId,
                rowIndex: rowItem.index,
                abortSignal: abortController.signal
              });
              stats.totalCompleted += 1;
            } catch (err) {
              if (abortController.signal.aborted) return;
              stats.totalFailed += 1;
              const errMsg = err?.message || 'Không tạo được phân cảnh';
              const updatedRow = this.accountManager.updateRow(accountId, rowItem.index, {
                status: 'error',
                statusMessage: `Lỗi (Đã bỏ qua): ${errMsg}`,
                error: errMsg
              });
              this.emit('row_updated', {
                accountId,
                rowIndex: rowItem.index,
                row: updatedRow
              });
              this.emit('row_error_skipped', {
                accountId,
                rowIndex: rowItem.index,
                error: errMsg
              });
            } finally {
              stats.completedInCurrentBatch += 1;
              stats.activeThreads = Math.max(0, stats.activeThreads - 1);
              this.emit('batch_progress', { accountId, stats });
            }
          });

          await Promise.allSettled(workerPromises);
        }
      } finally {
        stats.running = false;
        stats.activeThreads = 0;
        this.jobs.set(accountId, {
          running: false,
          abortController: null,
          stats
        });
        this.emit('batch_progress', { accountId, stats });
      }
    })();

    return stats;
  }

  stopBatch(accountId) {
    const job = this.jobs.get(accountId);
    if (job && job.running && job.abortController) {
      job.abortController.abort();
      job.running = false;
      job.stats.running = false;
      this.emit('batch_progress', { accountId, stats: job.stats });
      return true;
    }
    return false;
  }

  abortAllForAccount(accountId) {
    this.stopBatch(accountId);
    const prefix = `${accountId}::`;
    for (const [k, ctrl] of Array.from(this.singleRowControllers.entries())) {
      if (k.startsWith(prefix)) {
        try {
          ctrl.abort();
        } catch (_) {}
        this.singleRowControllers.delete(k);
      }
    }
  }
}

module.exports = {
  BatchScheduler
};
