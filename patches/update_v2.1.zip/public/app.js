(() => {
  const urlParams = new URLSearchParams(window.location.search);
  const pinnedAccountFromUrl = urlParams.get('account') || '';

  const state = {
    version: '2.1',
    accounts: [],
    activeAccount: null,
    loginTargetAccountId: null,
    filmGenres: [],
    voicePresets: [],
    lightingPresets: [],
    actingStylePresets: [],
    combatIntensityPresets: [],
    transitionEffects: [],
    shotSizePresets: [],
    cameraMovePresets: [],
    colorGradePresets: [],
    posterThemePresets: [],
    posterSourceModes: [],
    posterBadgePresets: [],
    activePromoVariantIdx: 0,
    license: null,
    batchStats: null,
    activeTab: 'script',
    sceneFilter: 'all',
    sequentialPlaylist: [],
    sequentialIndex: -1,
    castBatchRunning: false,
    castBatchAbort: false,
    generatingCharId: null,
    locBatchRunning: false,
    locBatchAbort: false,
    generatingLocId: null,
    cachedUpdateInfo: null,
    updateInstalling: false
  };

  const SAMPLE_STORIES = {
    fairytale: {
      genreId: 'fairy_tale_kids',
      lightingPreset: 'golden_hour',
      worldLock: 'Làng quê Bắc Bộ Việt Nam cổ xưa thanh bình, mái nhà tranh, giếng nước gốc đa, sương sớm nắng vàng ấm áp, tuyệt đối không có đồ vật hiện đại.',
      story: [
        'Cảnh 1: Sân nhà tranh buổi sáng sớm nắng xuyên qua tán cau, khói bếp bay nhẹ.',
        '[Dẫn chuyện]: Ngày xửa ngày xưa, ở một ngôi làng nhỏ ven sông, có cô Tấm hiền lành chịu thương chịu khó sống cùng dì ghẻ và Cám.',
        '',
        'Cảnh 2: Bên giếng nước cổ rêu phong dưới gốc cây thị vàng ươm.',
        '[@Tam]: Bống ơi Bống à, lên ăn cơm vàng cơm bạc nhà ta, chớ ăn cơm hẩm cháo hoa nhà người.',
        '',
        'Cảnh 3: Dưới mặt nước giếng trong vắt, chú cá Bống nhỏ vẫy đuôi ánh bạc bơi lên mừng rỡ.',
        '[Dẫn chuyện]: Mỗi lần nghe tiếng gọi quen thuộc, chú cá Bống nhỏ lại ngoi lên mặt nước, trở thành người bạn tri kỷ duy nhất của cô gái nghèo.',
        '',
        'Cảnh 4: Đêm hội làng rực rỡ đèn lồng đỏ, đoàn ngựa của Hoàng Tử đi qua con đường lát gạch cổ.',
        '[@HoangTu]: Đôi hài thêu tinh xảo này chắc chắn thuộc về một người con gái có tâm hồn thanh khiết nhất kinh thành!'
      ].join('\n')
    },
    pixar: {
      genreId: '3d_pixar',
      lightingPreset: 'volumetric_godrays',
      worldLock: 'Khu rừng thu lá phong đỏ vàng rực rỡ kỳ diệu kiểu hoạt hình 3D Pixar, ánh nắng chiếu xuyên tán cây lung linh.',
      story: [
        'Cảnh 1: Bìa rừng lá phong rực nắng buổi bình minh, chú chó nhỏ lông vàng đeo khăn quàng đỏ đứng ngước nhìn con đường mòn.',
        '[Dẫn chuyện]: Sau cơn mưa đêm qua, chú cún nhỏ Lạc Lạc quyết định lên đường băng qua khu rừng mùa thu để tìm chiếc diều giấy bị gió cuốn đi của cậu chủ.',
        '',
        'Cảnh 2: Trên cành cây sồi cổ thụ, bác Cú Mèo đeo kính tròn khẽ nghiêng đầu nhìn xuống.',
        '[@BacCuMeo]: Chào cậu bạn nhỏ dũng cảm! Cậu đang đi tìm thứ gì giữa khu rừng rộng lớn này thế?',
        '[@LacLac]: Cháu đi tìm chiếc diều ngôi sao của cậu Minh ạ! Bác có thấy nó bay qua đây không?',
        '',
        'Cảnh 3: Đỉnh đồi cỏ xanh lộng gió nhìn ra thung lũng mây trắng, chiếc diều ngôi sao vướng trên nhành hoa dại.',
        '[Dẫn chuyện]: Nhờ sự chỉ đường tận tình của bác Cú Mèo, Lạc Lạc đã tìm thấy chiếc diều ngay khi ánh hoàng hôn vừa nhuộm vàng cả bầu trời.'
      ].join('\n')
    },
    history: {
      genreId: 'historical_epic',
      lightingPreset: 'volumetric_godrays',
      worldLock: 'Đại Việt thế kỷ 13 hào hùng, bến sông Bạch Đằng sương mù giăng kín mặt nước, chiến thuyền gỗ cổ đại và giáp trụ truyền thống, tuyệt đối không có vật dụng hiện đại.',
      story: [
        'Cảnh 1: Toàn cảnh dòng sông Bạch Đằng mênh mông trong sương sớm, hàng trăm chiến thuyền gỗ nhẹ lướt trên sóng nước.',
        '[Dẫn chuyện]: Mùa xuân năm một nghìn hai trăm tám mươi tám, trên dòng sông Bạch Đằng lịch sử, thế trận cọc ngầm đã sẵn sàng chờ con nước lớn.',
        '',
        'Cảnh 2: Trên mũi chiến thuyền soái hạm, vị Tướng Quân khoác giáp đồng uy nghiêm rút gươm chỉ thẳng về phía mặt trời mọc.',
        '[@TuongQuan]: Hỡi ba quân tướng sĩ! Hôm nay chúng ta quyết giữ trọn non sông bờ cõi của tổ tiên!',
        '',
        'Cảnh 3: Nước thủy triều rút mạnh để lộ hàng cọc gỗ nhọn hoắt giữa sóng bạc, tiếng trống trận vang dội khắp mặt sông.',
        '[Dẫn chuyện]: Khi tiếng trống lệnh vang rền cả đất trời, toàn bộ đoàn thuyền đồng loạt quay mũi phản công tạo nên bản hùng ca bất diệt.'
      ].join('\n')
    }
  };

  let saveTimer = null;
  const rowSaveTimers = new Map();
  const charSaveTimers = new Map();
  const locSaveTimers = new Map();

  function $(id) {
    return document.getElementById(id);
  }

  function escapeHtml(str) {
    return String(str ?? '')
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;');
  }

  function showToast(msg, type = 'info') {
    const box = $('toastContainer');
    if (!box) return;
    const el = document.createElement('div');
    el.className = `cinema-toast ${type}`;
    el.textContent = msg;
    box.appendChild(el);
    setTimeout(() => {
      el.style.opacity = '0';
      setTimeout(() => el.remove(), 250);
    }, 3600);
  }

  async function api(url, options = {}) {
    const opts = { ...options };
    if (opts.body && typeof opts.body === 'object' && !(opts.body instanceof FormData)) {
      opts.headers = { 'Content-Type': 'application/json', ...(opts.headers || {}) };
      opts.body = JSON.stringify(opts.body);
    }
    const res = await fetch(url, opts);
    const data = await res.json().catch(() => ({ ok: false, error: `HTTP ${res.status}` }));
    if (!res.ok || data.ok === false) {
      if (data.licenseRequired) {
        openModal('modalLicense');
      }
      throw new Error(data.error || `Lỗi yêu cầu (${res.status})`);
    }
    return data;
  }

  /* ==================== THEME & TABS ==================== */

  function initTheme() {
    const saved = localStorage.getItem('mcs_theme') || 'dark';
    if (saved === 'light') {
      document.body.classList.add('light-theme');
      $('btnToggleTheme').textContent = '🌙';
    } else {
      document.body.classList.remove('light-theme');
      $('btnToggleTheme').textContent = '☀️';
    }
  }

  function switchTab(tabId) {
    state.activeTab = tabId;
    document.querySelectorAll('.step-tab').forEach((btn) => {
      btn.classList.toggle('active', btn.dataset.tab === tabId);
    });
    document.querySelectorAll('.tab-pane').forEach((pane) => {
      pane.classList.toggle('active', pane.id === `tab-${tabId}`);
    });
    if (tabId === 'postprod') {
      renderPostProductionTab();
    }
  }

  function openModal(id) {
    const m = $(id);
    if (m) m.classList.remove('hidden');
  }

  function closeModal(id) {
    if (id === 'modalUpdateOta' && (state.updateInstalling || state.cachedUpdateInfo?.mandatory)) {
      return;
    }
    const m = $(id);
    if (m) m.classList.add('hidden');
    if (id === 'modalZoomVideo') {
      const v = $('zoomVideoPlayer');
      if (v) v.pause();
    }
  }

  /* ==================== TOP BAR & ACCOUNT / LICENSE (GIỐNG MUSE FLOW STUDIO 3.8) ==================== */

  function getAccountLoginAndTokenDisplay(acc) {
    if (!acc) {
      return { loginName: 'Chưa đăng nhập', usedText: '--', remainingText: '--' };
    }
    const info = acc.accountInfo || {};
    const tu = info.tokenUsage && typeof info.tokenUsage === 'object' ? info.tokenUsage : null;
    const rawCand =
      info.customLoginName ||
      info.loginName ||
      info.agentName ||
      (info.displayName &&
      !/chưa kết nối|chưa đăng nhập|đã đăng xuất/i.test(info.displayName) &&
      info.displayName !== acc.name
        ? info.displayName
        : '');

    const loginName = rawCand
      ? String(rawCand).trim()
      : acc.loginVerified
      ? 'Đã đăng nhập'
      : 'Chưa đăng nhập';

    if (!tu) {
      return { loginName, usedText: '--', remainingText: '--' };
    }

    const usedPct = typeof tu.tokensUsedPercent === 'number' ? Math.min(100, Math.max(0, tu.tokensUsedPercent)) : 0;
    const remPct =
      typeof tu.tokensRemainingPercent === 'number'
        ? Math.min(100, Math.max(0, tu.tokensRemainingPercent))
        : Math.max(0, 100 - usedPct);

    const usedText = tu.hasTokenPool
      ? `${tu.tokensUsedFormatted || '0'} (${usedPct}%)`
      : tu.tokensUsedFormatted || `${usedPct}%`;
    const remainingText = tu.hasTokenPool
      ? `${tu.tokensRemainingFormatted || '0'} (${remPct}%)`
      : tu.tokensRemainingFormatted || `${remPct}%`;

    return { loginName, usedText, remainingText };
  }

  function renderTopBar() {
    const acc = state.activeAccount;
    if ($('topVersionBadge') && state.version) {
      $('topVersionBadge').textContent = `v${state.version}`;
    }

    const sel = $('selectActiveMovie');
    if (sel) {
      const opts = (state.accounts || [])
        .map((a) => {
          const dot = a.loginVerified ? '🟢' : '🔴';
          const meta = getAccountLoginAndTokenDisplay(a);
          const userSuffix =
            a.loginVerified && meta.loginName && !/^đã đăng nhập$/i.test(meta.loginName)
              ? ` — ${meta.loginName}`
              : '';
          const done = (a.rows || []).filter((r) => r.status === 'completed').length;
          const total = (a.rows || []).length;
          return `<option value="${escapeHtml(a.id)}" ${
            acc && a.id === acc.id ? 'selected' : ''
          }>${dot} ${escapeHtml(a.name)}${escapeHtml(userSuffix)} (${done}/${total} cảnh)</option>`;
        })
        .join('');
      sel.innerHTML = `${opts}<option value="__add_new__">➕ Thêm Tài khoản &amp; Bộ phim mới...</option>`;
    }

    if (!acc) return;

    const meta = getAccountLoginAndTokenDisplay(acc);
    const isLogged = Boolean(acc.loginVerified);
    $('loginDot').className = `status-dot ${isLogged ? 'online' : 'offline'}`;
    $('loginBtnLabel').textContent = isLogged ? meta.loginName : 'Đăng nhập tài khoản';
    if ($('topQuotaUsedText')) $('topQuotaUsedText').textContent = meta.usedText;
    if ($('topQuotaRemainingText')) $('topQuotaRemainingText').textContent = meta.remainingText;

    // Cập nhật huy hiệu trên thanh 4 bước
    const castCount = (acc.characters || []).length;
    const locCount = (acc.locations || []).length;
    $('badgeCastCount').textContent = locCount > 0 ? `${castCount}+${locCount}` : String(castCount);
    const doneScenes = (acc.rows || []).filter((r) => r.status === 'completed').length;
    const totalScenes = (acc.rows || []).length;
    $('badgeSceneProgress').textContent = `${doneScenes}/${totalScenes}`;

    // Bản quyền
    if (state.license) {
      const hwid = state.license.hwid || state.license.machineId || '--';
      $('licMachineId').textContent = hwid;
      const planLabel = state.license.planName ? ` (${state.license.planName})` : '';
      $('licStatusText').textContent = state.license.valid
        ? `✅ Đang sử dụng hợp lệ${planLabel}`
        : `⚠️ ${state.license.reason || 'Vui lòng kích hoạt bản quyền'}`;
      const rem = state.license.daysRemaining ? ` • Còn lại: ${state.license.daysRemaining}` : '';
      $('licExpiryText').textContent = `${state.license.expiresAtFormatted || '--'}${rem}`;
      const licBtn = $('btnOpenLicenseModal');
      if (licBtn) {
        licBtn.textContent = state.license.valid
          ? state.license.isTrial
            ? '👑 Dùng Thử'
            : '👑 Bản Quyền'
          : '⚠️ Kích Hoạt';
      }
    }
  }

  /* ==================== TAB 1: KỊCH BẢN & THỂ LOẠI ==================== */

  function populateStaticDropdowns() {
    const voiceSel = $('cfgNarratorVoice');
    if (voiceSel && state.voicePresets.length > 0) {
      voiceSel.innerHTML = state.voicePresets
        .map((v) => `<option value="${escapeHtml(v.id)}">${escapeHtml(v.label)}</option>`)
        .join('');
    }

    const lightSel = $('cfgLightingPreset');
    if (lightSel && state.lightingPresets.length > 0) {
      lightSel.innerHTML = state.lightingPresets
        .map((l) => `<option value="${escapeHtml(l.id)}">${escapeHtml(l.label)}</option>`)
        .join('');
    }

    const actSel = $('cfgActingStyle');
    if (actSel && state.actingStylePresets.length > 0) {
      actSel.innerHTML = state.actingStylePresets
        .map((a) => `<option value="${escapeHtml(a.id)}">${escapeHtml(a.label)}</option>`)
        .join('');
    }
    const combatSel = $('cfgCombatIntensity');
    if (combatSel && state.combatIntensityPresets.length > 0) {
      combatSel.innerHTML = state.combatIntensityPresets
        .map((c) => `<option value="${escapeHtml(c.id)}">${escapeHtml(c.label)}</option>`)
        .join('');
    }

    const transSel = $('selectExportTransition');
    const gradeSel = $('selectColorGrade');
    if (gradeSel && state.colorGradePresets.length > 0) {
      gradeSel.innerHTML = state.colorGradePresets
        .map((g) => `<option value="${escapeHtml(g.id)}">${escapeHtml(g.label)}</option>`)
        .join('');
    }
    if (transSel && state.transitionEffects.length > 0) {
      transSel.innerHTML = state.transitionEffects
        .map((t) => `<option value="${escapeHtml(t.id)}">${escapeHtml(t.label)}</option>`)
        .join('');
    }

    const posterSrcSel = $('selectPosterSourceMode');
    if (posterSrcSel && state.posterSourceModes.length > 0) {
      posterSrcSel.innerHTML = state.posterSourceModes
        .map((m) => `<option value="${escapeHtml(m.id)}">${escapeHtml(m.label)}</option>`)
        .join('');
    }
    const posterThemeSel = $('selectPosterTheme');
    if (posterThemeSel && state.posterThemePresets.length > 0) {
      posterThemeSel.innerHTML = state.posterThemePresets
        .map((p) => `<option value="${escapeHtml(p.id)}">${escapeHtml(p.label)}</option>`)
        .join('');
    }
    const posterBadgeSel = $('selectPosterBadge');
    if (posterBadgeSel && state.posterBadgePresets.length > 0) {
      posterBadgeSel.innerHTML = state.posterBadgePresets
        .map((b) => `<option value="${escapeHtml(b.id)}">${escapeHtml(b.label)}</option>`)
        .join('');
    }
  }

  // v1.7: Vũ khí / Pháp bảo CHỈ hiển thị khi chọn thể loại Tiên Hiệp / Huyền Huyễn
  const WEAPON_GENRE_IDS = new Set(['xianxia_fantasy']);
  function isWeaponGenreActive(acc = state.activeAccount) {
    return WEAPON_GENRE_IDS.has(acc?.settings?.filmConfig?.genreId || '');
  }

  function renderGenreCards() {
    const grid = $('genreCardGrid');
    if (!grid || !state.activeAccount) return;
    const currentGenreId = state.activeAccount.settings?.filmConfig?.genreId || '3d_pixar';

    grid.innerHTML = (state.filmGenres || [])
      .map((g) => {
        const isSel = g.id === currentGenreId;
        const icon = g.icon || '🎬';
        const name = g.shortName || g.label || g.id;
        const sub = g.subDesc || '';
        return `
          <button type="button" class="genre-card ${isSel ? 'selected' : ''}" data-genre="${escapeHtml(g.id)}">
            <span class="genre-icon">${escapeHtml(icon)}</span>
            <div class="genre-text">
              <span class="genre-name">${escapeHtml(name)}</span>
              <span class="genre-sub">${escapeHtml(sub)}</span>
            </div>
          </button>
        `;
      })
      .join('');

    const activeGenre = state.filmGenres.find((g) => g.id === currentGenreId) || state.filmGenres[0];
    if (activeGenre) {
      $('activeGenrePill').textContent = activeGenre.label || `${activeGenre.icon || ''} ${activeGenre.shortName || ''}`;
    }
    $('customStyleWrap').classList.toggle('hidden', currentGenreId !== 'custom');

    grid.querySelectorAll('.genre-card').forEach((card) => {
      card.addEventListener('click', () => {
        const gId = card.dataset.genre;
        const chosen = state.filmGenres.find((x) => x.id === gId);
        const patch = { genreId: gId };
        if (chosen && chosen.defaultAspect) {
          patch.aspectRatio = chosen.defaultAspect;
          $('cfgAspectRatio').value = chosen.defaultAspect;
        }
        updateFilmConfigLive(patch);
        renderGenreCards();
        // Bật/tắt khu vực Vũ khí ở Bước 2 & ô Vũ khí trên thẻ cảnh ở Bước 3 theo thể loại vừa chọn
        renderCastTab();
        renderProductionTab();
        if (WEAPON_GENRE_IDS.has(gId)) {
          showToast('🐉 Đã bật khu vực ⚔️ Vũ khí / Pháp bảo cho thể loại Tiên Hiệp / Huyền Huyễn (Bước 2).', 'info');
        }
      });
    });
  }

  function renderScriptTab() {
    const acc = state.activeAccount;
    if (!acc) return;
    const fc = acc.settings?.filmConfig || {};

    renderGenreCards();
    $('inputCustomStyle').value = fc.customStylePrompt || '';
    $('cfgAspectRatio').value = fc.aspectRatio || '16:9';
    $('cfgResolution').value = fc.resolution || '720p';

    // Chọn giá trị gần nhất trong dropdown targetMovieSeconds
    const tSec = String(fc.targetMovieSeconds || 180);
    const tSel = $('cfgTargetMovieSeconds');
    if (Array.from(tSel.options).some((o) => o.value === tSec)) {
      tSel.value = tSec;
    }

    const sSec = String(fc.sceneDurationSeconds || 10);
    const sSel = $('cfgSceneDuration');
    if (Array.from(sSel.options).some((o) => o.value === sSec)) {
      sSel.value = sSec;
    }

    $('cfgAudioMode').value = fc.audioMode || 'mixed';
    if (fc.narratorVoicePreset) {
      $('cfgNarratorVoice').value = fc.narratorVoicePreset;
    }
    $('inputWorldLock').value = fc.worldLock || '';
    if ($('cfgLightingPreset')) {
      $('cfgLightingPreset').value = fc.lightingPreset || 'auto';
    }
    if ($('inputCustomLighting') && document.activeElement !== $('inputCustomLighting')) {
      $('inputCustomLighting').value = fc.customLightingNote || '';
    }
    if ($('cfgActingStyle')) {
      $('cfgActingStyle').value = fc.actingStyle || 'subtle_realistic';
    }
    if ($('cfgCombatIntensity')) {
      $('cfgCombatIntensity').value = fc.combatIntensity || 'epic_donghua';
    }

    if (document.activeElement !== $('textareaStoryDraft')) {
      $('textareaStoryDraft').value = fc.storyDraft || '';
    }
    updateScriptWordStats();
  }

  function updateScriptWordStats() {
    const txt = ($('textareaStoryDraft').value || '').trim();
    const words = txt ? txt.split(/\s+/).filter(Boolean).length : 0;
    const movieSec = Number($('cfgTargetMovieSeconds').value) || 180;
    const sceneSec = Number($('cfgSceneDuration').value) || 10;
    const estScenes = Math.max(1, Math.round(movieSec / sceneSec));
    $('scriptWordStats').textContent = `${words} từ • Mục tiêu ~${estScenes} phân cảnh (${sceneSec}s/cảnh)`;
  }

  function updateFilmConfigLive(partialFilmCfg) {
    if (!state.activeAccount) return;
    const accId = state.activeAccount.id;
    state.activeAccount.settings.filmConfig = {
      ...(state.activeAccount.settings.filmConfig || {}),
      ...partialFilmCfg
    };

    if (saveTimer) clearTimeout(saveTimer);
    saveTimer = setTimeout(async () => {
      try {
        const res = await api(`/api/accounts/${accId}/settings`, {
          method: 'PUT',
          body: { filmConfig: state.activeAccount.settings.filmConfig }
        });
        if (state.activeAccount && state.activeAccount.id === accId) {
          state.activeAccount = res.account;
        }
      } catch (_) {}
    }, 350);
  }

  /* ==================== TAB 2: ĐOÀN DIỄN VIÊN (CAST STUDIO) ==================== */

  function renderCastTab() {
    const acc = state.activeAccount;
    if (!acc) return;
    const chars = acc.characters || [];
    const onScreenCount = chars.filter((c) => c.roleType !== 'narrator').length;
    const weaponGenreOn = isWeaponGenreActive(acc);

    if ($('castToolbarTitle')) {
      $('castToolbarTitle').textContent = weaponGenreOn
        ? '🎭 Hồ Sơ Đoàn Diễn Viên & Khóa Vũ Khí / Pháp Bảo Cố Định'
        : '🎭 Hồ Sơ Đoàn Diễn Viên & Khóa Nhân Vật Xuyên Suốt';
    }
    if ($('castToolbarDesc')) {
      $('castToolbarDesc').innerHTML = weaponGenreOn
        ? 'Khóa đồng nhất 100% <strong>Khuôn mặt, Trang phục &amp; Vũ khí / Pháp bảo</strong> xuyên suốt mọi phân cảnh (vũ khí chỉ xuất hiện ở cảnh cần dùng).'
        : 'Khóa đồng nhất 100% <strong>Khuôn mặt, Trang phục &amp; Giọng nói</strong> của từng vai diễn xuyên suốt mọi phân cảnh.';
    }

    const genAllBtn = $('btnAiGenerateAllCast');
    const stopAllBtn = $('btnStopGenerateAllCast');
    if (genAllBtn && stopAllBtn) {
      genAllBtn.classList.toggle('hidden', state.castBatchRunning);
      genAllBtn.disabled = onScreenCount === 0;
      stopAllBtn.classList.toggle('hidden', !state.castBatchRunning);
    }

    $('castEmptyState').classList.toggle('hidden', chars.length > 0);
    const grid = $('castCardGrid');
    if (chars.length === 0) {
      grid.innerHTML = '';
      renderLocationVaultSection();
      return;
    }

    const voiceOptionsHtml = (selectedId) =>
      state.voicePresets
        .map(
          (v) =>
            `<option value="${escapeHtml(v.id)}" ${v.id === selectedId ? 'selected' : ''}>${escapeHtml(
              v.label
            )}</option>`
        )
        .join('');

    grid.innerHTML = chars
      .map((ch) => {
        const portraitImg = (ch.referenceImages || []).find((im) => Number(im?.slot || 0) === 0) || null;
        const weaponImg = (ch.referenceImages || []).find((im) => Number(im?.slot) === 1) || null;
        const isGenNow = state.generatingCharId === ch.id;
        const isGenWepNow = state.generatingWeaponCharId === ch.id;
        const wepMode = ch.weaponLockMode || 'smart_context';
        const isNarratorOnly = ch.roleType === 'narrator';
        return `
          <div class="actor-card ${isGenNow || isGenWepNow ? 'is-generating-portrait' : ''}" data-char-id="${escapeHtml(ch.id)}">
            <div class="actor-top">
              <div class="actor-portrait-box">
                ${
                  portraitImg && portraitImg.publicUrl
                    ? `<img src="${escapeHtml(portraitImg.publicUrl)}?t=${Date.now()}" alt="${escapeHtml(ch.name)}" />
                       <button type="button" class="portrait-remove-btn" data-act="remove-char-img" title="Xóa ảnh chân dung">✕</button>`
                    : `<div class="portrait-placeholder" data-act="pick-char-img">${
                        isGenNow ? '⏳<br/>AI đang vẽ<br/>nhân vật...' : '📷<br/>Bấm tải ảnh<br/>hoặc AI tạo'
                      }</div>`
                }
                <input type="file" accept="image/*" class="hidden char-file-input" />
              </div>

              <div class="actor-meta-col">
                <div class="actor-name-row">
                  <input type="text" class="cinema-input char-name-inp" value="${escapeHtml(ch.name)}" placeholder="Tên nhân vật..." />
                  <button type="button" class="icon-btn danger-hover" data-act="del-char" title="Xóa diễn viên">🗑️</button>
                </div>

                <div style="display:flex; align-items:center; gap:6px; flex-wrap:wrap;">
                  <span class="actor-tag-badge" title="Mã gắn nhân vật trong lời thoại kịch bản">${escapeHtml(ch.tag)}</span>
                  <select class="cinema-select compact-sel char-role-sel">
                    <option value="character" ${!isNarratorOnly ? 'selected' : ''}>🎭 Xuất hiện trên hình</option>
                    <option value="narrator" ${isNarratorOnly ? 'selected' : ''}>🎙️ Chỉ đọc dẫn chuyện</option>
                  </select>
                </div>

                <div class="portrait-action-row">
                  <button type="button" class="mini-ghost-btn" data-act="pick-char-img">📤 Tải ảnh NV</button>
                  <button type="button" class="mini-gold-btn" data-act="ai-portrait" ${
                    state.castBatchRunning ? 'disabled' : ''
                  } title="Dùng AI vẽ ảnh nhân vật gốc (luôn để tay không — vũ khí chỉ xuất hiện ở những cảnh cần dùng)">${
                    isGenNow ? '⏳ Đang vẽ...' : '🎨 AI Tạo Ảnh NV'
                  }</button>
                </div>
              </div>
            </div>

            <div class="cfg-field">
              <label>🔊 Giọng nói khóa riêng suốt bộ phim:</label>
              <select class="cinema-select compact-sel char-voice-sel">
                ${voiceOptionsHtml(ch.voicePreset || 'auto')}
              </select>
            </div>

            <div>
              <div class="actor-dna-head">
                <span>🧬 Ngoại hình &amp; Trang phục cố định (DNA):</span>
                <button type="button" class="tiny-tag-btn" data-act="ai-read-dna" title="Đọc tự động đặc điểm khuôn mặt & quần áo từ ảnh chân dung">✨ AI Đọc Ảnh</button>
              </div>
              <textarea class="actor-dna-textarea char-dna-inp" rows="2" placeholder="VD: Nam thanh niên 20 tuổi, mày kiếm mắt sáng, tóc đen buộc cao, khoác áo choàng đen viền vàng cổ trang...">${escapeHtml(
                ch.appearanceDna || ''
              )}</textarea>
            </div>

            <div class="weapon-lock-box ${isNarratorOnly || !weaponGenreOn ? 'hidden' : ''}">
              <div class="weapon-lock-head">
                <span class="weapon-lock-title">⚔️ Vũ khí / Pháp bảo cố định (Chống nhảy loạn):</span>
                <select class="cinema-select compact-sel char-weapon-mode-sel" style="font-size:11px; padding:3px 7px;" title="Chế độ dùng vũ khí trong các phân cảnh">
                  <option value="smart_context" ${wepMode === 'smart_context' ? 'selected' : ''}>⚡ Chỉ rút khi cảnh cần</option>
                  <option value="always_carry" ${wepMode === 'always_carry' ? 'selected' : ''}>🎒 Đeo theo người, chỉ rút khi cần</option>
                  <option value="off" ${wepMode === 'off' ? 'selected' : ''}>🚫 Không dùng vũ khí</option>
                </select>
              </div>
              <div class="weapon-hint-line">💡 Ảnh nhân vật nên để <strong>tay không</strong>. Vũ khí chỉ được đưa vào cảnh có hành động như <em>rút kiếm, vung đao, giao chiến...</em> Muốn ép từng cảnh thì chọn ở ô <strong>⚔️ Vũ khí</strong> trên thẻ cảnh (Bước 3).</div>

              <div class="weapon-ref-row">
                <div class="weapon-thumb-box" title="Ảnh mẫu Vũ khí / Pháp bảo cố định (Slot #2)">
                  ${
                    weaponImg && weaponImg.publicUrl
                      ? `<img src="${escapeHtml(weaponImg.publicUrl)}?t=${Date.now()}" alt="Weapon" />
                         <button type="button" class="portrait-remove-btn" data-act="remove-weapon-img" title="Gỡ ảnh vũ khí">✕</button>`
                      : `<div class="weapon-thumb-placeholder" data-act="pick-weapon-img">${
                          isGenWepNow ? '⏳ Đang vẽ VK...' : '🗡️<br/>Ảnh Vũ Khí<br/>(Tùy chọn)'
                        }</div>`
                  }
                  <input type="file" accept="image/*" class="hidden char-weapon-file-input" />
                </div>

                <div class="weapon-meta-right">
                  <div class="weapon-btn-row">
                    <button type="button" class="mini-ghost-btn" data-act="pick-weapon-img" style="font-size:11px; padding:4px 8px;">📤 Tải ảnh VK</button>
                    <button type="button" class="mini-gold-btn" data-act="ai-weapon" style="font-size:11px; padding:4px 8px;" title="Dùng AI thiết kế ảnh mẫu Vũ khí rời theo mô tả bên dưới để ghim cứng cho các cảnh đánh nhau">${
                      isGenWepNow ? '⏳ Đang vẽ...' : '⚔️ AI Tạo VK'
                    }</button>
                    <button type="button" class="tiny-tag-btn" data-act="ai-read-weapon-dna" title="Đọc tự động hình dáng hình học vật lý từ ảnh vũ khí đã tải lên">✨ Đọc Ảnh VK</button>
                  </div>
                  <textarea class="actor-dna-textarea char-weapon-dna-inp" rows="2" placeholder="Mô tả rõ hình dáng, độ dài, bản rộng, màu sắc (VD: Thanh cự xích đen nhám phẳng không mũi nhọn dài 1m6, rộng 25cm khắc vân lửa đỏ — cấm vẽ kiếm mảnh)...">${escapeHtml(
                    ch.weaponDna || ''
                  )}</textarea>
                </div>
              </div>
            </div>
          </div>
        `;
      })
      .join('');

    // Gắn sự kiện cho từng thẻ diễn viên
    grid.querySelectorAll('.actor-card').forEach((card) => {
      const charId = card.dataset.charId;
      const fileInp = card.querySelector('.char-file-input');
      const wepFileInp = card.querySelector('.char-weapon-file-input');

      const buildCharPayloadFromCard = () => ({
        id: charId,
        name: card.querySelector('.char-name-inp').value,
        roleType: card.querySelector('.char-role-sel').value,
        voicePreset: card.querySelector('.char-voice-sel').value,
        appearanceDna: card.querySelector('.char-dna-inp').value,
        weaponDna: card.querySelector('.char-weapon-dna-inp')?.value || '',
        weaponLockMode: card.querySelector('.char-weapon-mode-sel')?.value || 'smart_context'
      });

      const scheduleCharSave = () => {
        if (charSaveTimers.has(charId)) clearTimeout(charSaveTimers.get(charId));
        charSaveTimers.set(
          charId,
          setTimeout(async () => {
            try {
              const res = await api(`/api/accounts/${acc.id}/characters`, {
                method: 'POST',
                body: buildCharPayloadFromCard()
              });
              state.activeAccount = res.account;
              const updated = (res.account.characters || []).find((c) => c.id === charId);
              if (updated) {
                card.querySelector('.actor-tag-badge').textContent = updated.tag;
              }
              renderProductionTab();
            } catch (e) {
              showToast(e.message, 'error');
            }
          }, 420)
        );
      };

      card.querySelector('.char-name-inp').addEventListener('input', scheduleCharSave);
      card.querySelector('.char-role-sel').addEventListener('change', (ev) => {
        card.querySelector('.weapon-lock-box')?.classList.toggle('hidden', ev.target.value === 'narrator' || !isWeaponGenreActive());
        scheduleCharSave();
      });
      card.querySelector('.char-voice-sel').addEventListener('change', scheduleCharSave);
      card.querySelector('.char-dna-inp').addEventListener('input', scheduleCharSave);
      card.querySelector('.char-weapon-dna-inp')?.addEventListener('input', scheduleCharSave);
      card.querySelector('.char-weapon-mode-sel')?.addEventListener('change', scheduleCharSave);

      card.querySelectorAll('[data-act="pick-char-img"]').forEach((b) => {
        b.addEventListener('click', () => fileInp.click());
      });

      fileInp.addEventListener('change', async () => {
        if (!fileInp.files || !fileInp.files[0]) return;
        const fd = new FormData();
        fd.append('image', fileInp.files[0]);
        try {
          showToast('Đang tải ảnh chân dung diễn viên...');
          const res = await api(`/api/accounts/${acc.id}/characters/${charId}/image/0`, {
            method: 'POST',
            body: fd
          });
          state.activeAccount = res.account;
          renderCastTab();
          renderProductionTab();
          showToast('Đã lưu ảnh chân dung diễn viên!', 'success');
        } catch (e) {
          showToast(e.message, 'error');
        }
      });

      const rmBtn = card.querySelector('[data-act="remove-char-img"]');
      if (rmBtn) {
        rmBtn.addEventListener('click', async () => {
          try {
            const res = await api(`/api/accounts/${acc.id}/characters/${charId}/image/0`, { method: 'DELETE' });
            state.activeAccount = res.account;
            renderCastTab();
            renderProductionTab();
          } catch (e) {
            showToast(e.message, 'error');
          }
        });
      }

      // Sự kiện tải / xóa / AI tạo Ảnh Vũ Khí Cố Định (Slot #1)
      card.querySelectorAll('[data-act="pick-weapon-img"]').forEach((b) => {
        b.addEventListener('click', () => wepFileInp?.click());
      });

      wepFileInp?.addEventListener('change', async () => {
        if (!wepFileInp.files || !wepFileInp.files[0]) return;
        const fd = new FormData();
        fd.append('image', wepFileInp.files[0]);
        try {
          showToast('⚔️ Đang tải ảnh vũ khí cố định...');
          const res = await api(`/api/accounts/${acc.id}/characters/${charId}/image/1`, {
            method: 'POST',
            body: fd
          });
          state.activeAccount = res.account;
          renderCastTab();
          renderProductionTab();
          showToast('⚔️ Đã ghim ảnh vũ khí cố định cho nhân vật!', 'success');
        } catch (e) {
          showToast(e.message, 'error');
        }
      });

      card.querySelector('[data-act="remove-weapon-img"]')?.addEventListener('click', async () => {
        try {
          const res = await api(`/api/accounts/${acc.id}/characters/${charId}/image/1`, { method: 'DELETE' });
          state.activeAccount = res.account;
          renderCastTab();
          renderProductionTab();
        } catch (e) {
          showToast(e.message, 'error');
        }
      });

      card.querySelector('[data-act="ai-weapon"]')?.addEventListener('click', async (ev) => {
        const btn = ev.currentTarget;
        const origText = btn.textContent;
        btn.disabled = true;
        btn.textContent = '⏳ Đang vẽ...';
        state.generatingWeaponCharId = charId;
        try {
          await api(`/api/accounts/${acc.id}/characters`, {
            method: 'POST',
            body: buildCharPayloadFromCard()
          });
          showToast('⚔️ AI đang thiết kế ảnh mẫu Vũ khí cố định (khoảng 25–45s)...');
          const res = await api(`/api/accounts/${acc.id}/characters/${charId}/ai-weapon`, { method: 'POST' });
          state.activeAccount = res.account;
          renderCastTab();
          renderProductionTab();
          showToast('✅ Đã tạo xong ảnh Vũ khí cố định chuẩn thiết kế!', 'success');
        } catch (e) {
          showToast(e.message, 'error');
        } finally {
          state.generatingWeaponCharId = null;
          btn.disabled = false;
          btn.textContent = origText;
        }
      });

      card.querySelector('[data-act="ai-read-weapon-dna"]')?.addEventListener('click', async (ev) => {
        const btn = ev.currentTarget;
        const origText = btn.textContent;
        btn.disabled = true;
        btn.textContent = '⏳ Đang đọc...';
        try {
          showToast('✨ AI đang đọc hình dáng hình học vật lý từ ảnh vũ khí...');
          const res = await api(`/api/accounts/${acc.id}/characters/${charId}/extract-dna`, {
            method: 'POST',
            body: { targetSlot: 1 }
          });
          state.activeAccount = res.account;
          renderCastTab();
          showToast('✅ Đã trích xuất xong mô tả khóa hình học vũ khí!', 'success');
        } catch (e) {
          showToast(e.message, 'error');
        } finally {
          btn.disabled = false;
          btn.textContent = origText;
        }
      });

      card.querySelector('[data-act="del-char"]').addEventListener('click', async () => {
        if (!confirm('Xóa diễn viên này khỏi đoàn làm phim?')) return;
        try {
          const res = await api(`/api/accounts/${acc.id}/characters/${charId}`, { method: 'DELETE' });
          state.activeAccount = res.account;
          renderTopBar();
          renderCastTab();
          renderProductionTab();
        } catch (e) {
          showToast(e.message, 'error');
        }
      });

      card.querySelector('[data-act="ai-portrait"]').addEventListener('click', async (ev) => {
        const btn = ev.currentTarget;
        const origText = btn.textContent;
        btn.disabled = true;
        btn.textContent = '⏳ Đang vẽ...';
        try {
          // Lưu cả Ngoại hình + Vũ khí cố định vừa gõ trước khi gọi AI vẽ
          await api(`/api/accounts/${acc.id}/characters`, {
            method: 'POST',
            body: buildCharPayloadFromCard()
          });
          showToast('🎨 AI Muse.ai đang thiết kế ảnh gốc nhân vật (khoảng 25–50s)...');
          const res = await api(`/api/accounts/${acc.id}/characters/${charId}/ai-portrait`, { method: 'POST' });
          state.activeAccount = res.account;
          renderCastTab();
          renderProductionTab();
          showToast('✅ Đã tạo xong ảnh gốc diễn viên đồng bộ thể loại phim!', 'success');
        } catch (e) {
          showToast(e.message, 'error');
        } finally {
          btn.disabled = false;
          btn.textContent = origText;
        }
      });

      card.querySelector('[data-act="ai-read-dna"]').addEventListener('click', async (ev) => {
        const btn = ev.currentTarget;
        const origText = btn.textContent;
        btn.disabled = true;
        btn.textContent = '⏳ Đang đọc...';
        try {
          showToast('✨ AI đang phân tích ảnh chân dung để trích xuất DNA ngoại hình...');
          const res = await api(`/api/accounts/${acc.id}/characters/${charId}/extract-dna`, {
            method: 'POST',
            body: { targetSlot: 0 }
          });
          state.activeAccount = res.account;
          renderCastTab();
          showToast('✅ Đã trích xuất xong DNA ngoại hình nhân vật!', 'success');
        } catch (e) {
          showToast(e.message, 'error');
        } finally {
          btn.disabled = false;
          btn.textContent = origText;
        }
      });
    });

    renderLocationVaultSection();
  }

  function renderLocationVaultSection() {
    const acc = state.activeAccount;
    if (!acc) return;
    const locs = acc.locations || [];

    const genAllLocBtn = $('btnAiGenerateAllLocations');
    const stopAllLocBtn = $('btnStopGenerateAllLocations');
    if (genAllLocBtn && stopAllLocBtn) {
      genAllLocBtn.classList.toggle('hidden', state.locBatchRunning);
      genAllLocBtn.disabled = locs.length === 0;
      stopAllLocBtn.classList.toggle('hidden', !state.locBatchRunning);
    }

    $('locationEmptyState')?.classList.toggle('hidden', locs.length > 0);
    const locGrid = $('locationCardGrid');
    if (!locGrid) return;
    if (locs.length === 0) {
      locGrid.innerHTML = '';
      return;
    }

    locGrid.innerHTML = locs
      .map((loc) => {
        const primaryImg = (loc.referenceImages || [])[0] || null;
        const isGenNow = state.generatingLocId === loc.id;
        return `
          <div class="location-card ${isGenNow ? 'is-generating-plate' : ''}" data-loc-id="${escapeHtml(loc.id)}">
            <div class="location-plate-box">
              ${
                primaryImg && primaryImg.publicUrl
                  ? `<img src="${escapeHtml(primaryImg.publicUrl)}?t=${Date.now()}" alt="${escapeHtml(loc.name)}" />
                     <button type="button" class="portrait-remove-btn" data-act="remove-loc-img" title="Gỡ ảnh bối cảnh cố định">✕</button>`
                  : `<div class="portrait-placeholder" data-act="pick-loc-img">${
                      isGenNow
                        ? '⏳ AI đang thiết kế phim trường trống (100% không người)...'
                        : '🏞️ Bấm tải ảnh bối cảnh trống hoặc để AI tự vẽ phim trường cố định'
                    }</div>`
              }
              <input type="file" accept="image/*" class="hidden loc-file-input" />
            </div>

            <div class="actor-name-row">
              <span class="loc-tag-badge" title="Mã gắn bối cảnh cố định">${escapeHtml(loc.tag)}</span>
              <input type="text" class="cinema-input loc-name-inp" value="${escapeHtml(loc.name)}" placeholder="Tên bối cảnh (VD: Sân nhà tranh)..." />
              <button type="button" class="icon-btn danger-hover" data-act="del-loc" title="Xóa bối cảnh này">🗑️</button>
            </div>

            <div class="portrait-action-row">
              <button type="button" class="mini-ghost-btn" data-act="pick-loc-img">📤 Tải ảnh bối cảnh</button>
              <button type="button" class="mini-gold-btn" data-act="ai-loc-plate" ${
                state.locBatchRunning ? 'disabled' : ''
              } title="Dùng AI Muse.ai vẽ ảnh phim trường trống (100% không người) đồng bộ thể loại & ánh sáng toàn phim">${
                isGenNow ? '⏳ Đang vẽ...' : '🏞️ AI Tạo Bối Cảnh (Trống)'
              }</button>
            </div>

            <div>
              <div class="actor-dna-head">
                <span>🏛️ Kiến trúc, bố cục &amp; đạo cụ cố định (Không người):</span>
              </div>
              <textarea class="actor-dna-textarea loc-dna-inp" rows="2" placeholder="VD: Sân gạch đỏ trước ngôi nhà gỗ 3 gian mái ngói rêu phong, bên phải có giếng đá cổ và cây thị lớn, tuyệt đối không có người...">${escapeHtml(
                loc.descriptionDna || ''
              )}</textarea>
            </div>
          </div>
        `;
      })
      .join('');

    locGrid.querySelectorAll('.location-card').forEach((card) => {
      const locId = card.dataset.locId;
      const fileInp = card.querySelector('.loc-file-input');

      const scheduleLocSave = () => {
        if (locSaveTimers.has(locId)) clearTimeout(locSaveTimers.get(locId));
        locSaveTimers.set(
          locId,
          setTimeout(async () => {
            try {
              const res = await api(`/api/accounts/${acc.id}/locations`, {
                method: 'POST',
                body: {
                  id: locId,
                  name: card.querySelector('.loc-name-inp').value,
                  descriptionDna: card.querySelector('.loc-dna-inp').value
                }
              });
              state.activeAccount = res.account;
              const updated = (res.account.locations || []).find((l) => l.id === locId);
              if (updated) {
                card.querySelector('.loc-tag-badge').textContent = updated.tag;
              }
              renderProductionTab();
            } catch (e) {
              showToast(e.message, 'error');
            }
          }, 420)
        );
      };

      card.querySelector('.loc-name-inp').addEventListener('input', scheduleLocSave);
      card.querySelector('.loc-dna-inp').addEventListener('input', scheduleLocSave);

      card.querySelectorAll('[data-act="pick-loc-img"]').forEach((b) => {
        b.addEventListener('click', () => fileInp.click());
      });

      fileInp.addEventListener('change', async () => {
        if (!fileInp.files || !fileInp.files[0]) return;
        const fd = new FormData();
        fd.append('image', fileInp.files[0]);
        try {
          showToast('Đang tải ảnh bối cảnh cố định...');
          const res = await api(`/api/accounts/${acc.id}/locations/${locId}/image`, {
            method: 'POST',
            body: fd
          });
          state.activeAccount = res.account;
          renderLocationVaultSection();
          renderProductionTab();
          showToast('🏞️ Đã khóa ảnh bối cảnh cố định!', 'success');
        } catch (e) {
          showToast(e.message, 'error');
        }
      });

      card.querySelector('[data-act="remove-loc-img"]')?.addEventListener('click', async () => {
        try {
          const res = await api(`/api/accounts/${acc.id}/locations/${locId}/image`, { method: 'DELETE' });
          state.activeAccount = res.account;
          renderLocationVaultSection();
          renderProductionTab();
        } catch (e) {
          showToast(e.message, 'error');
        }
      });

      card.querySelector('[data-act="del-loc"]').addEventListener('click', async () => {
        if (!confirm('Xóa bối cảnh cố định này khỏi dự án phim?')) return;
        try {
          const res = await api(`/api/accounts/${acc.id}/locations/${locId}`, { method: 'DELETE' });
          state.activeAccount = res.account;
          renderTopBar();
          renderLocationVaultSection();
          renderProductionTab();
        } catch (e) {
          showToast(e.message, 'error');
        }
      });

      card.querySelector('[data-act="ai-loc-plate"]').addEventListener('click', async (ev) => {
        const btn = ev.currentTarget;
        const origText = btn.textContent;
        btn.disabled = true;
        btn.textContent = '⏳ Đang vẽ...';
        try {
          await api(`/api/accounts/${acc.id}/locations`, {
            method: 'POST',
            body: {
              id: locId,
              name: card.querySelector('.loc-name-inp').value,
              descriptionDna: card.querySelector('.loc-dna-inp').value
            }
          });
          showToast('🏞️ AI Muse.ai đang thiết kế ảnh phim trường trống 100% không người (25–50s)...');
          const res = await api(`/api/accounts/${acc.id}/locations/${locId}/ai-plate`, { method: 'POST' });
          state.activeAccount = res.account;
          renderLocationVaultSection();
          renderProductionTab();
          showToast('✅ Đã tạo xong ảnh bối cảnh phim trường cố định!', 'success');
        } catch (e) {
          showToast(e.message, 'error');
        } finally {
          btn.disabled = false;
          btn.textContent = origText;
        }
      });
    });
  }

  /* ==================== TAB 3: TRUNG TÂM SẢN XUẤT PHÂN CẢNH ==================== */

  function isSceneRunning(status) {
    return ['queued', 'connecting', 'uploading', 'submitting', 'rendering', 'downloading'].includes(status);
  }

  function getScenePillInfo(row) {
    if (row.status === 'completed') return { cls: 'completed', label: '✅ Đã quay xong' };
    if (row.status === 'error') return { cls: 'error', label: '⚠️ Lỗi cảnh' };
    if (isSceneRunning(row.status)) return { cls: 'running', label: '🎬 Đang quay...' };
    return { cls: '', label: '⏳ Chờ bấm máy' };
  }

  function getQcBadgeInfo(qc) {
    if (!qc || !Number.isFinite(qc.score)) return null;
    if (qc.verdict === 'pass') return { cls: 'qc-pass', label: `🛡️ QC ${qc.score}`, title: 'Không phát hiện lỗi' };
    if (qc.verdict === 'warn') return { cls: 'qc-warn', label: `⚠️ QC ${qc.score}`, title: (qc.issues || []).join(' • ') };
    return { cls: 'qc-fail', label: `❌ QC ${qc.score}`, title: (qc.issues || []).join(' • ') };
  }

  function presetLabel(list, id) {
    return (list || []).find((p) => p.id === id)?.label || id;
  }

  /** Dải "Bản quay" của 1 cảnh: chọn bản đẹp nhất, xem điểm QC, xóa bản hỏng. */
  function buildTakesStripHtml(row) {
    const takes = Array.isArray(row.takes) ? row.takes : [];
    if (takes.length === 0) return '';
    const activeQc = getQcBadgeInfo(row.qc);
    const chips = takes
      .map((t, i) => {
        const isActive = t.id === row.activeTakeId;
        const q = getQcBadgeInfo(t.qc);
        return `<span class="take-chip ${isActive ? 'active' : ''} ${q ? q.cls : ''}" data-take-id="${escapeHtml(t.id)}" title="${escapeHtml(
          q ? `Điểm QC ${t.qc.score}/100${q.title ? ` — ${q.title}` : ''}` : 'Chưa kiểm tra chất lượng'
        )}">
          <button type="button" class="take-pick" data-act="pick-take">${isActive ? '▶ ' : ''}Bản ${i + 1}${q ? ` • ${t.qc.score}` : ''}</button>
          ${takes.length > 1 ? `<button type="button" class="take-del" data-act="del-take" title="Xóa bản quay này">✕</button>` : ''}
        </span>`;
      })
      .join('');
    const issuesLine =
      row.qc && (row.qc.issues || []).length > 0
        ? `<div class="take-issues ${activeQc ? activeQc.cls : ''}">${escapeHtml(row.qc.issues.join(' • '))}</div>`
        : '';
    const shotLine =
      row.lastShotPlan && row.lastShotPlan.shotSize
        ? `<div class="take-shot-note">🎥 Lần quay gần nhất: ${escapeHtml(presetLabel(state.shotSizePresets, row.lastShotPlan.shotSize))} • ${escapeHtml(
            presetLabel(state.cameraMovePresets, row.lastShotPlan.cameraMove)
          )}</div>`
        : '';
    return `
      <div class="take-strip-row">
        <span class="cast-strip-label">🎞️ Bản quay:</span>
        ${chips}
        ${row.videoUrl && !row.qc ? `<button type="button" class="tiny-tag-btn" data-act="run-qc" title="Kiểm tra khung đen, đứng hình, mất tiếng">🛡️ Kiểm tra QC</button>` : ''}
      </div>
      ${issuesLine}
      ${shotLine}
    `;
  }

  function buildMonitorStageInnerHtml(row) {
    const pad = String(row.index).padStart(2, '0');
    const pill = getScenePillInfo(row);
    const qcBadge = row.videoUrl ? getQcBadgeInfo(row.qc) : null;
    const envImg = (row.referenceImages || []).find((im) => im && im.publicUrl);

    const videoOrSlate =
      row.videoUrl
        ? `<video src="${escapeHtml(row.videoUrl)}" controls preload="metadata"></video>`
        : `
          <div class="monitor-slate">
            <div class="slate-clapper">${isSceneRunning(row.status) ? '🎥' : '🎬'}</div>
            <div class="slate-status-msg">${escapeHtml(row.statusMessage || 'Sẵn sàng bấm máy')}</div>
          </div>
        `;

    return `
      <div class="monitor-top-badges">
        <span class="scene-num-slate">CẢNH ${pad}</span>
        <span style="display:flex; gap:6px;">
          ${qcBadge ? `<span class="scene-qc-pill ${qcBadge.cls}" title="${escapeHtml(qcBadge.title)}">${qcBadge.label}</span>` : ''}
          <span class="scene-state-pill ${pill.cls}">${pill.label}</span>
        </span>
      </div>
      ${videoOrSlate}
      <div class="scene-env-ref-corner">
        ${
          envImg
            ? `<div class="env-thumb-chip" data-act="remove-env-img" title="Bấm để gỡ ảnh bối cảnh riêng của cảnh này">
                 <img src="${escapeHtml(envImg.publicUrl)}" alt="env" />
                 <span>✕ Bối cảnh</span>
               </div>`
            : `<button type="button" class="env-thumb-chip" data-act="pick-env-img" title="Tải ảnh bối cảnh / đạo cụ riêng cho phân cảnh này (Tùy chọn)">🖼️ + Ảnh bối cảnh</button>`
        }
        <input type="file" accept="image/*" class="hidden scene-env-file-inp" />
      </div>
    `;
  }

  function renderProductionSummaryAndControls() {
    const acc = state.activeAccount;
    if (!acc) return;
    const rows = acc.rows || [];
    const done = rows.filter((r) => r.status === 'completed').length;
    const sceneSec = Number(acc.settings?.filmConfig?.sceneDurationSeconds) || 10;
    const estTotalSec = rows.length * sceneSec;
    const mins = Math.floor(estTotalSec / 60);
    const secs = estTotalSec % 60;
    $('prodSummaryText').innerHTML = `Đã quay: <strong>${done} / ${rows.length}</strong> cảnh • Ước tính: <strong>${
      mins > 0 ? `${mins}p${String(secs).padStart(2, '0')}s` : `${secs}s`
    }</strong>`;

    const fc = acc.settings?.filmConfig || {};
    $('selectContinuityMode').value = fc.continuityMode || 'parallel_fast';
    if ($('chkAutoQcRetry')) $('chkAutoQcRetry').checked = acc.settings?.autoQcRetry !== false;
    $('selectConcurrency').value = String(fc.concurrency || 4);
    $('concurrencyWrap').classList.toggle('hidden', fc.continuityMode === 'sequential_chain');

    const isRunningBatch = Boolean(state.batchStats && state.batchStats.running);
    $('btnStartShootAll').classList.toggle('hidden', isRunningBatch);
    $('btnStopShootAll').classList.toggle('hidden', !isRunningBatch);

    const banner = $('batchLiveBanner');
    if (isRunningBatch && state.batchStats) {
      banner.classList.remove('hidden');
      const st = state.batchStats;
      const pct =
        st.totalTargetRows > 0
          ? Math.min(100, Math.round(((st.totalCompleted + st.totalFailed) / st.totalTargetRows) * 100))
          : 10;
      $('batchProgressFill').style.width = `${pct}%`;
      $('batchBannerText').textContent = `Đang bấm máy Lượt ${st.currentBatchIndex}/${st.totalBatches} • Hoàn tất ${st.totalCompleted}/${st.totalTargetRows} cảnh (Đang chạy ${st.activeThreads} máy quay ngầm)...`;
    } else {
      banner.classList.add('hidden');
    }
  }

  function matchesSceneFilter(row) {
    const f = state.sceneFilter;
    if (f === 'all') return true;
    if (f === 'completed') return row.status === 'completed';
    if (f === 'error') return row.status === 'error';
    if (f === 'running') return isSceneRunning(row.status);
    if (f === 'pending') return row.status !== 'completed' && !isSceneRunning(row.status);
    return true;
  }

  function renderProductionTab() {
    const acc = state.activeAccount;
    if (!acc) return;
    renderProductionSummaryAndControls();

    const grid = $('storyboardSceneGrid');
    const chars = acc.characters || [];
    const visibleRows = (acc.rows || []).filter(matchesSceneFilter);

    if (visibleRows.length === 0) {
      grid.innerHTML = `
        <div class="empty-stage-card" style="grid-column: 1 / -1;">
          <div class="empty-icon">🎞️</div>
          <h3>Không có phân cảnh nào khớp bộ lọc hiện tại</h3>
          <p>Chuyển bộ lọc về "Tất cả" hoặc bấm "➕ Thêm Cảnh" để tạo phân cảnh mới.</p>
        </div>
      `;
      return;
    }

    grid.innerHTML = visibleRows
      .map((row) => {
        const selectedIds = new Set(Array.isArray(row.sceneCharacterIds) ? row.sceneCharacterIds : []);
        const cardStateCls = isSceneRunning(row.status)
          ? 'is-rendering'
          : row.status === 'completed'
          ? 'is-completed'
          : row.status === 'error'
          ? 'is-error'
          : '';

        const castChipsHtml =
          chars.length > 0
            ? chars
                .filter((c) => c.roleType !== 'narrator')
                .map((c) => {
                  const isAct = selectedIds.has(c.id);
                  const img = (c.referenceImages || []).find((im) => Number(im?.slot || 0) === 0);
                  const hasWep = Boolean(
                    c.weaponLockMode !== 'off' &&
                      ((c.weaponDna && c.weaponDna.trim()) ||
                        (c.referenceImages || []).some((im) => Number(im?.slot) === 1))
                  );
                  const avaInner =
                    img && img.publicUrl
                      ? `<img src="${escapeHtml(img.publicUrl)}" alt="" />`
                      : `<span>🎭</span>`;
                  return `
                    <button type="button" class="scene-actor-chip ${isAct ? 'active' : ''}" data-char-toggle="${escapeHtml(
                      c.id
                    )}" title="Bật/tắt diễn viên ${escapeHtml(c.name)} (${escapeHtml(c.tag)})${
                      hasWep ? ' • Đã khóa vũ khí cố định' : ''
                    }">
                      <span class="mini-ava">${avaInner}</span>
                      <span>${escapeHtml(c.name)}</span>
                      ${hasWep ? '<span class="scene-wep-pill" title="Đã khóa hình học Vũ khí cố định">⚔️</span>' : ''}
                    </button>
                  `;
                })
                .join('')
            : `<span style="font-size:11.5px; color:var(--text-muted);">Chưa tạo diễn viên (Có thể thêm ở Bước 2)</span>`;

        const speakerInsertBtns = [
          `<button type="button" class="tiny-tag-btn" data-insert-speaker="[Dẫn chuyện]: ">+ Dẫn chuyện</button>`,
          ...chars.slice(0, 5).map(
            (c) =>
              `<button type="button" class="tiny-tag-btn" data-insert-speaker="[${escapeHtml(c.tag)}]: ">+ ${escapeHtml(
                c.name
              )}</button>`
          )
        ].join('');

        return `
          <article class="scene-studio-card ${cardStateCls}" data-row-index="${row.index}">
            <div class="scene-monitor-stage">
              ${buildMonitorStageInnerHtml(row)}
            </div>

            <div class="scene-card-body">
              <div class="scene-title-bar">
                <input type="text" class="scene-title-input" value="${escapeHtml(
                  row.sceneTitle || `Cảnh ${row.index}`
                )}" placeholder="Tên phân cảnh..." />
                ${
                  row.index > 1
                    ? `<label class="chain-toggle-label ${row.continueFromPrevScene ? 'active' : ''}" title="Trích xuất khung hình cuối của Cảnh ${
                        row.index - 1
                      } làm điểm bắt đầu nối tiếp mượt cho Cảnh ${row.index}">
                         <input type="checkbox" class="hidden chk-chain-prev" ${
                           row.continueFromPrevScene ? 'checked' : ''
                         } />
                         🔗 Nối cảnh ${row.index - 1}
                       </label>`
                    : ''
                }
              </div>

              <div class="scene-cast-strip">
                <span class="cast-strip-label">🎭 Diễn viên:</span>
                ${castChipsHtml}
              </div>

              <div class="scene-loc-trim-bar">
                <div class="scene-loc-group">
                  <span class="cast-strip-label" title="Khóa bối cảnh cố định từ Bước 2 để không nhảy kiến trúc">🏞️ Bối cảnh:</span>
                  <select class="cinema-select compact-sel scene-loc-sel">
                    <option value="">-- Tự do theo cảnh --</option>
                    ${(acc.locations || [])
                      .map((loc) => {
                        const hasPlate = Boolean(loc.referenceImages && loc.referenceImages[0]?.publicUrl);
                        return `<option value="${escapeHtml(loc.id)}" ${
                          row.sceneLocationId === loc.id ? 'selected' : ''
                        }>${hasPlate ? '📸 ' : ''}${escapeHtml(loc.name)} (${escapeHtml(loc.tag)})</option>`;
                      })
                      .join('')}
                  </select>
                </div>
                ${
                  isWeaponGenreActive(acc) && chars.some((c) => c.roleType !== 'narrator' && c.weaponLockMode !== 'off' && ((c.weaponDna || '').trim() || (c.referenceImages || []).some((im) => Number(im?.slot) === 1)))
                    ? `<div class="scene-weapon-group" title="Tự động: chỉ cầm vũ khí khi cảnh có hành động rút kiếm / giao chiến. Có thể ép thủ công cho riêng cảnh này.">
                        <span class="cast-strip-label">⚔️ Vũ khí:</span>
                        <select class="cinema-select compact-sel scene-weapon-sel">
                          <option value="auto" ${!row.weaponMode || row.weaponMode === 'auto' ? 'selected' : ''}>🤖 Tự động theo cảnh</option>
                          <option value="drawn" ${row.weaponMode === 'drawn' ? 'selected' : ''}>⚔️ Rút vũ khí</option>
                          <option value="none" ${row.weaponMode === 'none' ? 'selected' : ''}>✋ Tay không</option>
                        </select>
                      </div>`
                    : ''
                }
                <div class="scene-trim-group" title="Cắt gọt khoảng khựng đầu / cuối cảnh khi dựng xuất phim Master">
                  <span>✂️ Cắt nhịp:</span>
                  <label class="trim-mini-lbl">Đầu <input type="number" step="0.1" min="0" max="15" class="mini-trim-inp inp-trim-start" value="${
                    Number(row.trimStartSec) || 0
                  }" />s</label>
                  <label class="trim-mini-lbl">Đuôi <input type="number" step="0.1" min="0" max="15" class="mini-trim-inp inp-trim-end" value="${
                    Number(row.trimEndSec) || 0
                  }" />s</label>
                </div>
              </div>

              <div class="scene-camera-bar" title="Ngôn ngữ máy quay: cỡ cảnh / góc máy & chuyển động máy cho riêng cảnh này">
                <div class="scene-camera-group">
                  <span class="cast-strip-label">🎥 Cỡ cảnh:</span>
                  <select class="cinema-select compact-sel scene-shot-sel">
                    ${(state.shotSizePresets || [])
                      .map((s) => `<option value="${escapeHtml(s.id)}" ${(row.shotSize || 'auto') === s.id ? 'selected' : ''}>${escapeHtml(s.label)}</option>`)
                      .join('')}
                  </select>
                </div>
                <div class="scene-camera-group">
                  <span class="cast-strip-label">🎬 Máy quay:</span>
                  <select class="cinema-select compact-sel scene-move-sel">
                    ${(state.cameraMovePresets || [])
                      .map((m) => `<option value="${escapeHtml(m.id)}" ${(row.cameraMove || 'auto') === m.id ? 'selected' : ''}>${escapeHtml(m.label)}</option>`)
                      .join('')}
                  </select>
                </div>
              </div>

              <div class="scene-field-block">
                <div class="scene-field-head">
                  <label>🎥 Cảnh quay, Bối cảnh & Diễn xuất:</label>
                </div>
                <textarea class="scene-textarea inp-scene-prompt" rows="3" placeholder="Mô tả góc máy, không gian và hành động của nhân vật trong phân cảnh này...">${escapeHtml(
                  row.prompt || ''
                )}</textarea>
              </div>

              <div class="scene-field-block">
                <div class="scene-field-head">
                  <label>🎙️ Lời thoại / Thuyết minh:</label>
                  <div class="quick-speaker-chips">${speakerInsertBtns}</div>
                </div>
                <textarea class="scene-textarea inp-scene-dialogue" rows="2" placeholder="VD: [Dẫn chuyện]: Đêm hôm ấy trăng sáng vằng vặc...&#10;[@Tam]: Muộn rồi sao người còn chưa về?">${escapeHtml(
                  row.dialogue || ''
                )}</textarea>
              </div>
            </div>

            <div class="scene-takes-strip">${buildTakesStripHtml(row)}</div>

            <div class="scene-card-footer">
              <div style="display:flex; gap:6px;">
                <button type="button" class="scene-shoot-btn" data-act="run-scene" title="${
                  row.videoUrl ? 'Quay thêm 1 bản mới để so sánh — bản cũ vẫn được giữ lại' : 'Bấm máy quay cảnh này'
                }">
                  ${row.videoUrl ? '➕ Quay Thêm Bản' : '▶ Quay Cảnh Này'}
                </button>
              </div>

              <div class="scene-tools-right">
                ${
                  row.videoUrl
                    ? `<button type="button" class="icon-btn" data-act="zoom-scene" title="Xem phóng to màn hình rộng">👁️</button>
                       <a class="icon-btn" style="text-decoration:none;" href="/api/download-file?url=${encodeURIComponent(
                         row.videoUrl.split('?')[0]
                       )}" title="Tải file MP4 của cảnh này">⬇️</a>
                       <button type="button" class="icon-btn" data-act="locate-scene" title="Mở file trên ổ cứng">📂</button>`
                    : ''
                }
                <button type="button" class="icon-btn danger-hover" data-act="delete-scene" title="Xóa phân cảnh này">🗑️</button>
              </div>
            </div>
          </article>
        `;
      })
      .join('');

    grid.querySelectorAll('.scene-studio-card').forEach((card) => {
      bindSceneCardEvents(card);
    });
  }

  function bindSceneCardEvents(card) {
    const acc = state.activeAccount;
    if (!acc) return;
    const rowIndex = Number(card.dataset.rowIndex);

    const scheduleRowSave = (extraPatch = {}) => {
      const key = `${acc.id}_${rowIndex}`;
      if (rowSaveTimers.has(key)) clearTimeout(rowSaveTimers.get(key));
      rowSaveTimers.set(
        key,
        setTimeout(async () => {
          try {
            const titleEl = card.querySelector('.scene-title-input');
            const promptEl = card.querySelector('.inp-scene-prompt');
            const dlgEl = card.querySelector('.inp-scene-dialogue');
            const locSelEl = card.querySelector('.scene-loc-sel');
            const trimStartEl = card.querySelector('.inp-trim-start');
            const trimEndEl = card.querySelector('.inp-trim-end');
            const res = await api(`/api/accounts/${acc.id}/rows/${rowIndex}`, {
              method: 'PUT',
              body: {
                sceneTitle: titleEl ? titleEl.value : undefined,
                prompt: promptEl ? promptEl.value : undefined,
                dialogue: dlgEl ? dlgEl.value : undefined,
                sceneLocationId: locSelEl ? locSelEl.value : undefined,
                trimStartSec: trimStartEl ? Number(trimStartEl.value) || 0 : undefined,
                trimEndSec: trimEndEl ? Number(trimEndEl.value) || 0 : undefined,
                ...extraPatch
              }
            });
            const idx = (state.activeAccount.rows || []).findIndex((r) => Number(r.index) === rowIndex);
            if (idx >= 0) state.activeAccount.rows[idx] = res.row;
          } catch (_) {}
        }, 380)
      );
    };

    card.querySelector('.scene-title-input')?.addEventListener('input', () => scheduleRowSave());
    card.querySelector('.inp-scene-prompt')?.addEventListener('input', () => scheduleRowSave());
    card.querySelector('.inp-scene-dialogue')?.addEventListener('input', () => scheduleRowSave());
    card.querySelector('.scene-loc-sel')?.addEventListener('change', () => scheduleRowSave());
    card.querySelector('.scene-weapon-sel')?.addEventListener('change', (ev) => scheduleRowSave({ weaponMode: ev.target.value }));
    card.querySelector('.scene-shot-sel')?.addEventListener('change', (ev) => scheduleRowSave({ shotSize: ev.target.value }));
    card.querySelector('.scene-move-sel')?.addEventListener('change', (ev) => scheduleRowSave({ cameraMove: ev.target.value }));
    bindTakesStripEvents(card, rowIndex);
    card.querySelector('.inp-trim-start')?.addEventListener('change', () => scheduleRowSave());
    card.querySelector('.inp-trim-end')?.addEventListener('change', () => scheduleRowSave());

    // Bấm chọn nhanh thẻ người nói [Dẫn chuyện]: / [@Tag]:
    card.querySelectorAll('[data-insert-speaker]').forEach((btn) => {
      btn.addEventListener('click', () => {
        const prefix = btn.dataset.insertSpeaker;
        const dlg = card.querySelector('.inp-scene-dialogue');
        if (!dlg) return;
        const cur = dlg.value.trim();
        dlg.value = cur ? `${cur}\n${prefix}` : prefix;
        dlg.focus();
        scheduleRowSave();
      });
    });

    // Bật / tắt diễn viên xuất hiện trong cảnh
    card.querySelectorAll('[data-char-toggle]').forEach((chip) => {
      chip.addEventListener('click', async () => {
        chip.classList.toggle('active');
        const activeIds = Array.from(card.querySelectorAll('[data-char-toggle].active')).map(
          (el) => el.dataset.charToggle
        );
        try {
          const res = await api(`/api/accounts/${acc.id}/rows/${rowIndex}`, {
            method: 'PUT',
            body: { sceneCharacterIds: activeIds }
          });
          const idx = (state.activeAccount.rows || []).findIndex((r) => Number(r.index) === rowIndex);
          if (idx >= 0) state.activeAccount.rows[idx] = res.row;
        } catch (e) {
          showToast(e.message, 'error');
        }
      });
    });

    // Bật / tắt Nối mạch khung cuối cảnh trước
    const chainChk = card.querySelector('.chk-chain-prev');
    if (chainChk) {
      chainChk.addEventListener('change', async () => {
        const lbl = chainChk.closest('.chain-toggle-label');
        if (lbl) lbl.classList.toggle('active', chainChk.checked);
        try {
          const res = await api(`/api/accounts/${acc.id}/rows/${rowIndex}`, {
            method: 'PUT',
            body: { continueFromPrevScene: chainChk.checked }
          });
          const idx = (state.activeAccount.rows || []).findIndex((r) => Number(r.index) === rowIndex);
          if (idx >= 0) state.activeAccount.rows[idx] = res.row;
        } catch (_) {}
      });
    }

    // Ảnh bối cảnh riêng của cảnh
    bindMonitorEnvUploadEvents(card, rowIndex);

    // Quay cảnh đơn lẻ
    card.querySelector('[data-act="run-scene"]')?.addEventListener('click', async () => {
      try {
        // Lưu nội dung vừa nhập ngay lập tức trước khi bấm máy
        const rowRes = await api(`/api/accounts/${acc.id}/rows/${rowIndex}`, {
          method: 'PUT',
          body: {
            sceneTitle: card.querySelector('.scene-title-input')?.value,
            prompt: card.querySelector('.inp-scene-prompt')?.value,
            dialogue: card.querySelector('.inp-scene-dialogue')?.value,
            sceneLocationId: card.querySelector('.scene-loc-sel')?.value ?? '',
            weaponMode: card.querySelector('.scene-weapon-sel')?.value || undefined,
            trimStartSec: Number(card.querySelector('.inp-trim-start')?.value) || 0,
            trimEndSec: Number(card.querySelector('.inp-trim-end')?.value) || 0
          }
        });
        const hasExistingVid = Boolean(rowRes.row?.videoUrl);
        const endpoint = hasExistingVid ? 'regenerate' : 'run';
        await api(`/api/accounts/${acc.id}/rows/${rowIndex}/${endpoint}`, { method: 'POST' });
        showToast(`🎬 Đã bấm máy quay Cảnh ${rowIndex}!`);
      } catch (e) {
        showToast(e.message, 'error');
      }
    });

    // Xem phóng to, mở file, xóa cảnh
    bindFooterMediaActions(card, rowIndex);
  }

  function bindTakesStripEvents(card, rowIndex) {
    const acc = state.activeAccount;
    const strip = card.querySelector('.scene-takes-strip');
    if (!acc || !strip) return;

    strip.querySelectorAll('.take-chip').forEach((chip) => {
      const takeId = chip.dataset.takeId;
      chip.querySelector('[data-act="pick-take"]')?.addEventListener('click', async () => {
        try {
          const res = await api(`/api/accounts/${acc.id}/rows/${rowIndex}/takes/${encodeURIComponent(takeId)}/select`, { method: 'POST' });
          updateSingleSceneCardInDom(res.row);
          showToast(`Đã chọn bản quay này cho Cảnh ${rowIndex}`, 'success');
        } catch (e) {
          showToast(e.message, 'error');
        }
      });
      chip.querySelector('[data-act="del-take"]')?.addEventListener('click', async () => {
        if (!confirm('Xóa hẳn bản quay này (xóa luôn file video trên ổ cứng)?')) return;
        try {
          const res = await api(`/api/accounts/${acc.id}/rows/${rowIndex}/takes/${encodeURIComponent(takeId)}`, { method: 'DELETE' });
          updateSingleSceneCardInDom(res.row);
        } catch (e) {
          showToast(e.message, 'error');
        }
      });
    });

    strip.querySelector('[data-act="run-qc"]')?.addEventListener('click', async (ev) => {
      const btn = ev.currentTarget;
      btn.disabled = true;
      btn.textContent = '⏳ Đang kiểm tra...';
      try {
        const res = await api(`/api/accounts/${acc.id}/rows/${rowIndex}/qc`, { method: 'POST' });
        if (res.row) updateSingleSceneCardInDom(res.row);
        showToast(`🛡️ QC Cảnh ${rowIndex}: ${res.qc.score}/100${res.qc.issues.length ? ` — ${res.qc.issues.join(', ')}` : ' — Không phát hiện lỗi'}`, res.qc.verdict === 'fail' ? 'error' : 'success');
      } catch (e) {
        showToast(e.message, 'error');
        btn.disabled = false;
        btn.textContent = '🛡️ Kiểm tra QC';
      }
    });
  }

  function bindMonitorEnvUploadEvents(card, rowIndex) {
    const acc = state.activeAccount;
    if (!acc) return;
    const envInp = card.querySelector('.scene-env-file-inp');
    const pickBtn = card.querySelector('[data-act="pick-env-img"]');
    const rmBtn = card.querySelector('[data-act="remove-env-img"]');

    if (pickBtn && envInp) {
      pickBtn.addEventListener('click', () => envInp.click());
      envInp.addEventListener('change', async () => {
        if (!envInp.files || !envInp.files[0]) return;
        const fd = new FormData();
        fd.append('image', envInp.files[0]);
        try {
          const res = await api(`/api/accounts/${acc.id}/rows/${rowIndex}/image/0`, {
            method: 'POST',
            body: fd
          });
          updateSingleSceneCardInDom(res.row);
          showToast(`Đã gắn ảnh bối cảnh cho Cảnh ${rowIndex}`, 'success');
        } catch (e) {
          showToast(e.message, 'error');
        }
      });
    }

    if (rmBtn) {
      rmBtn.addEventListener('click', async () => {
        try {
          const res = await api(`/api/accounts/${acc.id}/rows/${rowIndex}/image/0`, { method: 'DELETE' });
          updateSingleSceneCardInDom(res.row);
        } catch (e) {
          showToast(e.message, 'error');
        }
      });
    }
  }

  function bindFooterMediaActions(card, rowIndex) {
    const acc = state.activeAccount;
    if (!acc) return;

    card.querySelector('[data-act="zoom-scene"]')?.addEventListener('click', () => {
      const row = (state.activeAccount.rows || []).find((r) => Number(r.index) === rowIndex);
      if (!row || !row.videoUrl) return;
      $('zoomVideoTitle').textContent = `🎞️ Cảnh ${String(row.index).padStart(2, '0')} — ${row.sceneTitle || ''}`;
      const player = $('zoomVideoPlayer');
      player.src = row.videoUrl;
      openModal('modalZoomVideo');
    });

    card.querySelector('[data-act="locate-scene"]')?.addEventListener('click', async () => {
      try {
        await api('/api/open-output-file', {
          method: 'POST',
          body: { accountId: acc.id, rowIndex }
        });
      } catch (e) {
        showToast(e.message, 'error');
      }
    });

    card.querySelector('[data-act="delete-scene"]')?.addEventListener('click', async () => {
      if (!confirm(`Xóa Phân cảnh #${rowIndex} khỏi bộ phim?`)) return;
      try {
        const res = await api(`/api/accounts/${acc.id}/scenes/${rowIndex}`, { method: 'DELETE' });
        state.activeAccount = res.account;
        renderTopBar();
        renderProductionTab();
      } catch (e) {
        showToast(e.message, 'error');
      }
    });
  }

  /**
   * Cập nhật mượt mà đúng 1 thẻ Phân cảnh khi có sự kiện WebSocket mà KHÔNG làm mất con trỏ đang gõ chữ!
   */
  function updateSingleSceneCardInDom(updatedRow) {
    if (!state.activeAccount || !updatedRow) return;
    const idx = (state.activeAccount.rows || []).findIndex((r) => Number(r.index) === Number(updatedRow.index));
    if (idx >= 0) {
      state.activeAccount.rows[idx] = updatedRow;
    }
    renderTopBar();
    renderProductionSummaryAndControls();

    const card = document.querySelector(`.scene-studio-card[data-row-index="${updatedRow.index}"]`);
    if (!card) return;

    card.classList.toggle('is-rendering', isSceneRunning(updatedRow.status));
    card.classList.toggle('is-completed', updatedRow.status === 'completed');
    card.classList.toggle('is-error', updatedRow.status === 'error');

    const stage = card.querySelector('.scene-monitor-stage');
    if (stage) {
      const existingVid = stage.querySelector('video');
      const currentVidSrc = existingVid ? existingVid.getAttribute('src') : null;
      if (!updatedRow.videoUrl || currentVidSrc !== updatedRow.videoUrl) {
        stage.innerHTML = buildMonitorStageInnerHtml(updatedRow);
        bindMonitorEnvUploadEvents(card, Number(updatedRow.index));
      } else {
        const pillInfo = getScenePillInfo(updatedRow);
        const pillEl = stage.querySelector('.scene-state-pill');
        if (pillEl) {
          pillEl.className = `scene-state-pill ${pillInfo.cls}`;
          pillEl.textContent = pillInfo.label;
        }
        const qcInfo = getQcBadgeInfo(updatedRow.qc);
        let qcEl = stage.querySelector('.scene-qc-pill');
        if (qcInfo) {
          if (!qcEl && pillEl) {
            qcEl = document.createElement('span');
            pillEl.parentElement.insertBefore(qcEl, pillEl);
          }
          if (qcEl) {
            qcEl.className = `scene-qc-pill ${qcInfo.cls}`;
            qcEl.textContent = qcInfo.label;
            qcEl.title = qcInfo.title;
          }
        } else if (qcEl) {
          qcEl.remove();
        }
      }
    }

    const takesStrip = card.querySelector('.scene-takes-strip');
    if (takesStrip) {
      takesStrip.innerHTML = buildTakesStripHtml(updatedRow);
      bindTakesStripEvents(card, Number(updatedRow.index));
    }

    // Cập nhật thanh footer nút tải/phóng to nếu cảnh vừa hoàn tất
    const footer = card.querySelector('.scene-card-footer');
    if (footer) {
      footer.innerHTML = `
        <div style="display:flex; gap:6px;">
          <button type="button" class="scene-shoot-btn" data-act="run-scene" title="${
            updatedRow.videoUrl ? 'Quay thêm 1 bản mới để so sánh — bản cũ vẫn được giữ lại' : 'Bấm máy quay cảnh này'
          }">
            ${updatedRow.videoUrl ? '➕ Quay Thêm Bản' : '▶ Quay Cảnh Này'}
          </button>
        </div>
        <div class="scene-tools-right">
          ${
            updatedRow.videoUrl
              ? `<button type="button" class="icon-btn" data-act="zoom-scene" title="Xem phóng to màn hình rộng">👁️</button>
                 <a class="icon-btn" style="text-decoration:none;" href="/api/download-file?url=${encodeURIComponent(
                   updatedRow.videoUrl.split('?')[0]
                 )}" title="Tải file MP4 của cảnh này">⬇️</a>
                 <button type="button" class="icon-btn" data-act="locate-scene" title="Mở file trên ổ cứng">📂</button>`
              : ''
          }
          <button type="button" class="icon-btn danger-hover" data-act="delete-scene" title="Xóa phân cảnh này">🗑️</button>
        </div>
      `;
      footer.querySelector('[data-act="run-scene"]')?.addEventListener('click', async () => {
        try {
          const endpoint = updatedRow.videoUrl ? 'regenerate' : 'run';
          await api(`/api/accounts/${state.activeAccount.id}/rows/${updatedRow.index}/${endpoint}`, { method: 'POST' });
        } catch (e) {
          showToast(e.message, 'error');
        }
      });
      bindFooterMediaActions(card, Number(updatedRow.index));
    }
  }

  /* ==================== TAB 4: DỰNG HẬU KỲ & XUẤT PHIM ==================== */

  function renderPromoResultCard(promo, variantIdx = state.activePromoVariantIdx || 0) {
    const card = $('promoResultCard');
    if (!card) return;
    if (!promo || (!promo.thumbnailUrl && !promo.trailerUrl)) {
      card.classList.add('hidden');
      return;
    }
    card.classList.remove('hidden');
    const dl = (u) => `/api/download-file?url=${encodeURIComponent(String(u).split('?')[0])}`;
    const cacheBust = encodeURIComponent(promo.createdAt || Date.now());

    const variants =
      Array.isArray(promo.thumbnailVariants) && promo.thumbnailVariants.length > 0
        ? promo.thumbnailVariants
        : promo.thumbnailUrl
        ? [
            {
              index: 1,
              label: '🖼️ Mẫu Ảnh Bìa',
              thumbnailUrl: promo.thumbnailUrl,
              thumbnailCleanUrl: promo.thumbnailCleanUrl || ''
            }
          ]
        : [];

    const safeIdx = variants.length > 0 ? Math.max(0, Math.min(variants.length - 1, Number(variantIdx) || 0)) : 0;
    state.activePromoVariantIdx = safeIdx;
    const chosen = variants[safeIdx] || null;

    const tabsBox = $('promoVariantTabs');
    if (tabsBox) {
      if (variants.length > 1) {
        tabsBox.innerHTML = variants
          .map(
            (v, idx) => `
            <button type="button" class="promo-var-btn ${idx === safeIdx ? 'active' : ''}" data-var-idx="${idx}">
              <img src="${escapeHtml(v.thumbnailUrl)}?t=${cacheBust}" alt="Mẫu ${idx + 1}" />
              <span>${escapeHtml((v.label || `Mẫu ${idx + 1}`).replace(/^Mẫu\s+/i, ''))}</span>
            </button>
          `
          )
          .join('');
        tabsBox.querySelectorAll('.promo-var-btn').forEach((b) => {
          b.addEventListener('click', () => {
            renderPromoResultCard(promo, Number(b.dataset.varIdx) || 0);
          });
        });
      } else {
        tabsBox.innerHTML = '';
      }
    }

    if (chosen && chosen.thumbnailUrl) {
      const fullPreviewUrl = `${chosen.thumbnailUrl}?t=${cacheBust}`;
      $('promoThumbPreview').src = fullPreviewUrl;
      $('promoThumbPreview').classList.remove('hidden');
      if ($('linkOpenThumbFull')) $('linkOpenThumbFull').href = fullPreviewUrl;
      $('linkDownloadThumb').href = dl(chosen.thumbnailUrl);
      $('linkDownloadThumb').classList.remove('hidden');
    } else {
      $('promoThumbPreview').classList.add('hidden');
      $('linkDownloadThumb').classList.add('hidden');
    }
    if (chosen && chosen.thumbnailCleanUrl) {
      $('linkDownloadThumbClean').href = dl(chosen.thumbnailCleanUrl);
      $('linkDownloadThumbClean').classList.remove('hidden');
    } else {
      $('linkDownloadThumbClean').classList.add('hidden');
    }
    const hasTrailer = Boolean(promo.trailerUrl);
    $('linkDownloadTrailer').classList.toggle('hidden', !hasTrailer);
    $('btnPlayTrailer').classList.toggle('hidden', !hasTrailer);
    if (hasTrailer) $('linkDownloadTrailer').href = dl(promo.trailerUrl);
    const parts = [];
    if (chosen && chosen.thumbnailUrl) {
      parts.push(
        `Poster ${promo.thumbnailSize || ''} • ${chosen.label || 'Mẫu 1'} (${promo.thumbnailSourceScene || 'Tự động'})`
      );
    }
    if (hasTrailer) {
      parts.push(
        `Trailer ${promo.trailerDuration || '?'}s gồm ${(promo.trailerSceneIndices || []).length} khoảnh khắc (Cảnh ${(promo.trailerSceneIndices || []).join(', ')})`
      );
    }
    $('promoResultMeta').textContent = parts.join(' • ');
  }

  function renderPostProductionTab() {
    const acc = state.activeAccount;
    if (!acc) return;
    const settings = acc.settings || {};

    if (!$('inputExportMovieTitle').value) {
      $('inputExportMovieTitle').value = settings.exportMovieTitle || acc.name || 'Bo_Phim_AI';
    }
    $('selectExportTransition').value = settings.transitionEffect || 'director_smart';
    if ($('selectColorGrade')) $('selectColorGrade').value = settings.colorGrade || 'auto_match';
    renderPromoResultCard(settings.lastPromoExport);
    const volPct = Math.round((Number(settings.bgmVolume) || 0.22) * 100);
    $('sliderBgmVolume').value = String(volPct);
    $('bgmVolValue').textContent = `${volPct}%`;
    if ($('chkAutoDuckBgm')) {
      $('chkAutoDuckBgm').checked = settings.autoDuckBgm !== false;
    }
    $('chkBurnSubtitles').checked = Boolean(settings.burnSubtitles);

    if (settings.bgmAudio && settings.bgmAudio.fileName) {
      $('bgmStatusLabel').textContent = `🎵 Đang dùng nhạc nền: ${settings.bgmAudio.fileName}`;
      $('btnRemoveBgm').classList.remove('hidden');
    } else {
      $('bgmStatusLabel').textContent = 'Chưa gắn nhạc nền riêng (Giữ nguyên âm thanh gốc của các phân cảnh).';
      $('btnRemoveBgm').classList.add('hidden');
    }

    const completedScenes = (acc.rows || []).filter((r) => r.videoUrl);
    const includedScenes = completedScenes.filter((r) => r.includeInExport !== false);
    $('reelIncludedSummary').textContent = `Các phân cảnh đã quay xong đưa vào phim (${includedScenes.length}/${completedScenes.length} cảnh):`;

    const reelList = $('exportSceneReelList');
    if (completedScenes.length === 0) {
      reelList.innerHTML = `<div style="color:var(--text-muted); font-size:13px; padding:12px;">Chưa có cảnh nào quay xong video. Hãy quay các phân cảnh ở Bước 3 trước!</div>`;
    } else {
      reelList.innerHTML = completedScenes
        .map(
          (r) => `
          <div class="reel-scene-item" data-row-index="${r.index}">
            <label class="reel-left" style="cursor:pointer;">
              <input type="checkbox" class="chk-include-reel" ${r.includeInExport !== false ? 'checked' : ''} />
              <span class="ver-pill">Cảnh ${String(r.index).padStart(2, '0')}</span>
              <span class="reel-title">${escapeHtml(r.sceneTitle || `Cảnh ${r.index}`)}</span>
            </label>
            <button type="button" class="mini-ghost-btn btn-preview-reel">▶ Xem cảnh</button>
          </div>
        `
        )
        .join('');

      reelList.querySelectorAll('.reel-scene-item').forEach((item) => {
        const rIdx = Number(item.dataset.rowIndex);
        const rowObj = completedScenes.find((x) => Number(x.index) === rIdx);
        item.querySelector('.chk-include-reel').addEventListener('change', async (ev) => {
          const checked = ev.target.checked;
          try {
            const res = await api(`/api/accounts/${acc.id}/rows/${rIdx}`, {
              method: 'PUT',
              body: { includeInExport: checked }
            });
            const foundIdx = acc.rows.findIndex((x) => Number(x.index) === rIdx);
            if (foundIdx >= 0) acc.rows[foundIdx] = res.row;
            renderPostProductionTab();
          } catch (_) {}
        });

        item.querySelector('.btn-preview-reel').addEventListener('click', () => {
          if (!rowObj || !rowObj.videoUrl) return;
          state.sequentialPlaylist = [];
          const player = $('masterScreeningVideo');
          $('masterScreenPlaceholder').classList.add('hidden');
          player.src = rowObj.videoUrl;
          player.play().catch(() => {});
        });
      });
    }

    // Hiển thị bản Master gần nhất nếu đã xuất
    const lastMaster = settings.lastMasterExport;
    const resCard = $('masterResultCard');
    if (lastMaster && lastMaster.publicUrl) {
      resCard.classList.remove('hidden');
      const mb = lastMaster.sizeBytes ? (lastMaster.sizeBytes / (1024 * 1024)).toFixed(2) : '--';
      $('masterResultMeta').textContent = `${lastMaster.fileName} • Thời lượng: ${lastMaster.duration}s (${lastMaster.sceneCount} cảnh • ${mb} MB)`;
      $('linkDownloadMasterMp4').href = `/api/download-file?url=${encodeURIComponent(lastMaster.publicUrl)}`;
      if (lastMaster.srtPublicUrl) {
        $('linkDownloadMasterSrt').classList.remove('hidden');
        $('linkDownloadMasterSrt').href = `/api/download-file?url=${encodeURIComponent(lastMaster.srtPublicUrl)}`;
      } else {
        $('linkDownloadMasterSrt').classList.add('hidden');
      }

      const player = $('masterScreeningVideo');
      if (!player.getAttribute('src')) {
        $('masterScreenPlaceholder').classList.add('hidden');
        player.src = `${lastMaster.publicUrl}?t=${Date.now()}`;
      }
    } else {
      resCard.classList.add('hidden');
      if (completedScenes.length > 0 && !$('masterScreeningVideo').getAttribute('src')) {
        $('masterScreenPlaceholder').classList.add('hidden');
        $('masterScreeningVideo').src = completedScenes[0].videoUrl;
      } else if (completedScenes.length === 0) {
        $('masterScreenPlaceholder').classList.remove('hidden');
      }
    }
  }

  /* ==================== MODAL QUẢN LÝ TÀI KHOẢN & ĐĂNG NHẬP MUSE.AI (GIỐNG MUSE FLOW 3.8) ==================== */

  function getLoginModalAccount() {
    const targetId = state.loginTargetAccountId || state.activeAccount?.id;
    return (state.accounts || []).find((a) => a.id === targetId) || state.activeAccount || null;
  }

  async function switchActiveMovieWorkspace(accountId, { showNotice = true } = {}) {
    if (!accountId) return;
    const res = await api('/api/accounts/select', {
      method: 'POST',
      body: { accountId }
    });
    state.accounts = res.accounts || state.accounts;
    state.activeAccount = res.activeAccount;
    state.batchStats = res.batchStats;
    $('masterScreeningVideo')?.removeAttribute('src');
    renderTopBar();
    renderScriptTab();
    renderCastTab();
    renderProductionTab();
    if (state.activeTab === 'postprod') renderPostProductionTab();
    renderAccountsModalList();
    if (showNotice && state.activeAccount) {
      showToast(`🎬 Đã mở trang sản xuất của "${state.activeAccount.name}"!`, 'info');
    }
  }

  function openInAppLoginForAccount(accountId) {
    const target = (state.accounts || []).find((a) => a.id === accountId) || state.activeAccount;
    if (!target) return;
    state.loginTargetAccountId = target.id;
    if ($('inAppLoginSubTarget')) {
      $('inAppLoginSubTarget').textContent = `Dự án: ${target.name} (Port ${target.port}) • Chạy ngầm 100%`;
    }
    $('inputAuthIdentifier').value = '';
    $('inputAuthPassword').value = '';
    $('inputAuthOtp').value = '';
    $('inputAccountProxy').value = target.proxy || '';
    openModal('modalInAppLogin');
    inspectAuthModal(false);
  }

  function renderAccountsModalList() {
    const box = $('accountsModalList');
    if (!box) return;
    const list = state.accounts || [];

    box.innerHTML = list
      .map((acc) => {
        const isCurrent = state.activeAccount && acc.id === state.activeAccount.id;
        const meta = getAccountLoginAndTokenDisplay(acc);
        const done = (acc.rows || []).filter((r) => r.status === 'completed').length;
        const total = (acc.rows || []).length;
        const subLine = acc.loginVerified
          ? `✅ ${meta.loginName} • Đã dùng: ${meta.usedText} • Còn lại: ${meta.remainingText} • Phim: ${done}/${total} cảnh${
              acc.proxyLabel ? ` • 🌐 ${acc.proxyLabel}` : ''
            }`
          : `⚪ Chưa đăng nhập Muse.ai • Phim: ${done}/${total} cảnh (Port ${acc.port})${
              acc.proxyLabel ? ` • 🌐 ${acc.proxyLabel}` : ''
            }`;

        return `
          <div class="muse-session-card ${isCurrent ? 'active-slot' : ''}" data-acc-id="${escapeHtml(acc.id)}">
            <div class="muse-sess-left">
              <span class="status-dot ${acc.loginVerified ? 'online' : 'offline'}"></span>
              <div class="muse-sess-meta">
                <div style="display:flex; align-items:center; gap:6px; flex-wrap:wrap;">
                  <input type="text" class="acc-inline-name-inp" value="${escapeHtml(
                    acc.name
                  )}" data-orig="${escapeHtml(acc.name)}" maxlength="80" title="Bấm sửa tên dự án phim (Enter để lưu)" />
                </div>
                <span class="muse-sess-sub">${escapeHtml(subLine)}</span>
              </div>
            </div>
            <div class="muse-sess-actions">
              <button type="button" class="${isCurrent ? 'ver-pill' : 'mini-gold-btn'}" data-act="switch-acc">
                ${isCurrent ? '✓ Đang mở' : '🎬 Mở trang phim'}
              </button>
              <button type="button" class="mini-ghost-btn" data-act="open-new-tab" title="Mở trang sản xuất của tài khoản này sang 1 cửa sổ/tab riêng">
                ↗ Tab mới
              </button>
              <button type="button" class="mini-gold-btn" data-act="login-acc">
                ${acc.loginVerified ? '🔐 Đổi / Xem TK' : '🔑 Đăng nhập'}
              </button>
              <button type="button" class="mini-ghost-btn" data-act="sync-quota" title="Cập nhật số dư Token">
                ↻ Token
              </button>
              ${
                acc.loginVerified
                  ? `<button type="button" class="mini-ghost-btn danger-hover" data-act="logout-acc" title="Đăng xuất Muse.ai để đổi nick khác (Giữ nguyên kịch bản & video)">🚪 Đăng xuất</button>`
                  : ''
              }
              <button type="button" class="icon-btn danger-hover" data-act="delete-acc" title="Xóa dự án & phiên đăng nhập này">🗑️</button>
            </div>
          </div>
        `;
      })
      .join('');

    box.querySelectorAll('.muse-session-card').forEach((card) => {
      const accId = card.dataset.accId;
      const nameInp = card.querySelector('.acc-inline-name-inp');

      const commitInlineRename = async () => {
        const nextName = (nameInp.value || '').trim();
        const orig = nameInp.dataset.orig || '';
        if (!nextName || nextName === orig) {
          nameInp.value = orig;
          return;
        }
        try {
          const res = await api(`/api/accounts/${accId}/name`, {
            method: 'PUT',
            body: { name: nextName }
          });
          state.accounts = res.accounts || state.accounts;
          if (state.activeAccount && state.activeAccount.id === accId) {
            state.activeAccount = res.account;
          }
          nameInp.dataset.orig = nextName;
          renderTopBar();
          showToast('Đã lưu tên dự án phim!', 'success');
        } catch (e) {
          nameInp.value = orig;
          showToast(e.message, 'error');
        }
      };

      nameInp?.addEventListener('keydown', (e) => {
        if (e.key === 'Enter') {
          e.preventDefault();
          nameInp.blur();
        }
      });
      nameInp?.addEventListener('blur', commitInlineRename);

      card.querySelector('[data-act="switch-acc"]')?.addEventListener('click', async () => {
        try {
          await switchActiveMovieWorkspace(accId, { showNotice: true });
          closeModal('modalAccountManager');
        } catch (e) {
          showToast(e.message, 'error');
        }
      });

      card.querySelector('[data-act="open-new-tab"]')?.addEventListener('click', () => {
        window.open(`${window.location.origin}/?account=${encodeURIComponent(accId)}`, '_blank');
      });

      card.querySelector('[data-act="login-acc"]')?.addEventListener('click', async () => {
        if (!state.activeAccount || state.activeAccount.id !== accId) {
          await switchActiveMovieWorkspace(accId, { showNotice: false }).catch(() => {});
        }
        closeModal('modalAccountManager');
        openInAppLoginForAccount(accId);
      });

      card.querySelector('[data-act="sync-quota"]')?.addEventListener('click', async (ev) => {
        const btn = ev.currentTarget;
        btn.disabled = true;
        try {
          const res = await api(`/api/accounts/${accId}/refresh-quota`, { method: 'POST' });
          state.accounts = res.accounts || state.accounts;
          if (state.activeAccount && state.activeAccount.id === accId) {
            state.activeAccount = res.account;
          }
          renderTopBar();
          renderAccountsModalList();
          showToast('Đã cập nhật số dư Token!', 'success');
        } catch (e) {
          showToast(e.message, 'error');
        } finally {
          btn.disabled = false;
        }
      });

      card.querySelector('[data-act="logout-acc"]')?.addEventListener('click', async () => {
        await handleLogoutAccount(accId, false);
      });

      card.querySelector('[data-act="delete-acc"]')?.addEventListener('click', async () => {
        const target = (state.accounts || []).find((a) => a.id === accId);
        if (!confirm(`Xóa dự án "${target?.name || accId}" cùng phiên đăng nhập của dự án này?`)) return;
        try {
          const res = await api(`/api/accounts/${accId}?wipeProfile=true`, { method: 'DELETE' });
          state.accounts = res.accounts || [];
          state.activeAccount = res.activeAccount;
          state.batchStats = res.batchStats;
          renderTopBar();
          renderScriptTab();
          renderCastTab();
          renderProductionTab();
          renderAccountsModalList();
          showToast('Đã xóa dự án & làm sạch phiên đăng nhập!', 'info');
        } catch (e) {
          showToast(e.message, 'error');
        }
      });
    });
  }

  async function handleLogoutAccount(accountId = null, openLoginAfter = true) {
    const target = accountId
      ? (state.accounts || []).find((a) => a.id === accountId)
      : getLoginModalAccount();
    if (!target) return;

    const meta = getAccountLoginAndTokenDisplay(target);
    if (
      !confirm(
        `Đăng xuất tài khoản "${meta.loginName}" trên dự án "${target.name}" để đăng nhập tài khoản Muse.ai khác?\n(Kịch bản, Dàn diễn viên & Video của bộ phim vẫn được giữ nguyên 100%!)`
      )
    ) {
      return;
    }

    if (openLoginAfter) {
      $('loginStepHeading').textContent = '⏳ Đang đăng xuất & mở form đăng nhập mới...';
      $('loginStepDesc').textContent = 'Vui lòng đợi khoảng 2–4 giây...';
    }
    try {
      const res = await api(`/api/accounts/${target.id}/logout`, {
        method: 'POST',
        body: { openLoginNow: openLoginAfter }
      });
      state.accounts = res.accounts || state.accounts;
      if (state.activeAccount && state.activeAccount.id === target.id) {
        state.activeAccount = res.account || res.activeAccount;
      }
      $('inputAuthIdentifier').value = '';
      $('inputAuthPassword').value = '';
      $('inputAuthOtp').value = '';
      renderTopBar();
      renderAccountsModalList();
      if (openLoginAfter) {
        if (res.state) renderAuthStepUI(res.state);
        else await inspectAuthModal(true);
      }
      showToast('🚪 Đã đăng xuất thành công! Bạn có thể đăng nhập tài khoản Muse.ai mới.', 'success');
    } catch (e) {
      showToast(e.message, 'error');
    }
  }

  function renderAuthStepUI(authState) {
    ['authPaneIdentifier', 'authPanePassword', 'authPaneOtp', 'authPane2FA', 'authPaneSaved', 'authPaneLoggedIn'].forEach(
      (id) => $(id).classList.add('hidden')
    );
    $('loginStepHeading').textContent = authState.heading || 'Đăng nhập Muse.ai';
    $('loginStepDesc').textContent = authState.description || '';

    const errBox = $('loginErrorAlert');
    if (authState.errorText) {
      errBox.textContent = authState.errorText;
      errBox.classList.remove('hidden');
    } else {
      errBox.classList.add('hidden');
    }

    if (authState.step === 'logged_in' || authState.isLoggedIn) {
      const target = getLoginModalAccount();
      $('authPaneLoggedIn').classList.remove('hidden');
      $('inputCustomAccLabel').value = target?.accountInfo?.customLoginName || '';
    } else if (authState.step === 'identifier') {
      $('authPaneIdentifier').classList.remove('hidden');
      if (authState.rememberedIdentifier && !$('inputAuthIdentifier').value) {
        $('inputAuthIdentifier').value = authState.rememberedIdentifier;
      }
    } else if (authState.step === 'password') {
      $('authPanePassword').classList.remove('hidden');
    } else if (authState.step === 'otp') {
      $('authPaneOtp').classList.remove('hidden');
    } else if (authState.step === 'two_factor_method') {
      $('authPane2FA').classList.remove('hidden');
      const list = $('auth2FAMethodList');
      list.innerHTML = (authState.twoFactorMethods || [])
        .map(
          (m, idx) =>
            `<label class="checkbox-line"><input type="radio" name="mfs_2fa" value="${escapeHtml(m.methodId)}" ${
              m.checked || idx === 0 ? 'checked' : ''
            } /> <span>${escapeHtml(m.label)}</span></label>`
        )
        .join('');
    } else if (authState.step === 'saved_account') {
      $('authPaneSaved').classList.remove('hidden');
    }
  }

  async function inspectAuthModal(resetToStart = false) {
    const target = getLoginModalAccount();
    if (!target) return;
    $('loginStepHeading').textContent = '⏳ Đang kết nối ngầm tới Muse.ai...';
    $('loginStepDesc').textContent = 'Vui lòng đợi khoảng 2–5 giây...';
    try {
      const res = await api(`/api/accounts/${target.id}/inapp-login/inspect`, {
        method: 'POST',
        body: { resetToStart }
      });
      state.accounts = res.accounts || state.accounts;
      if (state.activeAccount && res.account && state.activeAccount.id === res.account.id) {
        state.activeAccount = res.account;
      }
      renderTopBar();
      renderAccountsModalList();
      renderAuthStepUI(res.state);
    } catch (e) {
      $('loginStepHeading').textContent = 'Không thể mở kết nối';
      $('loginErrorAlert').textContent = e.message;
      $('loginErrorAlert').classList.remove('hidden');
    }
  }

  /* ==================== AUTO-UPDATE OTA (GITHUB) ==================== */

  function openUpdateModalWithInfo(info) {
    if (!info) return;
    state.cachedUpdateInfo = info;
    if ($('topUpdateVerText')) $('topUpdateVerText').textContent = `v${info.latestVersion}`;
    $('btnTopUpdateAlert')?.classList.remove('hidden');

    if ($('updateModalTitle')) $('updateModalTitle').textContent = info.title || `🎉 Đã có phiên bản v${info.latestVersion}!`;
    if ($('updateCurrentVerLabel')) $('updateCurrentVerLabel').textContent = `v${info.currentVersion || state.version}`;
    if ($('updateLatestVerLabel')) $('updateLatestVerLabel').textContent = `v${info.latestVersion}`;
    if ($('updateModalChangelog')) $('updateModalChangelog').textContent = info.changelog || '';
    $('btnDismissUpdateModal')?.classList.toggle('hidden', Boolean(info.mandatory));
    $('btnCloseUpdateModalX')?.classList.toggle('hidden', Boolean(info.mandatory));
    openModal('modalUpdateOta');
  }

  async function checkRemoteUpdate(manualClick = false) {
    try {
      const res = await fetch('/api/update/check', { cache: 'no-store' });
      const info = await res.json();
      if (info && info.updateAvailable) {
        openUpdateModalWithInfo(info);
        return;
      }
      if (manualClick) {
        if (!info.configured) {
          showToast(`Đang sử dụng v${state.version} (Chưa cấu hình kho cập nhật GitHub).`, 'info');
        } else if (info.error) {
          showToast(`Không thể kiểm tra cập nhật: ${info.error}`, 'error');
        } else {
          showToast(`✅ Bạn đang sử dụng phiên bản mới nhất (v${info.currentVersion || state.version})!`, 'success');
        }
      }
    } catch (_) {
      if (manualClick) {
        showToast('Không thể kết nối máy chủ kiểm tra cập nhật lúc này.', 'error');
      }
    }
  }

  /* ==================== WEBSOCKET REALTIME ==================== */

  function connectWebSocket() {
    const proto = location.protocol === 'https:' ? 'wss:' : 'ws:';
    const ws = new WebSocket(`${proto}//${location.host}`);

    ws.onmessage = (ev) => {
      try {
        const { event, payload } = JSON.parse(ev.data);
        if (event === 'update_progress') {
          if ($('updateProgressStatus') && payload?.message) {
            $('updateProgressStatus').textContent = payload.message;
          }
          return;
        }
        if (!state.activeAccount) return;

        if (event === 'row_updated' && payload.accountId === state.activeAccount.id) {
          updateSingleSceneCardInDom(payload.row);
        } else if (event === 'batch_progress' && payload.accountId === state.activeAccount.id) {
          state.batchStats = payload.stats;
          renderProductionSummaryAndControls();
          if (!payload.stats.running) {
            loadInitialState(false);
          }
        } else if (event === 'storyboard_progress' && payload.accountId === state.activeAccount.id) {
          const box = $('storyboardProgressBox');
          if (payload.running) {
            box.classList.remove('hidden');
            $('storyboardProgressText').textContent = payload.message || 'Đang triển khai phân cảnh...';
          } else {
            box.classList.add('hidden');
          }
        } else if (event === 'promo_progress' && payload.accountId === state.activeAccount.id) {
          const pb = $('promoProgressBanner');
          if (pb) {
            if (payload.running) {
              pb.classList.remove('hidden');
              $('promoProgressText').textContent = payload.message || 'Đang tạo ảnh bìa & trailer...';
            } else {
              pb.classList.add('hidden');
            }
          }
        } else if (event === 'export_progress' && payload.accountId === state.activeAccount.id) {
          const b = $('exportProgressBanner');
          if (payload.running) {
            b.classList.remove('hidden');
            $('exportProgressText').textContent = payload.message || 'Đang dựng hậu kỳ phim...';
          } else {
            b.classList.add('hidden');
          }
        } else if (event === 'account_status_changed') {
          if (payload.account) {
            const idx = (state.accounts || []).findIndex((a) => a.id === payload.account.id);
            if (idx >= 0) {
              state.accounts[idx] = {
                ...state.accounts[idx],
                connected: payload.account.connected,
                loginVerified: payload.account.loginVerified,
                savedAccount: payload.account.savedAccount,
                proxy: payload.account.proxy || '',
                proxyLabel: payload.account.proxyLabel || '',
                accountInfo: payload.account.accountInfo
              };
            }
            if (state.activeAccount && payload.account.id === state.activeAccount.id) {
              state.activeAccount.connected = payload.account.connected;
              state.activeAccount.loginVerified = payload.account.loginVerified;
              state.activeAccount.savedAccount = payload.account.savedAccount;
              state.activeAccount.proxy = payload.account.proxy || '';
              state.activeAccount.proxyLabel = payload.account.proxyLabel || '';
              state.activeAccount.accountInfo = payload.account.accountInfo;
            }
          }
          renderTopBar();
          if (!$('modalAccountManager')?.classList.contains('hidden')) {
            renderAccountsModalList();
          }
        } else if (event === 'license_updated') {
          state.license = payload.license;
          renderTopBar();
        }
      } catch (_) {}
    };

    ws.onclose = () => {
      setTimeout(connectWebSocket, 2500);
    };
  }

  /* ==================== INITIAL LOAD & GLOBAL EVENTS ==================== */

  async function loadInitialState(resetInputs = true) {
    try {
      const qs = pinnedAccountFromUrl ? `?accountId=${encodeURIComponent(pinnedAccountFromUrl)}` : '';
      const data = await api(`/api/state${qs}`);
      if (data.version) state.version = data.version;
      state.accounts = data.accounts || [];
      state.activeAccount = data.activeAccount || state.accounts[0] || null;
      state.filmGenres = data.filmGenres || [];
      state.voicePresets = data.voicePresets || [];
      state.lightingPresets = data.lightingPresets || [];
      state.actingStylePresets = data.actingStylePresets || [];
      state.combatIntensityPresets = data.combatIntensityPresets || [];
      state.transitionEffects = data.transitionEffects || [];
      state.shotSizePresets = data.shotSizePresets || [];
      state.cameraMovePresets = data.cameraMovePresets || [];
      state.colorGradePresets = data.colorGradePresets || [];
      state.posterThemePresets = data.posterThemePresets || [];
      state.posterSourceModes = data.posterSourceModes || [];
      state.posterBadgePresets = data.posterBadgePresets || [];
      state.license = data.license || null;
      state.batchStats = data.batchStats || null;

      populateStaticDropdowns();
      renderTopBar();
      renderAccountsModalList();
      if (resetInputs) {
        renderScriptTab();
        try {
          const justUpdated = sessionStorage.getItem('mcs_just_updated_to');
          if (justUpdated) {
            sessionStorage.removeItem('mcs_just_updated_to');
            showToast(`🎉 Đã cập nhật thành công lên MUSE CINEMA STUDIO v${justUpdated}!`, 'success');
          }
        } catch (_) {}
      }
      renderCastTab();
      renderProductionTab();
      if (resetInputs && state.license && !state.license.valid) {
        openModal('modalLicense');
      }
      if (state.activeTab === 'postprod') {
        renderPostProductionTab();
      }
    } catch (e) {
      showToast(e.message, 'error');
    }
  }

  function bindGlobalEvents() {
    // Đổi giao diện Sáng / Tối
    $('btnToggleTheme').addEventListener('click', () => {
      const isLight = document.body.classList.toggle('light-theme');
      localStorage.setItem('mcs_theme', isLight ? 'light' : 'dark');
      $('btnToggleTheme').textContent = isLight ? '🌙' : '☀️';
    });

    // Chuyển tab 4 bước
    document.querySelectorAll('.step-tab').forEach((btn) => {
      btn.addEventListener('click', () => switchTab(btn.dataset.tab));
    });

    // Đóng modals
    document.querySelectorAll('.close-modal-btn').forEach((btn) => {
      btn.addEventListener('click', () => closeModal(btn.dataset.close));
    });

    // Quản lý Tài khoản & Bộ phim độc lập (Giống MUSE FLOW STUDIO 3.8)
    const createNewAccountAndOpenWorkspace = async (customName = '', customProxy = '', autoOpenLogin = true) => {
      const res = await api('/api/accounts', {
        method: 'POST',
        body: {
          name: customName || undefined,
          proxy: customProxy || undefined
        }
      });
      state.accounts = res.accounts || [];
      state.activeAccount = res.activeAccount;
      state.batchStats = res.batchStats;
      $('masterScreeningVideo')?.removeAttribute('src');
      renderTopBar();
      renderScriptTab();
      renderCastTab();
      renderProductionTab();
      renderAccountsModalList();
      switchTab('script');
      showToast(`🎬 Đã tạo "${res.activeAccount.name}" trên một trang sản xuất riêng biệt!`, 'success');
      if (autoOpenLogin) {
        openInAppLoginForAccount(res.activeAccount.id);
      }
    };

    $('selectActiveMovie').addEventListener('change', async (ev) => {
      const val = ev.target.value;
      if (val === '__add_new__') {
        const name = prompt('Nhập tên Bộ phim / Dự án mới (mỗi tài khoản 1 bộ phim riêng):', `Bộ Phim #${state.accounts.length + 1}`);
        if (name === null) {
          renderTopBar();
          return;
        }
        try {
          await createNewAccountAndOpenWorkspace(name.trim(), '', true);
        } catch (e) {
          renderTopBar();
          showToast(e.message, 'error');
        }
        return;
      }
      try {
        await switchActiveMovieWorkspace(val, { showNotice: true });
      } catch (e) {
        showToast(e.message, 'error');
      }
    });

    const topRenameInput = $('topInlineProjectNameInput');
    const topMovieSelect = $('selectActiveMovie');
    const finishTopRename = async (commit) => {
      if (!topRenameInput || topRenameInput.classList.contains('hidden')) return;
      const nextVal = topRenameInput.value.trim();
      const origVal = topRenameInput.dataset.origName || '';
      topRenameInput.classList.add('hidden');
      topMovieSelect?.classList.remove('hidden');
      if (!commit || !state.activeAccount || !nextVal || nextVal === origVal) return;
      try {
        const res = await api(`/api/accounts/${state.activeAccount.id}/name`, {
          method: 'PUT',
          body: { name: nextVal }
        });
        state.accounts = res.accounts;
        state.activeAccount = res.account;
        renderTopBar();
        renderAccountsModalList();
        showToast('Đã đổi tên dự án phim!', 'success');
      } catch (e) {
        showToast(e.message, 'error');
      }
    };

    $('btnRenameMovie').addEventListener('click', () => {
      if (!state.activeAccount || !topRenameInput || !topMovieSelect) return;
      if (!topRenameInput.classList.contains('hidden')) {
        finishTopRename(true);
      } else {
        topRenameInput.value = state.activeAccount.name || '';
        topRenameInput.dataset.origName = state.activeAccount.name || '';
        topMovieSelect.classList.add('hidden');
        topRenameInput.classList.remove('hidden');
        topRenameInput.focus();
        topRenameInput.select();
      }
    });
    topRenameInput?.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') {
        e.preventDefault();
        finishTopRename(true);
      } else if (e.key === 'Escape') {
        finishTopRename(false);
      }
    });
    topRenameInput?.addEventListener('blur', () => finishTopRename(true));

    $('btnNewMovie').addEventListener('click', async () => {
      const name = prompt('Nhập tên Bộ phim / Dự án mới (mỗi tài khoản Muse.ai tạo 1 bộ phim riêng):', `Bộ Phim #${state.accounts.length + 1}`);
      if (name === null) return;
      try {
        await createNewAccountAndOpenWorkspace(name.trim(), '', true);
      } catch (e) {
        showToast(e.message, 'error');
      }
    });

    $('btnCloneEpisode').addEventListener('click', async () => {
      if (!state.activeAccount) return;
      const defaultEpName = `${state.activeAccount.name.replace(/\s*-\s*Tập\s*\d+$/i, '')} - Tập ${
        state.accounts.length + 1
      }`;
      const epName = prompt(
        'Nhân bản sang Dự Án Tập Tiếp Theo (Giữ 100% Đoàn Diễn Viên + Ảnh chân dung + Thể loại + Ánh sáng):\nNhập tên Tập mới:',
        defaultEpName
      );
      if (epName === null) return;
      try {
        const res = await api(`/api/accounts/${state.activeAccount.id}/clone-episode`, {
          method: 'POST',
          body: { name: epName.trim() }
        });
        state.accounts = res.accounts;
        state.activeAccount = res.activeAccount;
        state.batchStats = res.batchStats;
        renderTopBar();
        renderScriptTab();
        renderCastTab();
        renderProductionTab();
        renderAccountsModalList();
        switchTab('script');
        showToast(`📑 Đã khởi tạo "${res.activeAccount.name}" giữ nguyên toàn bộ Đoàn Diễn Viên!`, 'success');
      } catch (e) {
        showToast(e.message, 'error');
      }
    });

    $('btnOpenOutputFolder').addEventListener('click', async () => {
      await api('/api/open-output-folder', {
        method: 'POST',
        body: { accountId: state.activeAccount?.id }
      }).catch((e) => showToast(e.message, 'error'));
    });

    // Nút XÓA TOÀN BỘ LÀM LẠI TỪ ĐẦU (Topbar & Bước 1)
    const handleWipeEntireMovie = async () => {
      if (!state.activeAccount) return;
      const ok = confirm(
        `⚠️ XÓA TOÀN BỘ ĐỂ LÀM LẠI TỪ ĐẦU?\n\nHệ thống sẽ xóa trắng toàn bộ dữ liệu cũ của "${state.activeAccount.name}":\n• Kịch bản, Khóa bối cảnh & Ánh sáng riêng\n• Đoàn Diễn Viên, Vũ khí cố định & Kho Bối Cảnh\n• Toàn bộ Bảng Phân Cảnh & Nhạc nền\n\n✅ Tài khoản Muse.ai đã đăng nhập và Bản quyền VIP vẫn được GIỮ NGUYÊN 100%.\n\nBạn có chắc chắn muốn xóa trắng làm lại từ đầu không?`
      );
      if (!ok) return;

      try {
        state.castBatchAbort = true;
        state.locBatchAbort = true;
        const res = await api(`/api/accounts/${state.activeAccount.id}/wipe-all`, {
          method: 'POST'
        });
        state.accounts = res.accounts || state.accounts;
        state.activeAccount = res.account;
        state.batchStats = res.batchStats;
        state.sceneFilter = 'all';

        const player = $('masterScreeningVideo');
        if (player) {
          player.pause?.();
          player.removeAttribute('src');
          player.load?.();
        }
        $('masterScreenPlaceholder')?.classList.remove('hidden');
        $('masterResultCard')?.classList.add('hidden');
        $('storyboardProgressBox')?.classList.add('hidden');

        renderTopBar();
        renderScriptTab();
        renderCastTab();
        renderProductionTab();
        renderPostProductionTab();
        renderAccountsModalList();
        switchTab('script');
        showToast('🧹 Đã xóa trắng toàn bộ dự án — Sẵn sàng làm bộ phim mới từ đầu!', 'success');
      } catch (e) {
        showToast(e.message, 'error');
      }
    };

    $('btnWipeAllTop')?.addEventListener('click', handleWipeEntireMovie);
    $('btnWipeAllScript')?.addEventListener('click', handleWipeEntireMovie);

    $('btnWipeCastAndLocs')?.addEventListener('click', async () => {
      if (!state.activeAccount) return;
      const hasAny =
        (state.activeAccount.characters || []).length > 0 ||
        (state.activeAccount.locations || []).length > 0;
      if (!hasAny) {
        showToast('Đoàn Diễn Viên và Kho Bối Cảnh hiện đã trống sẵn!', 'info');
        return;
      }
      if (
        !confirm(
          'Xóa sạch toàn bộ Diễn Viên (kèm Vũ khí) & Kho Bối Cảnh hiện tại để tạo mới? (Kịch bản ở Bước 1 vẫn được giữ nguyên)'
        )
      ) {
        return;
      }
      try {
        state.castBatchAbort = true;
        state.locBatchAbort = true;
        const res = await api(`/api/accounts/${state.activeAccount.id}/wipe-cast-locations`, {
          method: 'POST'
        });
        state.accounts = res.accounts || state.accounts;
        state.activeAccount = res.account;
        renderTopBar();
        renderCastTab();
        renderProductionTab();
        showToast('🗑️ Đã xóa sạch Đoàn Diễn Viên & Kho Bối Cảnh!', 'success');
      } catch (e) {
        showToast(e.message, 'error');
      }
    });

    // Sự kiện Tab 1 (Kịch bản & Thể loại)
    $('inputCustomStyle').addEventListener('input', (e) => updateFilmConfigLive({ customStylePrompt: e.target.value }));
    $('cfgAspectRatio').addEventListener('change', (e) => updateFilmConfigLive({ aspectRatio: e.target.value }));
    $('cfgResolution').addEventListener('change', (e) => updateFilmConfigLive({ resolution: e.target.value }));
    $('cfgTargetMovieSeconds').addEventListener('change', (e) => {
      updateScriptWordStats();
      updateFilmConfigLive({ targetMovieSeconds: Number(e.target.value) });
    });
    $('cfgSceneDuration').addEventListener('change', (e) => {
      updateScriptWordStats();
      updateFilmConfigLive({ sceneDurationSeconds: Number(e.target.value) });
    });
    $('cfgAudioMode').addEventListener('change', (e) => updateFilmConfigLive({ audioMode: e.target.value }));
    $('cfgNarratorVoice').addEventListener('change', (e) =>
      updateFilmConfigLive({ narratorVoicePreset: e.target.value })
    );
    $('inputWorldLock').addEventListener('input', (e) => updateFilmConfigLive({ worldLock: e.target.value }));
    $('cfgLightingPreset')?.addEventListener('change', (e) => {
      updateFilmConfigLive({ lightingPreset: e.target.value });
      if (e.target.value === 'custom') {
        $('inputCustomLighting')?.focus();
      }
    });
    $('inputCustomLighting')?.addEventListener('input', (e) =>
      updateFilmConfigLive({ customLightingNote: e.target.value })
    );
    $('cfgActingStyle')?.addEventListener('change', (e) =>
      updateFilmConfigLive({ actingStyle: e.target.value })
    );
    $('cfgCombatIntensity')?.addEventListener('change', (e) =>
      updateFilmConfigLive({ combatIntensity: e.target.value })
    );
    $('textareaStoryDraft').addEventListener('input', (e) => {
      updateScriptWordStats();
      updateFilmConfigLive({ storyDraft: e.target.value });
    });

    // Mẫu thử nhanh ở Tab 1
    document.querySelectorAll('[data-sample]').forEach((btn) => {
      btn.addEventListener('click', () => {
        const tpl = SAMPLE_STORIES[btn.dataset.sample];
        if (!tpl) return;
        $('textareaStoryDraft').value = tpl.story;
        $('inputWorldLock').value = tpl.worldLock;
        if ($('cfgLightingPreset') && tpl.lightingPreset) {
          $('cfgLightingPreset').value = tpl.lightingPreset;
        }
        updateFilmConfigLive({
          genreId: tpl.genreId,
          lightingPreset: tpl.lightingPreset || 'auto',
          worldLock: tpl.worldLock,
          storyDraft: tpl.story
        });
        renderGenreCards();
        updateScriptWordStats();
        showToast('✨ Đã nạp kịch bản mẫu! Bấm "⚡ Tách Nhanh" hoặc "🎬 AI Đạo Diễn" để lên phân cảnh.', 'info');
      });
    });

    // Nút Tách Nhanh Kịch Bản Có Sẵn (0.1s)
    $('btnLocalSplitScript').addEventListener('click', async () => {
      if (!state.activeAccount) return;
      const storyText = $('textareaStoryDraft').value.trim();
      if (!storyText) {
        showToast('Vui lòng nhập Kịch bản hoặc bấm chọn 1 Mẫu thử nhanh trước!', 'error');
        return;
      }
      try {
        const res = await api(`/api/accounts/${state.activeAccount.id}/storyboard/local-split`, {
          method: 'POST',
          body: { storyText, append: false }
        });
        state.activeAccount = res.account;
        renderTopBar();
        renderCastTab();
        renderProductionTab();
        switchTab('production');
        showToast(
          `⚡ Đã tách xong ${res.sceneCount} phân cảnh phim${
            res.extractedCharacterCount > 0 ? ` & nhận diện ${res.extractedCharacterCount} nhân vật mới` : ''
          }!`,
          'success'
        );
      } catch (e) {
        showToast(e.message, 'error');
      }
    });

    // Nút AI Đạo Diễn Triển Khai Toàn Bộ Phim
    $('btnAiBuildMovie').addEventListener('click', async () => {
      if (!state.activeAccount) return;
      const storyText = $('textareaStoryDraft').value.trim();
      if (!storyText) {
        showToast('Vui lòng nhập Ý tưởng cốt truyện trước khi bấm AI Đạo Diễn!', 'error');
        return;
      }
      const btn = $('btnAiBuildMovie');
      btn.disabled = true;
      $('storyboardProgressBox').classList.remove('hidden');
      $('storyboardProgressText').textContent = '🎬 AI Đạo Diễn đang đọc cốt truyện, tạo Dàn Diễn Viên & viết Phân Cảnh...';
      try {
        const res = await api(`/api/accounts/${state.activeAccount.id}/storyboard/ai-generate`, {
          method: 'POST',
          body: { storyText, append: false }
        });
        state.activeAccount = res.account;
        renderTopBar();
        renderCastTab();
        renderProductionTab();
        const hasCastWithoutImg = (res.account.characters || []).some(
          (c) =>
            c.roleType !== 'narrator' &&
            !(c.referenceImages || []).some((im) => Number(im?.slot || 0) === 0 && im.publicUrl)
        );
        switchTab(hasCastWithoutImg ? 'cast' : 'production');
        showToast(
          hasCastWithoutImg
            ? '🎭 AI đã tạo xong Đoàn Diễn Viên (kèm Vũ khí) & Bảng Phân Cảnh! Hãy bấm tạo ảnh nhân vật rồi sang Bước 3 Bấm Máy!'
            : '🎬 Đã lên xong toàn bộ Bảng Phân Cảnh phim!',
          'success'
        );
      } catch (e) {
        showToast(e.message, 'error');
      } finally {
        btn.disabled = false;
        $('storyboardProgressBox').classList.add('hidden');
      }
    });

    $('btnStopStoryboard').addEventListener('click', async () => {
      if (!state.activeAccount) return;
      await api(`/api/accounts/${state.activeAccount.id}/storyboard/stop`, { method: 'POST' }).catch(() => {});
      $('storyboardProgressBox').classList.add('hidden');
    });

    // Sự kiện Tab 2 (Đoàn diễn viên)
    const flushAllCastCardEdits = async (accId) => {
      const cards = Array.from(document.querySelectorAll('#castCardGrid .actor-card'));
      for (const card of cards) {
        const charId = card.dataset.charId;
        if (charSaveTimers.has(charId)) {
          clearTimeout(charSaveTimers.get(charId));
          charSaveTimers.delete(charId);
        }
        try {
          const res = await api(`/api/accounts/${accId}/characters`, {
            method: 'POST',
            body: {
              id: charId,
              name: card.querySelector('.char-name-inp')?.value,
              roleType: card.querySelector('.char-role-sel')?.value,
              voicePreset: card.querySelector('.char-voice-sel')?.value,
              appearanceDna: card.querySelector('.char-dna-inp')?.value,
              weaponDna: card.querySelector('.char-weapon-dna-inp')?.value || '',
              weaponLockMode: card.querySelector('.char-weapon-mode-sel')?.value || 'smart_context'
            }
          });
          state.activeAccount = res.account;
        } catch (_) {}
      }
    };

    $('btnAiGenerateAllCast')?.addEventListener('click', async () => {
      if (!state.activeAccount || state.castBatchRunning) return;
      const accId = state.activeAccount.id;

      await flushAllCastCardEdits(accId);

      const allVisualChars = (state.activeAccount.characters || []).filter((c) => c.roleType !== 'narrator');
      if (allVisualChars.length === 0) {
        showToast('Chưa có diễn viên xuất hiện trên hình nào để tạo ảnh! Hãy thêm diễn viên trước.', 'error');
        return;
      }

      const missingChars = allVisualChars.filter(
        (c) => !(c.referenceImages || []).some((im) => Number(im?.slot || 0) === 0 && im.publicUrl)
      );

      let targets = missingChars;
      if (missingChars.length === 0) {
        const regenerateAll = confirm(
          `Tất cả ${allVisualChars.length} diễn viên đều đã có ảnh chân dung.\nBạn có muốn AI tạo lại mới lần lượt cho toàn bộ ${allVisualChars.length} diễn viên không?`
        );
        if (!regenerateAll) return;
        targets = allVisualChars;
      }

      state.castBatchRunning = true;
      state.castBatchAbort = false;
      const banner = $('castBatchProgressBanner');
      banner?.classList.remove('hidden');

      let completedCount = 0;
      try {
        for (let i = 0; i < targets.length; i++) {
          if (state.castBatchAbort) break;
          const target = targets[i];
          state.generatingCharId = target.id;
          renderCastTab();

          const activeCard = document.querySelector(`.actor-card[data-char-id="${target.id}"]`);
          activeCard?.scrollIntoView({ behavior: 'smooth', block: 'nearest' });

          $('castBatchBannerTitle').textContent = `🎨 Đang tạo nhân vật lần lượt (${i + 1}/${targets.length}): "${target.name}" (${target.tag})...`;
          $('castBatchBannerSub').textContent = `Đã hoàn thành ${completedCount}/${targets.length} diễn viên • Hệ thống tự động tạo sạch từng người một để giữ nét mặt chuẩn nhất.`;

          try {
            const res = await api(`/api/accounts/${accId}/characters/${target.id}/ai-portrait`, {
              method: 'POST'
            });
            state.activeAccount = res.account;
            completedCount += 1;
            renderCastTab();
            renderProductionTab();
          } catch (err) {
            if (state.castBatchAbort) break;
            showToast(`⚠️ Chưa tạo được ảnh cho "${target.name}": ${err.message}`, 'error');
          }
        }

        if (state.castBatchAbort) {
          showToast(`⏹ Đã dừng tạo nhân vật (Hoàn thành ${completedCount}/${targets.length}).`, 'info');
        } else if (completedCount > 0) {
          showToast(`🎉 Đã tạo xong ảnh chân dung cho ${completedCount}/${targets.length} diễn viên!`, 'success');
        }
      } finally {
        state.castBatchRunning = false;
        state.castBatchAbort = false;
        state.generatingCharId = null;
        banner?.classList.add('hidden');
        renderCastTab();
        renderProductionTab();
      }
    });

    $('btnStopGenerateAllCast')?.addEventListener('click', async () => {
      if (!state.activeAccount || !state.castBatchRunning) return;
      state.castBatchAbort = true;
      $('castBatchBannerTitle').textContent = '⏹ Đang dừng tạo ảnh nhân vật...';
      await api(`/api/accounts/${state.activeAccount.id}/characters/stop-portrait`, { method: 'POST' }).catch(() => {});
    });

    const handleAddCharacter = async () => {
      if (!state.activeAccount) return;
      try {
        const nextIdx = (state.activeAccount.characters || []).length + 1;
        const res = await api(`/api/accounts/${state.activeAccount.id}/characters`, {
          method: 'POST',
          body: { name: `Diễn viên ${nextIdx}` }
        });
        state.activeAccount = res.account;
        renderTopBar();
        renderCastTab();
        renderProductionTab();
      } catch (e) {
        showToast(e.message, 'error');
      }
    };
    $('btnAddCharacter').addEventListener('click', handleAddCharacter);
    $('btnAddFirstCharacter').addEventListener('click', handleAddCharacter);
    $('btnGoToProductionFromCast').addEventListener('click', () => switchTab('production'));

    // Kho Bối Cảnh Cố Định (Location Vault) ở Tab 2
    const flushAllLocationCardEdits = async (accId) => {
      const cards = Array.from(document.querySelectorAll('#locationCardGrid .location-card'));
      for (const card of cards) {
        const locId = card.dataset.locId;
        if (locSaveTimers.has(locId)) {
          clearTimeout(locSaveTimers.get(locId));
          locSaveTimers.delete(locId);
        }
        try {
          const res = await api(`/api/accounts/${accId}/locations`, {
            method: 'POST',
            body: {
              id: locId,
              name: card.querySelector('.loc-name-inp')?.value,
              descriptionDna: card.querySelector('.loc-dna-inp')?.value
            }
          });
          state.activeAccount = res.account;
        } catch (_) {}
      }
    };

    const handleAddLocation = async () => {
      if (!state.activeAccount) return;
      try {
        const nextIdx = (state.activeAccount.locations || []).length + 1;
        const res = await api(`/api/accounts/${state.activeAccount.id}/locations`, {
          method: 'POST',
          body: { name: `Bối cảnh ${nextIdx}` }
        });
        state.activeAccount = res.account;
        renderTopBar();
        renderLocationVaultSection();
        renderProductionTab();
      } catch (e) {
        showToast(e.message, 'error');
      }
    };
    $('btnAddLocation')?.addEventListener('click', handleAddLocation);
    $('btnAddFirstLocation')?.addEventListener('click', handleAddLocation);

    $('btnAiGenerateAllLocations')?.addEventListener('click', async () => {
      if (!state.activeAccount || state.locBatchRunning) return;
      const accId = state.activeAccount.id;

      await flushAllLocationCardEdits(accId);

      const allLocs = state.activeAccount.locations || [];
      if (allLocs.length === 0) {
        showToast('Chưa có bối cảnh cố định nào! Hãy bấm "➕ Thêm Bối Cảnh Cố Định" trước.', 'error');
        return;
      }

      const missingLocs = allLocs.filter(
        (l) => !l.referenceImages || l.referenceImages.length === 0 || !l.referenceImages[0]?.publicUrl
      );

      let targets = missingLocs;
      if (missingLocs.length === 0) {
        const regen = confirm(
          `Tất cả ${allLocs.length} bối cảnh đều đã có ảnh phim trường.\nBạn có muốn AI vẽ lại mới lần lượt cho toàn bộ ${allLocs.length} bối cảnh không?`
        );
        if (!regen) return;
        targets = allLocs;
      }

      state.locBatchRunning = true;
      state.locBatchAbort = false;
      const banner = $('locationBatchProgressBanner');
      banner?.classList.remove('hidden');

      let completedCount = 0;
      try {
        for (let i = 0; i < targets.length; i++) {
          if (state.locBatchAbort) break;
          const target = targets[i];
          state.generatingLocId = target.id;
          renderLocationVaultSection();

          const activeCard = document.querySelector(`.location-card[data-loc-id="${target.id}"]`);
          activeCard?.scrollIntoView({ behavior: 'smooth', block: 'nearest' });

          $('locationBatchBannerTitle').textContent = `🏞️ Đang thiết kế phim trường trống (${i + 1}/${targets.length}): "${target.name}" (${target.tag})...`;
          $('locationBatchBannerSub').textContent = `Đã hoàn thành ${completedCount}/${targets.length} bối cảnh • Bối cảnh 100% không người giúp các cảnh quay giữ nguyên kiến trúc.`;

          try {
            const res = await api(`/api/accounts/${accId}/locations/${target.id}/ai-plate`, { method: 'POST' });
            state.activeAccount = res.account;
            completedCount += 1;
            renderLocationVaultSection();
            renderProductionTab();
          } catch (err) {
            if (state.locBatchAbort) break;
            showToast(`⚠️ Chưa tạo được ảnh cho "${target.name}": ${err.message}`, 'error');
          }
        }

        if (state.locBatchAbort) {
          showToast(`⏹ Đã dừng tạo bối cảnh (Hoàn thành ${completedCount}/${targets.length}).`, 'info');
        } else if (completedCount > 0) {
          showToast(`🎉 Đã tạo xong ảnh phim trường cho ${completedCount}/${targets.length} bối cảnh!`, 'success');
        }
      } finally {
        state.locBatchRunning = false;
        state.locBatchAbort = false;
        state.generatingLocId = null;
        banner?.classList.add('hidden');
        renderLocationVaultSection();
        renderProductionTab();
      }
    });

    $('btnStopGenerateAllLocations')?.addEventListener('click', async () => {
      if (!state.activeAccount || !state.locBatchRunning) return;
      state.locBatchAbort = true;
      $('locationBatchBannerTitle').textContent = '⏹ Đang dừng tạo ảnh bối cảnh...';
      await api(`/api/accounts/${state.activeAccount.id}/locations/stop-plate`, { method: 'POST' }).catch(() => {});
    });

    // Sự kiện Tab 3 (Trung Tâm Sản Xuất Phân Cảnh)
    $('sceneFilterGroup').querySelectorAll('.filter-pill').forEach((btn) => {
      btn.addEventListener('click', () => {
        state.sceneFilter = btn.dataset.filter;
        $('sceneFilterGroup').querySelectorAll('.filter-pill').forEach((b) => b.classList.remove('active'));
        btn.classList.add('active');
        renderProductionTab();
      });
    });

    $('selectContinuityMode').addEventListener('change', (e) => {
      updateFilmConfigLive({ continuityMode: e.target.value });
      $('concurrencyWrap').classList.toggle('hidden', e.target.value === 'sequential_chain');
    });

    $('chkAutoQcRetry')?.addEventListener('change', async (ev) => {
      if (!state.activeAccount) return;
      try {
        const res = await api(`/api/accounts/${state.activeAccount.id}/settings`, {
          method: 'PUT',
          body: { autoQcRetry: Boolean(ev.target.checked) }
        });
        state.activeAccount = res.account;
        showToast(ev.target.checked ? '🛡️ Đã bật tự kiểm tra & quay lại cảnh lỗi' : 'Đã tắt tự quay lại cảnh lỗi (vẫn chấm điểm QC)', 'info');
      } catch (e) {
        showToast(e.message, 'error');
      }
    });

    $('selectColorGrade')?.addEventListener('change', async (ev) => {
      if (!state.activeAccount) return;
      await api(`/api/accounts/${state.activeAccount.id}/settings`, {
        method: 'PUT',
        body: { colorGrade: ev.target.value }
      }).catch(() => {});
    });

    const triggerPromoExport = async ({ makeThumbnail = true, makeTrailer = true }) => {
      if (!state.activeAccount) return;
      const btnThumb = $('btnRenderThumbOnly');
      const btnBoth = $('btnRenderPromo');
      if (btnThumb) btnThumb.disabled = true;
      if (btnBoth) btnBoth.disabled = true;
      $('promoProgressBanner').classList.remove('hidden');
      const srcMode = $('selectPosterSourceMode')?.value || 'smart_pack';
      $('promoProgressText').textContent =
        srcMode === 'ai_keyart'
          ? '✨ Đang kết nối AI Muse.ai vẽ Poster Key Art Đa Nhân Vật & thiết kế chữ...'
          : makeTrailer
          ? '🎬 Đang thiết kế Bộ 3 Poster Truyền Hình & dựng Video Trailer...'
          : '🎨 Đang thiết kế Bộ 3 Poster Ảnh Bìa Phim Truyền Hình (khoảng 2–3 giây)...';
      try {
        const res = await api(`/api/accounts/${state.activeAccount.id}/export-promo`, {
          method: 'POST',
          body: {
            movieTitle: $('inputExportMovieTitle').value.trim() || state.activeAccount.name,
            tagline: ($('inputPromoTagline')?.value || '').trim(),
            badgeText: $('selectPosterBadge')?.value || 'TRAILER CHÍNH THỨC',
            posterTheme: $('selectPosterTheme')?.value || 'auto',
            posterSourceMode: srcMode,
            trailerSeconds: Number($('selectTrailerSeconds')?.value) || 30,
            colorGrade: $('selectColorGrade')?.value || 'auto_match',
            makeThumbnail,
            makeTrailer
          }
        });
        state.activeAccount = res.account;
        state.activePromoVariantIdx = 0;
        renderPromoResultCard(res.promo, 0);
        showToast(
          makeTrailer
            ? `🎉 Đã tạo Bộ 3 Poster Ảnh Bìa & Trailer ${res.promo.trailerDuration}s!`
            : `🖼️ Đã thiết kế xong Bộ 3 Poster Ảnh Bìa Truyền Hình — Bấm chọn mẫu ưng ý nhất!`,
          'success'
        );
      } catch (e) {
        showToast(e.message, 'error');
      } finally {
        if (btnThumb) btnThumb.disabled = false;
        if (btnBoth) btnBoth.disabled = false;
        $('promoProgressBanner').classList.add('hidden');
      }
    };

    $('btnRenderThumbOnly')?.addEventListener('click', () =>
      triggerPromoExport({ makeThumbnail: true, makeTrailer: false })
    );
    $('btnRenderPromo')?.addEventListener('click', () =>
      triggerPromoExport({ makeThumbnail: true, makeTrailer: true })
    );

    $('btnPlayTrailer')?.addEventListener('click', () => {
      const promo = state.activeAccount?.settings?.lastPromoExport;
      if (!promo || !promo.trailerUrl) return;
      state.sequentialPlaylist = [];
      const player = $('masterScreeningVideo');
      $('masterScreenPlaceholder').classList.add('hidden');
      player.src = `${promo.trailerUrl}?t=${Date.now()}`;
      player.play().catch(() => {});
      player.scrollIntoView({ behavior: 'smooth', block: 'center' });
    });

    $('selectConcurrency').addEventListener('change', (e) => {
      updateFilmConfigLive({ concurrency: Number(e.target.value) });
    });

    $('btnAddSceneCard').addEventListener('click', async () => {
      if (!state.activeAccount) return;
      try {
        const res = await api(`/api/accounts/${state.activeAccount.id}/scenes/add`, { method: 'POST', body: {} });
        state.activeAccount = res.account;
        state.sceneFilter = 'all';
        renderTopBar();
        renderProductionTab();
        showToast(`Đã thêm Cảnh ${res.row.index}!`, 'success');
      } catch (e) {
        showToast(e.message, 'error');
      }
    });

    $('btnResetScenes').addEventListener('click', async () => {
      if (!state.activeAccount) return;
      if (!confirm('Xóa trắng toàn bộ các phân cảnh hiện tại để làm lại kịch bản mới? (Đoàn Diễn Viên vẫn được giữ nguyên)')) {
        return;
      }
      try {
        const res = await api(`/api/accounts/${state.activeAccount.id}/reset-project`, { method: 'POST' });
        state.activeAccount = res.account;
        state.batchStats = res.batchStats;
        renderTopBar();
        renderProductionTab();
        showToast('Đã làm mới bảng phân cảnh!', 'success');
      } catch (e) {
        showToast(e.message, 'error');
      }
    });

    $('btnStartShootAll').addEventListener('click', async () => {
      if (!state.activeAccount) return;
      try {
        const res = await api(`/api/accounts/${state.activeAccount.id}/batch/start`, {
          method: 'POST',
          body: { forceAll: false }
        });
        state.batchStats = res.stats;
        renderProductionSummaryAndControls();
        showToast('🎬 Đoàn làm phim đã bấm máy quay tự động!', 'success');
      } catch (e) {
        showToast(e.message, 'error');
      }
    });

    $('btnStopShootAll').addEventListener('click', async () => {
      if (!state.activeAccount) return;
      await api(`/api/accounts/${state.activeAccount.id}/batch/stop`, { method: 'POST' }).catch(() => {});
      showToast('⏹ Đã gửi lệnh dừng quay hàng loạt.');
    });

    $('btnGoToPostProd').addEventListener('click', () => switchTab('postprod'));

    // Sự kiện Tab 4 (Hậu kỳ & Xuất Master)
    $('btnPlayAllSequential').addEventListener('click', () => {
      const completed = (state.activeAccount?.rows || []).filter((r) => r.videoUrl && r.includeInExport !== false);
      if (completed.length === 0) {
        showToast('Chưa có cảnh phim nào hoàn tất để chiếu thử!', 'error');
        return;
      }
      state.sequentialPlaylist = completed.map((r) => r.videoUrl);
      state.sequentialIndex = 0;
      const player = $('masterScreeningVideo');
      $('masterScreenPlaceholder').classList.add('hidden');
      player.src = state.sequentialPlaylist[0];
      player.play().catch(() => {});
      showToast(`🎥 Đang chiếu thử liên tiếp ${completed.length} phân cảnh...`);
    });

    $('masterScreeningVideo').addEventListener('ended', () => {
      if (
        state.sequentialPlaylist.length > 0 &&
        state.sequentialIndex >= 0 &&
        state.sequentialIndex < state.sequentialPlaylist.length - 1
      ) {
        state.sequentialIndex += 1;
        const player = $('masterScreeningVideo');
        player.src = state.sequentialPlaylist[state.sequentialIndex];
        player.play().catch(() => {});
      }
    });

    $('btnSelectAllReel').addEventListener('click', async () => {
      if (!state.activeAccount) return;
      for (const r of state.activeAccount.rows || []) {
        if (r.videoUrl && r.includeInExport === false) {
          await api(`/api/accounts/${state.activeAccount.id}/rows/${r.index}`, {
            method: 'PUT',
            body: { includeInExport: true }
          }).catch(() => {});
          r.includeInExport = true;
        }
      }
      renderPostProductionTab();
    });

    $('btnUploadBgm').addEventListener('click', () => $('inputBgmFile').click());
    $('inputBgmFile').addEventListener('change', async (ev) => {
      if (!state.activeAccount || !ev.target.files || !ev.target.files[0]) return;
      const fd = new FormData();
      fd.append('bgm', ev.target.files[0]);
      try {
        const res = await api(`/api/accounts/${state.activeAccount.id}/bgm`, { method: 'POST', body: fd });
        state.activeAccount = res.account;
        renderPostProductionTab();
        showToast('🎵 Đã tải lên nhạc nền phim!', 'success');
      } catch (e) {
        showToast(e.message, 'error');
      }
    });

    $('btnRemoveBgm').addEventListener('click', async () => {
      if (!state.activeAccount) return;
      try {
        const res = await api(`/api/accounts/${state.activeAccount.id}/bgm`, { method: 'DELETE' });
        state.activeAccount = res.account;
        renderPostProductionTab();
      } catch (e) {
        showToast(e.message, 'error');
      }
    });

    $('sliderBgmVolume').addEventListener('input', (ev) => {
      const pct = Number(ev.target.value) || 22;
      $('bgmVolValue').textContent = `${pct}%`;
    });

    $('sliderBgmVolume').addEventListener('change', async (ev) => {
      if (!state.activeAccount) return;
      const vol = (Number(ev.target.value) || 22) / 100;
      await api(`/api/accounts/${state.activeAccount.id}/settings`, {
        method: 'PUT',
        body: { bgmVolume: vol }
      }).catch(() => {});
    });

    $('chkAutoDuckBgm')?.addEventListener('change', async (ev) => {
      if (!state.activeAccount) return;
      await api(`/api/accounts/${state.activeAccount.id}/settings`, {
        method: 'PUT',
        body: { autoDuckBgm: Boolean(ev.target.checked) }
      }).catch(() => {});
    });

    $('btnRenderMasterMovie').addEventListener('click', async () => {
      if (!state.activeAccount) return;
      const btn = $('btnRenderMasterMovie');
      btn.disabled = true;
      $('exportProgressBanner').classList.remove('hidden');
      $('exportProgressText').textContent = '🎞️ Đang khởi tạo bàn dựng hậu kỳ & Mastering âm thanh chuẩn rạp...';
      try {
        const movieTitle = $('inputExportMovieTitle').value.trim() || state.activeAccount.name;
        const aspectMode = $('selectExportAspect').value;
        const transitionEffect = $('selectExportTransition').value || 'director_smart';
        const bgmVolume = (Number($('sliderBgmVolume').value) || 22) / 100;
        const autoDuckBgm = $('chkAutoDuckBgm') ? Boolean($('chkAutoDuckBgm').checked) : true;
        const burnSubtitles = $('chkBurnSubtitles').checked;
        const colorGrade = $('selectColorGrade')?.value || 'auto_match';

        await api(`/api/accounts/${state.activeAccount.id}/settings`, {
          method: 'PUT',
          body: { exportMovieTitle: movieTitle, transitionEffect, bgmVolume, autoDuckBgm, burnSubtitles, colorGrade }
        });

        const res = await api(`/api/accounts/${state.activeAccount.id}/export-movie`, {
          method: 'POST',
          body: { movieTitle, aspectMode, transitionEffect, bgmVolume, autoDuckBgm, burnSubtitles, colorGrade }
        });

        state.activeAccount = res.account;
        state.sequentialPlaylist = [];
        const player = $('masterScreeningVideo');
        $('masterScreenPlaceholder').classList.add('hidden');
        player.src = `${res.exportResult.publicUrl}?t=${Date.now()}`;
        renderPostProductionTab();
        showToast(`🏆 Xuất bản thành công bộ phim (${res.exportResult.duration}s)!`, 'success');
      } catch (e) {
        showToast(e.message, 'error');
      } finally {
        btn.disabled = false;
        $('exportProgressBanner').classList.add('hidden');
      }
    });

    $('btnLocateMasterFile').addEventListener('click', async () => {
      if (!state.activeAccount) return;
      await api('/api/open-output-file', {
        method: 'POST',
        body: { accountId: state.activeAccount.id, masterExport: true }
      }).catch((e) => showToast(e.message, 'error'));
    });

    // Quản lý Tài khoản & Token (Modal giống MUSE FLOW STUDIO 3.8) + OTA Update
    $('btnOpenAccountManager')?.addEventListener('click', () => {
      renderAccountsModalList();
      openModal('modalAccountManager');
    });

    $('btnCreateAndConnectAcc')?.addEventListener('click', async () => {
      const name = ($('inputNewAccName')?.value || '').trim();
      const proxy = ($('inputNewAccProxy')?.value || '').trim();
      try {
        if ($('inputNewAccName')) $('inputNewAccName').value = '';
        if ($('inputNewAccProxy')) $('inputNewAccProxy').value = '';
        closeModal('modalAccountManager');
        await createNewAccountAndOpenWorkspace(name, proxy, true);
      } catch (e) {
        showToast(e.message, 'error');
      }
    });

    $('btnSyncAllAccountsQuota')?.addEventListener('click', async (ev) => {
      const btn = ev.currentTarget;
      btn.disabled = true;
      try {
        const loggedList = (state.accounts || []).filter((a) => a.loginVerified);
        if (loggedList.length === 0 && state.activeAccount) {
          loggedList.push(state.activeAccount);
        }
        for (const a of loggedList) {
          const res = await api(`/api/accounts/${a.id}/refresh-quota`, { method: 'POST' }).catch(() => null);
          if (res?.accounts) state.accounts = res.accounts;
          if (res?.account && state.activeAccount && state.activeAccount.id === a.id) {
            state.activeAccount = res.account;
          }
        }
        renderTopBar();
        renderAccountsModalList();
        showToast('✅ Đã cập nhật số dư Token mới nhất!', 'success');
      } finally {
        btn.disabled = false;
      }
    });

    $('btnLogoutCurrentMuse')?.addEventListener('click', () => handleLogoutAccount(null, true));
    $('btnLogoutFromSaved')?.addEventListener('click', () => handleLogoutAccount(null, true));
    $('btnResetAuthFlow').addEventListener('click', () => inspectAuthModal(true));

    const runAuthAction = async (payload) => {
      const target = getLoginModalAccount();
      if (!target) return;
      $('loginStepHeading').textContent = '⏳ Đang xác thực với Muse.ai...';
      $('loginErrorAlert').classList.add('hidden');
      try {
        const res = await api(`/api/accounts/${target.id}/inapp-login/submit`, {
          method: 'POST',
          body: payload
        });
        state.accounts = res.accounts || state.accounts;
        if (state.activeAccount && res.account && state.activeAccount.id === res.account.id) {
          state.activeAccount = res.account;
        }
        renderTopBar();
        renderAccountsModalList();
        renderAuthStepUI(res.state);
        if (res.state?.isLoggedIn) {
          showToast('✅ Đăng nhập Muse.ai thành công!', 'success');
        }
      } catch (e) {
        $('loginErrorAlert').textContent = e.message;
        $('loginErrorAlert').classList.remove('hidden');
      }
    };

    $('btnSubmitIdentifier').addEventListener('click', () =>
      runAuthAction({ action: 'submit_identifier', identifier: $('inputAuthIdentifier').value.trim() })
    );
    $('btnSubmitPassword').addEventListener('click', () =>
      runAuthAction({ action: 'submit_password', password: $('inputAuthPassword').value })
    );
    $('btnSwitchToOtp').addEventListener('click', () =>
      runAuthAction({ action: 'request_otp_instead', identifier: $('inputAuthIdentifier').value.trim() })
    );
    $('btnSubmitOtp').addEventListener('click', () =>
      runAuthAction({ action: 'submit_otp', code: $('inputAuthOtp').value.trim() })
    );
    $('btnResendOtp').addEventListener('click', () => runAuthAction({ action: 'resend_code' }));
    $('btnSubmit2FA').addEventListener('click', () => {
      const checked = document.querySelector('input[name="mfs_2fa"]:checked');
      runAuthAction({ action: 'select_2fa_method', methodId: checked ? checked.value : '' });
    });
    $('btnContinueSaved').addEventListener('click', () => runAuthAction({ action: 'continue_saved_account' }));
    $('btnUseAnotherAcc').addEventListener('click', () => runAuthAction({ action: 'use_another_account' }));

    $('btnSaveCustomAccLabel').addEventListener('click', async () => {
      const target = getLoginModalAccount();
      if (!target) return;
      try {
        const res = await api(`/api/accounts/${target.id}/custom-login-name`, {
          method: 'PUT',
          body: { loginName: $('inputCustomAccLabel').value.trim() }
        });
        state.accounts = res.accounts;
        if (state.activeAccount && state.activeAccount.id === target.id) {
          state.activeAccount = res.account;
        }
        renderTopBar();
        renderAccountsModalList();
        showToast('Đã lưu tên gợi nhớ tài khoản!', 'success');
      } catch (e) {
        showToast(e.message, 'error');
      }
    });

    $('btnSaveProxy').addEventListener('click', async () => {
      const target = getLoginModalAccount();
      if (!target) return;
      try {
        const res = await api(`/api/accounts/${target.id}/proxy`, {
          method: 'PUT',
          body: { proxy: $('inputAccountProxy').value.trim() }
        });
        state.accounts = res.accounts;
        if (state.activeAccount && state.activeAccount.id === target.id) {
          state.activeAccount = res.account;
        }
        renderAccountsModalList();
        showToast('Đã lưu cấu hình Proxy!', 'success');
      } catch (e) {
        showToast(e.message, 'error');
      }
    });

    $('btnRefreshQuota').addEventListener('click', async (ev) => {
      ev.stopPropagation();
      if (!state.activeAccount) return;
      if ($('topQuotaRemainingText')) $('topQuotaRemainingText').textContent = '...';
      try {
        const res = await api(`/api/accounts/${state.activeAccount.id}/refresh-quota`, { method: 'POST' });
        state.accounts = res.accounts;
        state.activeAccount = res.account;
        renderTopBar();
        renderAccountsModalList();
        showToast('Đã đồng bộ số dư Token Muse.ai!', 'success');
      } catch (e) {
        renderTopBar();
        showToast(e.message, 'error');
      }
    });

    // Sự kiện Tự động cập nhật OTA từ GitHub (Giống MUSE FLOW STUDIO 3.8)
    $('topVersionBadge')?.addEventListener('click', () => checkRemoteUpdate(true));
    $('btnTopUpdateAlert')?.addEventListener('click', () => {
      if (state.cachedUpdateInfo && state.cachedUpdateInfo.updateAvailable) {
        openUpdateModalWithInfo(state.cachedUpdateInfo);
      } else {
        checkRemoteUpdate(true);
      }
    });

    $('btnApplyUpdateNow')?.addEventListener('click', async () => {
      if (state.updateInstalling) return;
      state.updateInstalling = true;
      const btnApply = $('btnApplyUpdateNow');
      const btnDismiss = $('btnDismissUpdateModal');
      const btnCloseX = $('btnCloseUpdateModalX');
      const progBox = $('updateProgressBox');
      const progStatus = $('updateProgressStatus');

      if (btnApply) btnApply.disabled = true;
      btnDismiss?.classList.add('hidden');
      btnCloseX?.classList.add('hidden');
      progBox?.classList.remove('hidden');
      if (progStatus) progStatus.textContent = 'Đang kết nối GitHub tải gói nâng cấp mới...';

      try {
        const res = await api('/api/update/apply', { method: 'POST' });
        if (res.alreadyLatest) {
          state.updateInstalling = false;
          if (btnApply) btnApply.disabled = false;
          progBox?.classList.add('hidden');
          closeModal('modalUpdateOta');
          showToast(res.message || 'Bạn đang ở phiên bản mới nhất!', 'success');
          return;
        }

        const targetVer = res.newVersion || state.cachedUpdateInfo?.latestVersion || '';
        if (progStatus) {
          progStatus.textContent = `Đã cài xong v${targetVer}! Đang tự khởi động lại công cụ (đợi 2–3 giây)...`;
        }

        let attempts = 0;
        const pollRestart = setInterval(async () => {
          attempts++;
          try {
            const r = await fetch(`/api/state?t=${Date.now()}`, { cache: 'no-store' });
            if (r.ok) {
              const st = await r.json();
              if (st && st.ok && (!targetVer || st.version === targetVer || attempts >= 6)) {
                clearInterval(pollRestart);
                try {
                  sessionStorage.setItem('mcs_just_updated_to', st.version || targetVer);
                } catch (_) {}
                window.location.reload();
              }
            }
          } catch (_) {}
        }, 1200);
      } catch (e) {
        state.updateInstalling = false;
        if (btnApply) btnApply.disabled = false;
        if (!state.cachedUpdateInfo?.mandatory) {
          btnDismiss?.classList.remove('hidden');
          btnCloseX?.classList.remove('hidden');
        }
        progBox?.classList.add('hidden');
        showToast(e.message, 'error');
      }
    });

    let activeQrOrder = null;
    let qrPollTimer = null;

    const stopQrPolling = () => {
      if (qrPollTimer) {
        clearInterval(qrPollTimer);
        qrPollTimer = null;
      }
    };

    const verifyQrOrderOnce = async (manual = false) => {
      if (!activeQrOrder) return;
      try {
        if (manual) $('licPayNotice').textContent = '⏳ Đang đối soát giao dịch chuyển khoản...';
        const res = await api('/api/license/payment/check', {
          method: 'POST',
          body: { planId: activeQrOrder.plan.id, orderCode: activeQrOrder.orderCode }
        });
        if (res.paid && res.license) {
          stopQrPolling();
          state.license = res.license;
          renderTopBar();
          showToast('🎉 Thanh toán thành công! Đã tự động kích hoạt bản quyền!', 'success');
          closeModal('modalLicense');
        } else if (manual) {
          $('licPayNotice').textContent = res.message || 'Chưa ghi nhận giao dịch mới. Hệ thống vẫn đang tự động kiểm tra...';
        }
      } catch (e) {
        if (manual) showToast(e.message, 'error');
      }
    };

    $('btnOpenLicenseModal').addEventListener('click', () => openModal('modalLicense'));

    $('btnCopyHwid')?.addEventListener('click', async () => {
      const hwid = state.license?.hwid || $('licMachineId').textContent || '';
      if (!hwid || hwid === '--') return;
      try {
        await navigator.clipboard.writeText(hwid);
        showToast(`📋 Đã sao chép Mã Máy: ${hwid}`, 'success');
      } catch (_) {
        prompt('Sao chép Mã Máy (HWID) bên dưới:', hwid);
      }
    });

    document.querySelectorAll('.lic-plan-btn').forEach((btn) => {
      btn.addEventListener('click', async () => {
        const planId = btn.dataset.plan;
        document.querySelectorAll('.lic-plan-btn').forEach((b) => b.classList.remove('active'));
        btn.classList.add('active');
        try {
          const res = await api('/api/license/payment/create-order', {
            method: 'POST',
            body: { planId }
          });
          activeQrOrder = res.order;
          $('licQrImg').src = activeQrOrder.qrUrl;
          $('licQrPlanLabel').textContent = `${activeQrOrder.plan.planName} — ${activeQrOrder.amountFormatted}`;
          $('licBankInfo').textContent = `${activeQrOrder.bankName} — ${activeQrOrder.accountNumber} (${activeQrOrder.accountHolder})`;
          $('licTransferContent').textContent = activeQrOrder.transferDisplay || activeQrOrder.transferContent;
          $('licPayNotice').textContent = 'Quét mã QR đúng nội dung — hệ thống tự động kích hoạt sau 10–20 giây!';
          $('licQrBox').classList.remove('hidden');

          stopQrPolling();
          qrPollTimer = setInterval(() => verifyQrOrderOnce(false), 6000);
        } catch (e) {
          showToast(e.message, 'error');
        }
      });
    });

    $('btnVerifyQrNow')?.addEventListener('click', () => verifyQrOrderOnce(true));

    $('btnActivateLicense').addEventListener('click', async () => {
      const key = $('inputLicenseKey').value.trim();
      if (!key) return;
      try {
        const res = await api('/api/license/activate', {
          method: 'POST',
          body: { licenseKey: key }
        });
        stopQrPolling();
        state.license = res.license;
        renderTopBar();
        showToast(res.message || 'Kích hoạt bản quyền thành công!', 'success');
        closeModal('modalLicense');
      } catch (e) {
        showToast(e.message, 'error');
      }
    });
  }

  initTheme();
  bindGlobalEvents();
  loadInitialState(true);
  connectWebSocket();
  setTimeout(() => checkRemoteUpdate(false), 2500);
  setInterval(() => checkRemoteUpdate(false), 30 * 60 * 1000);
})();
