/**
 * MUSE CINEMA STUDIO v2.0 — Xưởng Thiết Kế Poster Phim Truyền Hình & Trailer Giới Thiệu Tự Động
 * Tích hợp trọn bộ 4 công nghệ:
 *  1. Engine Đồ Họa Poster HTML5/CSS3/SVG qua Chromium Headless Full HD (chữ kim loại chuyển sắc, serif truyền hình,
 *     ánh sáng rim-light, hạt lửa/bokeh, huy hiệu phát sóng, câu hook kịch tính & hàng tên diễn viên Billing Block).
 *  2. Chế độ AI Muse.ai vẽ riêng Ảnh Bìa Key Art Đa Nhân Vật từ Hồ sơ Diễn Viên & Bối Cảnh.
 *  3. Chế độ Ghép Đa Nhân Vật Phim Bộ Truyền Hình (Double-Exposure Ensemble & Diagonal Split Triptych) siêu tốc 0 tốn Token.
 *  4. Xuất đồng thời Bộ 3 Phương Án Ảnh Bìa + Nút Tạo Riêng Ảnh Bìa tức thì + Khung kết thúc Trailer đồng bộ Poster.
 */
const fs = require('fs');
const path = require('path');
const { chromium } = require('playwright-core');
const { findChromeExecutable } = require('./chromeLauncher');
const {
  getFfmpegExecutable,
  runFfmpeg,
  probeMediaFile,
  resolveSceneVideoDiskPath,
  mergeNormalizedSegmentsWithTransition,
  measureClipColorStats,
  computeColorGradeFiltersForClips,
  COLOR_GRADE_PRESETS
} = require('./videoEditor');

const POSTER_THEME_PRESETS = [
  { id: 'auto', label: '🤖 Tự động khớp Thể loại phim (Khuyên dùng)' },
  { id: 'tv_drama_vtv', label: '📺 Phim Truyền Hình Tâm Lý / Gia Đình (Kiểu VTV / Hàn Quốc)' },
  { id: 'epic_xianxia_gold', label: '🐉 Cổ Trang / Tiên Hiệp Kim Hoàng (Kiểu WeTV / iQIYI)' },
  { id: 'netflix_thriller', label: '🔥 Hành Động / Hình Sự Kịch Tính (Kiểu Netflix Series)' },
  { id: 'pixar_fairy_glow', label: '✨ Hoạt Hình 3D / Cổ Tích Rực Rỡ (Kiểu Disney / Pixar)' },
  { id: 'cinema_prestige', label: '🎞️ Điện Ảnh Nghệ Thuật Sang Trọng (Widescreen Prestige)' }
];

const POSTER_SOURCE_MODES = [
  { id: 'smart_pack', label: '🎨 Trọn Bộ 3 Bố Cục Thông Minh (Đa Nhân Vật + Đa Khung + Điện Ảnh — 3 giây)' },
  { id: 'ai_keyart', label: '✨ AI Muse.ai Vẽ Riêng Poster Đa Nhân Vật (Key Art Đoàn Phim)' },
  { id: 'ensemble_only', label: '👥 Ưu Tiên Ghép Đa Nhân Vật Phim Bộ Truyền Hình (Double-Exposure)' },
  { id: 'split_only', label: '🎬 Ưu Tiên Chia Khung Cao Trào Đa Tuyến Nhân Vật (Split Panels)' }
];

const POSTER_BADGE_PRESETS = [
  { id: 'TRAILER CHÍNH THỨC', label: '🔴 TRAILER CHÍNH THỨC (Chuẩn Trailer)' },
  { id: 'PHIM TRUYỀN HÌNH ĐẶC SẮC', label: '📺 PHIM TRUYỀN HÌNH ĐẶC SẮC' },
  { id: 'SIÊU PHẨM DÀI TẬP', label: '🔥 SIÊU PHẨM DÀI TẬP' },
  { id: 'TẬP MỚI PHÁT SÓNG', label: '⚡ TẬP MỚI PHÁT SÓNG' },
  { id: 'PHIM ĐIỆN ẢNH ĐỘC QUYỀN', label: '🎬 PHIM ĐIỆN ẢNH ĐỘC QUYỀN' },
  { id: 'NONE', label: '🚫 Không gắn nhãn góc trên' }
];

const FONT_CANDIDATES = [
  'C:\\Windows\\Fonts\\segoeuib.ttf',
  'C:\\Windows\\Fonts\\tahomabd.ttf',
  'C:\\Windows\\Fonts\\arialbd.ttf',
  'C:\\Windows\\Fonts\\arial.ttf'
];

const ACTION_WORDS = [
  'chiến đấu', 'giao chiến', 'chém', 'lao tới', 'lao vào', 'bay vút', 'phi thân', 'bùng nổ', 'nổ tung', 'sấm sét',
  'rượt', 'đuổi theo', 'xuất chiêu', 'kiếm khí', 'rồng', 'ngọn lửa', 'bão', 'truy đuổi', 'tấn công',
  'quyết chiến', 'phép thuật', 'pháp lực', 'nhảy', 'bỏ chạy', 'battle', 'fight', 'explosion', 'chase'
];
const EMOTION_WORDS = [
  'khóc', 'nước mắt', 'rưng rưng', 'ôm chầm', 'tuyệt vọng', 'xúc động', 'sững sờ', 'thì thầm', 'giận dữ', 'hoảng sợ',
  'mỉm cười', 'nghẹn ngào', 'bàng hoàng', 'định mệnh', 'bí mật', 'phản bội', 'lời thề'
];
const SPECTACLE_WORDS = [
  'toàn cảnh', 'bầu trời', 'hoàng hôn', 'bình minh', 'cung điện', 'kinh thành', 'đỉnh núi', 'thần long', 'chiến trường',
  'đoàn quân', 'thành trì', 'vũ trụ', 'tầng mây', 'thung lũng', 'biệt thự', 'phố đêm'
];

function countHits(text, words) {
  const low = String(text || '').toLowerCase();
  return words.reduce((n, w) => (low.includes(w) ? n + 1 : n), 0);
}

function escapeHtml(str) {
  return String(str || '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

function findBrowserForPoster() {
  const chrome = findChromeExecutable();
  if (chrome && fs.existsSync(chrome)) return chrome;
  const edgeCandidates = [
    process.env['PROGRAMFILES(X86)'] && path.join(process.env['PROGRAMFILES(X86)'], 'Microsoft', 'Edge', 'Application', 'msedge.exe'),
    process.env.PROGRAMFILES && path.join(process.env.PROGRAMFILES, 'Microsoft', 'Edge', 'Application', 'msedge.exe'),
    'C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe',
    'C:\\Program Files\\Microsoft\\Edge\\Application\\msedge.exe'
  ].filter(Boolean);
  for (const e of edgeCandidates) {
    try {
      if (fs.existsSync(e)) return e;
    } catch (_) {}
  }
  return null;
}

function resolvePromoSize(acc, purpose = 'video') {
  const fc = acc.settings?.filmConfig || {};
  const aspect = fc.aspectRatio || '16:9';
  const isFullHd = (fc.resolution || acc.settings?.resolution) === '1080p';
  if (purpose === 'thumbnail') {
    if (aspect === '9:16') return { w: 1080, h: 1920, aspect: '9:16' };
    if (aspect === '1:1') return { w: 1080, h: 1080, aspect: '1:1' };
    if (aspect === '21:9') return { w: 1920, h: 816, aspect: '21:9' };
    return { w: 1920, h: 1080, aspect: '16:9' };
  }
  if (aspect === '9:16') return isFullHd ? { w: 1080, h: 1920, aspect } : { w: 720, h: 1280, aspect };
  if (aspect === '1:1') return { w: 1080, h: 1080, aspect };
  if (aspect === '21:9') return isFullHd ? { w: 1920, h: 816, aspect } : { w: 1280, h: 544, aspect };
  return isFullHd ? { w: 1920, h: 1080, aspect } : { w: 1280, h: 720, aspect };
}

function resolveEffectivePosterTheme(requestedTheme = 'auto', genreId = '3d_pixar') {
  if (requestedTheme && requestedTheme !== 'auto' && POSTER_THEME_PRESETS.some((p) => p.id === requestedTheme)) {
    return requestedTheme;
  }
  switch (genreId) {
    case 'drama_modern':
    case 'family_drama':
    case 'romance_youth':
      return 'tv_drama_vtv';
    case 'xianxia_fantasy':
    case 'historical_vn':
      return 'epic_xianxia_gold';
    case 'action_thriller':
    case 'horror_mystery':
    case 'scifi_future':
      return 'netflix_thriller';
    case '3d_pixar':
    case 'fairy_tale_kids':
    case 'anime_2d':
      return 'pixar_fairy_glow';
    default:
      return 'cinema_prestige';
  }
}

function getThemeVisualSpec(themeId, genreId = '') {
  const specs = {
    tv_drama_vtv: {
      id: 'tv_drama_vtv',
      kickerDefault: 'BỘ PHIM TRUYỀN HÌNH TÂM LÝ ĐẶC SẮC',
      fontFamily: "'Palatino Linotype', 'Times New Roman', Georgia, serif",
      fontWeight: 700,
      letterSpacing: '0.035em',
      titleGradient: 'linear-gradient(180deg, #FFFFFF 0%, #FFF6E0 45%, #F3C978 82%, #C9933B 100%)',
      accentColor: '#F59E0B',
      accentSoft: 'rgba(245, 158, 11, 0.36)',
      badgeBg: 'linear-gradient(135deg, rgba(185, 28, 28, 0.94), rgba(127, 29, 29, 0.94))',
      badgeBorder: 'rgba(252, 165, 165, 0.45)',
      glowColor: 'rgba(245, 158, 11, 0.42)',
      rimTint: 'rgba(251, 191, 36, 0.24)',
      topAtmosphere: 'radial-gradient(ellipse 90% 55% at 50% 18%, rgba(251, 191, 36, 0.14), transparent 70%)',
      bottomShade:
        'linear-gradient(to top, rgba(7, 8, 15, 0.97) 0%, rgba(11, 12, 22, 0.88) 24%, rgba(14, 15, 26, 0.48) 46%, rgba(14, 15, 26, 0.08) 68%, transparent 100%)',
      particleColor: '#FDE68A',
      flareColor: 'rgba(251, 191, 36, 0.35)'
    },
    epic_xianxia_gold: {
      id: 'epic_xianxia_gold',
      kickerDefault: genreId === 'historical_vn' ? 'SIÊU PHẨM LỊCH SỬ CỔ TRANG HÀO HÙNG' : 'SIÊU PHẨM CỔ TRANG TIÊN HIỆP KỲ ẢO',
      fontFamily: "'Palatino Linotype', 'Times New Roman', Georgia, serif",
      fontWeight: 700,
      letterSpacing: '0.055em',
      titleGradient: 'linear-gradient(180deg, #FFFDF5 0%, #FFE58F 28%, #F59E0B 64%, #B45309 92%, #FEF3C7 100%)',
      accentColor: '#FBBF24',
      accentSoft: 'rgba(251, 191, 36, 0.48)',
      badgeBg: 'linear-gradient(135deg, rgba(146, 64, 14, 0.94), rgba(69, 26, 3, 0.95))',
      badgeBorder: 'rgba(253, 224, 71, 0.65)',
      glowColor: 'rgba(245, 158, 11, 0.58)',
      rimTint: 'rgba(245, 158, 11, 0.28)',
      topAtmosphere: 'radial-gradient(ellipse 95% 55% at 50% 15%, rgba(56, 189, 248, 0.14), transparent 72%)',
      bottomShade:
        'linear-gradient(to top, rgba(5, 7, 14, 0.98) 0%, rgba(9, 12, 22, 0.89) 25%, rgba(12, 16, 28, 0.52) 48%, rgba(12, 16, 28, 0.1) 70%, transparent 100%)',
      particleColor: '#FBBF24',
      flareColor: 'rgba(251, 191, 36, 0.48)'
    },
    netflix_thriller: {
      id: 'netflix_thriller',
      kickerDefault: 'SERIES HÀNH ĐỘNG & KỊCH TÍNH ĐẶC SẮC',
      fontFamily: "'Segoe UI', Tahoma, Verdana, Arial, sans-serif",
      fontWeight: 900,
      letterSpacing: '0.045em',
      titleGradient: 'linear-gradient(180deg, #FFFFFF 0%, #F1F5F9 48%, #CBD5E1 82%, #94A3B8 100%)',
      accentColor: '#EF4444',
      accentSoft: 'rgba(239, 68, 68, 0.45)',
      badgeBg: 'linear-gradient(135deg, #E50914, #991B1B)',
      badgeBorder: 'rgba(254, 202, 202, 0.45)',
      glowColor: 'rgba(239, 68, 68, 0.45)',
      rimTint: 'rgba(56, 189, 248, 0.25)',
      topAtmosphere: 'radial-gradient(ellipse 90% 50% at 50% 16%, rgba(14, 165, 233, 0.16), transparent 72%)',
      bottomShade:
        'linear-gradient(to top, rgba(3, 5, 11, 0.98) 0%, rgba(6, 10, 19, 0.9) 25%, rgba(9, 14, 26, 0.54) 48%, rgba(9, 14, 26, 0.1) 70%, transparent 100%)',
      particleColor: '#38BDF8',
      flareColor: 'rgba(56, 189, 248, 0.44)'
    },
    pixar_fairy_glow: {
      id: 'pixar_fairy_glow',
      kickerDefault: 'PHIM HOẠT HÌNH ĐIỆN ẢNH ĐẶC SẮC',
      fontFamily: "'Segoe UI', 'Trebuchet MS', Tahoma, sans-serif",
      fontWeight: 900,
      letterSpacing: '0.025em',
      titleGradient: 'linear-gradient(180deg, #FFFFFF 0%, #FEF08A 38%, #FBBF24 75%, #EA580C 100%)',
      accentColor: '#FBBF24',
      accentSoft: 'rgba(251, 191, 36, 0.45)',
      badgeBg: 'linear-gradient(135deg, rgba(234, 88, 12, 0.95), rgba(180, 83, 9, 0.95))',
      badgeBorder: 'rgba(254, 240, 138, 0.6)',
      glowColor: 'rgba(251, 191, 36, 0.55)',
      rimTint: 'rgba(250, 204, 21, 0.26)',
      topAtmosphere: 'radial-gradient(ellipse 95% 55% at 50% 18%, rgba(253, 224, 71, 0.18), transparent 72%)',
      bottomShade:
        'linear-gradient(to top, rgba(8, 10, 24, 0.96) 0%, rgba(12, 16, 34, 0.86) 24%, rgba(16, 20, 42, 0.45) 46%, transparent 72%)',
      particleColor: '#FEF08A',
      flareColor: 'rgba(253, 224, 71, 0.4)'
    },
    cinema_prestige: {
      id: 'cinema_prestige',
      kickerDefault: 'TÁC PHẨM ĐIỆN ẢNH ĐẶC SẮC',
      fontFamily: "'Palatino Linotype', Georgia, 'Times New Roman', serif",
      fontWeight: 700,
      letterSpacing: '0.06em',
      titleGradient: 'linear-gradient(180deg, #FFFFFF 0%, #F8FAFC 52%, #E2E8F0 85%, #94A3B8 100%)',
      accentColor: '#E2E8F0',
      accentSoft: 'rgba(226, 232, 240, 0.35)',
      badgeBg: 'linear-gradient(135deg, rgba(30, 41, 59, 0.92), rgba(15, 23, 42, 0.95))',
      badgeBorder: 'rgba(226, 232, 240, 0.4)',
      glowColor: 'rgba(148, 163, 184, 0.4)',
      rimTint: 'rgba(226, 232, 240, 0.2)',
      topAtmosphere: 'radial-gradient(ellipse 90% 50% at 50% 18%, rgba(226, 232, 240, 0.1), transparent 70%)',
      bottomShade:
        'linear-gradient(to top, rgba(4, 6, 12, 0.98) 0%, rgba(8, 11, 20, 0.88) 24%, rgba(10, 14, 24, 0.46) 46%, transparent 72%)',
      particleColor: '#E2E8F0',
      flareColor: 'rgba(226, 232, 240, 0.32)'
    }
  };
  return specs[themeId] || specs.tv_drama_vtv;
}

function wrapTitleLines(title, maxChars) {
  const clean = String(title || '').replace(/_/g, ' ').replace(/\s+/g, ' ').trim();
  const words = clean.split(/\s+/).filter(Boolean);
  if (words.join(' ').length <= maxChars) return [words.join(' ')];
  const lines = [];
  let cur = '';
  for (const w of words) {
    if ((cur ? `${cur} ${w}` : w).length > maxChars && cur) {
      lines.push(cur);
      cur = w;
    } else {
      cur = cur ? `${cur} ${w}` : w;
    }
  }
  if (cur) lines.push(cur);
  if (lines.length > 3) {
    const head = lines.slice(0, 2);
    head.push(lines.slice(2).join(' '));
    return head;
  }
  return lines;
}

/**
 * Tự động rút trích các thành phần nhận diện Poster Truyền Hình từ dữ liệu bộ phim:
 * - Tên tập phim (nếu có trong tiêu đề hoặc dòng phụ)
 * - Câu thoại / câu dẫn kịch tính nhất (Hook Quote)
 * - Hàng tên dàn diễn viên chính (Cast Billing Block)
 */
function extractBroadcastPosterMeta(acc, rawTitle, rawTagline, badgeText = 'TRAILER CHÍNH THỨC') {
  const fc = acc.settings?.filmConfig || {};
  let cleanTitle = String(rawTitle || acc.name || 'BỘ PHIM MỚI')
    .replace(/_/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();

  // Nếu tiêu đề có "- Tập X" ở cuối và chưa có tagline, tách "TẬP X" ra thành huy hiệu tập phim chuyên nghiệp
  let episodePill = '';
  const epInTitle = cleanTitle.match(/^(.*?)\s*[-–:|•]\s*(tập\s*\d+.*)$/i);
  if (epInTitle && epInTitle[1].trim().length >= 3) {
    cleanTitle = epInTitle[1].trim();
    if (!rawTagline) {
      episodePill = epInTitle[2].trim();
    }
  }

  const tagline = String(rawTagline || episodePill || '').trim();

  // Rút trích câu Hook đắt giá nhất từ kịch bản / lời thoại các phân cảnh
  let hookQuote = '';
  const rows = Array.isArray(acc.rows) ? acc.rows : [];
  let bestLineScore = -1;
  for (const r of rows) {
    const dlgLines = String(r.dialogue || '')
      .split(/\r?\n|\s+\/\s+/)
      .map((s) => s.replace(/^(?:\[[^\]]+\]|@[a-zA-Z0-9_]+|[^:]{1,22})\s*:\s*/i, '').replace(/^[“"«]+|[”"»]+$/g, '').trim())
      .filter((s) => s.length >= 18 && s.length <= 96);
    for (const ln of dlgLines) {
      const sc = countHits(ln, EMOTION_WORDS) * 2.5 + countHits(ln, ACTION_WORDS) * 1.5 + (ln.includes('?') || ln.includes('!') ? 0.8 : 0.3);
      if (sc > bestLineScore) {
        bestLineScore = sc;
        hookQuote = ln;
      }
    }
  }
  if (!hookQuote && fc.storyDraft) {
    const firstSent = String(fc.storyDraft)
      .replace(/^(?:cảnh\s*\d+|\[[^\]]+\]|@[a-zA-Z0-9_]+)\s*[:.-]\s*/gim, '')
      .split(/[.!?…\n]+/)
      .map((s) => s.trim())
      .find((s) => s.length >= 22 && s.length <= 96);
    if (firstSent) hookQuote = firstSent;
  }

  const castNames = (acc.characters || [])
    .filter((c) => c && c.roleType !== 'narrator' && c.name)
    .slice(0, 4)
    .map((c) => String(c.name).trim().toLocaleUpperCase('vi-VN'));

  const resBadge = (fc.resolution || '720p') === '1080p' ? 'FULL HD 1080P' : 'HD CINEMA';
  const normalizedBadge = badgeText === 'NONE' ? '' : String(badgeText || 'TRAILER CHÍNH THỨC').trim();

  return {
    cleanTitle,
    tagline,
    hookQuote,
    castNames,
    badgeLeft: normalizedBadge,
    badgeRight: resBadge,
    genreId: fc.genreId || '3d_pixar'
  };
}

function fileToDataUrl(filePath) {
  if (!filePath || !fs.existsSync(filePath)) return null;
  const ext = path.extname(filePath).toLowerCase();
  const mime = ext === '.png' ? 'image/png' : ext === '.webp' ? 'image/webp' : 'image/jpeg';
  const b64 = fs.readFileSync(filePath).toString('base64');
  return `data:${mime};base64,${b64}`;
}

function lookFilterOf(colorGrade) {
  const p = (COLOR_GRADE_PRESETS || []).find((x) => x.id === colorGrade);
  return p && p.filter ? p.filter : '';
}

function collectEligibleRows(appRootDir, acc) {
  return (acc.rows || [])
    .filter((r) => r.includeInExport !== false)
    .map((r) => ({ row: r, filePath: resolveSceneVideoDiskPath(appRootDir, r) }))
    .filter((x) => x.filePath && fs.existsSync(x.filePath))
    .sort((a, b) => Number(a.row.index) - Number(b.row.index));
}

function scoreSceneForTrailer(row, isLast) {
  const text = `${row.sceneTitle || ''}\n${row.prompt || ''}\n${row.dialogue || ''}`;
  let score = 1;
  score += Math.min(3, countHits(text, ACTION_WORDS)) * 2.2;
  score += Math.min(2, countHits(text, EMOTION_WORDS)) * 1.6;
  score += Math.min(2, countHits(text, SPECTACLE_WORDS)) * 1.2;
  if (String(row.dialogue || '').trim()) score += 0.4;
  if (['close_up', 'low_angle', 'extreme_wide', 'aerial', 'extreme_close'].includes(row.shotSize)) score += 0.8;
  if (row.qc && Number.isFinite(row.qc.score)) score += (row.qc.score - 70) / 30;
  if (row.qc && row.qc.verdict === 'fail') score -= 4;
  if (isLast) score -= 1.5;
  return score;
}

/**
 * Quét & chuẩn bị kho hình ảnh chất lượng cao cho Poster Truyền Hình:
 * - Ảnh chân dung diễn viên chính (Bước 2)
 * - Ảnh bối cảnh gốc (Bước 2)
 * - Top 4 khung hình sắc nét & khác cảnh nhau từ các video đã quay (Bước 3)
 */
async function collectPosterVisualAssets({ ffmpegBin, acc, eligible, tempDir, w, h, colorGrade, aiKeyArtPath, report }) {
  const look = lookFilterOf(colorGrade);

  // 1. Lấy ảnh chân dung diễn viên chính từ Bước 2 (nếu có)
  const castPortraits = [];
  for (const ch of (acc.characters || []).filter((c) => c && c.roleType !== 'narrator')) {
    const pImg = (ch.referenceImages || []).find((im) => Number(im.slot || 0) === 0 && im.filePath && fs.existsSync(im.filePath));
    if (pImg) {
      const normPath = path.join(tempDir, `cast_norm_${castPortraits.length}.jpg`);
      try {
        await runFfmpeg(ffmpegBin, [
          '-y', '-i', pImg.filePath,
          '-vf', `scale=900:900:force_original_aspect_ratio=increase:flags=lanczos,crop=900:900${look ? `,${look}` : ''}`,
          '-frames:v', '1', '-q:v', '2', normPath
        ]);
        if (fs.existsSync(normPath)) {
          castPortraits.push({ name: ch.name, filePath: normPath, dataUrl: fileToDataUrl(normPath) });
        }
      } catch (_) {}
    }
    if (castPortraits.length >= 3) break;
  }

  // 2. Lấy ảnh bối cảnh gốc từ Bước 2 (nếu có)
  let locationBackdrop = null;
  const locWithImg = (acc.locations || []).find((l) => l?.referenceImage?.filePath && fs.existsSync(l.referenceImage.filePath));
  if (locWithImg) {
    const locNorm = path.join(tempDir, 'loc_backdrop.jpg');
    try {
      await runFfmpeg(ffmpegBin, [
        '-y', '-i', locWithImg.referenceImage.filePath,
        '-vf', `scale=${w}:${h}:force_original_aspect_ratio=increase:flags=lanczos,crop=${w}:${h}${look ? `,${look}` : ''}`,
        '-frames:v', '1', '-q:v', '2', locNorm
      ]);
      if (fs.existsSync(locNorm)) {
        locationBackdrop = { filePath: locNorm, dataUrl: fileToDataUrl(locNorm), sceneIndex: 'Bối cảnh gốc' };
      }
    } catch (_) {}
  }

  // 3. Nếu có ảnh AI Key Art vừa vẽ riêng trên Muse.ai
  let aiKeyArt = null;
  if (aiKeyArtPath && fs.existsSync(aiKeyArtPath)) {
    const keyNorm = path.join(tempDir, 'ai_keyart_norm.jpg');
    try {
      await runFfmpeg(ffmpegBin, [
        '-y', '-i', aiKeyArtPath,
        '-vf', `scale=${w}:${h}:force_original_aspect_ratio=increase:flags=lanczos,crop=${w}:${h}${look ? `,${look}` : ''}`,
        '-frames:v', '1', '-q:v', '2', keyNorm
      ]);
      if (fs.existsSync(keyNorm)) {
        aiKeyArt = { filePath: keyNorm, dataUrl: fileToDataUrl(keyNorm), sceneIndex: 'AI Key Art' };
      }
    } catch (_) {}
  }

  // 4. Trích xuất các khung hình đẹp nhất từ các phân cảnh đã quay (tối đa 10 cảnh trải đều)
  const sceneFrames = [];
  if (eligible.length > 0) {
    report('🖼️ Đang quét các khung hình sắc nét & giàu cảm xúc nhất trong phim...');
    const sampled =
      eligible.length <= 10
        ? eligible
        : Array.from({ length: 10 }, (_, k) => eligible[Math.round((k * (eligible.length - 1)) / 9)]);

    const candidates = [];
    for (let i = 0; i < sampled.length; i++) {
      const { row, filePath } = sampled[i];
      const info = await probeMediaFile(ffmpegBin, filePath);
      const dur = Math.max(1, info.duration || 5);
      for (const frac of [0.38, 0.66]) {
        const t = Math.max(0.2, Math.min(dur - 0.25, dur * frac));
        const candPath = path.join(tempDir, `cand_${i}_${Math.round(frac * 100)}.jpg`);
        try {
          await runFfmpeg(ffmpegBin, ['-y', '-ss', t.toFixed(3), '-i', filePath, '-frames:v', '1', '-vf', 'scale=640:-2', '-q:v', '3', candPath]);
          if (!fs.existsSync(candPath)) continue;
          const sizeKb = fs.statSync(candPath).size / 1024;
          const stats = await measureClipColorStats(ffmpegBin, candPath).catch(() => null);
          const y = stats ? stats.y : 110;
          const brightness = Math.max(0.25, 1 - Math.abs(y - 118) / 140);
          const hasCast = Array.isArray(row.sceneCharacterIds) && row.sceneCharacterIds.length > 0;
          const dramaHits = countHits(`${row.prompt || ''} ${row.dialogue || ''}`, [...ACTION_WORDS, ...EMOTION_WORDS]);
          const shotBonus = ['close_up', 'medium_close', 'low_angle', 'medium'].includes(row.shotSize) ? 1.16 : 1;
          const isWide = ['extreme_wide', 'wide', 'aerial'].includes(row.shotSize);
          const qcPenalty = row.qc && row.qc.verdict === 'fail' ? 0.35 : 1;
          candidates.push({
            row,
            filePath,
            t,
            isWide,
            score: sizeKb * brightness * (hasCast ? 1.18 : 1) * (1 + Math.min(3, dramaHits) * 0.08) * shotBonus * qcPenalty
          });
        } catch (_) {}
      }
    }

    candidates.sort((a, b) => b.score - a.score);
    const usedRows = new Set();
    const topPicks = [];
    for (const c of candidates) {
      if (usedRows.has(c.row.index)) continue;
      usedRows.add(c.row.index);
      topPicks.push(c);
      if (topPicks.length >= 4) break;
    }
    if (topPicks.length === 0 && candidates.length > 0) {
      topPicks.push(candidates[0]);
    }

    for (let k = 0; k < topPicks.length; k++) {
      const pick = topPicks[k];
      const hiResPath = path.join(tempDir, `scene_hires_${k}.jpg`);
      await runFfmpeg(ffmpegBin, [
        '-y', '-ss', pick.t.toFixed(3), '-i', pick.filePath, '-frames:v', '1',
        '-vf', `scale=${w}:${h}:force_original_aspect_ratio=increase:flags=lanczos,crop=${w}:${h}${look ? `,${look}` : ''}`,
        '-q:v', '2', hiResPath
      ]);
      if (fs.existsSync(hiResPath)) {
        sceneFrames.push({
          filePath: hiResPath,
          dataUrl: fileToDataUrl(hiResPath),
          sceneIndex: pick.row.index,
          timeSec: Number(pick.t.toFixed(2)),
          isWide: pick.isWide
        });
      }
    }
  }

  if (!aiKeyArt && sceneFrames.length === 0 && castPortraits.length === 0 && !locationBackdrop) {
    throw new Error('Chưa có cảnh phim hoặc ảnh diễn viên/bối cảnh nào để thiết kế Ảnh bìa!');
  }

  return {
    aiKeyArt,
    castPortraits,
    locationBackdrop,
    sceneFrames
  };
}

function buildParticlesSvg(color, count = 26) {
  const circles = [];
  for (let i = 0; i < count; i++) {
    const cx = ((i * 37 + 13) % 96) + 2;
    const cy = ((i * 53 + 29) % 86) + 8;
    const r = (i % 3 === 0 ? 3.2 : i % 2 === 0 ? 2.1 : 1.3).toFixed(1);
    const op = (0.14 + ((i * 17) % 45) / 100).toFixed(2);
    circles.push(`<circle cx="${cx}%" cy="${cy}%" r="${r}" fill="${color}" opacity="${op}" />`);
  }
  return `<svg class="particles-layer" viewBox="0 0 1000 1000" preserveAspectRatio="none">${circles.join('')}</svg>`;
}

/**
 * Tạo tài liệu HTML5/CSS3 hoàn chỉnh cho 1 phương án Poster Truyền Hình
 * @param {boolean} includeTypography true = Poster hoàn chỉnh có chữ, false = Ảnh nền nghệ thuật sạch không chữ
 */
function buildPosterHtmlDocument({
  layoutType, // 'ensemble' | 'split_drama' | 'hero_cinema'
  w,
  h,
  themeSpec,
  meta,
  assets,
  includeTypography = true
}) {
  const isPortrait = h > w;
  const upperTitle = meta.cleanTitle.toLocaleUpperCase('vi-VN');
  const maxCharsPerLine = isPortrait ? 14 : layoutType === 'hero_cinema' ? 18 : 22;
  const titleLines = wrapTitleLines(upperTitle, maxCharsPerLine);
  const longestLine = Math.max(...titleLines.map((l) => l.length), 1);

  const maxTitleHeightRatio = isPortrait ? 0.064 : layoutType === 'hero_cinema' ? 0.092 : 0.102;
  const maxWidthAvail = w * (isPortrait ? 0.86 : layoutType === 'hero_cinema' ? 0.72 : 0.86);
  const charWidthFactor = themeSpec.fontFamily.includes('Palatino') ? 0.64 : 0.68;
  const fsTitle = Math.max(
    36,
    Math.round(Math.min(h * maxTitleHeightRatio, maxWidthAvail / (longestLine * charWidthFactor)))
  );
  const fsKicker = Math.max(13, Math.round(fsTitle * 0.21));
  const fsTagline = Math.max(17, Math.round(fsTitle * 0.31));
  const fsHook = Math.max(15, Math.round(fsTitle * 0.24));
  const fsBilling = Math.max(12, Math.round(fsTitle * 0.18));

  // Chọn nguồn ảnh cho từng lớp bố cục
  const primaryFrame =
    assets.aiKeyArt ||
    assets.sceneFrames[0] ||
    assets.locationBackdrop ||
    (assets.castPortraits[0] ? { dataUrl: assets.castPortraits[0].dataUrl } : null);

  const wideBackdrop =
    assets.sceneFrames.find((f) => f.isWide) ||
    assets.locationBackdrop ||
    assets.sceneFrames[assets.sceneFrames.length - 1] ||
    primaryFrame;

  let artworkHtml = '';

  if (layoutType === 'ensemble') {
    if (assets.aiKeyArt) {
      artworkHtml = `
        <div class="full-bg" style="background-image:url('${assets.aiKeyArt.dataUrl}'); filter: contrast(1.07) saturate(1.1);"></div>
        <div class="rim-glow" style="background: radial-gradient(ellipse 65% 55% at 50% 38%, ${themeSpec.rimTint}, transparent 72%);"></div>
      `;
    } else {
      // Ghép Đa Nhân Vật Phim Bộ Truyền Hình (Double-Exposure Ensemble)
      const subjectPool =
        assets.castPortraits.length > 0
          ? assets.castPortraits.map((c) => c.dataUrl)
          : assets.sceneFrames.map((f) => f.dataUrl);

      const heroUrl = subjectPool[0] || primaryFrame.dataUrl;
      const leftCoUrl = subjectPool[1] || assets.sceneFrames[1]?.dataUrl || null;
      const rightCoUrl = subjectPool[2] || assets.sceneFrames[2]?.dataUrl || null;

      if (!leftCoUrl && !rightCoUrl && assets.castPortraits.length === 0) {
        artworkHtml = `
          <div class="full-bg" style="background-image:url('${heroUrl}'); filter: contrast(1.08) saturate(1.12);"></div>
          <div class="rim-glow" style="background: radial-gradient(ellipse 68% 54% at 50% 40%, ${themeSpec.rimTint}, transparent 72%);"></div>
        `;
      } else {
        artworkHtml = `
          <div class="full-bg" style="background-image:url('${wideBackdrop.dataUrl}'); filter: brightness(0.62) contrast(1.12) saturate(1.15) blur(1.5px); transform: scale(1.04);"></div>
          <div class="rim-glow" style="background: radial-gradient(ellipse 72% 58% at 50% 38%, ${themeSpec.rimTint}, transparent 70%);"></div>
          ${
            leftCoUrl
              ? `<div class="ens-side ens-left" style="background-image:url('${leftCoUrl}');"></div>`
              : ''
          }
          ${
            rightCoUrl
              ? `<div class="ens-side ens-right" style="background-image:url('${rightCoUrl}');"></div>`
              : ''
          }
          <div class="ens-center" style="background-image:url('${heroUrl}');"></div>
        `;
      }
    }
  } else if (layoutType === 'split_drama') {
    const panelPool = [];
    for (const f of assets.sceneFrames) panelPool.push(f.dataUrl);
    for (const c of assets.castPortraits) {
      if (panelPool.length < 3) panelPool.push(c.dataUrl);
    }
    if (assets.aiKeyArt && panelPool.length < 3) panelPool.unshift(assets.aiKeyArt.dataUrl);
    if (assets.locationBackdrop && panelPool.length < 3) panelPool.push(assets.locationBackdrop.dataUrl);

    if (panelPool.length >= 3) {
      artworkHtml = `
        <div class="triptych-wrap">
          <div class="trip-panel trip-left" style="background-image:url('${panelPool[1]}');"></div>
          <div class="trip-panel trip-right" style="background-image:url('${panelPool[2]}');"></div>
          <div class="trip-panel trip-mid" style="background-image:url('${panelPool[0]}');"></div>
          <svg class="trip-dividers" viewBox="0 0 1000 1000" preserveAspectRatio="none">
            <defs>
              <linearGradient id="divGrad" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stop-color="${themeSpec.accentColor}" stop-opacity="0.2"/>
                <stop offset="45%" stop-color="${themeSpec.accentColor}" stop-opacity="0.95"/>
                <stop offset="84%" stop-color="${themeSpec.accentColor}" stop-opacity="0"/>
              </linearGradient>
            </defs>
            <line x1="368" y1="0" x2="308" y2="880" stroke="url(#divGrad)" stroke-width="3.2" />
            <line x1="692" y1="0" x2="632" y2="880" stroke="url(#divGrad)" stroke-width="3.2" />
          </svg>
        </div>
      `;
    } else if (panelPool.length === 2) {
      artworkHtml = `
        <div class="triptych-wrap">
          <div class="duel-left" style="background-image:url('${panelPool[0]}');"></div>
          <div class="duel-right" style="background-image:url('${panelPool[1]}');"></div>
          <svg class="trip-dividers" viewBox="0 0 1000 1000" preserveAspectRatio="none">
            <line x1="538" y1="0" x2="462" y2="880" stroke="${themeSpec.accentColor}" stroke-opacity="0.85" stroke-width="3.5" />
          </svg>
        </div>
      `;
    } else {
      artworkHtml = `<div class="full-bg" style="background-image:url('${primaryFrame.dataUrl}'); filter: contrast(1.1) saturate(1.14);"></div>`;
    }
  } else {
    // hero_cinema: Khung hình đắt giá đặc tả kiểu Netflix / HBO Prestige
    const heroScene = assets.aiKeyArt || assets.sceneFrames[1] || assets.sceneFrames[0] || null;
    if (heroScene) {
      artworkHtml = `
        <div class="full-bg" style="background-image:url('${heroScene.dataUrl}'); filter: contrast(1.09) saturate(1.12);"></div>
        <div class="left-cinema-shade"></div>
      `;
    } else {
      const bgUrl = (assets.locationBackdrop || primaryFrame).dataUrl;
      const rightActorUrl = assets.castPortraits[0]?.dataUrl || null;
      artworkHtml = `
        <div class="full-bg" style="background-image:url('${bgUrl}'); filter: brightness(0.75) contrast(1.1) saturate(1.12);"></div>
        ${
          rightActorUrl && !isPortrait
            ? `<div class="hero-right-portrait" style="background-image:url('${rightActorUrl}');"></div>`
            : rightActorUrl
            ? `<div class="ens-center" style="background-image:url('${rightActorUrl}');"></div>`
            : ''
        }
        <div class="left-cinema-shade"></div>
      `;
    }
  }

  const titleHtmlLines = titleLines.map((ln) => `<span>${escapeHtml(ln)}</span>`).join('');
  const isLeftHero = layoutType === 'hero_cinema' && !isPortrait;
  const billingItems = [...meta.castNames];
  const billingHtml =
    billingItems.length > 0
      ? `<div class="billing-row"><span class="billing-prefix">DIỄN VIÊN CHÍNH</span> ${billingItems
          .map((n) => `<strong>${escapeHtml(n)}</strong>`)
          .join('<span class="dot">•</span>')}</div>`
      : `<div class="billing-row"><span class="billing-prefix">SẢN XUẤT HÌNH ẢNH</span> <strong>MUSE CINEMA STUDIO</strong> <span class="dot">•</span> <strong>${escapeHtml(
          meta.badgeRight
        )}</strong></div>`;

  return `<!DOCTYPE html>
<html lang="vi">
<head>
<meta charset="UTF-8" />
<style>
  * { box-sizing: border-box; margin: 0; padding: 0; }
  html, body {
    width: ${w}px;
    height: ${h}px;
    overflow: hidden;
    background: #05070e;
    font-family: 'Segoe UI', Tahoma, sans-serif;
    -webkit-font-smoothing: antialiased;
  }
  .poster-stage {
    position: relative;
    width: ${w}px;
    height: ${h}px;
    overflow: hidden;
    background: #05070e;
  }
  .full-bg {
    position: absolute;
    inset: 0;
    background-size: cover;
    background-position: center 24%;
  }
  .rim-glow {
    position: absolute;
    inset: 0;
    mix-blend-mode: screen;
    pointer-events: none;
  }

  /* Double-exposure Multi-character Ensemble */
  .ens-side {
    position: absolute;
    top: ${isPortrait ? '6%' : '2%'};
    width: ${isPortrait ? '62%' : '46%'};
    height: ${isPortrait ? '56%' : '78%'};
    background-size: cover;
    background-position: center 18%;
    opacity: 0.88;
    filter: contrast(1.06) saturate(1.06);
    -webkit-mask-image: radial-gradient(closest-side at 50% 45%, rgba(0,0,0,0.95) 32%, rgba(0,0,0,0.48) 68%, transparent 98%);
    mask-image: radial-gradient(closest-side at 50% 45%, rgba(0,0,0,0.95) 32%, rgba(0,0,0,0.48) 68%, transparent 98%);
  }
  .ens-left { left: ${isPortrait ? '-8%' : '0%'}; }
  .ens-right { right: ${isPortrait ? '-8%' : '0%'}; }
  .ens-center {
    position: absolute;
    top: ${isPortrait ? '2%' : '0%'};
    left: 50%;
    transform: translateX(-50%);
    width: ${isPortrait ? '86%' : '58%'};
    height: ${isPortrait ? '66%' : '86%'};
    background-size: cover;
    background-position: center 16%;
    filter: contrast(1.08) saturate(1.1);
    -webkit-mask-image: radial-gradient(closest-side at 50% 44%, #000 44%, rgba(0,0,0,0.62) 74%, transparent 99%);
    mask-image: radial-gradient(closest-side at 50% 44%, #000 44%, rgba(0,0,0,0.62) 74%, transparent 99%);
  }
  .hero-right-portrait {
    position: absolute;
    top: 0%;
    right: 2%;
    width: 54%;
    height: 92%;
    background-size: cover;
    background-position: center 16%;
    filter: contrast(1.08) saturate(1.1);
    -webkit-mask-image: radial-gradient(closest-side at 54% 44%, #000 46%, rgba(0,0,0,0.62) 76%, transparent 99%);
    mask-image: radial-gradient(closest-side at 54% 44%, #000 46%, rgba(0,0,0,0.62) 76%, transparent 99%);
  }

  /* 3-Panel Diagonal Split Drama */
  .triptych-wrap { position: absolute; inset: 0; }
  .trip-panel {
    position: absolute;
    top: 0;
    height: 100%;
    background-size: cover;
    background-position: center 18%;
    filter: contrast(1.08) saturate(1.12);
  }
  .trip-left {
    left: 0;
    width: 37.5%;
    clip-path: polygon(0 0, 100% 0, 82% 100%, 0 100%);
  }
  .trip-mid {
    left: 30.2%;
    width: 39.6%;
    clip-path: polygon(16.8% 0, 100% 0, 83.2% 100%, 0 100%);
    filter: contrast(1.12) saturate(1.15) brightness(1.04);
  }
  .trip-right {
    right: 0;
    width: 37.5%;
    clip-path: polygon(18% 0, 100% 0, 100% 100%, 0 100%);
  }
  .duel-left {
    position: absolute; top: 0; left: 0; width: 54.5%; height: 100%;
    background-size: cover; background-position: center 18%;
    clip-path: polygon(0 0, 100% 0, 84.5% 100%, 0 100%);
  }
  .duel-right {
    position: absolute; top: 0; right: 0; width: 54.5%; height: 100%;
    background-size: cover; background-position: center 18%;
    clip-path: polygon(15.5% 0, 100% 0, 100% 100%, 0 100%);
  }
  .trip-dividers {
    position: absolute; inset: 0; width: 100%; height: 100%; pointer-events: none;
  }

  .top-atmo {
    position: absolute; inset: 0;
    background: ${themeSpec.topAtmosphere};
    pointer-events: none;
  }
  .edge-vignette {
    position: absolute; inset: 0;
    background: radial-gradient(ellipse 92% 88% at 50% 42%, transparent 48%, rgba(3, 5, 12, 0.68) 100%);
    pointer-events: none;
  }
  .bottom-shade {
    position: absolute; inset: 0;
    background: ${themeSpec.bottomShade};
    pointer-events: none;
  }
  .left-cinema-shade {
    position: absolute; inset: 0;
    background: ${
      isLeftHero
        ? 'linear-gradient(90deg, rgba(4, 6, 14, 0.92) 0%, rgba(5, 8, 18, 0.72) 38%, rgba(5, 8, 18, 0.18) 68%, transparent 100%)'
        : 'transparent'
    };
    pointer-events: none;
  }
  .particles-layer {
    position: absolute; inset: 0; width: 100%; height: 100%;
    mix-blend-mode: screen; pointer-events: none;
  }
  .lens-flare {
    position: absolute;
    left: ${isLeftHero ? '4%' : '15%'};
    right: ${isLeftHero ? '38%' : '15%'};
    bottom: ${isPortrait ? '25%' : '26%'};
    height: 3px;
    background: linear-gradient(90deg, transparent 0%, ${themeSpec.flareColor} 32%, #FFFFFF 50%, ${themeSpec.flareColor} 68%, transparent 100%);
    box-shadow: 0 0 22px 4px ${themeSpec.flareColor};
    opacity: 0.72;
    pointer-events: none;
  }
  .inner-frame {
    position: absolute;
    inset: ${Math.round(Math.min(w, h) * 0.022)}px;
    border: 1px solid rgba(255, 255, 255, 0.13);
    border-radius: 4px;
    pointer-events: none;
  }

  /* Top Broadcast Badges */
  .top-bar {
    position: absolute;
    top: ${Math.round(h * 0.042)}px;
    left: ${Math.round(w * 0.042)}px;
    right: ${Math.round(w * 0.042)}px;
    display: flex;
    align-items: center;
    justify-content: space-between;
    z-index: 10;
  }
  .badge-main {
    display: inline-flex;
    align-items: center;
    gap: 10px;
    padding: ${Math.max(7, Math.round(h * 0.009))}px ${Math.max(16, Math.round(w * 0.014))}px;
    background: ${themeSpec.badgeBg};
    border: 1px solid ${themeSpec.badgeBorder};
    border-radius: 5px;
    color: #FFFFFF;
    font-size: ${Math.max(13, Math.round(fsKicker * 0.88))}px;
    font-weight: 800;
    letter-spacing: 0.14em;
    box-shadow: 0 8px 26px rgba(0, 0, 0, 0.65);
  }
  .badge-dot {
    width: 8px; height: 8px; border-radius: 50%;
    background: #FFFFFF;
    box-shadow: 0 0 10px #FFFFFF;
  }
  .badge-spec {
    padding: 6px 14px;
    background: rgba(9, 13, 24, 0.68);
    border: 1px solid rgba(255, 255, 255, 0.24);
    backdrop-filter: blur(8px);
    border-radius: 4px;
    color: rgba(248, 250, 252, 0.92);
    font-size: ${Math.max(11, Math.round(fsKicker * 0.76))}px;
    font-weight: 700;
    letter-spacing: 0.16em;
  }

  /* Main Typography Block */
  .typo-zone {
    position: absolute;
    left: ${Math.round(w * 0.048)}px;
    right: ${Math.round(w * 0.048)}px;
    bottom: ${Math.round(h * (isPortrait ? 0.048 : 0.046))}px;
    display: flex;
    flex-direction: column;
    align-items: ${isLeftHero ? 'flex-start' : 'center'};
    text-align: ${isLeftHero ? 'left' : 'center'};
    z-index: 12;
  }
  .kicker-line {
    display: inline-flex;
    align-items: center;
    gap: 14px;
    color: rgba(248, 250, 252, 0.9);
    font-size: ${fsKicker}px;
    font-weight: 700;
    letter-spacing: 0.28em;
    text-transform: uppercase;
    text-shadow: 0 2px 12px rgba(0, 0, 0, 0.95);
    margin-bottom: ${Math.round(fsTitle * 0.06)}px;
  }
  .kicker-rule {
    width: ${Math.round(w * 0.045)}px;
    height: 1.5px;
    background: linear-gradient(90deg, transparent, ${themeSpec.accentColor});
  }
  .kicker-rule.right {
    background: linear-gradient(90deg, ${themeSpec.accentColor}, transparent);
  }

  .hero-accent-wrap {
    display: inline-block;
    ${isLeftHero ? `border-left: 7px solid ${themeSpec.accentColor}; padding-left: ${Math.round(w * 0.015)}px;` : ''}
  }
  .title-stack {
    position: relative;
    display: inline-block;
  }
  .title-layer {
    font-family: ${themeSpec.fontFamily};
    font-weight: ${themeSpec.fontWeight};
    font-size: ${fsTitle}px;
    line-height: 1.19;
    letter-spacing: ${themeSpec.letterSpacing};
    padding: 0.14em 0.1em 0.1em;
    display: flex;
    flex-direction: column;
    align-items: ${isLeftHero ? 'flex-start' : 'center'};
  }
  .title-shadow {
    position: absolute;
    inset: 0;
    color: transparent;
    text-shadow:
      0 4px 10px rgba(0, 0, 0, 0.96),
      0 12px 32px rgba(0, 0, 0, 0.92),
      0 0 42px ${themeSpec.glowColor};
    pointer-events: none;
    user-select: none;
  }
  .title-grad span {
    display: block;
    padding: 0 0.06em;
    background: ${themeSpec.titleGradient};
    -webkit-background-clip: text;
    background-clip: text;
    -webkit-text-fill-color: transparent;
    filter: drop-shadow(0 2px 3px rgba(0, 0, 0, 0.82));
  }

  .tagline-pill {
    margin-top: ${Math.round(fsTitle * 0.08)}px;
    padding: ${Math.max(5, Math.round(fsTagline * 0.24))}px ${Math.max(18, Math.round(fsTagline * 0.85))}px;
    background: linear-gradient(90deg, rgba(15, 23, 42, 0.35), rgba(15, 23, 42, 0.82), rgba(15, 23, 42, 0.35));
    border-top: 1px solid ${themeSpec.accentSoft};
    border-bottom: 1px solid ${themeSpec.accentSoft};
    color: ${themeSpec.accentColor};
    font-size: ${fsTagline}px;
    font-weight: 800;
    letter-spacing: 0.09em;
    text-transform: uppercase;
    text-shadow: 0 2px 12px rgba(0, 0, 0, 0.95);
  }

  .hook-quote {
    margin-top: ${Math.round(fsTitle * 0.12)}px;
    max-width: ${Math.round(w * (isLeftHero ? 0.66 : 0.78))}px;
    color: rgba(241, 245, 249, 0.93);
    font-family: 'Palatino Linotype', Georgia, serif;
    font-style: italic;
    font-size: ${fsHook}px;
    line-height: 1.42;
    text-shadow: 0 2px 14px rgba(0, 0, 0, 0.98);
  }

  .billing-row {
    margin-top: ${Math.round(fsTitle * 0.18)}px;
    padding-top: ${Math.round(fsTitle * 0.11)}px;
    border-top: 1px solid rgba(255, 255, 255, 0.16);
    width: 100%;
    display: flex;
    align-items: center;
    justify-content: ${isLeftHero ? 'flex-start' : 'center'};
    flex-wrap: wrap;
    gap: 10px;
    color: rgba(203, 213, 225, 0.86);
    font-size: ${fsBilling}px;
    letter-spacing: 0.2em;
    text-transform: uppercase;
  }
  .billing-prefix {
    color: rgba(148, 163, 184, 0.82);
    font-weight: 600;
    margin-right: 4px;
  }
  .billing-row strong {
    color: #F8FAFC;
    font-weight: 800;
  }
  .billing-row .dot {
    color: ${themeSpec.accentColor};
  }
</style>
</head>
<body>
  <div class="poster-stage">
    ${artworkHtml}
    <div class="top-atmo"></div>
    <div class="edge-vignette"></div>
    ${includeTypography ? `<div class="bottom-shade"></div>` : ''}
    ${buildParticlesSvg(themeSpec.particleColor, 28)}
    ${
      includeTypography
        ? `
      <div class="inner-frame"></div>
      ${!isLeftHero ? '<div class="lens-flare"></div>' : ''}
      <div class="top-bar">
        ${
          meta.badgeLeft
            ? `<div class="badge-main"><span class="badge-dot"></span><span>${escapeHtml(meta.badgeLeft)}</span></div>`
            : '<div></div>'
        }
        <div class="badge-spec">${escapeHtml(meta.badgeRight)}</div>
      </div>

      <div class="typo-zone">
        <div class="kicker-line">
          ${!isLeftHero ? '<span class="kicker-rule"></span>' : ''}
          <span>${escapeHtml(themeSpec.kickerDefault)}</span>
          ${!isLeftHero ? '<span class="kicker-rule right"></span>' : ''}
        </div>

        <div class="hero-accent-wrap">
          <div class="title-stack">
            <div class="title-layer title-shadow" aria-hidden="true">${titleHtmlLines}</div>
            <div class="title-layer title-grad">${titleHtmlLines}</div>
          </div>
        </div>

        ${meta.tagline ? `<div class="tagline-pill">${escapeHtml(meta.tagline)}</div>` : ''}
        ${
          meta.hookQuote
            ? `<div class="hook-quote">“${escapeHtml(meta.hookQuote)}”</div>`
            : ''
        }
        ${billingHtml}
      </div>
    `
        : ''
    }
  </div>
</body>
</html>`;
}

/**
 * Render đồng loạt cả 3 Phương Án Poster Truyền Hình (kèm ảnh nền sạch không chữ) bằng Chromium Headless
 */
async function renderPosterPackWithChromium({
  browserExe,
  w,
  h,
  themeSpec,
  meta,
  assets,
  orderedLayouts,
  promoDir,
  baseName,
  report
}) {
  let browser = null;
  try {
    browser = await chromium.launch({
      executablePath: browserExe,
      headless: true,
      args: ['--no-sandbox', '--disable-gpu', '--hide-scrollbars', '--font-render-hinting=none']
    });
    const context = await browser.newContext({
      viewport: { width: w, height: h },
      deviceScaleFactor: 1
    });
    const page = await context.newPage();

    const layoutLabels = {
      ensemble: '👥 Mẫu Đa Nhân Vật Truyền Hình',
      split_drama: '🎬 Mẫu Đa Khung Cao Trào',
      hero_cinema: '🎞️ Mẫu Điện Ảnh Đặc Tả'
    };

    const variants = [];
    for (let i = 0; i < orderedLayouts.length; i++) {
      const layoutType = orderedLayouts[i];
      report(`🎨 Đang thiết kế đồ họa ${layoutLabels[layoutType] || `Mẫu ${i + 1}`} (${i + 1}/${orderedLayouts.length})...`);

      const cleanFileName = `${baseName}_bia_goc_v${i + 1}.jpg`;
      const cleanFilePath = path.join(promoDir, cleanFileName);
      const cleanHtml = buildPosterHtmlDocument({
        layoutType,
        w,
        h,
        themeSpec,
        meta,
        assets,
        includeTypography: false
      });
      await page.setContent(cleanHtml, { waitUntil: 'load', timeout: 15000 });
      await page.screenshot({ path: cleanFilePath, type: 'jpeg', quality: 94 });

      const posterFileName = i === 0 ? `${baseName}_anh_bia.jpg` : `${baseName}_anh_bia_v${i + 1}.jpg`;
      const posterFilePath = path.join(promoDir, posterFileName);
      const posterHtml = buildPosterHtmlDocument({
        layoutType,
        w,
        h,
        themeSpec,
        meta,
        assets,
        includeTypography: true
      });
      await page.setContent(posterHtml, { waitUntil: 'load', timeout: 15000 });
      await page.screenshot({ path: posterFilePath, type: 'jpeg', quality: 95 });

      variants.push({
        id: layoutType,
        label: layoutLabels[layoutType] || `Phương án ${i + 1}`,
        posterFileName,
        posterFilePath,
        cleanFileName,
        cleanFilePath
      });
    }

    return variants;
  } finally {
    if (browser) {
      await browser.close().catch(() => {});
    }
  }
}

/** Dự phòng FFmpeg trong trường hợp máy khách hoàn toàn chưa cài Chrome/Edge */
function prepareFontFallback(tempDir) {
  for (const f of FONT_CANDIDATES) {
    try {
      if (fs.existsSync(f)) {
        fs.copyFileSync(f, path.join(tempDir, 'font.ttf'));
        return 'font.ttf';
      }
    } catch (_) {}
  }
  return null;
}

async function renderFallbackFfmpegPoster({ ffmpegBin, tempDir, promoDir, baseName, w, h, meta, assets }) {
  const srcPath =
    assets.aiKeyArt?.filePath ||
    assets.sceneFrames[0]?.filePath ||
    assets.locationBackdrop?.filePath ||
    assets.castPortraits[0]?.filePath;
  const cleanFileName = `${baseName}_bia_goc_v1.jpg`;
  const cleanFilePath = path.join(promoDir, cleanFileName);
  await runFfmpeg(ffmpegBin, [
    '-y', '-i', srcPath,
    '-vf', `scale=${w}:${h}:force_original_aspect_ratio=increase:flags=lanczos,crop=${w}:${h}`,
    '-frames:v', '1', '-q:v', '2', cleanFilePath
  ]);

  const posterFileName = `${baseName}_anh_bia.jpg`;
  const posterFilePath = path.join(promoDir, posterFileName);
  const fontFile = prepareFontFallback(tempDir);
  if (fontFile) {
    const lines = wrapTitleLines(meta.cleanTitle.toLocaleUpperCase('vi-VN'), h > w ? 14 : 22);
    fs.writeFileSync(path.join(tempDir, 'fb_title.txt'), lines.join('\n'), 'utf8');
    const fsTitle = Math.round(h * (h > w ? 0.062 : 0.095));
    const vf = [
      `vignette=PI/4`,
      `drawtext=fontfile=${fontFile}:textfile=fb_title.txt:expansion=none:fontcolor=0xFFF3C4:fontsize=${fsTitle}:borderw=3:bordercolor=black@0.85:shadowcolor=black@0.85:shadowx=3:shadowy=5:x=(w-text_w)/2:y=h-text_h-${Math.round(
        h * 0.12
      )}`
    ].join(',');
    await runFfmpeg(ffmpegBin, ['-y', '-i', cleanFilePath, '-vf', vf, '-frames:v', '1', '-q:v', '2', posterFilePath], {
      cwd: tempDir
    });
  } else {
    fs.copyFileSync(cleanFilePath, posterFilePath);
  }
  return [
    {
      id: 'hero_cinema',
      label: '🎞️ Mẫu Điện Ảnh',
      posterFileName,
      posterFilePath,
      cleanFileName,
      cleanFilePath
    }
  ];
}

/* ================= ẢNH BÌA POSTER TRUYỀN HÌNH (BỘ 3 PHƯƠNG ÁN) ================= */

async function buildThumbnailPack({
  appRootDir,
  acc,
  eligible,
  tempDir,
  promoDir,
  baseName,
  title,
  tagline,
  badgeText,
  posterTheme,
  posterSourceMode,
  aiKeyArtPath,
  colorGrade,
  report
}) {
  const ffmpegBin = getFfmpegExecutable(appRootDir);
  const { w, h } = resolvePromoSize(acc, 'thumbnail');
  const meta = extractBroadcastPosterMeta(acc, title, tagline, badgeText);
  const effectiveThemeId = resolveEffectivePosterTheme(posterTheme, meta.genreId);
  const themeSpec = getThemeVisualSpec(effectiveThemeId, meta.genreId);

  const assets = await collectPosterVisualAssets({
    ffmpegBin,
    acc,
    eligible,
    tempDir,
    w,
    h,
    colorGrade,
    aiKeyArtPath,
    report
  });

  let orderedLayouts = ['ensemble', 'split_drama', 'hero_cinema'];
  if (posterSourceMode === 'split_only') {
    orderedLayouts = ['split_drama', 'ensemble', 'hero_cinema'];
  } else if (posterSourceMode === 'ai_keyart') {
    orderedLayouts = ['ensemble', 'hero_cinema', 'split_drama'];
  }

  const browserExe = findBrowserForPoster();
  let variants = null;
  if (browserExe) {
    try {
      variants = await renderPosterPackWithChromium({
        browserExe,
        w,
        h,
        themeSpec,
        meta,
        assets,
        orderedLayouts,
        promoDir,
        baseName,
        report
      });
    } catch (_) {
      variants = null;
    }
  }
  if (!variants || variants.length === 0) {
    variants = await renderFallbackFfmpegPoster({
      ffmpegBin,
      tempDir,
      promoDir,
      baseName,
      w,
      h,
      meta,
      assets
    });
  }

  const primary = variants[0];
  const sourceLabel = assets.aiKeyArt
    ? 'AI Key Art Đa Nhân Vật'
    : assets.castPortraits.length >= 2
    ? `Ghép ${assets.castPortraits.length} diễn viên + bối cảnh`
    : assets.sceneFrames[0]
    ? `Cảnh ${assets.sceneFrames[0].sceneIndex}`
    : 'Bối cảnh phim';

  return {
    primary,
    variants,
    sourceLabel,
    themeId: effectiveThemeId,
    width: w,
    height: h
  };
}

/* ================= TRAILER GIỚI THIỆU PHIM ================= */

async function buildTrailer({
  appRootDir,
  acc,
  eligible,
  tempDir,
  promoDir,
  baseName,
  title,
  tagline,
  badgeText,
  posterTheme,
  posterCardPath,
  colorGrade,
  trailerSeconds,
  report
}) {
  const ffmpegBin = getFfmpegExecutable(appRootDir);
  const { w, h } = resolvePromoSize(acc, 'video');
  const target = Math.max(10, Math.min(90, Number(trailerSeconds) || 30));
  const endCardSec = 3.2;
  const transSec = 0.35;

  const scored = eligible.map((x, i) => ({
    ...x,
    score: scoreSceneForTrailer(x.row, i === eligible.length - 1 && eligible.length > 2)
  }));
  const k = Math.max(1, Math.min(scored.length, 12, Math.max(3, Math.round((target - endCardSec) / 3))));
  const picks = [];
  for (let b = 0; b < k; b++) {
    const from = Math.floor((b * scored.length) / k);
    const to = Math.max(from + 1, Math.floor(((b + 1) * scored.length) / k));
    const bucket = scored.slice(from, to);
    picks.push(bucket.reduce((a, c) => (c.score > a.score ? c : a)));
  }

  const segLenTarget = Math.max(1.6, Math.min(5, (target - endCardSec + k * transSec) / k));

  const segPlans = [];
  for (const p of picks) {
    const info = await probeMediaFile(ffmpegBin, p.filePath);
    const dur = Math.max(1, info.duration || 5);
    const trimStart = Math.max(0, Number(p.row.trimStartSec) || 0);
    const trimEnd = Math.max(0, Number(p.row.trimEndSec) || 0);
    const usableStart = Math.min(trimStart, Math.max(0, dur - 1.2));
    const usableEnd = Math.max(usableStart + 1, dur - trimEnd);
    const usable = usableEnd - usableStart;
    const segLen = Math.max(1.2, Math.min(segLenTarget, usable - 0.1));
    const start = Math.max(usableStart + 0.1, Math.min(usableEnd - segLen - 0.05, usableStart + usable * 0.4 - segLen / 2));
    segPlans.push({ ...p, start, segLen, hasAudio: info.hasAudio });
  }
  const gradeFilters = await computeColorGradeFiltersForClips(
    ffmpegBin,
    segPlans.map((s) => ({ filePath: s.filePath, startSec: s.start, durSec: s.segLen, label: s.row.index })),
    colorGrade,
    report
  );

  const segFiles = [];
  for (let i = 0; i < segPlans.length; i++) {
    const s = segPlans[i];
    report(`🎞️ Đang cắt khoảnh khắc nổi bật ${i + 1}/${segPlans.length} (Cảnh ${s.row.index})...`);
    const out = path.join(tempDir, `seg_${String(i).padStart(2, '0')}.mp4`);
    const baseV = `scale=${w}:${h}:force_original_aspect_ratio=increase:flags=lanczos,crop=${w}:${h},setsar=1,fps=30,format=yuv420p`;
    const vf = gradeFilters[i] ? `${baseV},${gradeFilters[i]}` : baseV;
    const common = [
      '-c:v', 'libx264', '-preset', 'fast', '-crf', '17', '-pix_fmt', 'yuv420p',
      '-c:a', 'aac', '-b:a', '192k', '-ar', '44100', '-ac', '2'
    ];
    if (s.hasAudio) {
      await runFfmpeg(ffmpegBin, [
        '-y', '-ss', s.start.toFixed(3), '-t', s.segLen.toFixed(3), '-i', s.filePath,
        '-vf', vf, '-af', 'aresample=44100,aformat=sample_fmts=fltp:channel_layouts=stereo',
        ...common, out
      ]);
    } else {
      await runFfmpeg(ffmpegBin, [
        '-y', '-ss', s.start.toFixed(3), '-t', s.segLen.toFixed(3), '-i', s.filePath,
        '-f', 'lavfi', '-t', s.segLen.toFixed(3), '-i', 'anullsrc=channel_layout=stereo:sample_rate=44100',
        '-map', '0:v:0', '-map', '1:a:0', '-vf', vf, ...common, '-shortest', out
      ]);
    }
    if (fs.existsSync(out) && fs.statSync(out).size > 5000) segFiles.push(out);
  }
  if (segFiles.length === 0) throw new Error('Không cắt được đoạn nào cho trailer.');

  // Khung kết thúc Trailer đồng bộ Poster Truyền Hình (Slow Zoom Push-In sang trọng)
  report('🎬 Đang dựng khung Poster kết thúc Trailer chuẩn truyền hình...');
  const endCard = path.join(tempDir, 'end_card.mp4');
  let cardImgForEnd = posterCardPath && fs.existsSync(posterCardPath) ? posterCardPath : null;
  if (!cardImgForEnd) {
    try {
      const quickPack = await buildThumbnailPack({
        appRootDir,
        acc,
        eligible,
        tempDir,
        promoDir: tempDir,
        baseName: 'endcard_tmp',
        title,
        tagline,
        badgeText,
        posterTheme,
        posterSourceMode: 'smart_pack',
        aiKeyArtPath: null,
        colorGrade,
        report: () => {}
      });
      cardImgForEnd = quickPack.primary?.posterFilePath || null;
    } catch (_) {}
  }

  if (cardImgForEnd && fs.existsSync(cardImgForEnd)) {
    const framesTotal = Math.round(endCardSec * 30);
    try {
      await runFfmpeg(ffmpegBin, [
        '-y',
        '-loop', '1', '-t', String(endCardSec), '-i', cardImgForEnd,
        '-f', 'lavfi', '-t', String(endCardSec), '-i', 'anullsrc=channel_layout=stereo:sample_rate=44100',
        '-map', '0:v:0', '-map', '1:a:0',
        '-vf', `scale=${Math.round(w * 1.12)}:${Math.round(h * 1.12)}:force_original_aspect_ratio=increase:flags=lanczos,crop=${Math.round(w * 1.12)}:${Math.round(h * 1.12)},zoompan=z='min(zoom+0.0012,1.08)':x='iw/2-(iw/zoom/2)':y='ih/2-(ih/zoom/2)':d=${framesTotal}:s=${w}x${h}:fps=30,setsar=1,format=yuv420p`,
        '-c:v', 'libx264', '-preset', 'fast', '-crf', '17', '-pix_fmt', 'yuv420p',
        '-c:a', 'aac', '-b:a', '192k', '-ar', '44100', '-ac', '2', '-shortest',
        endCard
      ]);
      if (fs.existsSync(endCard) && fs.statSync(endCard).size > 5000) segFiles.push(endCard);
    } catch (_) {}
  }

  report('🎞️ Đang nối các khoảnh khắc thành Trailer...');
  const stitched = path.join(tempDir, 'trailer_stitched.mp4');
  try {
    await mergeNormalizedSegmentsWithTransition(ffmpegBin, segFiles, stitched, 'fadeblack', transSec);
  } catch (_) {
    const listPath = path.join(tempDir, 'concat.txt');
    fs.writeFileSync(listPath, segFiles.map((p) => `file '${p.replace(/\\/g, '/').replace(/'/g, "'\\''")}'`).join('\n'), 'utf8');
    await runFfmpeg(ffmpegBin, ['-y', '-f', 'concat', '-safe', '0', '-i', listPath, '-c', 'copy', stitched]);
  }

  const stitchedInfo = await probeMediaFile(ffmpegBin, stitched);
  const total = Math.max(2, stitchedInfo.duration || target);
  const fadeOutSt = Math.max(0, total - 1.2).toFixed(3);
  const vFade = `fade=t=in:st=0:d=0.5,fade=t=out:st=${Math.max(0, total - 0.8).toFixed(3)}:d=0.8`;
  const bgm = acc.settings?.bgmAudio?.filePath && fs.existsSync(acc.settings.bgmAudio.filePath) ? acc.settings.bgmAudio.filePath : null;
  const trailerName = `${baseName}_trailer_${Math.round(total)}s.mp4`;
  const trailerPath = path.join(promoDir, trailerName);
  const encode = ['-c:v', 'libx264', '-preset', 'fast', '-crf', '17', '-pix_fmt', 'yuv420p', '-c:a', 'aac', '-b:a', '192k', '-ar', '44100', '-ac', '2', '-movflags', '+faststart'];

  report(bgm ? '🎵 Đang lồng nhạc nền Trailer...' : '🎵 Đang hoàn thiện âm thanh Trailer...');
  if (bgm) {
    await runFfmpeg(ffmpegBin, [
      '-y', '-i', stitched, '-stream_loop', '-1', '-i', bgm,
      '-filter_complex',
      `[0:v]${vFade}[vout];[0:a]volume=0.65[vo];[1:a]aresample=44100,aformat=sample_fmts=fltp:channel_layouts=stereo,volume=0.85,afade=t=in:st=0:d=1[bg];[vo][bg]amix=inputs=2:duration=first:dropout_transition=0:normalize=0,afade=t=out:st=${fadeOutSt}:d=1.2[aout]`,
      '-map', '[vout]', '-map', '[aout]', ...encode, '-shortest', trailerPath
    ]);
  } else {
    await runFfmpeg(ffmpegBin, [
      '-y', '-i', stitched, '-vf', vFade, '-af', `afade=t=in:st=0:d=0.3,afade=t=out:st=${fadeOutSt}:d=1.2`, ...encode, trailerPath
    ]);
  }

  const finalInfo = await probeMediaFile(ffmpegBin, trailerPath);
  return {
    trailerName,
    trailerPath,
    duration: Number((finalInfo.duration || total).toFixed(2)),
    sceneIndices: segPlans.map((s) => s.row.index),
    width: w,
    height: h
  };
}

/* ================= HÀM CHÍNH ================= */

async function renderPromoPack({
  appRootDir,
  accountManager,
  cdpEngine = null,
  accountId,
  movieTitle = '',
  tagline = '',
  badgeText = 'TRAILER CHÍNH THỨC',
  posterTheme = 'auto',
  posterSourceMode = 'smart_pack',
  trailerSeconds = 30,
  colorGrade = null,
  makeThumbnail = true,
  makeTrailer = true,
  onProgress = null
}) {
  const report = (msg) => {
    if (typeof onProgress === 'function') {
      try {
        onProgress(msg);
      } catch (_) {}
    }
  };
  const acc = accountManager.getAccount(accountId);
  if (!acc) throw new Error('Không tìm thấy dự án phim.');
  const eligible = collectEligibleRows(appRootDir, acc);

  if (makeTrailer && eligible.length === 0) {
    throw new Error('Chưa có phân cảnh nào quay xong video để cắt dựng Trailer! (Bạn có thể bấm "🖼️ Chỉ Tạo Ảnh Bìa" nếu đã có ảnh Diễn viên / Bối cảnh).');
  }

  const title = String(movieTitle || acc.settings?.exportMovieTitle || acc.name || 'Bộ Phim AI').trim().slice(0, 85);
  const grade = colorGrade || acc.settings?.colorGrade || 'auto_match';
  const safeBase =
    title
      .normalize('NFD')
      .replace(/[\u0300-\u036f]/g, '')
      .replace(/đ/g, 'd')
      .replace(/Đ/g, 'D')
      .replace(/[^a-zA-Z0-9_-]+/g, '_')
      .replace(/^_+|_+$/g, '')
      .slice(0, 45) || 'MuseCinema';
  const baseName = `${safeBase}_${Date.now()}`;

  const outAccountDir = accountManager.ensureAccountOutputDir(accountId, { create: true });
  const promoDir = path.join(outAccountDir, 'Master_Movies', 'Promo');
  const tempDir = path.join(appRootDir, 'Project_Data', 'temp_editor', `promo_${Date.now()}`);
  [promoDir, tempDir].forEach((d) => fs.mkdirSync(d, { recursive: true }));

  try {
    const prevPromo = acc.settings?.lastPromoExport || {};
    const result = {
      ...(makeTrailer ? {} : {
        trailerFileName: prevPromo.trailerFileName,
        trailerFilePath: prevPromo.trailerFilePath,
        trailerUrl: prevPromo.trailerUrl,
        trailerDuration: prevPromo.trailerDuration,
        trailerSceneIndices: prevPromo.trailerSceneIndices,
        trailerSize: prevPromo.trailerSize
      }),
      title,
      tagline: String(tagline || '').trim(),
      badgeText,
      posterTheme,
      posterSourceMode,
      createdAt: new Date().toISOString()
    };

    let aiKeyArtPath = null;
    if (makeThumbnail && posterSourceMode === 'ai_keyart') {
      if (!cdpEngine || typeof cdpEngine.generateMoviePosterKeyArtWithAi !== 'function') {
        throw new Error('Không tìm thấy kết nối AI Muse.ai để vẽ Poster Key Art.');
      }
      const keyRes = await cdpEngine.generateMoviePosterKeyArtWithAi({
        accountId,
        aspectRatio: acc.settings?.filmConfig?.aspectRatio || '16:9',
        onProgress: report
      });
      aiKeyArtPath = keyRes.filePath;
    }

    let primaryPosterDiskPath = null;
    if (makeThumbnail) {
      const th = await buildThumbnailPack({
        appRootDir,
        acc,
        eligible,
        tempDir,
        promoDir,
        baseName,
        title,
        tagline: result.tagline,
        badgeText,
        posterTheme,
        posterSourceMode,
        aiKeyArtPath,
        colorGrade: grade,
        report
      });
      primaryPosterDiskPath = th.primary.posterFilePath;

      const mappedVariants = th.variants.map((v, idx) => ({
        index: idx + 1,
        id: v.id,
        label: v.label,
        thumbnailFileName: v.posterFileName,
        thumbnailUrl: accountManager.buildAccountOutputPublicUrl(accountId, 'Master_Movies', 'Promo', v.posterFileName),
        thumbnailCleanFileName: v.cleanFileName,
        thumbnailCleanUrl: accountManager.buildAccountOutputPublicUrl(accountId, 'Master_Movies', 'Promo', v.cleanFileName)
      }));

      Object.assign(result, {
        thumbnailFileName: th.primary.posterFileName,
        thumbnailFilePath: th.primary.posterFilePath,
        thumbnailUrl: mappedVariants[0].thumbnailUrl,
        thumbnailCleanFilePath: th.primary.cleanFilePath,
        thumbnailCleanUrl: mappedVariants[0].thumbnailCleanUrl,
        thumbnailSourceScene: th.sourceLabel,
        thumbnailThemeId: th.themeId,
        thumbnailSize: `${th.width}x${th.height}`,
        thumbnailVariants: mappedVariants
      });
    }

    if (makeTrailer) {
      const tr = await buildTrailer({
        appRootDir,
        acc,
        eligible,
        tempDir,
        promoDir,
        baseName,
        title,
        tagline: result.tagline,
        badgeText,
        posterTheme,
        posterCardPath: primaryPosterDiskPath || prevPromo.thumbnailFilePath || null,
        colorGrade: grade,
        trailerSeconds,
        report
      });
      Object.assign(result, {
        trailerFileName: tr.trailerName,
        trailerFilePath: tr.trailerPath,
        trailerUrl: accountManager.buildAccountOutputPublicUrl(accountId, 'Master_Movies', 'Promo', tr.trailerName),
        trailerDuration: tr.duration,
        trailerSceneIndices: tr.sceneIndices,
        trailerSize: `${tr.width}x${tr.height}`
      });
    }

    const fresh = accountManager.getAccount(accountId);
    fresh.settings.lastPromoExport = result;
    accountManager.save();
    return { ok: true, ...result };
  } finally {
    try {
      fs.rmSync(tempDir, { recursive: true, force: true });
    } catch (_) {}
  }
}

module.exports = {
  POSTER_THEME_PRESETS,
  POSTER_SOURCE_MODES,
  POSTER_BADGE_PRESETS,
  renderPromoPack,
  scoreSceneForTrailer,
  wrapTitleLines,
  extractBroadcastPosterMeta
};
