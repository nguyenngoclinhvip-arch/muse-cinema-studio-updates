const fs = require('fs');
const path = require('path');
const { spawn } = require('child_process');
const { parseSceneMultiSpeakerLines } = require('./cinemaDirector');

const TRANSITION_EFFECTS = [
  { id: 'director_smart', label: '🎬 Đạo diễn thông minh (Cùng cảnh cắt mượt, đổi cảnh mờ dần)' },
  { id: 'fade', label: '✨ Mờ dần điện ảnh (Crossfade)' },
  { id: 'fadeblack', label: '🎬 Chuyển tối rạp phim (Fade to Black)' },
  { id: 'dissolve', label: '🌊 Hòa tan mềm (Dissolve)' },
  { id: 'none', label: '⚡ Cắt thẳng dứt khoát (Hard Cut)' },
  { id: 'hblur', label: '💨 Mờ chuyển động (Motion Blur)' },
  { id: 'smoothleft', label: '⬅️ Lướt ngang mượt' },
  { id: 'zoomin', label: '🔍 Phóng tâm (Zoom In)' },
  { id: 'random', label: '🎲 Ngẫu nhiên mượt mà' }
];

const RANDOM_POOL = ['fade', 'dissolve', 'fadeblack', 'hblur', 'smoothleft', 'zoomin'];

function getFfmpegExecutable(appRootDir) {
  try {
    const staticPath = require('ffmpeg-static');
    if (staticPath && fs.existsSync(staticPath)) {
      return staticPath;
    }
  } catch (_) {}

  const candidates = [
    path.join(appRootDir, 'node_modules', 'ffmpeg-static', 'ffmpeg.exe'),
    path.join(appRootDir, 'runtime', 'ffmpeg', 'ffmpeg.exe'),
    'ffmpeg'
  ];

  for (const c of candidates) {
    if (c === 'ffmpeg' || fs.existsSync(c)) {
      return c;
    }
  }
  return 'ffmpeg';
}

function runFfmpeg(ffmpegBin, args, options = {}) {
  return new Promise((resolve, reject) => {
    const proc = spawn(ffmpegBin, args, {
      windowsHide: true,
      ...(options.cwd ? { cwd: options.cwd } : {})
    });
    let stderr = '';
    proc.stderr.on('data', (chunk) => {
      stderr += chunk.toString();
    });
    proc.on('error', (err) => {
      reject(new Error(`Không thể khởi chạy FFmpeg (${err.message}).`));
    });
    proc.on('close', (code) => {
      if (code === 0) {
        resolve(stderr);
      } else {
        const tail = stderr.split(/\r?\n/).slice(-8).join(' | ');
        reject(new Error(`Lỗi xử lý FFmpeg (code ${code}): ${tail}`));
      }
    });
  });
}

function probeMediaFile(ffmpegBin, filePath) {
  return new Promise((resolve) => {
    const proc = spawn(ffmpegBin, ['-hide_banner', '-i', filePath], { windowsHide: true });
    let stderr = '';
    proc.stderr.on('data', (d) => {
      stderr += d.toString();
    });
    proc.on('error', () => {
      resolve({
        duration: 0,
        width: 1280,
        height: 720,
        hasAudio: false,
        audioSampleRate: 0,
        audioChannels: '',
        bitrateKbps: 0,
        majorBrand: ''
      });
    });
    proc.on('close', () => {
      let duration = 0;
      const durMatch = stderr.match(/Duration:\s*(\d+):(\d+):(\d+(?:\.\d+)?)/i);
      if (durMatch) {
        duration =
          Number(durMatch[1]) * 3600 +
          Number(durMatch[2]) * 60 +
          parseFloat(durMatch[3]);
      }

      let bitrateKbps = 0;
      const brMatch = stderr.match(/bitrate:\s*(\d+)\s*kb\/s/i);
      if (brMatch) {
        bitrateKbps = Number(brMatch[1]) || 0;
      }

      let majorBrand = '';
      const brandMatch = stderr.match(/major_brand\s*:\s*(\S+)/i);
      if (brandMatch) {
        majorBrand = String(brandMatch[1] || '').trim().toLowerCase();
      }

      let width = 1280;
      let height = 720;
      const resMatch = stderr.match(/Stream\s+#\d+:\d+.*Video:.*?\s(\d{2,5})x(\d{2,5})(?:[\s,]|$)/i);
      if (resMatch) {
        width = Number(resMatch[1]) || 1280;
        height = Number(resMatch[2]) || 720;
      }

      const audioLineMatch = stderr.match(/Stream\s+#\d+:\d+.*Audio:([^\r\n]+)/i);
      const hasAudio = Boolean(audioLineMatch);
      let audioSampleRate = 0;
      let audioChannels = '';
      if (audioLineMatch) {
        const audioLine = audioLineMatch[1];
        const srMatch = audioLine.match(/(\d{4,6})\s*Hz/i);
        if (srMatch) audioSampleRate = Number(srMatch[1]) || 0;
        if (/\bstereo\b|\b2\s*channels\b/i.test(audioLine)) {
          audioChannels = 'stereo';
        } else if (/\bmono\b|\b1\s*channels?\b/i.test(audioLine)) {
          audioChannels = 'mono';
        }
      }

      resolve({
        duration,
        width,
        height,
        hasAudio,
        audioSampleRate,
        audioChannels,
        bitrateKbps,
        majorBrand
      });
    });
  });
}

async function ensureUniversalPlayableMp4(appRootDir, filePath, options = {}) {
  if (!filePath || !fs.existsSync(filePath)) return filePath;
  const origStat = fs.statSync(filePath);
  if (origStat.size < 10000) return filePath;

  const ffmpegBin = getFfmpegExecutable(appRootDir);
  const info = await probeMediaFile(ffmpegBin, filePath);

  const isMod16 = info.width > 0 && info.height > 0 && info.width % 16 === 0 && info.height % 16 === 0;
  const isReasonableBitrate = !info.bitrateKbps || info.bitrateKbps <= 12500;
  const isStandardAudio = !info.hasAudio || (info.audioSampleRate === 44100 && info.audioChannels === 'stereo');
  const isMp42 = info.majorBrand === 'mp42';

  if (!options.forceReencode && isMp42 && isStandardAudio && isMod16 && isReasonableBitrate) {
    return filePath;
  }

  const tempOut = `${filePath}.norm_${Date.now()}_${Math.random().toString(36).slice(2, 6)}.mp4`;

  const runFullCleanEncode = async () => {
    const evenW = Math.max(16, Math.round((info.width || 1280) / 16) * 16);
    const evenH = Math.max(16, Math.round((info.height || 720) / 16) * 16);
    const vf = `scale=${evenW}:${evenH}:flags=lanczos:in_color_matrix=bt709:out_color_matrix=bt709,setsar=1,format=yuv420p`;

    if (info.hasAudio) {
      await runFfmpeg(ffmpegBin, [
        '-y', '-i', filePath,
        '-map_metadata', '-1',
        '-vf', vf,
        '-af', 'aresample=44100',
        '-c:v', 'libx264', '-preset', 'fast', '-crf', '16',
        '-profile:v', 'high', '-level', '4.1',
        '-colorspace', 'bt709', '-color_primaries', 'bt709', '-color_trc', 'bt709',
        '-maxrate', '12M', '-bufsize', '24M',
        '-c:a', 'aac', '-b:a', '192k', '-ar', '44100', '-ac', '2',
        '-brand', 'mp42', '-movflags', '+faststart',
        tempOut
      ]);
    } else {
      await runFfmpeg(ffmpegBin, [
        '-y', '-i', filePath,
        '-map_metadata', '-1',
        '-vf', vf,
        '-c:v', 'libx264', '-preset', 'fast', '-crf', '16',
        '-profile:v', 'high', '-level', '4.1',
        '-colorspace', 'bt709', '-color_primaries', 'bt709', '-color_trc', 'bt709',
        '-maxrate', '12M', '-bufsize', '24M',
        '-brand', 'mp42', '-movflags', '+faststart',
        tempOut
      ]);
    }
  };

  try {
    if (!options.forceReencode && isMod16 && isReasonableBitrate) {
      try {
        if (info.hasAudio) {
          await runFfmpeg(ffmpegBin, [
            '-y', '-i', filePath,
            '-map_metadata', '-1',
            '-c:v', 'copy',
            '-c:a', 'aac', '-b:a', '192k', '-ar', '44100', '-ac', '2',
            '-brand', 'mp42', '-movflags', '+faststart',
            tempOut
          ]);
        } else {
          await runFfmpeg(ffmpegBin, [
            '-y', '-i', filePath,
            '-map_metadata', '-1',
            '-c:v', 'copy',
            '-brand', 'mp42', '-movflags', '+faststart',
            tempOut
          ]);
        }
      } catch (_) {
        await runFullCleanEncode();
      }
    } else {
      await runFullCleanEncode();
    }

    if (fs.existsSync(tempOut) && fs.statSync(tempOut).size > 10000) {
      fs.renameSync(tempOut, filePath);
    }
  } catch (_) {
  } finally {
    if (fs.existsSync(tempOut)) {
      try {
        fs.unlinkSync(tempOut);
      } catch (_) {}
    }
  }

  return filePath;
}

function resolveOutputUrlToDiskPath(appRootDir, rawUrl) {
  if (!rawUrl) return null;
  const rel = String(rawUrl).split('?')[0].replace(/^\/+/, '');
  if (!rel.startsWith('outputs/')) return null;
  const sub = rel.slice('outputs/'.length);
  const decodedSegs = sub
    .split('/')
    .filter(Boolean)
    .map((s) => {
      try {
        return decodeURIComponent(s);
      } catch (_) {
        return s;
      }
    });
  const decodedCandidate = path.join(appRootDir, 'Output_Videos', ...decodedSegs);
  if (fs.existsSync(decodedCandidate)) return decodedCandidate;

  const rawCandidate = path.join(appRootDir, 'Output_Videos', sub);
  if (fs.existsSync(rawCandidate)) return rawCandidate;
  return null;
}

function resolveSceneVideoDiskPath(appRootDir, row) {
  if (!row) return null;
  if (row.videoFilePath && fs.existsSync(row.videoFilePath)) {
    return row.videoFilePath;
  }
  if (row.videoUrl) {
    const resolved = resolveOutputUrlToDiskPath(appRootDir, row.videoUrl);
    if (resolved) return resolved;
  }
  return null;
}

async function mergeNormalizedSegmentsWithTransition(
  ffmpegBin,
  normFiles,
  finalOutputPath,
  transitionEffect = 'director_smart',
  transitionSec = 0.36,
  effectSeedOffset = 0,
  perCutDurations = null
) {
  if (normFiles.length === 1) {
    fs.copyFileSync(normFiles[0], finalOutputPath);
    return finalOutputPath;
  }

  const cleanEffect = String(transitionEffect || 'director_smart').trim().toLowerCase();
  if (!cleanEffect || cleanEffect === 'none') {
    throw new Error('SKIP_TRANSITION');
  }

  const MAX_XFADE_BATCH = 8;
  if (normFiles.length > MAX_XFADE_BATCH) {
    const chunkWorkDir = path.join(
      path.dirname(finalOutputPath),
      `_xfade_chunks_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`
    );
    fs.mkdirSync(chunkWorkDir, { recursive: true });
    try {
      const chunkOutputs = [];
      const boundaryCuts = [];
      let cursor = 0;
      let chunkIdx = 0;
      while (cursor < normFiles.length) {
        const slice = normFiles.slice(cursor, cursor + MAX_XFADE_BATCH);
        if (cursor > 0) {
          boundaryCuts.push(
            Array.isArray(perCutDurations) && Number.isFinite(Number(perCutDurations[cursor - 1]))
              ? Number(perCutDurations[cursor - 1])
              : transitionSec
          );
        }
        if (slice.length === 1) {
          chunkOutputs.push(slice[0]);
        } else {
          const chunkOut = path.join(chunkWorkDir, `chunk_${chunkIdx}.mp4`);
          const sliceCuts = Array.isArray(perCutDurations)
            ? perCutDurations.slice(cursor, cursor + slice.length - 1)
            : null;
          await mergeNormalizedSegmentsWithTransition(
            ffmpegBin,
            slice,
            chunkOut,
            cleanEffect,
            transitionSec,
            effectSeedOffset + cursor,
            sliceCuts
          );
          chunkOutputs.push(chunkOut);
        }
        cursor += MAX_XFADE_BATCH;
        chunkIdx++;
      }
      return await mergeNormalizedSegmentsWithTransition(
        ffmpegBin,
        chunkOutputs,
        finalOutputPath,
        cleanEffect,
        transitionSec,
        effectSeedOffset + 100,
        boundaryCuts.length === chunkOutputs.length - 1 ? boundaryCuts : null
      );
    } finally {
      try {
        fs.rmSync(chunkWorkDir, { recursive: true, force: true });
      } catch (_) {}
    }
  }

  const durations = [];
  for (const nf of normFiles) {
    const info = await probeMediaFile(ffmpegBin, nf);
    durations.push(info.duration > 0.8 ? info.duration : 10);
  }

  const minClipDur = Math.min(...durations);
  const defaultTDur = Math.max(0.06, Math.min(transitionSec, minClipDur * 0.25, 0.65));

  const inputArgs = [];
  const filterParts = [];

  for (let i = 0; i < normFiles.length; i++) {
    inputArgs.push('-i', normFiles[i]);
    filterParts.push(`[${i}:v]settb=AVTB,fps=30,format=yuv420p[v${i}]`);
    filterParts.push(`[${i}:a]aresample=44100,aformat=sample_fmts=fltp:channel_layouts=stereo[a${i}]`);
  }

  let cumDuration = durations[0];
  let prevV = 'v0';
  let prevA = 'a0';

  for (let i = 1; i < normFiles.length; i++) {
    const chosenEffect =
      cleanEffect === 'director_smart'
        ? 'fade'
        : cleanEffect === 'random'
        ? RANDOM_POOL[(effectSeedOffset + i - 1) % RANDOM_POOL.length]
        : RANDOM_POOL.includes(cleanEffect) ||
          ['circleopen', 'fadeblack', 'fadewhite', 'wipeleft', 'smoothright'].includes(cleanEffect)
        ? cleanEffect
        : 'fade';

    const rawCutSec =
      Array.isArray(perCutDurations) && Number.isFinite(Number(perCutDurations[i - 1]))
        ? Number(perCutDurations[i - 1])
        : defaultTDur;
    const pairMinDur = Math.min(durations[i - 1], durations[i]);
    const tDur = Math.max(0.06, Math.min(rawCutSec, pairMinDur * 0.25, 0.65));

    const offset = Math.max(0.1, cumDuration - tDur);
    const nextV = `vx${i}`;
    const nextA = `ax${i}`;

    filterParts.push(
      `[${prevV}][v${i}]xfade=transition=${chosenEffect}:duration=${tDur.toFixed(3)}:offset=${offset.toFixed(3)}[${nextV}]`
    );
    filterParts.push(`[${prevA}][a${i}]acrossfade=d=${tDur.toFixed(3)}:c1=tri:c2=tri[${nextA}]`);

    cumDuration = offset + durations[i];
    prevV = nextV;
    prevA = nextA;
  }

  const filterComplex = filterParts.join(';');
  const scriptFile = path.join(
    path.dirname(finalOutputPath),
    `_fscript_${Date.now()}_${Math.random().toString(36).slice(2, 6)}.txt`
  );
  fs.writeFileSync(scriptFile, filterComplex, 'utf8');

  try {
    await runFfmpeg(ffmpegBin, [
      '-y',
      ...inputArgs,
      '-filter_complex_script', scriptFile,
      '-map', `[${prevV}]`,
      '-map', `[${prevA}]`,
      '-map_metadata', '-1',
      '-c:v', 'libx264', '-preset', 'fast', '-crf', '16',
      '-profile:v', 'high', '-level', '4.1',
      '-colorspace', 'bt709', '-color_primaries', 'bt709', '-color_trc', 'bt709',
      '-maxrate', '12M', '-bufsize', '24M',
      '-c:a', 'aac', '-b:a', '192k', '-ar', '44100', '-ac', '2',
      '-brand', 'mp42', '-movflags', '+faststart',
      finalOutputPath
    ]);
  } finally {
    try {
      if (fs.existsSync(scriptFile)) fs.unlinkSync(scriptFile);
    } catch (_) {}
  }

  return finalOutputPath;
}

/**
 * Trích xuất khung hình sắc nét tại một mốc thời gian chỉ định (dùng cho AI Tạo Ảnh Chân Dung Nhân Vật)
 */
async function extractFrameAtTimeFromVideo(appRootDir, videoFilePath, outputImagePath, targetSec = 1.2) {
  const ffmpegBin = getFfmpegExecutable(appRootDir);
  const info = await probeMediaFile(ffmpegBin, videoFilePath);
  const outDir = path.dirname(outputImagePath);
  if (!fs.existsSync(outDir)) fs.mkdirSync(outDir, { recursive: true });

  const safeSec = info.duration > 0.6 ? Math.min(Math.max(0.25, targetSec), Math.max(0.25, info.duration - 0.35)) : 0;
  const bt709RgbFilter = 'scale=in_color_matrix=bt709:out_color_matrix=bt709:flags=lanczos,format=rgb24';

  await runFfmpeg(ffmpegBin, [
    '-y',
    '-ss', safeSec.toFixed(3),
    '-i', videoFilePath,
    '-vf', bt709RgbFilter,
    '-frames:v', '1',
    ...(outputImagePath.toLowerCase().endsWith('.png') ? [] : ['-q:v', '1']),
    outputImagePath
  ]);
  return outputImagePath;
}

async function extractLastFrameFromVideo(appRootDir, videoFilePath, outputImagePath) {
  const ffmpegBin = getFfmpegExecutable(appRootDir);
  const info = await probeMediaFile(ffmpegBin, videoFilePath);

  const outDir = path.dirname(outputImagePath);
  if (!fs.existsSync(outDir)) {
    fs.mkdirSync(outDir, { recursive: true });
  }

  const bt709RgbFilter = 'scale=in_color_matrix=bt709:out_color_matrix=bt709:flags=lanczos,format=rgb24';
  if (info.duration > 0.6) {
    const candDir = path.join(outDir, `_sharp_cand_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`);
    fs.mkdirSync(candDir, { recursive: true });
    try {
      const startWindow = Math.max(0, info.duration - 0.38);
      await runFfmpeg(ffmpegBin, [
        '-y',
        '-ss', startWindow.toFixed(3),
        '-i', videoFilePath,
        '-vf', `fps=18,${bt709RgbFilter}`,
        '-frames:v', '7',
        path.join(candDir, 'cand_%02d.png')
      ]);

      const cands = fs
        .readdirSync(candDir)
        .filter((f) => f.endsWith('.png'))
        .sort()
        .map((f) => {
          const full = path.join(candDir, f);
          const sz = fs.statSync(full).size;
          return { name: f, full, size: sz };
        })
        .filter((c) => c.size > 1000);

      if (cands.length > 0) {
        const maxSz = Math.max(...cands.map((c) => c.size));
        let best = cands[cands.length - 1];
        let bestScore = -1;
        cands.forEach((c, idx) => {
          const sharpnessRatio = maxSz > 0 ? c.size / maxSz : 1;
          const recencyBonus = (idx / Math.max(1, cands.length - 1)) * 0.035;
          const score = sharpnessRatio + recencyBonus;
          if (score > bestScore) {
            bestScore = score;
            best = c;
          }
        });

        if (outputImagePath.toLowerCase().endsWith('.png')) {
          fs.copyFileSync(best.full, outputImagePath);
        } else {
          await runFfmpeg(ffmpegBin, ['-y', '-i', best.full, '-q:v', '1', outputImagePath]);
        }
      }
    } catch (_) {
    } finally {
      try {
        fs.rmSync(candDir, { recursive: true, force: true });
      } catch (_) {}
    }
  }

  if (!fs.existsSync(outputImagePath) || fs.statSync(outputImagePath).size < 500) {
    const seekSec = info.duration > 0.25 ? Math.max(0, info.duration - 0.12) : 0;
    try {
      await runFfmpeg(ffmpegBin, [
        '-y', '-ss', seekSec.toFixed(3), '-i', videoFilePath,
        '-vf', bt709RgbFilter, '-frames:v', '1',
        ...(outputImagePath.toLowerCase().endsWith('.png') ? [] : ['-q:v', '1']),
        outputImagePath
      ]);
    } catch (_) {}
  }

  return outputImagePath;
}

async function concatExtendedPartFiles(
  appRootDir,
  partFilePaths,
  finalOutputPath,
  transitionEffect = 'fade',
  options = {}
) {
  if (!Array.isArray(partFilePaths) || partFilePaths.length === 0) {
    throw new Error('Không có file thành phần để nối.');
  }
  if (partFilePaths.length === 1) {
    fs.copyFileSync(partFilePaths[0], finalOutputPath);
    await ensureUniversalPlayableMp4(appRootDir, finalOutputPath);
    return finalOutputPath;
  }

  const ffmpegBin = getFfmpegExecutable(appRootDir);
  const persistentCacheDir = options && options.cacheDir ? path.join(options.cacheDir, '_norm_cache') : null;
  const tempDir =
    persistentCacheDir ||
    path.join(appRootDir, 'Project_Data', 'temp_editor', `extend_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`);
  fs.mkdirSync(tempDir, { recursive: true });

  const cleanEffect = String(transitionEffect || 'fade').trim().toLowerCase();
  const fastPreviewOnly = Boolean(options && options.fastPreviewOnly);

  try {
    const firstInfo = await probeMediaFile(ffmpegBin, partFilePaths[0]);
    const targetW = Math.max(16, Math.round((firstInfo.width || 1280) / 16) * 16);
    const targetH = Math.max(16, Math.round((firstInfo.height || 720) / 16) * 16);

    const normFiles = [];
    for (let i = 0; i < partFilePaths.length; i++) {
      const p = partFilePaths[i];
      const safeTag = path.basename(p).replace(/[^a-zA-Z0-9._-]/g, '_');
      const normOut = path.join(tempDir, persistentCacheDir ? `norm_${i}_${safeTag}` : `norm_${i}.mp4`);

      if (persistentCacheDir && fs.existsSync(normOut) && fs.statSync(normOut).size > 5000) {
        normFiles.push(normOut);
        continue;
      }

      const info = await probeMediaFile(ffmpegBin, p);
      const vFilter = `scale=${targetW}:${targetH}:force_original_aspect_ratio=decrease:flags=lanczos:in_color_matrix=bt709:out_color_matrix=bt709,pad=${targetW}:${targetH}:(ow-iw)/2:(oh-ih)/2:black,setsar=1,fps=30,format=yuv420p`;

      if (info.hasAudio) {
        await runFfmpeg(ffmpegBin, [
          '-y', '-i', p, '-map_metadata', '-1', '-vf', vFilter, '-af', 'aresample=44100',
          '-c:v', 'libx264', '-preset', 'fast', '-crf', '15', '-profile:v', 'high', '-level', '4.1',
          '-colorspace', 'bt709', '-color_primaries', 'bt709', '-color_trc', 'bt709',
          '-maxrate', '12M', '-bufsize', '24M',
          '-c:a', 'aac', '-b:a', '192k', '-ac', '2', '-ar', '44100', '-brand', 'mp42',
          normOut
        ]);
      } else {
        const dur = Math.max(1, info.duration || 10);
        await runFfmpeg(ffmpegBin, [
          '-y', '-i', p, '-f', 'lavfi', '-t', dur.toFixed(3), '-i', 'anullsrc=channel_layout=stereo:sample_rate=44100',
          '-map_metadata', '-1', '-vf', vFilter, '-map', '0:v:0', '-map', '1:a:0',
          '-c:v', 'libx264', '-preset', 'fast', '-crf', '15', '-profile:v', 'high', '-level', '4.1',
          '-colorspace', 'bt709', '-color_primaries', 'bt709', '-color_trc', 'bt709',
          '-maxrate', '12M', '-bufsize', '24M',
          '-c:a', 'aac', '-b:a', '192k', '-ac', '2', '-ar', '44100', '-shortest', '-brand', 'mp42',
          normOut
        ]);
      }
      normFiles.push(normOut);
    }

    if (!fastPreviewOnly && cleanEffect && cleanEffect !== 'none') {
      const transitionSec = options && options.hasSpokenDialogue ? 0.18 : 0.45;
      try {
        await mergeNormalizedSegmentsWithTransition(ffmpegBin, normFiles, finalOutputPath, cleanEffect, transitionSec);
        if (fs.existsSync(finalOutputPath) && fs.statSync(finalOutputPath).size > 10000) {
          return finalOutputPath;
        }
      } catch (_) {}
    }

    const normListPath = path.join(tempDir, `norm_list_${Date.now()}.txt`);
    fs.writeFileSync(
      normListPath,
      normFiles.map((p) => `file '${p.replace(/\\/g, '/').replace(/'/g, "'\\''")}'`).join('\n'),
      'utf8'
    );

    try {
      await runFfmpeg(ffmpegBin, [
        '-y', '-f', 'concat', '-safe', '0', '-i', normListPath,
        '-map_metadata', '-1', '-c', 'copy', '-brand', 'mp42', '-movflags', '+faststart',
        finalOutputPath
      ]);
    } finally {
      try {
        if (fs.existsSync(normListPath)) fs.unlinkSync(normListPath);
      } catch (_) {}
    }

    return finalOutputPath;
  } finally {
    if (!persistentCacheDir) {
      try {
        fs.rmSync(tempDir, { recursive: true, force: true });
      } catch (_) {}
    }
  }
}

function formatSrtTimestamp(sec) {
  const safe = Math.max(0, Number(sec) || 0);
  const hrs = Math.floor(safe / 3600);
  const mins = Math.floor((safe % 3600) / 60);
  const secs = Math.floor(safe % 60);
  const ms = Math.round((safe - Math.floor(safe)) * 1000);
  return `${String(hrs).padStart(2, '0')}:${String(mins).padStart(2, '0')}:${String(secs).padStart(
    2,
    '0'
  )},${String(Math.min(999, ms)).padStart(3, '0')}`;
}

/**
 * Tạo file phụ đề chuẩn .SRT từ lời thoại các phân cảnh trong phim
 */
function generateSrtFromScenes(scenesWithTiming = [], allCharacters = [], srtOutPath = null) {
  const entries = [];
  let cueIndex = 1;

  for (const sc of scenesWithTiming) {
    const rawDlg = String(sc.dialogue || '').trim();
    if (!rawDlg) continue;

    const parsed = parseSceneMultiSpeakerLines(rawDlg, allCharacters);
    if (parsed.length === 0) continue;

    const sceneStart = Math.max(0, Number(sc.startSec) || 0) + 0.15;
    const sceneEnd = Math.max(sceneStart + 0.6, (Number(sc.endSec) || sceneStart + 5) - 0.25);
    const totalWindow = Math.max(0.6, sceneEnd - sceneStart);

    const distinctCharSpeakers = new Set(
      parsed.filter((p) => p.type === 'character' && p.speakerLabel).map((p) => p.speakerLabel)
    );
    const showSpeakerPrefix = distinctCharSpeakers.size >= 2;

    const weights = parsed.map((p) => Math.max(3, String(p.text || '').split(/\s+/).length));
    const totalWeight = weights.reduce((a, b) => a + b, 0) || 1;

    let cursor = sceneStart;
    parsed.forEach((p, idx) => {
      const share = (weights[idx] / totalWeight) * totalWindow;
      const start = cursor;
      const end = idx === parsed.length - 1 ? sceneEnd : Math.min(sceneEnd, cursor + share);
      cursor = end + 0.04;

      const cleanText =
        showSpeakerPrefix && p.type === 'character' && p.speakerLabel
          ? `${p.speakerLabel}: ${p.text}`
          : p.text;

      if (cleanText && end > start + 0.2) {
        entries.push(
          `${cueIndex++}\n${formatSrtTimestamp(start)} --> ${formatSrtTimestamp(end)}\n${cleanText}\n`
        );
      }
    });
  }

  const srtContent = entries.join('\n');
  if (srtOutPath) {
    fs.mkdirSync(path.dirname(srtOutPath), { recursive: true });
    // UTF-8 with BOM giúp CapCut, Premiere và Windows Notepad nhận diện tiếng Việt có dấu 100%
    fs.writeFileSync(srtOutPath, `\uFEFF${srtContent}`, 'utf8');
  }
  return { srtContent, cueCount: entries.length };
}

/* ================= v1.8: KIỂM TRA CHẤT LƯỢNG CLIP TỰ ĐỘNG (QC) ================= */

function runFfmpegCaptureStderr(ffmpegBin, args, timeoutMs = 120000) {
  return new Promise((resolve) => {
    const proc = spawn(ffmpegBin, args, { windowsHide: true });
    let stderr = '';
    const timer = setTimeout(() => {
      try {
        proc.kill();
      } catch (_) {}
    }, timeoutMs);
    proc.stderr.on('data', (d) => {
      stderr += d.toString();
      if (stderr.length > 4 * 1024 * 1024) stderr = stderr.slice(-2 * 1024 * 1024);
    });
    proc.on('error', () => {
      clearTimeout(timer);
      resolve({ code: -1, stderr });
    });
    proc.on('close', (code) => {
      clearTimeout(timer);
      resolve({ code, stderr });
    });
  });
}

/**
 * Quét 1 clip phân cảnh để phát hiện lỗi thường gặp của video AI:
 * khung đen, đứng hình, mất tiếng / thoại không phát ra, thiếu thời lượng.
 * Trả về { score 0-100, verdict 'pass'|'warn'|'fail', issues: [...], metrics }
 */
async function analyzeClipQuality({ appRootDir, filePath, expectedSec = 0, expectDialogue = false }) {
  const ffmpegBin = getFfmpegExecutable(appRootDir);
  const info = await probeMediaFile(ffmpegBin, filePath);
  const duration = info.duration || 0;
  const issues = [];
  let score = 100;

  if (!duration || duration < 0.5) {
    return {
      score: 0,
      verdict: 'fail',
      issues: ['Không đọc được video (file hỏng hoặc rỗng)'],
      metrics: { duration },
      checkedAt: new Date().toISOString()
    };
  }

  const args = [
    '-hide_banner', '-nostats', '-i', filePath,
    '-vf', 'scale=320:-2,blackdetect=d=0.4:pix_th=0.10,freezedetect=n=0.003:d=1.5',
    ...(info.hasAudio ? ['-af', 'silencedetect=n=-45dB:d=1.0,volumedetect'] : ['-an']),
    '-f', 'null', '-'
  ];
  const { stderr } = await runFfmpegCaptureStderr(ffmpegBin, args);

  let blackTotal = 0;
  for (const m of stderr.matchAll(/black_duration:\s*([\d.]+)/g)) blackTotal += parseFloat(m[1]) || 0;

  let freezeTotal = 0;
  for (const m of stderr.matchAll(/lavfi\.freezedetect\.freeze_duration:\s*([\d.]+)/g)) freezeTotal += parseFloat(m[1]) || 0;
  // Đoạn đứng hình kéo tới cuối clip (không có freeze_end) -> tính từ freeze_start tới hết clip
  const starts = [...stderr.matchAll(/lavfi\.freezedetect\.freeze_start:\s*([\d.]+)/g)].map((m) => parseFloat(m[1]) || 0);
  const ends = [...stderr.matchAll(/lavfi\.freezedetect\.freeze_end:\s*([\d.]+)/g)].length;
  if (starts.length > ends) freezeTotal += Math.max(0, duration - starts[starts.length - 1]);

  let silenceTotal = 0;
  for (const m of stderr.matchAll(/silence_duration:\s*([\d.]+)/g)) silenceTotal += parseFloat(m[1]) || 0;
  const silStarts = [...stderr.matchAll(/silence_start:\s*([\d.]+)/g)].map((m) => parseFloat(m[1]) || 0);
  const silEnds = [...stderr.matchAll(/silence_end:\s*([\d.]+)/g)].length;
  if (silStarts.length > silEnds) silenceTotal += Math.max(0, duration - silStarts[silStarts.length - 1]);

  const meanVolMatch = stderr.match(/mean_volume:\s*(-?[\d.]+)\s*dB/);
  const meanVolume = meanVolMatch ? parseFloat(meanVolMatch[1]) : info.hasAudio ? null : -91;

  const blackRatio = Math.min(1, blackTotal / duration);
  const freezeRatio = Math.min(1, freezeTotal / duration);
  const silenceRatio = info.hasAudio ? Math.min(1, silenceTotal / duration) : 1;

  // 1. Thời lượng
  let critical = false;
  if (expectedSec > 0 && duration < expectedSec * 0.6) {
    issues.push(`Thiếu thời lượng (${duration.toFixed(1)}s / ${expectedSec}s)`);
    score -= 45;
    critical = true;
  } else if (expectedSec > 0 && duration < expectedSec * 0.8) {
    issues.push(`Hơi ngắn (${duration.toFixed(1)}s / ${expectedSec}s)`);
    score -= 12;
  }

  // 2. Khung đen
  if (blackRatio >= 0.3) {
    issues.push(`Khung đen ${Math.round(blackRatio * 100)}% thời lượng`);
    score -= 50;
    critical = true;
  } else if (blackRatio >= 0.12) {
    issues.push(`Có đoạn khung đen ${blackTotal.toFixed(1)}s`);
    score -= 18;
  }

  // 3. Đứng hình
  if (freezeRatio >= 0.45) {
    issues.push(`Đứng hình ${Math.round(freezeRatio * 100)}% thời lượng`);
    score -= 50;
    critical = true;
  } else if (freezeRatio >= 0.2) {
    issues.push(`Có đoạn đứng hình ${freezeTotal.toFixed(1)}s`);
    score -= 18;
  }

  // 4. Âm thanh
  if (!info.hasAudio) {
    issues.push('Không có âm thanh');
    score -= expectDialogue ? 45 : 10;
    if (expectDialogue) critical = true;
  } else if (expectDialogue && (silenceRatio >= 0.85 || (meanVolume !== null && meanVolume < -50))) {
    issues.push('Cảnh có lời thoại nhưng gần như không có tiếng');
    score -= 40;
    critical = true;
  } else if (silenceRatio >= 0.95) {
    issues.push('Gần như im lặng hoàn toàn');
    score -= 8;
  }

  score = Math.max(0, Math.min(100, Math.round(score)));
  if (critical) score = Math.min(score, 45);
  const verdict = critical || score < 55 ? 'fail' : score < 80 ? 'warn' : 'pass';
  return {
    score,
    verdict,
    issues,
    metrics: {
      duration: Number(duration.toFixed(2)),
      blackSec: Number(blackTotal.toFixed(2)),
      freezeSec: Number(freezeTotal.toFixed(2)),
      silenceSec: Number(silenceTotal.toFixed(2)),
      meanVolume,
      hasAudio: info.hasAudio
    },
    checkedAt: new Date().toISOString()
  };
}

/* ================= v1.8: CHỈNH MÀU ĐỒNG BỘ TOÀN PHIM ================= */

const COLOR_GRADE_PRESETS = [
  { id: 'auto_match', label: '⚖️ Cân màu đồng đều các cảnh (giữ tông gốc)', filter: '' },
  {
    id: 'fresh_bright_hd',
    label: '🌤️ Đời Thực Trong Trẻo & Sáng Rõ 4K (Tôn Da Sáng Mịn • Xóa Ám Tối Cũ)',
    filter:
      'colorbalance=rs=0.01:gs=0.01:bs=0.02:rm=0.01:gm=0.00:bm=0.01:rh=0.02:gh=0.01:bh=0.01,eq=brightness=0.03:contrast=1.04:saturation=1.09:gamma=0.95,unsharp=3:3:0.38:3:3:0.0'
  },
  {
    id: 'xianxia_3d_cinema',
    label: '🐉 Tiên Hiệp 3D Cinema Chiếu Rạp (Xanh Ngọc Sâu • Bùa Vàng • Tương Phản Khối)',
    filter: 'colorbalance=rs=-0.06:gs=0.04:bs=0.07:rm=-0.02:gm=0.01:bm=0.03:rh=0.05:gh=0.02:bh=-0.03,eq=contrast=1.10:saturation=1.08:brightness=-0.01,unsharp=3:3:0.45:3:3:0.0'
  },
  { id: 'cinema_warm', label: '🎞️ Điện ảnh ấm áp', filter: 'colorbalance=rs=0.04:bs=-0.04:rm=0.03:bm=-0.03,eq=contrast=1.06:saturation=1.05' },
  { id: 'teal_orange', label: '🎬 Hollywood xanh - cam (Teal & Orange)', filter: 'colorbalance=rs=-0.05:bs=0.07:rh=0.07:bh=-0.06,eq=contrast=1.08:saturation=1.08' },
  { id: 'ancient_jade', label: '🏯 Cổ trang ngọc bích (Tiên hiệp)', filter: 'colorbalance=gs=0.03:bs=0.02:rh=0.04:gh=0.01,eq=contrast=1.05:saturation=0.94' },
  { id: 'cold_mystery', label: '🌫️ Lạnh huyền bí (Kinh dị / Trinh thám)', filter: 'colorbalance=rs=-0.05:bs=0.08:bm=0.04,eq=contrast=1.08:saturation=0.82:brightness=-0.02' },
  { id: 'vivid_anime', label: '🌈 Rực rỡ hoạt hình', filter: 'eq=saturation=1.22:contrast=1.05' },
  { id: 'soft_pastel', label: '🌸 Pastel dịu nhẹ', filter: 'eq=saturation=0.88:contrast=0.95:brightness=0.03' },
  { id: 'vintage_film', label: '📼 Phim xưa hoài niệm', filter: 'curves=preset=vintage,eq=saturation=0.9' },
  { id: 'bw_classic', label: '⚫ Đen trắng kinh điển', filter: 'hue=s=0,eq=contrast=1.12' },
  { id: 'none', label: '🚫 Không chỉnh màu (giữ nguyên bản gốc)', filter: '' }
];
const COLOR_GRADE_MAP = new Map(COLOR_GRADE_PRESETS.map((p) => [p.id, p]));

/** Đo độ sáng (Y) & sắc độ trung bình (U/V) + dải tương phản của 1 clip / ảnh bằng signalstats. */
async function measureClipColorStats(ffmpegBin, filePath, { startSec = 0, durSec = 0 } = {}) {
  const args = ['-hide_banner', '-nostats'];
  if (startSec > 0) args.push('-ss', startSec.toFixed(3));
  if (durSec > 0) args.push('-t', durSec.toFixed(3));
  args.push('-i', filePath, '-vf', 'fps=2,scale=320:-2,signalstats,metadata=mode=print', '-an', '-f', 'null', '-');
  const { stderr } = await runFfmpegCaptureStderr(ffmpegBin, args, 90000);
  const avg = (key) => {
    const vals = [...stderr.matchAll(new RegExp(`lavfi\\.signalstats\\.${key}=([\\d.]+)`, 'g'))].map((m) => parseFloat(m[1]));
    const clean = vals.filter((v) => Number.isFinite(v));
    return clean.length ? clean.reduce((a, b) => a + b, 0) / clean.length : null;
  };
  const y = avg('YAVG');
  if (y === null) return null;
  return {
    y,
    u: avg('UAVG') ?? 128,
    v: avg('VAVG') ?? 128,
    yLow: avg('YLOW') ?? 16,
    yHigh: avg('YHIGH') ?? 235
  };
}

function median(arr) {
  const s = arr.filter((v) => Number.isFinite(v)).sort((a, b) => a - b);
  if (s.length === 0) return null;
  const mid = Math.floor(s.length / 2);
  return s.length % 2 ? s[mid] : (s[mid - 1] + s[mid]) / 2;
}

/**
 * Tính bộ lọc cân màu cho từng clip để mọi cảnh về cùng độ sáng / sắc độ / tương phản trung vị của cả phim,
 * sau đó (tuỳ chọn) phủ thêm 1 "look" màu điện ảnh chung.
 * Trả về mảng chuỗi filter (mỗi phần tử ứng với 1 clip, có thể rỗng).
 */
function buildColorGradeFilters(statsList = [], colorGrade = 'auto_match') {
  const grade = COLOR_GRADE_MAP.has(colorGrade) ? colorGrade : 'auto_match';
  if (grade === 'none') return statsList.map(() => '');
  const look = COLOR_GRADE_MAP.get(grade)?.filter || '';

  const valid = statsList.filter(Boolean);
  const tY = median(valid.map((s) => s.y));
  const tU = median(valid.map((s) => s.u));
  const tV = median(valid.map((s) => s.v));
  const tRange = median(valid.map((s) => Math.max(20, s.yHigh - s.yLow)));

  return statsList.map((s) => {
    const parts = [];
    if (s && valid.length >= 2 && tY !== null) {
      const clamp = (v, lim) => Math.max(-lim, Math.min(lim, v));
      const dy = clamp(tY - s.y, 22) * 0.85;
      const du = clamp(tU - s.u, 10) * 0.85;
      const dv = clamp(tV - s.v, 10) * 0.85;
      const range = Math.max(20, s.yHigh - s.yLow);
      const cf = Math.max(0.88, Math.min(1.15, tRange / range));
      const needs = Math.abs(dy) > 1.5 || Math.abs(du) > 1 || Math.abs(dv) > 1 || Math.abs(cf - 1) > 0.02;
      if (needs) {
        const mid = s.y.toFixed(2);
        parts.push(
          `lutyuv=y='clip((val-${mid})*${cf.toFixed(3)}+${mid}+${dy.toFixed(2)},16,235)':u='clip(val+${du.toFixed(
            2
          )},16,240)':v='clip(val+${dv.toFixed(2)},16,240)'`
        );
      }
    }
    if (look) parts.push(look);
    return parts.length ? `${parts.join(',')},format=yuv420p` : '';
  });
}

async function computeColorGradeFiltersForClips(ffmpegBin, clipSpecs = [], colorGrade = 'auto_match', report = null) {
  const grade = COLOR_GRADE_MAP.has(colorGrade) ? colorGrade : 'auto_match';
  if (grade === 'none') return clipSpecs.map(() => '');
  const stats = [];
  for (let i = 0; i < clipSpecs.length; i++) {
    const spec = clipSpecs[i];
    if (typeof report === 'function') report(`🎨 Đang đo màu Cảnh ${spec.label || i + 1} (${i + 1}/${clipSpecs.length}) để cân màu đồng bộ...`);
    try {
      stats.push(await measureClipColorStats(ffmpegBin, spec.filePath, { startSec: spec.startSec || 0, durSec: spec.durSec || 0 }));
    } catch (_) {
      stats.push(null);
    }
  }
  return buildColorGradeFilters(stats, grade);
}

/**
 * Hậu kỳ & Xuất Bộ Phim Hoàn Chỉnh (Master Export):
 * - Nối toàn bộ các phân cảnh đã chọn theo đúng trình tự kịch bản
 * - Đồng bộ chuẩn khung hình rạp phim (16:9 / 21:9 CinemaScope / 9:16 / 1:1)
 * - Chuyển cảnh mượt mà + Lồng nhạc nền BGM tự động lặp & cân bằng âm lượng + Xuất file phụ đề .SRT + Tùy chọn đốt cứng phụ đề tiếng Việt
 */
async function renderFullCinemaMaster({
  appRootDir,
  accountManager,
  accountId,
  sceneIndices = null,
  movieTitle = '',
  aspectMode = 'auto',
  transitionEffect = 'director_smart',
  bgmFilePath = null,
  bgmVolume = 0.22,
  autoDuckBgm = true,
  burnSubtitles = false,
  colorGrade = 'auto_match',
  onProgress = null
}) {
  const report = (msg) => {
    if (typeof onProgress === 'function') {
      try {
        onProgress(msg);
      } catch (_) {}
    }
  };

  const acc = accountManager.getAccount(accountId);
  if (!acc) throw new Error('Không tìm thấy dự án phim.');

  const allCompletedRows = (acc.rows || [])
    .filter((r) => {
      const fp = resolveSceneVideoDiskPath(appRootDir, r);
      return Boolean(fp && fs.existsSync(fp));
    })
    .sort((a, b) => Number(a.index) - Number(b.index));

  const targetRows =
    Array.isArray(sceneIndices) && sceneIndices.length > 0
      ? sceneIndices
          .map((idx) => allCompletedRows.find((r) => Number(r.index) === Number(idx)))
          .filter(Boolean)
      : allCompletedRows.filter((r) => r.includeInExport !== false);

  if (targetRows.length === 0) {
    throw new Error('Chưa có phân cảnh nào đã quay xong video để xuất phim hoàn chỉnh!');
  }

  const ffmpegBin = getFfmpegExecutable(appRootDir);
  const outAccountDir = accountManager.ensureAccountOutputDir(accountId, { create: true });
  const masterDir = path.join(outAccountDir, 'Master_Movies');
  const tempDir = path.join(appRootDir, 'Project_Data', 'temp_editor', `cinema_master_${Date.now()}`);
  [outAccountDir, masterDir, tempDir].forEach((d) => {
    if (!fs.existsSync(d)) fs.mkdirSync(d, { recursive: true });
  });

  try {
    const firstClipPath = resolveSceneVideoDiskPath(appRootDir, targetRows[0]);
    const firstInfo = await probeMediaFile(ffmpegBin, firstClipPath);

    const isFullHd = (acc.settings?.filmConfig?.resolution || acc.settings?.resolution) === '1080p';
    const effectiveAspect =
      aspectMode && aspectMode !== 'auto'
        ? aspectMode
        : acc.settings?.filmConfig?.aspectRatio || 'auto';

    let targetW = firstInfo.width || 1280;
    let targetH = firstInfo.height || 720;

    if (effectiveAspect === '16:9') {
      targetW = isFullHd ? 1920 : 1280;
      targetH = isFullHd ? 1088 : 720;
      if (isFullHd) targetH = 1080; // 1920x1080 chuẩn
    } else if (effectiveAspect === '21:9') {
      targetW = isFullHd ? 1920 : 1280;
      targetH = isFullHd ? 816 : 544;
    } else if (effectiveAspect === '9:16') {
      targetW = isFullHd ? 1080 : 720;
      targetH = isFullHd ? 1920 : 1280;
    } else if (effectiveAspect === '1:1') {
      targetW = 1088;
      targetH = 1088;
    } else {
      targetW = Math.max(16, Math.round(targetW / 16) * 16);
      targetH = Math.max(16, Math.round(targetH / 16) * 16);
    }

    // Đảm bảo chia hết cho 2
    if (targetW % 2 !== 0) targetW += 1;
    if (targetH % 2 !== 0) targetH += 1;

    const normFiles = [];
    const clipDurations = [];

    // v1.8: Đo màu từng cảnh (đúng đoạn sẽ dùng sau khi cắt nhịp) để cân màu đồng bộ toàn phim
    const gradeSpecs = [];
    for (const row of targetRows) {
      const clipPath = resolveSceneVideoDiskPath(appRootDir, row);
      const pInfo = await probeMediaFile(ffmpegBin, clipPath);
      const rawD = Math.max(0.8, pInfo.duration || 10);
      const ts = Math.min(Math.max(0, Number(row.trimStartSec) || 0), Math.max(0, rawD - 0.8));
      const te = Math.min(Math.max(0, Number(row.trimEndSec) || 0), Math.max(0, rawD - 0.8 - ts));
      gradeSpecs.push({ filePath: clipPath, startSec: ts, durSec: Math.max(0.8, rawD - ts - te), label: row.index });
    }
    const gradeFilters = await computeColorGradeFiltersForClips(ffmpegBin, gradeSpecs, colorGrade || acc.settings?.colorGrade, report);

    for (let i = 0; i < targetRows.length; i++) {
      const row = targetRows[i];
      const clipPath = resolveSceneVideoDiskPath(appRootDir, row);
      report(`Đang chuẩn hóa hình ảnh & Mastering âm thanh chuẩn rạp Cảnh ${row.index} (${i + 1}/${targetRows.length})...`);

      const info = await probeMediaFile(ffmpegBin, clipPath);
      const rawDur = Math.max(0.8, info.duration || 10);
      const reqTrimStart = Math.max(0, Number(row.trimStartSec) || 0);
      const reqTrimEnd = Math.max(0, Number(row.trimEndSec) || 0);
      const maxTotalTrim = Math.max(0, rawDur - 0.8);
      const effectiveTrimStart = Math.min(reqTrimStart, maxTotalTrim);
      const effectiveTrimEnd = Math.min(reqTrimEnd, Math.max(0, maxTotalTrim - effectiveTrimStart));
      const dur = Math.max(0.8, rawDur - effectiveTrimStart - effectiveTrimEnd);
      const trimArgs =
        effectiveTrimStart > 0.01 || effectiveTrimEnd > 0.01
          ? ['-ss', effectiveTrimStart.toFixed(3), '-t', dur.toFixed(3)]
          : [];

      const segOut = path.join(tempDir, `scene_norm_${String(i).padStart(3, '0')}.mp4`);
      const baseVFilter = `scale=${targetW}:${targetH}:force_original_aspect_ratio=decrease:flags=lanczos:in_color_matrix=bt709:out_color_matrix=bt709,pad=${targetW}:${targetH}:(ow-iw)/2:(oh-ih)/2:black,setsar=1,fps=30,format=yuv420p`;
      const vFilter = gradeFilters[i] ? `${baseVFilter},${gradeFilters[i]}` : baseVFilter;

      if (info.hasAudio) {
        const fadeOutStart = Math.max(0, dur - 0.14).toFixed(3);
        const fallbackAf = `aresample=44100,aformat=sample_fmts=fltp:channel_layouts=stereo,afade=t=in:st=0:d=0.10,afade=t=out:st=${fadeOutStart}:d=0.14`;
        const masteredAf =
          dur >= 2.0
            ? `aresample=44100,loudnorm=I=-16:TP=-1.5:LRA=11,aresample=44100,aformat=sample_fmts=fltp:channel_layouts=stereo,afade=t=in:st=0:d=0.10,afade=t=out:st=${fadeOutStart}:d=0.14`
            : fallbackAf;
        try {
          await runFfmpeg(ffmpegBin, [
            '-y', '-i', clipPath, ...trimArgs, '-map_metadata', '-1', '-vf', vFilter, '-af', masteredAf,
            '-c:v', 'libx264', '-preset', 'fast', '-crf', '16', '-profile:v', 'high', '-level', '4.1',
            '-colorspace', 'bt709', '-color_primaries', 'bt709', '-color_trc', 'bt709',
            '-maxrate', '12M', '-bufsize', '24M',
            '-c:a', 'aac', '-b:a', '192k', '-ac', '2', '-ar', '44100', '-brand', 'mp42',
            segOut
          ]);
        } catch (_) {
          await runFfmpeg(ffmpegBin, [
            '-y', '-i', clipPath, ...trimArgs, '-map_metadata', '-1', '-vf', vFilter, '-af', fallbackAf,
            '-c:v', 'libx264', '-preset', 'fast', '-crf', '16', '-profile:v', 'high', '-level', '4.1',
            '-colorspace', 'bt709', '-color_primaries', 'bt709', '-color_trc', 'bt709',
            '-maxrate', '12M', '-bufsize', '24M',
            '-c:a', 'aac', '-b:a', '192k', '-ac', '2', '-ar', '44100', '-brand', 'mp42',
            segOut
          ]);
        }
      } else {
        await runFfmpeg(ffmpegBin, [
          '-y', '-i', clipPath, ...trimArgs,
          '-f', 'lavfi', '-t', dur.toFixed(3), '-i', 'anullsrc=channel_layout=stereo:sample_rate=44100',
          '-map_metadata', '-1', '-vf', vFilter, '-map', '0:v:0', '-map', '1:a:0',
          '-c:v', 'libx264', '-preset', 'fast', '-crf', '16', '-profile:v', 'high', '-level', '4.1',
          '-colorspace', 'bt709', '-color_primaries', 'bt709', '-color_trc', 'bt709',
          '-maxrate', '12M', '-bufsize', '24M',
          '-c:a', 'aac', '-b:a', '192k', '-ac', '2', '-ar', '44100', '-shortest', '-brand', 'mp42',
          segOut
        ]);
      }

      const normProbe = await probeMediaFile(ffmpegBin, segOut);
      clipDurations.push(normProbe.duration > 0.8 ? normProbe.duration : dur);
      normFiles.push(segOut);
    }

    const cleanTransition = String(transitionEffect || 'director_smart').trim().toLowerCase();
    const useXfade = normFiles.length > 1 && cleanTransition && cleanTransition !== 'none';
    const minClipDur = Math.min(...clipDurations);
    const effectiveTransSec = useXfade ? Math.max(0.12, Math.min(0.42, minClipDur * 0.25)) : 0;

    // Tính độ dài chuyển cảnh riêng cho từng điểm cắt (director_smart: cùng cảnh nối tiếp cắt siêu sát 0.08s, đổi cảnh mới mờ mượt 0.36s)
    const cutTransitionSecs = [];
    for (let k = 0; k < targetRows.length - 1; k++) {
      if (!useXfade) {
        cutTransitionSecs.push(0);
        continue;
      }
      const pairMin = Math.min(clipDurations[k], clipDurations[k + 1]);
      if (cleanTransition === 'director_smart') {
        const isChainedCut = Boolean(targetRows[k + 1].continueFromPrevScene);
        const desiredSec = isChainedCut ? 0.08 : 0.36;
        cutTransitionSecs.push(Math.max(0.06, Math.min(desiredSec, pairMin * 0.25)));
      } else {
        cutTransitionSecs.push(Math.max(0.12, Math.min(0.42, pairMin * 0.25)));
      }
    }

    // Tính chính xác mốc thời gian bắt đầu / kết thúc của từng phân cảnh để khớp phụ đề SRT 100%
    const scenesWithTiming = [];
    let timelineCursor = 0;
    for (let i = 0; i < targetRows.length; i++) {
      const cutOverlap = i === 0 ? 0 : cutTransitionSecs[i - 1] || 0;
      const startSec = i === 0 ? 0 : Math.max(0, timelineCursor - cutOverlap);
      const endSec = startSec + clipDurations[i];
      scenesWithTiming.push({
        rowIndex: targetRows[i].index,
        sceneTitle: targetRows[i].sceneTitle,
        dialogue: targetRows[i].dialogue || '',
        startSec,
        endSec
      });
      timelineCursor = endSec;
    }

    const stitchedVideoPath = path.join(tempDir, 'stitched_raw.mp4');
    report(`Đang dựng nối ${normFiles.length} phân cảnh phim...`);

    let mergedWithXfade = false;
    if (useXfade) {
      try {
        await mergeNormalizedSegmentsWithTransition(
          ffmpegBin,
          normFiles,
          stitchedVideoPath,
          cleanTransition,
          effectiveTransSec,
          0,
          cutTransitionSecs
        );
        mergedWithXfade = fs.existsSync(stitchedVideoPath) && fs.statSync(stitchedVideoPath).size > 20000;
      } catch (_) {
        mergedWithXfade = false;
      }
    }

    if (!mergedWithXfade) {
      if (normFiles.length === 1) {
        fs.copyFileSync(normFiles[0], stitchedVideoPath);
      } else {
        const concatListPath = path.join(tempDir, 'concat_list.txt');
        fs.writeFileSync(
          concatListPath,
          normFiles.map((p) => `file '${p.replace(/\\/g, '/').replace(/'/g, "'\\''")}'`).join('\n'),
          'utf8'
        );
        await runFfmpeg(ffmpegBin, [
          '-y', '-f', 'concat', '-safe', '0', '-i', concatListPath,
          '-map_metadata', '-1', '-c', 'copy', '-brand', 'mp42', '-movflags', '+faststart',
          stitchedVideoPath
        ]);
      }
    }

    const rawTitle = String(movieTitle || acc.settings?.exportMovieTitle || acc.name || 'Bo_Phim_AI').trim();
    const safeFileBase =
      rawTitle
        .normalize('NFD')
        .replace(/[\u0300-\u036f]/g, '')
        .replace(/đ/g, 'd')
        .replace(/Đ/g, 'D')
        .replace(/[^a-zA-Z0-9_-]+/g, '_')
        .replace(/^_+|_+$/g, '')
        .slice(0, 55) || 'MuseCinema_Master';

    const stamp = Date.now();
    const finalMp4Name = `${safeFileBase}_${stamp}.mp4`;
    const finalSrtName = `${safeFileBase}_${stamp}.srt`;
    const finalMp4Path = path.join(masterDir, finalMp4Name);
    const finalSrtPath = path.join(masterDir, finalSrtName);

    const srtResult = generateSrtFromScenes(scenesWithTiming, acc.characters || [], finalSrtPath);

    const resolvedBgm =
      bgmFilePath && fs.existsSync(bgmFilePath)
        ? bgmFilePath
        : acc.settings?.bgmAudio?.filePath && fs.existsSync(acc.settings.bgmAudio.filePath)
        ? acc.settings.bgmAudio.filePath
        : null;
    const vol = Math.max(0.02, Math.min(1.0, Number(bgmVolume ?? acc.settings?.bgmVolume ?? 0.22)));
    const useAutoDuck = autoDuckBgm !== undefined ? Boolean(autoDuckBgm) : acc.settings?.autoDuckBgm !== false;
    const wantBurnSubs = Boolean(burnSubtitles && srtResult.cueCount > 0);

    if (!resolvedBgm && !wantBurnSubs) {
      fs.copyFileSync(stitchedVideoPath, finalMp4Path);
    } else {
      report(
        wantBurnSubs && resolvedBgm
          ? 'Đang hòa âm Nhạc nền BGM (Auto-Ducking) & in Phụ đề tiếng Việt lên phim...'
          : resolvedBgm
          ? 'Đang hòa âm Nhạc nền BGM điện ảnh (Auto-Ducking)...'
          : 'Đang in Phụ đề tiếng Việt lên phim...'
      );

      // Copy file .srt vào tempDir với tên ASCII ngắn để bộ lọc subtitles của FFmpeg Windows không bị lỗi ký tự đường dẫn có dấu!
      const localSrtName = 'subs_burn.srt';
      if (wantBurnSubs) {
        fs.writeFileSync(path.join(tempDir, localSrtName), srtResult.srtContent, 'utf8');
      }

      const subFilter = wantBurnSubs
        ? `subtitles=${localSrtName}:force_style='FontName=Arial,FontSize=18,PrimaryColour=&H00FFFFFF,OutlineColour=&H00000000,BorderStyle=1,Outline=2,Shadow=1,MarginV=24'`
        : null;

      const duckAudioGraph = `[0:a]aresample=44100,aformat=sample_fmts=fltp:channel_layouts=stereo,asplit=2[vo_main][vo_sc];[1:a]aresample=44100,aformat=sample_fmts=fltp:channel_layouts=stereo,volume=${vol.toFixed(2)}[bgm_raw];[bgm_raw][vo_sc]sidechaincompress=threshold=0.025:ratio=5:attack=80:release=650[bgm_duck];[vo_main][bgm_duck]amix=inputs=2:duration=first:dropout_transition=2:normalize=0[aout]`;
      const plainAudioGraph = `[1:a]aresample=44100,volume=${vol.toFixed(2)}[bgm];[0:a][bgm]amix=inputs=2:duration=first:dropout_transition=2:normalize=0[aout]`;

      if (resolvedBgm && wantBurnSubs) {
        const runMixWithSubs = async (audioGraph) =>
          runFfmpeg(
            ffmpegBin,
            [
              '-y',
              '-i', stitchedVideoPath,
              '-stream_loop', '-1', '-i', resolvedBgm,
              '-filter_complex',
              `[0:v]${subFilter}[vout];${audioGraph}`,
              '-map', '[vout]',
              '-map', '[aout]',
              '-c:v', 'libx264', '-preset', 'fast', '-crf', '16', '-profile:v', 'high', '-level', '4.1',
              '-c:a', 'aac', '-b:a', '192k', '-ar', '44100', '-ac', '2',
              '-shortest', '-brand', 'mp42', '-movflags', '+faststart',
              finalMp4Path
            ],
            { cwd: tempDir }
          );
        if (useAutoDuck) {
          try {
            await runMixWithSubs(duckAudioGraph);
          } catch (_) {
            await runMixWithSubs(plainAudioGraph);
          }
        } else {
          await runMixWithSubs(plainAudioGraph);
        }
      } else if (resolvedBgm) {
        const runMixOnly = async (audioGraph) =>
          runFfmpeg(ffmpegBin, [
            '-y',
            '-i', stitchedVideoPath,
            '-stream_loop', '-1', '-i', resolvedBgm,
            '-filter_complex',
            audioGraph,
            '-map', '0:v:0',
            '-map', '[aout]',
            '-c:v', 'copy',
            '-c:a', 'aac', '-b:a', '192k', '-ar', '44100', '-ac', '2',
            '-shortest', '-brand', 'mp42', '-movflags', '+faststart',
            finalMp4Path
          ]);
        if (useAutoDuck) {
          try {
            await runMixOnly(duckAudioGraph);
          } catch (_) {
            await runMixOnly(plainAudioGraph);
          }
        } else {
          await runMixOnly(plainAudioGraph);
        }
      } else {
        await runFfmpeg(
          ffmpegBin,
          [
            '-y',
            '-i', stitchedVideoPath,
            '-vf', subFilter,
            '-c:v', 'libx264', '-preset', 'fast', '-crf', '16', '-profile:v', 'high', '-level', '4.1',
            '-c:a', 'copy',
            '-brand', 'mp42', '-movflags', '+faststart',
            finalMp4Path
          ],
          { cwd: tempDir }
        );
      }
    }

    const finalProbe = await probeMediaFile(ffmpegBin, finalMp4Path);
    const stat = fs.statSync(finalMp4Path);
    const publicVideoUrl = accountManager.buildAccountOutputPublicUrl(accountId, 'Master_Movies', finalMp4Name);
    const publicSrtUrl =
      srtResult.cueCount > 0
        ? accountManager.buildAccountOutputPublicUrl(accountId, 'Master_Movies', finalSrtName)
        : null;

    const exportMeta = {
      title: rawTitle,
      fileName: finalMp4Name,
      filePath: finalMp4Path,
      publicUrl: publicVideoUrl,
      srtFileName: srtResult.cueCount > 0 ? finalSrtName : null,
      srtFilePath: srtResult.cueCount > 0 ? finalSrtPath : null,
      srtPublicUrl: publicSrtUrl,
      subtitleCount: srtResult.cueCount,
      sceneCount: targetRows.length,
      colorGrade: COLOR_GRADE_MAP.has(colorGrade) ? colorGrade : 'auto_match',
      duration: Number(finalProbe.duration.toFixed(2)),
      width: targetW,
      height: targetH,
      sizeBytes: stat.size,
      exportedAt: new Date().toISOString()
    };

    acc.settings.lastMasterExport = exportMeta;
    accountManager.save();

    return {
      ok: true,
      ...exportMeta
    };
  } finally {
    try {
      fs.rmSync(tempDir, { recursive: true, force: true });
    } catch (_) {}
  }
}

module.exports = {
  TRANSITION_EFFECTS,
  getFfmpegExecutable,
  runFfmpeg,
  probeMediaFile,
  ensureUniversalPlayableMp4,
  extractFrameAtTimeFromVideo,
  extractLastFrameFromVideo,
  concatExtendedPartFiles,
  generateSrtFromScenes,
  renderFullCinemaMaster,
  resolveSceneVideoDiskPath,
  mergeNormalizedSegmentsWithTransition,
  runFfmpegCaptureStderr,
  analyzeClipQuality,
  COLOR_GRADE_PRESETS,
  measureClipColorStats,
  buildColorGradeFilters,
  computeColorGradeFiltersForClips
};
