@echo off
chcp 65001 >nul
title MUSE CINEMA STUDIO 2.4 - NGUYEN LINH AI (0967981918)
cd /d "%~dp0"

echo ====================================================================
echo   DANG KHOI DONG MUSE CINEMA STUDIO 2.4 - NGUYEN LINH AI (0967981918)
echo ====================================================================

if not exist "public\index.html" (
  echo.
  echo [CANH BAO] BAN CHUA GIAI NEN DAY DU FILE CONG CU!
  echo Vui long bam Chuot phai vao file .rar / .zip -^> Chon "Extract to..."
  echo ^(Giai nen ra thu muc rieng^) va doi xong 100%% roi moi mo phan mem!
  echo.
  pause
  exit /b 1
)

if not exist "server.js" (
  echo.
  echo [CANH BAO] Khong tim thay server.js! Vui long giai nen day du toan bo thu muc.
  echo.
  pause
  exit /b 1
)

set "NODE_EXE=runtime\node\node.exe"
if not exist "%NODE_EXE%" (
  set "NODE_EXE=node"
)

if not exist "ChromeProfile_Data" mkdir "ChromeProfile_Data"
if not exist "Output_Videos" mkdir "Output_Videos"
if not exist "Project_Data" mkdir "Project_Data"

set "PORT=3890"
start "" /b "%NODE_EXE%" "server.js"
timeout /t 2 /nobreak >nul
start "" "http://127.0.0.1:3890"
