const fs = require('fs');
const path = require('path');

const MAX_FILM_CHARACTERS = 50;
const MAX_CHAR_REF_IMAGES = 2;

const FILM_GENRES = [
  {
    id: '3d_pixar',
    icon: '🧸',
    shortName: 'Hoạt Hình 3D Pixar',
    subDesc: 'Nhân vật 3D sống động, ánh sáng rạp chiếu',
    label: '🧸 Hoạt Hình 3D (Pixar / Disney)',
    defaultAspect: '16:9',
    eraGuard: false,
    styleDirective:
      'High-end 3D CGI feature animation in Pixar / Walt Disney Animation Studios style: appealing stylized 3D character sculpts with consistent proportions, expressive eyes and subtle facial micro-expressions, rich subsurface skin scattering, tactile fabric and hair grooming, warm cinematic key-and-rim lighting, and cohesive theatrical color grading.'
  },
  {
    id: '2d_anime',
    icon: '🌸',
    shortName: 'Hoạt Hình 2D Anime',
    subDesc: 'Nét vẽ Ghibli / Shinkai giàu cảm xúc',
    label: '🌸 Hoạt Hình 2D Anime (Ghibli / Shinkai)',
    defaultAspect: '16:9',
    eraGuard: false,
    styleDirective:
      'Theatrical 2D Japanese anime feature film aesthetic inspired by Studio Ghibli and Makoto Shinkai: crisp hand-drawn character linework, consistent cel-shaded facial geometry and outfits, painterly atmospheric backgrounds, luminous volumetric sky and sunlight, and fluid 2D character animation.'
  },
  {
    id: 'historical_epic',
    icon: '⚔️',
    shortName: 'Lịch Sử & Cổ Trang',
    subDesc: 'Hào khí cổ đại, giáp trụ & thành quách xưa',
    label: '⚔️ Phim Lịch Sử / Cổ Trang Hào Hùng',
    defaultAspect: '16:9',
    eraGuard: true,
    styleDirective:
      'Grand historical period epic cinema: authentic period-accurate traditional garments, armor, textiles, hairstyles, props, and ancient architecture; natural sunlight, firelight/torchlight, atmospheric mist, anamorphic 35mm theatrical color grading. STRICT HISTORICAL PURITY: ZERO modern buildings, ZERO electricity/wires/streetlights, ZERO cars/plastics/watches/modern signage.'
  },
  {
    id: 'cinema_35mm',
    icon: '🎥',
    shortName: 'Điện Ảnh Đời Thực',
    subDesc: 'Quay máy phim 35mm chân thực như người thật',
    label: '🎥 Phim Điện Ảnh Đời Thực (35mm Live-Action)',
    defaultAspect: '16:9',
    eraGuard: false,
    styleDirective:
      'Photorealistic live-action theatrical cinema shot on ARRI Alexa Mini LF with 35mm anamorphic prime lenses: authentic human skin texture, natural film grain, shallow cinematic depth of field, motivated three-point dramatic lighting, and cohesive Hollywood color grading.'
  },
  {
    id: 'xianxia_fantasy',
    icon: '🐉',
    shortName: 'Tiên Hiệp / Huyền Huyễn',
    subDesc: 'Cổ phong kỳ ảo, kiếm hiệp & thần thoại',
    label: '🐉 Tiên Hiệp / Huyền Huyễn Kỳ Ảo',
    defaultAspect: '16:9',
    eraGuard: true,
    styleDirective:
      'High-budget Eastern Xianxia & mythical fantasy cinema: flowing layered silk ancient robes, intricate hairpins/crowns, ethereal spiritual aura, mist-shrouded celestial peaks and ancient pavilions, dramatic mystical lighting. STRICT ANCIENT FANTASY PURITY: ZERO modern objects or contemporary clothing.'
  },
  {
    id: 'fairy_tale_kids',
    icon: '🧚',
    shortName: 'Cổ Tích Thiếu Nhi',
    subDesc: 'Màu sắc rực rỡ, ngụ ngôn & kể chuyện bé nghe',
    label: '🧚 Cổ Tích / Ngụ Ngôn Thiếu Nhi',
    defaultAspect: '16:9',
    eraGuard: true,
    styleDirective:
      'Enchanting storybook fairy-tale feature film: vibrant warm magical color palette, wholesome expressive characters, charming village/forest/kingdom environments, soft golden-hour glow, and clear family-friendly visual storytelling with zero modern clutter.'
  },
  {
    id: 'buddhist_spiritual',
    icon: '🪷',
    shortName: 'Phật Giáo & Tâm Linh',
    subDesc: 'Truyện nhân quả, thiền định trang nghiêm',
    label: '🪷 Phật Giáo / Tâm Linh Nhân Quả',
    defaultAspect: '16:9',
    eraGuard: true,
    styleDirective:
      'Reverent Eastern spiritual & karmic parable cinema: serene ancient temple, lotus pond, and traditional Asian village settings, warm golden incense and morning sunbeams, peaceful compassionate character expressions, dignified traditional attire, zero modern distractions.'
  },
  {
    id: 'horror_thriller',
    icon: '🕯️',
    shortName: 'Kinh Dị & Trinh Thám',
    subDesc: 'Bầu không khí u tối, bí ẩn hồi hộp',
    label: '🕯️ Kinh Dị / Trinh Thám Bí Ẩn',
    defaultAspect: '16:9',
    eraGuard: false,
    styleDirective:
      'Suspenseful psychological thriller & mystery horror cinema: moody low-key chiaroscuro lighting, deep shadows, desaturated cold teal-and-amber palette, subtle volumetric mist, and tense controlled camera movement.'
  },
  {
    id: 'scifi_cyberpunk',
    icon: '🚀',
    shortName: 'Khoa Học Viễn Tưởng',
    subDesc: 'Vũ trụ, thế giới tương lai & Cyberpunk',
    label: '🚀 Khoa Học Viễn Tưởng (Sci-Fi)',
    defaultAspect: '21:9',
    eraGuard: false,
    styleDirective:
      'AAA theatrical science-fiction cinema: detailed futuristic architecture, spacecraft/cybernetic props, volumetric neon and holographic illumination, sleek atmospheric fog, anamorphic lens flares, and crisp futuristic costume design.'
  },
  {
    id: 'survival_prehistoric',
    icon: '🦖',
    shortName: 'Sinh Tồn & Tiền Sử',
    subDesc: 'Rừng rậm nguyên sinh, phiêu lưu hoang dã',
    label: '🦖 Sinh Tồn / Tiền Sử Hoang Dã',
    defaultAspect: '16:9',
    eraGuard: true,
    styleDirective:
      'Epic wilderness survival & prehistoric cinema: untouched primeval jungle, caves, rivers, and rugged natural terrain, tactile earth/rain/fire textures, dramatic natural daylight and campfire lighting, zero modern man-made structures.'
  },
  {
    id: 'family_drama',
    icon: '💔',
    shortName: 'Tâm Lý & Gia Đình',
    subDesc: 'Phim ngắn cảm xúc, đời thường, tổng tài',
    label: '💔 Tâm Lý Xã Hội / Drama Gia Đình',
    defaultAspect: '9:16',
    eraGuard: false,
    styleDirective:
      'Polished contemporary Asian drama & emotional cinema: crisp expressive close-ups and two-shots, refined interiors and wardrobe, flattering cinematic lighting, and authentic emotional acting.'
  },
  {
    id: 'documentary_story',
    icon: '🌍',
    shortName: 'Tài Liệu Đời Sống',
    subDesc: 'Kể chuyện lịch sử, thiên nhiên & ký sự',
    label: '🌍 Phim Tài Liệu / Ký Sự Đời Sống',
    defaultAspect: '16:9',
    eraGuard: false,
    styleDirective:
      'Poetic cinematic documentary realism: authentic real-world environments, natural golden-hour and window lighting, grounded human expressions, smooth gimbal camera intimacy, and rich documentary color tone.'
  },
  {
    id: 'custom',
    icon: '✨',
    shortName: 'Phong Cách Tùy Chỉnh',
    subDesc: 'Tự định nghĩa nét vẽ / chất phim riêng',
    label: '✨ Phong Cách Điện Ảnh Tự Định Nghĩa',
    defaultAspect: '16:9',
    eraGuard: false,
    styleDirective:
      'Cohesive theatrical filmmaking aesthetic with 100% consistent visual art direction, lighting, color palette, and character design across every scene.'
  }
];

const CINEMA_VOICE_PRESETS = [
  {
    id: 'auto',
    label: '🎭 Tự khớp giới tính & độ tuổi nhân vật',
    directive: 'Natural expressive Vietnamese character voice matching the character age, gender, and emotion.'
  },
  {
    id: 'vi_storyteller_cinema',
    label: '🎧 Người Kể Chuyện Điện Ảnh — Trầm lắng, truyền cảm',
    directive:
      'Deep, resonant, emotionally captivating Vietnamese cinematic narrator voice (giọng kể chuyện điện ảnh trầm ấm, sâu lắng, ngắt nghỉ giàu cảm xúc).'
  },
  {
    id: 'vi_mc_professional',
    label: '🎙️ Thuyết Minh Phim / Tài Liệu — Hùng hồn, rõ chữ',
    directive:
      'Authoritative, crystal-clear professional Vietnamese documentary/history narrator voice (giọng thuyết minh phim lịch sử chuẩn mực, hào sảng, rõ từng chữ).'
  },
  {
    id: 'vi_male_hero_epic',
    label: '🦁 Nam Chính / Tướng Quân — Trầm hùng, uy nghiêm',
    directive:
      'Commanding, resonant, heroic Vietnamese adult male voice (giọng nam trầm hùng, uy lực, đĩnh đạc của bậc tướng quân / nam chính).'
  },
  {
    id: 'vi_male_young_bright',
    label: '👦 Nam Trẻ / Thiếu Niên — Trẻ trung, nhiệt huyết',
    directive:
      'Youthful, energetic, sincere Vietnamese young man voice (20-26 years old, giọng nam trẻ nhiệt huyết, rõ nét).'
  },
  {
    id: 'vi_male_elder_wise',
    label: '👴 Ông Lão / Bậc Trưởng Bối — Trầm khàn, từng trải',
    directive:
      'Wise, warm, slightly gravelly elderly Vietnamese grandfather/sage voice (65+ years old, giọng cụ già hiền từ, từng trải, chậm rãi).'
  },
  {
    id: 'vi_female_lead_gentle',
    label: '👩 Nữ Chính — Dịu dàng, trong trẻo, giàu cảm xúc',
    directive:
      'Clear, graceful, emotionally expressive young Vietnamese female lead voice (22-28 years old, giọng nữ chính trong trẻo, truyền cảm).'
  },
  {
    id: 'vi_female_noble_warm',
    label: '👑 Nữ Vương / Người Mẹ — Đằm thắm, uy nghi',
    directive:
      'Warm, dignified, mature Vietnamese woman voice (35-48 years old, giọng phụ nữ trưởng thành đằm thắm, sâu sắc).'
  },
  {
    id: 'vi_female_elder_kind',
    label: '👵 Bà Lão Hiền Từ — Ấm áp, kể chuyện xưa',
    directive:
      'Gentle, affectionate elderly Vietnamese grandmother voice (65+ years old, giọng bà cụ hiền hậu, ấm áp).'
  },
  {
    id: 'vi_child_boy',
    label: '🧒 Bé Trai (6–11 tuổi) — Hồn nhiên, lanh lợi',
    directive:
      'Authentic, innocent, bright Vietnamese young boy child voice (7-10 years old, giọng bé trai hồn nhiên, trong sáng).'
  },
  {
    id: 'vi_child_girl',
    label: '👧 Bé Gái (6–11 tuổi) — Trong veo, đáng yêu',
    directive:
      'Sweet, pure, cheerful Vietnamese young girl child voice (7-10 years old, giọng bé gái trong veo, dễ thương).'
  },
  {
    id: 'vi_male_south_warm',
    label: '🌴 Nam Miền Nam — Gần gũi, hào sảng',
    directive:
      'Warm, authentic Southern Vietnamese (Saigon) male voice, natural and expressive.'
  },
  {
    id: 'vi_female_south_sweet',
    label: '🌸 Nữ Miền Nam — Ngọt ngào, tự nhiên',
    directive:
      'Sweet, natural Southern Vietnamese (Saigon) female voice, clear emotional delivery.'
  },
  {
    id: 'en_male_cinema',
    label: '🌐 Tiếng Anh (Nam) — Hollywood Cinema',
    directive: 'Deep expressive international English cinematic male voice.'
  },
  {
    id: 'en_female_cinema',
    label: '🌐 Tiếng Anh (Nữ) — International Storytelling',
    directive: 'Warm, articulate international English cinematic female voice.'
  },
  {
    id: 'custom',
    label: '✍️ Tự mô tả chất giọng riêng...',
    directive: 'Expressive studio-clear character voice.'
  }
];

const CINEMA_LIGHTING_PRESETS = [
  {
    id: 'auto',
    label: '🎬 Tự động theo thể loại & bối cảnh từng cảnh (Mặc định)',
    directive: ''
  },
  {
    id: 'golden_hour',
    label: '🌅 Nắng Vàng Hoàng Hôn / Bình Minh Ấm Áp (Golden Hour)',
    directive:
      'Warm cinematic golden-hour sunlight, soft long atmospheric shadows, glowing amber-gold rim light on characters, rich nostalgic color warmth.'
  },
  {
    id: 'bright_daylight',
    label: '☀️ Ban Ngày Trong Trẻo & Tươi Sáng (Natural Daylight)',
    directive:
      'Crisp bright natural daylight illumination, clear sky light, clean vibrant true-to-life colors, soft balanced fill light on faces.'
  },
  {
    id: 'soft_studio_3d',
    label: '✨ Ánh Sáng Rạp Chiếu 3D Mềm Mại (Soft Studio Cinema)',
    directive:
      'Polished theatrical three-point key-fill-rim lighting, gentle volumetric glow, smooth flattering facial illumination, vibrant cinema grading.'
  },
  {
    id: 'volumetric_godrays',
    label: '🌤️ Tia Nắng Xuyên Sương Sớm / Tán Rừng (Volumetric Sunbeams)',
    directive:
      'Poetic volumetric sunbeams (god-rays) piercing through gentle morning mist or foliage, luminous atmospheric depth, warm highlights and soft shadows.'
  },
  {
    id: 'moonlight_night',
    label: '🌙 Đêm Trăng Thanh & Sương Mờ Huyền Ảo (Moonlit Night)',
    directive:
      'Silvery-blue cinematic moonlight illumination, gentle night mist, deep atmospheric shadows with clear facial visibility and cool rim highlights.'
  },
  {
    id: 'firelight_lantern',
    label: '🏮 Ánh Lửa Trại / Đèn Dầu / Đèn Lồng Cổ Xưa (Warm Fire & Lantern)',
    directive:
      'Warm flickering firelight, candle/oil-lamp or traditional lantern glow against rich dark surroundings, authentic period warmth on faces and garments.'
  },
  {
    id: 'dramatic_chiaroscuro',
    label: '🎭 Tương Phản Điện Ảnh Sâu & Gay Cấn (Dramatic High-Contrast)',
    directive:
      'Dramatic high-contrast chiaroscuro cinema lighting, sculpted directional key light, deep moody shadows, intense theatrical atmosphere.'
  },
  {
    id: 'dark_mystery_fog',
    label: '🕯️ U Tối, Sương Mù & Bí Ẩn Hồi Hộp (Low-Key Mystery)',
    directive:
      'Low-key suspenseful dark mystery lighting, cold desaturated teal-grey shadows, eerie volumetric fog, subtle practical light sources.'
  },
  {
    id: 'rainy_nostalgic',
    label: '🌧️ Chiều Mưa Trầm Buồn & Mặt Đường Phản Chiếu (Rainy Mood)',
    directive:
      'Overcast rainy cinematic mood, diffused melancholic cool daylight mixed with warm interior/window reflections on wet surfaces.'
  },
  {
    id: 'neon_cyber',
    label: '🔮 Đèn Neon Phố Đêm / Tương Lai Rực Rỡ (Neon Night)',
    directive:
      'Vibrant cyan, magenta, and warm neon night illumination, glossy street reflections, sleek atmospheric haze, crisp futuristic rim lighting.'
  },
  {
    id: 'custom',
    label: '✍️ Tự mô tả ánh sáng riêng...',
    directive: ''
  }
];

const VALID_GENRE_IDS = new Set(FILM_GENRES.map((g) => g.id));
const VALID_VOICE_IDS = new Set(CINEMA_VOICE_PRESETS.map((v) => v.id));
const VALID_LIGHTING_IDS = new Set(CINEMA_LIGHTING_PRESETS.map((l) => l.id));
const VALID_AUDIO_MODES = new Set(['mixed', 'narrator', 'dialogue', 'ambient_only']);
const VALID_CONTINUITY_MODES = new Set(['parallel_fast', 'sequential_chain']);

function stripVietnameseAccents(str) {
  return String(str || '')
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/đ/g, 'd')
    .replace(/Đ/g, 'D');
}

function sanitizeCharacterTag(rawTagOrName, fallbackIndex = 1) {
  const raw = String(rawTagOrName || '').trim().replace(/^@+/, '');
  const words = stripVietnameseAccents(raw)
    .replace(/[^a-zA-Z0-9\s_]+/g, ' ')
    .trim()
    .split(/\s+/)
    .filter(Boolean);
  if (words.length === 0) return `@NhanVat${fallbackIndex}`;
  const pascal = words
    .map((w) => w.charAt(0).toUpperCase() + w.slice(1))
    .join('')
    .slice(0, 28);
  return `@${pascal || `NhanVat${fallbackIndex}`}`;
}

function getCinemaVoiceDirective(presetId = 'auto', customNote = '') {
  const found = CINEMA_VOICE_PRESETS.find((v) => v.id === presetId) || CINEMA_VOICE_PRESETS[0];
  const note = String(customNote || '').trim();
  if (presetId === 'custom' && note) {
    return `Custom locked character voice: ${note}.`;
  }
  if (note) {
    return `${found.directive} Additional voice nuance: ${note}.`;
  }
  return found.directive;
}

function getFilmGenreInfo(genreId = '3d_pixar', customStylePrompt = '') {
  const found = FILM_GENRES.find((g) => g.id === genreId) || FILM_GENRES[0];
  const customClean = String(customStylePrompt || '').trim();
  const fullStyleDirective =
    found.id === 'custom' && customClean
      ? `${customClean}. Maintain 100% consistent visual style, lighting, and character aesthetics across all scenes.`
      : customClean
      ? `${found.styleDirective} Additional director style note: ${customClean}`
      : found.styleDirective;
  return {
    ...found,
    fullStyleDirective
  };
}

function getCinemaLightingDirective(lightingPreset = 'auto', customLightingNote = '') {
  const found = CINEMA_LIGHTING_PRESETS.find((l) => l.id === lightingPreset) || CINEMA_LIGHTING_PRESETS[0];
  const customClean = String(customLightingNote || '').trim();
  if (found.id === 'custom') {
    return customClean;
  }
  if (found.directive && customClean) {
    return `${found.directive} Additional director lighting note: ${customClean}`;
  }
  return found.directive || customClean;
}

function createDefaultFilmConfig() {
  return {
    genreId: '3d_pixar',
    customStylePrompt: '',
    worldLock: '',
    lightingPreset: 'auto',
    customLightingNote: '',
    aspectRatio: '16:9',
    resolution: '720p',
    audioMode: 'mixed',
    narratorVoicePreset: 'vi_storyteller_cinema',
    narratorVoiceNote: '',
    continuityMode: 'parallel_fast',
    targetMovieSeconds: 180,
    sceneDurationSeconds: 10,
    concurrency: 4,
    storyDraft: ''
  };
}

function normalizeFilmConfig(raw = {}) {
  const def = createDefaultFilmConfig();
  if (!raw || typeof raw !== 'object') return def;
  const genreId = VALID_GENRE_IDS.has(raw.genreId) ? raw.genreId : def.genreId;
  const lightingPreset = VALID_LIGHTING_IDS.has(raw.lightingPreset) ? raw.lightingPreset : def.lightingPreset;
  const audioMode = VALID_AUDIO_MODES.has(raw.audioMode) ? raw.audioMode : def.audioMode;
  const continuityMode = VALID_CONTINUITY_MODES.has(raw.continuityMode) ? raw.continuityMode : def.continuityMode;
  const aspectRatio = ['16:9', '21:9', '9:16', '1:1'].includes(raw.aspectRatio) ? raw.aspectRatio : def.aspectRatio;
  const resolution = raw.resolution === '1080p' ? '1080p' : '720p';
  const targetMovieSeconds = Math.max(20, Math.min(7200, Math.round(Number(raw.targetMovieSeconds) || 180)));
  const sceneDurationSeconds = Math.max(5, Math.min(60, Math.round(Number(raw.sceneDurationSeconds) || 10)));
  const concurrency = Math.max(1, Math.min(16, Math.round(Number(raw.concurrency) || 4)));

  return {
    genreId,
    customStylePrompt: typeof raw.customStylePrompt === 'string' ? raw.customStylePrompt.trim().slice(0, 600) : '',
    worldLock: typeof raw.worldLock === 'string' ? raw.worldLock.trim().slice(0, 1000) : '',
    lightingPreset,
    customLightingNote:
      typeof raw.customLightingNote === 'string' ? raw.customLightingNote.trim().slice(0, 500) : '',
    aspectRatio,
    resolution,
    audioMode,
    narratorVoicePreset: VALID_VOICE_IDS.has(raw.narratorVoicePreset)
      ? raw.narratorVoicePreset
      : def.narratorVoicePreset,
    narratorVoiceNote: typeof raw.narratorVoiceNote === 'string' ? raw.narratorVoiceNote.trim().slice(0, 260) : '',
    continuityMode,
    targetMovieSeconds,
    sceneDurationSeconds,
    concurrency,
    storyDraft: typeof raw.storyDraft === 'string' ? raw.storyDraft.slice(0, 60000) : ''
  };
}

function normalizeCharacterRefImages(rawImages) {
  if (!Array.isArray(rawImages)) return [];
  return rawImages
    .filter((im) => im && typeof im === 'object' && im.filePath)
    .slice(0, MAX_CHAR_REF_IMAGES)
    .map((im, idx) => ({ ...im, slot: idx }));
}

function normalizeFilmCharacters(rawList) {
  if (!Array.isArray(rawList)) return [];
  const usedTags = new Set();
  const out = [];

  for (let i = 0; i < Math.min(MAX_FILM_CHARACTERS, rawList.length); i++) {
    const item = rawList[i];
    if (!item || typeof item !== 'object') continue;
    const id =
      typeof item.id === 'string' && item.id.trim()
        ? item.id.trim()
        : `char_${Date.now().toString(36)}_${i + 1}`;
    const name = String(item.name || `Nhân vật ${i + 1}`).trim().slice(0, 60) || `Nhân vật ${i + 1}`;
    let tag = sanitizeCharacterTag(item.tag || name, i + 1);
    if (usedTags.has(tag.toLowerCase())) {
      tag = `${tag}_${i + 1}`;
    }
    usedTags.add(tag.toLowerCase());

    out.push({
      id,
      name,
      tag,
      roleType: item.roleType === 'narrator' ? 'narrator' : 'character',
      appearanceDna: typeof item.appearanceDna === 'string' ? item.appearanceDna.trim().slice(0, 650) : '',
      voicePreset: VALID_VOICE_IDS.has(item.voicePreset) ? item.voicePreset : 'auto',
      voiceCustomNote: typeof item.voiceCustomNote === 'string' ? item.voiceCustomNote.trim().slice(0, 260) : '',
      referenceImages: normalizeCharacterRefImages(item.referenceImages)
    });
  }
  return out;
}

function detectCharactersInSceneText(text = '', allCharacters = []) {
  if (!text || !Array.isArray(allCharacters) || allCharacters.length === 0) return [];
  const hay = String(text);
  const hayLower = hay.toLowerCase();
  const hayAscii = stripVietnameseAccents(hayLower);
  const matched = [];

  for (const ch of allCharacters) {
    if (!ch) continue;
    const tagLower = String(ch.tag || '').toLowerCase();
    if (tagLower && hayLower.includes(tagLower)) {
      matched.push(ch);
      continue;
    }
    const cleanName = String(ch.name || '').trim();
    if (cleanName.length >= 2) {
      const nameLower = cleanName.toLowerCase();
      if (hayLower.includes(nameLower)) {
        matched.push(ch);
        continue;
      }
      const nameAscii = stripVietnameseAccents(nameLower).trim();
      if (nameAscii.length >= 4 && hayAscii.includes(nameAscii)) {
        matched.push(ch);
      }
    }
  }
  return matched;
}

function resolveSceneCharacters(row, allCharacters = []) {
  if (!Array.isArray(allCharacters) || allCharacters.length === 0) return [];
  const byId = new Map(allCharacters.map((c) => [c.id, c]));
  const ordered = [];
  const seen = new Set();

  const explicitIds = Array.isArray(row?.sceneCharacterIds)
    ? row.sceneCharacterIds
    : Array.isArray(row?.characterIds)
    ? row.characterIds
    : [];

  for (const cid of explicitIds) {
    const found = byId.get(cid);
    if (found && !seen.has(found.id)) {
      seen.add(found.id);
      ordered.push(found);
    }
  }

  const combinedText = `${row?.prompt || ''}\n${row?.dialogue || ''}`;
  const autoFound = detectCharactersInSceneText(combinedText, allCharacters);
  for (const ch of autoFound) {
    if (!seen.has(ch.id)) {
      seen.add(ch.id);
      ordered.push(ch);
    }
  }
  return ordered;
}

function parseSceneMultiSpeakerLines(rawDialogue, allCharacters = []) {
  const clean = String(rawDialogue || '').trim();
  if (!clean) return [];

  const lines = clean
    .split(/\r?\n/)
    .map((l) => l.trim())
    .filter(Boolean);

  const parsed = [];
  for (const line of lines) {
    const m = line.match(/^(?:\[([^\]]+)\]|(@[a-zA-Z0-9_]+)|([^:"“”]{1,28}))\s*:\s*(.+)$/);
    if (m) {
      const rawSpeaker = String(m[1] || m[2] || m[3] || '').trim();
      const text = String(m[4] || '')
        .replace(/^[“"«]+|[”"»]+$/g, '')
        .trim();
      if (!text) continue;

      const speakerNorm = stripVietnameseAccents(rawSpeaker.toLowerCase()).replace(/^@+/, '').trim();
      const isNarrator =
        /^(dan\s*chuyen|nguoi\s*dan|nguoi\s*ke|thuyet\s*minh|narrator|voiceover|vo|ke\s*chuyen)$/i.test(
          speakerNorm
        );

      if (isNarrator) {
        parsed.push({ type: 'narrator', speakerLabel: 'Người dẫn chuyện', character: null, text });
        continue;
      }

      let matchedChar = null;
      for (const ch of allCharacters) {
        const chTagClean = stripVietnameseAccents(ch.tag.toLowerCase()).replace(/^@+/, '');
        const chNameClean = stripVietnameseAccents(ch.name.toLowerCase()).trim();
        if (speakerNorm === chTagClean || speakerNorm === chNameClean || chNameClean.includes(speakerNorm)) {
          matchedChar = ch;
          break;
        }
      }

      if (matchedChar && matchedChar.roleType === 'narrator') {
        parsed.push({ type: 'narrator', speakerLabel: matchedChar.name, character: matchedChar, text });
      } else {
        parsed.push({
          type: 'character',
          speakerLabel: matchedChar ? matchedChar.name : rawSpeaker,
          character: matchedChar,
          text
        });
      }
    } else {
      const cleanSpeech = line.replace(/^[“"«]+|[”"»]+$/g, '').trim();
      if (cleanSpeech) {
        parsed.push({ type: 'default', speakerLabel: '', character: null, text: cleanSpeech });
      }
    }
  }
  return parsed;
}

function buildSceneCastReferenceImages({
  sceneCharacters = [],
  rowReferenceImages = [],
  prevSceneLastFramePath = null,
  tempDir = null,
  rowIndex = 1
}) {
  const maxTotalSlots = 5;
  const needPrevSceneSlot = Boolean(prevSceneLastFramePath && fs.existsSync(prevSceneLastFramePath));
  const maxCastAndRowSlots = needPrevSceneSlot ? maxTotalSlots - 1 : maxTotalSlots;

  const selected = [];
  const usedFilePaths = new Set();

  const validRowImgs = (Array.isArray(rowReferenceImages) ? rowReferenceImages : []).filter(
    (im) => im && im.filePath && fs.existsSync(im.filePath)
  );
  for (const rim of validRowImgs) {
    if (selected.length >= Math.min(2, maxCastAndRowSlots)) break;
    const norm = path.resolve(rim.filePath).toLowerCase();
    if (!usedFilePaths.has(norm)) {
      usedFilePaths.add(norm);
      selected.push({ ...rim, role: 'scene_environment_or_prop' });
    }
  }

  const onScreenChars = sceneCharacters.filter((c) => c && c.roleType !== 'narrator');
  for (const ch of onScreenChars) {
    if (selected.length >= maxCastAndRowSlots) break;
    const charImgs = Array.isArray(ch.referenceImages)
      ? ch.referenceImages.filter((im) => im && im.filePath && fs.existsSync(im.filePath))
      : [];
    if (charImgs.length === 0) continue;

    const primaryImg = charImgs[0];
    const resolvedPrimary = path.resolve(primaryImg.filePath).toLowerCase();
    if (!usedFilePaths.has(resolvedPrimary)) {
      let targetPath = primaryImg.filePath;
      let targetName = primaryImg.savedName || primaryImg.fileName || `${ch.tag.replace('@', '')}.png`;
      if (tempDir && fs.existsSync(tempDir)) {
        const ext = path.extname(primaryImg.filePath) || '.png';
        const cleanTag = ch.tag.replace(/[^a-zA-Z0-9_]/g, '');
        targetName = `Cast_${selected.length + 1}_${cleanTag}_Scene${String(rowIndex).padStart(2, '0')}${ext}`;
        const copyDest = path.join(tempDir, targetName);
        try {
          fs.copyFileSync(primaryImg.filePath, copyDest);
          targetPath = copyDest;
        } catch (_) {}
      }
      usedFilePaths.add(resolvedPrimary);
      selected.push({
        filePath: targetPath,
        savedName: targetName,
        fileName: targetName,
        publicUrl: primaryImg.publicUrl,
        role: 'film_cast_character',
        characterId: ch.id,
        characterName: ch.name,
        characterTag: ch.tag,
        characterDna: ch.appearanceDna || ''
      });
    }
  }

  if (onScreenChars.length <= 2 && selected.length < maxCastAndRowSlots) {
    for (const ch of onScreenChars) {
      if (selected.length >= maxCastAndRowSlots) break;
      const charImgs = Array.isArray(ch.referenceImages)
        ? ch.referenceImages.filter((im) => im && im.filePath && fs.existsSync(im.filePath))
        : [];
      if (charImgs.length >= 2) {
        const secondImg = charImgs[1];
        const resolvedSec = path.resolve(secondImg.filePath).toLowerCase();
        if (!usedFilePaths.has(resolvedSec)) {
          usedFilePaths.add(resolvedSec);
          selected.push({
            filePath: secondImg.filePath,
            savedName: secondImg.savedName || secondImg.fileName,
            fileName: secondImg.fileName || secondImg.savedName,
            publicUrl: secondImg.publicUrl,
            role: 'film_cast_character_extra_angle',
            characterId: ch.id,
            characterName: ch.name,
            characterTag: ch.tag,
            characterDna: ch.appearanceDna || ''
          });
        }
      }
    }
  }

  if (needPrevSceneSlot) {
    selected.push({
      filePath: prevSceneLastFramePath,
      savedName: path.basename(prevSceneLastFramePath),
      fileName: path.basename(prevSceneLastFramePath),
      role: 'prev_scene_last_frame'
    });
  }

  return selected;
}

function buildFilmmakingPromptBlocks({
  filmConfig = {},
  sceneCharacters = [],
  attachedImages = [],
  rawPartDialogue = '',
  rowSceneTitle = '',
  rowIndex = 1,
  partIdx = 1,
  totalParts = 1,
  partDurSec = 10
}) {
  const cfg = normalizeFilmConfig(filmConfig);
  const genre = getFilmGenreInfo(cfg.genreId, cfg.customStylePrompt);

  const bibleLines = [
    `[CINEMATIC FILM PRODUCTION — SCENE #${String(rowIndex).padStart(2, '0')}${
      rowSceneTitle ? ` ("${rowSceneTitle}")` : ''
    }${totalParts > 1 ? ` • PART ${partIdx}/${totalParts}` : ''}]`,
    `• FILM GENRE & VISUAL ART DIRECTION: ${genre.fullStyleDirective}`
  ];

  if (cfg.worldLock) {
    bibleLines.push(`• MANDATORY WORLD, ERA & ENVIRONMENT BIBLE (LOCKED ACROSS ALL SCENES): ${cfg.worldLock}`);
  }
  const lightingDirective = getCinemaLightingDirective(cfg.lightingPreset, cfg.customLightingNote);
  if (lightingDirective) {
    bibleLines.push(
      `• MANDATORY CINEMATIC LIGHTING & COLOR MOOD (LOCKED ACROSS ALL SCENES): ${lightingDirective}`
    );
  }
  if (genre.eraGuard) {
    bibleLines.push(
      `• ERA CONTINUITY GUARD: Strictly forbid any anachronistic modern items, modern text/logos, smartphones, cars, power lines, or contemporary clothing.`
    );
  }
  bibleLines.push(
    `• NO ON-SCREEN SUBTITLES OR WATERMARKS: Clean theatrical frame with ZERO burned-in text, captions, or UI overlays.`
  );

  const castLines = [];
  const onScreenChars = sceneCharacters.filter((c) => c && c.roleType !== 'narrator');
  if (onScreenChars.length > 0 || attachedImages.length > 0) {
    castLines.push(`[MULTI-CHARACTER CAST & STRICT IDENTITY MAPPING — ZERO IDENTITY SWAP]`);
    attachedImages.forEach((im, idx) => {
      const slotNum = idx + 1;
      if (im.role === 'film_cast_character') {
        castLines.push(
          `• Attached Image #${slotNum} = CHARACTER "${im.characterName}" (${im.characterTag}): Lock 100% of this character's face, hair, age, build, and signature costume${
            im.characterDna ? ` (${im.characterDna})` : ''
          }.`
        );
      } else if (im.role === 'film_cast_character_extra_angle') {
        castLines.push(
          `• Attached Image #${slotNum} = Supplementary angle of CHARACTER "${im.characterName}" (${im.characterTag}) — SAME person, do NOT duplicate into a second clone.`
        );
      } else if (im.role === 'scene_environment_or_prop') {
        castLines.push(`• Attached Image #${slotNum} = Scene environment / visual reference for this shot.`);
      } else if (im.role === 'prev_scene_last_frame') {
        castLines.push(
          `• Attached Image #${slotNum} = Ending frame of Previous Scene #${rowIndex - 1}: Maintain smooth spatial, lighting, and costume continuity.`
        );
      }
    });

    for (const ch of onScreenChars) {
      const hasAttached = attachedImages.some((im) => im.characterId === ch.id);
      if (!hasAttached) {
        castLines.push(
          `• CHARACTER "${ch.name}" (${ch.tag}) IN THIS SCENE: ${
            ch.appearanceDna || 'Maintain consistent character face, hair, and outfit across all scenes.'
          }`
        );
      }
    }

    if (onScreenChars.length >= 2) {
      castLines.push(
        `• MULTI-CHARACTER SEPARATION RULE: This scene features ${onScreenChars.length} distinct characters (${onScreenChars
          .map((c) => `"${c.name}"`)
          .join(', ')}). Keep each character visually distinct — NEVER blend faces or swap outfits between them!`
      );
    }
  }

  let filmDialogueBlock = '';
  const cleanDlg = String(rawPartDialogue || '').trim();
  if (cfg.audioMode === 'ambient_only' || !cleanDlg) {
    filmDialogueBlock = [
      `[CINEMATIC FOLEY & AMBIENT SOUNDTRACK — NO SPOKEN DIALOGUE]`,
      `• Rich natural cinematic environment audio, footsteps, wind, cloth movement, and subtle atmospheric score matching the genre.`,
      `• Characters do NOT speak in this shot (natural closed-mouth acting, zero random mumbling).`
    ].join('\n');
  } else {
    const parsedLines = parseSceneMultiSpeakerLines(cleanDlg, sceneCharacters);
    const narratorVoiceSpec = getCinemaVoiceDirective(cfg.narratorVoicePreset, cfg.narratorVoiceNote);

    if (cfg.audioMode === 'narrator' && parsedLines.every((l) => l.type === 'default' || l.type === 'narrator')) {
      const fullVoText = parsedLines.map((l) => l.text).join(' ');
      filmDialogueBlock = [
        `[OFF-SCREEN CINEMATIC NARRATION (VOICEOVER) — DO NOT LIP-SYNC ON-SCREEN CHARACTERS]`,
        `• NARRATOR VOICE PROFILE: ${narratorVoiceSpec}`,
        `• EXACT VOICEOVER SCRIPT (${partDurSec}s): "${fullVoText}"`,
        `• ACTING RULE: This is off-screen storytelling narration. On-screen characters perform expressive actions and emotions WITHOUT moving their lips to the narrator's voiceover. Mix gentle cinematic background ambiance underneath.`
      ].join('\n');
    } else {
      const speechDirectives = [
        `[MULTI-SPEAKER CINEMATIC DIALOGUE & NARRATION DIRECTION — ${partDurSec}s SHOT]`
      ];
      parsedLines.forEach((item, idx) => {
        if (item.type === 'narrator') {
          const voSpec = item.character
            ? getCinemaVoiceDirective(item.character.voicePreset, item.character.voiceCustomNote)
            : narratorVoiceSpec;
          speechDirectives.push(
            `• Line #${idx + 1} [OFF-SCREEN NARRATOR — ${voSpec}]: "${item.text}" (Off-screen voiceover ONLY; on-screen actors do NOT lip-sync this line).`
          );
        } else if (item.type === 'character') {
          const charVoice = item.character
            ? getCinemaVoiceDirective(item.character.voicePreset, item.character.voiceCustomNote)
            : 'Natural expressive Vietnamese voice matching this character';
          speechDirectives.push(
            `• Line #${idx + 1} [ON-SCREEN SPEAKER "${item.speakerLabel}"${
              item.character ? ` (${item.character.tag})` : ''
            } — Voice: ${charVoice}]: "${item.text}" (ONLY "${item.speakerLabel}" moves their lips in accurate lip-sync while other characters react naturally with closed mouths).`
          );
        } else {
          const primaryOnScreen = onScreenChars[0] || null;
          if (primaryOnScreen && cfg.audioMode !== 'narrator') {
            const cVoice = getCinemaVoiceDirective(primaryOnScreen.voicePreset, primaryOnScreen.voiceCustomNote);
            speechDirectives.push(
              `• Line #${idx + 1} [ON-SCREEN SPEAKER "${primaryOnScreen.name}" (${primaryOnScreen.tag}) — Voice: ${cVoice}]: "${item.text}" (Accurate lip-sync on "${primaryOnScreen.name}").`
            );
          } else {
            speechDirectives.push(`• Line #${idx + 1} [CINEMATIC NARRATION — ${narratorVoiceSpec}]: "${item.text}"`);
          }
        }
      });
      speechDirectives.push(
        `• AUDIO CLARITY RULE: Speak 100% of every quoted word clearly before ${Math.max(
          3.5,
          partDurSec - 0.8
        ).toFixed(1)}s with clean studio voice clarity and natural cinematic ambiance.`
      );
      filmDialogueBlock = speechDirectives.join('\n');
    }
  }

  return {
    bibleBlock: bibleLines.join('\n'),
    castBlock: castLines.join('\n'),
    filmDialogueBlock
  };
}

/**
 * Tạo Prompt thiết kế Chân dung Nhân vật đồng bộ đúng thể loại phim trên Muse.ai
 */
function buildCharacterPortraitPrompt({ character, filmConfig = {}, uniqueTag = 'mfs_portrait' }) {
  const cfg = normalizeFilmConfig(filmConfig);
  const genre = getFilmGenreInfo(cfg.genreId, cfg.customStylePrompt);
  const dna =
    character?.appearanceDna ||
    `Character named "${character?.name || 'Main Character'}", distinctive memorable face and signature period-appropriate outfit`;

  return [
    `[CHARACTER PORTRAIT DESIGN SHEET — ID: ${uniqueTag}]`,
    `Create a crystal-clear, well-lit medium portrait shot (chest-up, facing forward with slight 3/4 heroic angle, neutral clean atmospheric background) of ONLY ONE SINGLE CHARACTER:`,
    `• Character Name: "${character?.name || 'Character'}"`,
    `• Visual Appearance & Costume DNA: ${dna}`,
    `• Film Art Style: ${genre.fullStyleDirective}`,
    cfg.worldLock ? `• World / Era Context: ${cfg.worldLock}` : '',
    getCinemaLightingDirective(cfg.lightingPreset, cfg.customLightingNote)
      ? `• Harmonized Film Lighting Tone (keep face clearly lit & visible): ${getCinemaLightingDirective(
          cfg.lightingPreset,
          cfg.customLightingNote
        )}`
      : '',
    `• Portrait Rules: Single solo character centered clearly in frame, sharp eyes and facial features, zero text/watermarks, calm steady breathing expression ideal for character reference.`
  ]
    .filter(Boolean)
    .join('\n');
}

function splitScriptIntoScenesLocally({
  storyText = '',
  existingCharacters = [],
  targetMovieSeconds = 180,
  sceneDurationSeconds = 10,
  audioMode = 'mixed'
}) {
  const cleanStory = String(storyText || '').replace(/\r\n/g, '\n').trim();
  if (!cleanStory) return { extractedCharacters: [], scenes: [] };

  const targetSceneCount = Math.max(
    1,
    Math.min(200, Math.round(Number(targetMovieSeconds || 180) / Math.max(5, Number(sceneDurationSeconds || 10))))
  );
  const maxWordsPerScene = Math.max(16, Math.round(sceneDurationSeconds * 2.2));

  const explicitSceneRegex =
    /(?:^|\n)\s*(?=(?:cảnh|phân\s*cảnh|scene|shot|đoạn)\s*\d+\s*[:.\-–])/i;
  let rawBlocks = [];

  if (explicitSceneRegex.test(cleanStory)) {
    rawBlocks = cleanStory
      .split(/(?:^|\n)\s*(?:cảnh|phân\s*cảnh|scene|shot|đoạn)\s*\d+\s*[:.\-–]\s*/i)
      .map((b) => b.trim())
      .filter(Boolean);
  } else {
    const paragraphs = cleanStory
      .split(/\n\s*\n+/)
      .map((p) => p.trim())
      .filter(Boolean);

    if (paragraphs.length >= 2) {
      for (const para of paragraphs) {
        const words = para.split(/\s+/).filter(Boolean);
        if (words.length <= maxWordsPerScene * 1.45) {
          rawBlocks.push(para);
        } else {
          const sentences = para
            .split(/(?<=[.!?…])\s+/)
            .map((s) => s.trim())
            .filter(Boolean);
          let buf = [];
          let wCount = 0;
          for (const sent of sentences) {
            const sw = sent.split(/\s+/).filter(Boolean).length;
            if (buf.length > 0 && wCount + sw > maxWordsPerScene * 1.25) {
              rawBlocks.push(buf.join(' '));
              buf = [sent];
              wCount = sw;
            } else {
              buf.push(sent);
              wCount += sw;
            }
          }
          if (buf.length > 0) rawBlocks.push(buf.join(' '));
        }
      }
    } else {
      const sentences = cleanStory
        .split(/(?<=[.!?…\n])\s+/)
        .map((s) => s.trim())
        .filter(Boolean);
      const dynamicTarget = Math.max(1, Math.min(targetSceneCount, sentences.length));
      const totalW = cleanStory.split(/\s+/).filter(Boolean).length;
      const perSceneW = Math.max(14, Math.min(maxWordsPerScene, Math.ceil(totalW / dynamicTarget)));

      let buf = [];
      let wCount = 0;
      for (const sent of sentences) {
        const sw = sent.split(/\s+/).filter(Boolean).length;
        if (buf.length > 0 && wCount + sw > perSceneW) {
          rawBlocks.push(buf.join(' '));
          buf = [sent];
          wCount = sw;
        } else {
          buf.push(sent);
          wCount += sw;
        }
      }
      if (buf.length > 0) rawBlocks.push(buf.join(' '));
    }
  }

  rawBlocks = rawBlocks.slice(0, 200);

  const autoDiscoveredMap = new Map();
  const speakerScanRe = /(?:^\s*|\n\s*)(?:\[([^\]]{1,40})\]|(@[a-zA-Z0-9_]{2,32}))\s*:/g;
  let spMatch;
  while ((spMatch = speakerScanRe.exec(cleanStory)) !== null) {
    const rawSpeaker = String(spMatch[1] || spMatch[2] || '').trim();
    if (!rawSpeaker) continue;
    if (
      /^(?:dẫn\s*chuyện|người\s*dẫn|người\s*kể|thuyết\s*minh|narrator|voiceover|vo|cảnh\s*\d+|scene\s*\d+|tập\s*\d+|phần\s*\d+|hình\s*ảnh|visual|prompt)$/i.test(
        rawSpeaker
      )
    ) {
      continue;
    }
    const cleanName = rawSpeaker.replace(/^@+/, '').trim();
    if (!cleanName) continue;
    const normTag = sanitizeCharacterTag(rawSpeaker, existingCharacters.length + autoDiscoveredMap.size + 1);
    const alreadyExists = (existingCharacters || []).some(
      (c) =>
        c.tag.toLowerCase() === normTag.toLowerCase() ||
        c.name.trim().toLowerCase() === cleanName.toLowerCase()
    );
    if (!alreadyExists && !autoDiscoveredMap.has(normTag.toLowerCase())) {
      autoDiscoveredMap.set(normTag.toLowerCase(), {
        name: cleanName,
        tag: normTag,
        roleType: 'character',
        appearanceDna: '',
        voicePreset: 'auto'
      });
    }
  }
  const extractedCharacters = Array.from(autoDiscoveredMap.values());
  const combinedCharacters = [
    ...(Array.isArray(existingCharacters) ? existingCharacters : []),
    ...extractedCharacters.map((ec, i) => ({ id: `__ext_${i}`, ...ec }))
  ];

  const cameraCycle = [
    'Wide cinematic establishing shot, slow smooth camera push-in',
    'Medium cinematic shot at eye-level, gentle gimbal tracking',
    'Expressive medium close-up shot, shallow depth of field',
    'Dynamic two-shot / over-the-shoulder cinematic framing, subtle camera pan'
  ];

  const scenes = rawBlocks.map((block, idx) => {
    let visualPart = '';
    let dialoguePart = '';

    if (block.includes('||')) {
      const sp = block.split('||');
      visualPart = sp[0].trim();
      dialoguePart = sp.slice(1).join(' ').trim();
    } else {
      const lines = block
        .split('\n')
        .map((l) => l.trim())
        .filter(Boolean);
      const actionLines = [];
      const speechLines = [];

      for (const ln of lines) {
        if (/^(?:\[[^\]]+\]|@[a-zA-Z0-9_]+|(?:dẫn\s*chuyện|thuyết\s*minh|thoại|narrator))\s*:/i.test(ln)) {
          speechLines.push(ln);
        } else if (/^(?:hình\s*ảnh|bối\s*cảnh|hành\s*động|visual|prompt|camera)\s*:/i.test(ln)) {
          actionLines.push(ln.replace(/^[^:]+:\s*/, '').trim());
        } else {
          actionLines.push(ln);
        }
      }

      if (speechLines.length > 0 && actionLines.length > 0) {
        visualPart = actionLines.join(' ');
        dialoguePart = speechLines.join('\n');
      } else if (speechLines.length > 0) {
        visualPart = `${cameraCycle[idx % cameraCycle.length]}. Nhân vật diễn xuất biểu cảm tự nhiên khớp lời thoại trong bối cảnh phim.`;
        dialoguePart = speechLines.join('\n');
      } else if (audioMode === 'ambient_only') {
        visualPart = block.replace(/\s+/g, ' ').trim();
        dialoguePart = '';
      } else {
        const cleanNarrative = block.replace(/\s+/g, ' ').trim();
        visualPart = `${cameraCycle[idx % cameraCycle.length]}. Diễn tả sống động phân cảnh: ${cleanNarrative}`;
        if (audioMode === 'narrator' || audioMode === 'mixed') {
          dialoguePart = `[Dẫn chuyện]: ${cleanNarrative}`;
        } else {
          dialoguePart = cleanNarrative;
        }
      }
    }

    const matchedChars = detectCharactersInSceneText(`${visualPart}\n${dialoguePart}`, combinedCharacters);

    return {
      sceneNumber: idx + 1,
      sceneTitle: `Cảnh ${idx + 1}`,
      characterIds: matchedChars.filter((c) => !String(c.id).startsWith('__ext_')).map((c) => c.id),
      characterTags: matchedChars.map((c) => c.tag),
      prompt: visualPart,
      dialogue: dialoguePart
    };
  });

  return { extractedCharacters, scenes };
}

function buildAiStoryboardBreakdownPrompt({
  storyText = '',
  genreId = '3d_pixar',
  customStylePrompt = '',
  worldLock = '',
  lightingPreset = 'auto',
  customLightingNote = '',
  audioMode = 'mixed',
  existingCharacters = [],
  batchStartScene = 1,
  batchEndScene = 12,
  totalTargetScenes = 12,
  sceneDurationSeconds = 10,
  uniqueTag = 'mfs_sb_01',
  doneMarker = 'MFS_SB_DONE_01'
}) {
  const genre = getFilmGenreInfo(genreId, customStylePrompt);
  const lightingDir = getCinemaLightingDirective(lightingPreset, customLightingNote);
  const maxWordsPerScene = Math.max(15, Math.round(sceneDurationSeconds * 2.1));

  const existingCharBlock =
    existingCharacters.length > 0
      ? [
          `EXISTING CAST (MUST REUSE THESE EXACT @TAGS WHEN THEY APPEAR):`,
          ...existingCharacters.map(
            (c) => `- ${c.tag} | ${c.name} | ${c.roleType} | ${c.appearanceDna || 'Recurring character'}`
          )
        ].join('\n')
      : `NO PRE-DEFINED CAST YET: Extract up to 6 key recurring characters from the story and output CHAR lines first.`;

  const audioInstruction =
    audioMode === 'ambient_only'
      ? `AUDIO MODE = AMBIENT ONLY: Leave <Dialogue> as NONE for every scene.`
      : audioMode === 'narrator'
      ? `AUDIO MODE = NARRATOR VOICEOVER: Write <Dialogue> as "[Dẫn chuyện]: <Vietnamese narration max ${maxWordsPerScene} words>".`
      : audioMode === 'dialogue'
      ? `AUDIO MODE = CHARACTER DIALOGUE: Write <Dialogue> using "[@CharacterTag]: <Vietnamese line>" (total max ${maxWordsPerScene} words per scene).`
      : `AUDIO MODE = MIXED CINEMA: Combine "[Dẫn chuyện]: <short narration>" and/or "[@CharacterTag]: <character speech>" (total max ${maxWordsPerScene} words per ${sceneDurationSeconds}s scene). Separate multiple speaker lines in one scene with " / ".`;

  return [
    `[TEXT-ONLY FILM DIRECTOR & STORYBOARD ARCHITECT — ID: ${uniqueTag}]`,
    `[CRITICAL SYSTEM RULE: DO NOT GENERATE ANY VIDEO OR IMAGE IN THIS STEP! REPLY WITH STRUCTURED PLAIN TEXT ONLY!]`,
    `You are an award-winning Cinema Director adapting the following Vietnamese story/script into a cohesive ${totalTargetScenes}-scene movie (${sceneDurationSeconds}s per scene).`,
    `• Film Genre: ${genre.label} (${genre.fullStyleDirective})`,
    worldLock ? `• Locked World / Era Setting: ${worldLock}` : '',
    lightingDir ? `• Locked Cinematic Lighting & Atmosphere: ${lightingDir}` : '',
    `• ${audioInstruction}`,
    existingCharBlock,
    ``,
    `--- SOURCE STORY / SCRIPT ---`,
    String(storyText || '').trim().slice(0, 14000),
    `--- END SOURCE STORY ---`,
    ``,
    `TASK FOR THIS BATCH: Write scenes from SCENE_${batchStartScene} through SCENE_${batchEndScene} (out of ${totalTargetScenes} total scenes covering the story arc chronologically).`,
    batchStartScene === 1 && existingCharacters.length === 0
      ? `First, output 1 to 6 character definition lines in this exact pipe-separated format:\nCHAR | @Tag | Tên nhân vật | GenderAgeVoiceHint | Concise locked visual DNA (face, hair, age, signature outfit in Vietnamese)`
      : '',
    `Then output EVERY scene from ${batchStartScene} to ${batchEndScene} in this exact single-line pipe-separated format (NO markdown code fences):`,
    `SCENE_<N> | <Short Vietnamese Scene Title> | <Comma-separated @Tags in this shot, or NONE> | <Detailed Visual Camera + Environment + Character Action Prompt in Vietnamese & key English camera terms> | <Vietnamese Dialogue/Narration or NONE>`,
    `End your response with the exact token: ${doneMarker}`
  ]
    .filter(Boolean)
    .join('\n');
}

function mapVoiceHintToPreset(hint = '') {
  const h = stripVietnameseAccents(String(hint || '').toLowerCase());
  if (/tre\s*em|be\s*trai|cau\s*be|boy/.test(h)) return 'vi_child_boy';
  if (/be\s*gai|co\s*be|girl/.test(h)) return 'vi_child_girl';
  if (/ong\s*lao|cu\s*ong|gia\s*lang|elder\s*male|old\s*man/.test(h)) return 'vi_male_elder_wise';
  if (/ba\s*lao|cu\s*ba|ba\s*tien|old\s*woman/.test(h)) return 'vi_female_elder_kind';
  if (/tuong|vua|anh\s*hung|hero|uy\s*nghiem/.test(h)) return 'vi_male_hero_epic';
  if (/nam|male|man|trai/.test(h)) return 'vi_male_young_bright';
  if (/nu|female|woman|gai/.test(h)) return 'vi_female_lead_gentle';
  return 'auto';
}

function parseAiStoryboardBreakdownReply(replyText = '') {
  const lines = String(replyText || '')
    .replace(/```[a-z]*\n?/gi, '')
    .replace(/```/g, '')
    .split(/\r?\n/)
    .map((l) => l.trim())
    .filter(Boolean);

  const extractedCharacters = [];
  const scenes = [];

  for (const line of lines) {
    const cleanLine = line.replace(/^[-*•\d.)\s]+(?=(?:CHAR|SCENE_\d+)\b)/i, '').trim();

    if (/^CHAR\s*\|/i.test(cleanLine)) {
      const parts = cleanLine.split('|').map((p) => p.trim());
      if (parts.length >= 3) {
        const rawTag = parts[1];
        const name = parts[2] || rawTag.replace(/^@/, '');
        const voiceHint = parts[3] || '';
        const dna = parts.slice(4).join(' | ').trim() || voiceHint;
        extractedCharacters.push({
          tag: sanitizeCharacterTag(rawTag || name, extractedCharacters.length + 1),
          name,
          roleType: /narrator|dan\s*chuyen|thuyet\s*minh/i.test(stripVietnameseAccents(name))
            ? 'narrator'
            : 'character',
          voicePreset: mapVoiceHintToPreset(voiceHint),
          appearanceDna: dna
        });
      }
      continue;
    }

    const scMatch = cleanLine.match(/^SCENE_(\d+)\s*\|\s*(.+)$/i);
    if (scMatch) {
      const sceneNum = Number(scMatch[1]);
      const restParts = scMatch[2].split('|').map((p) => p.trim());
      let sceneTitle = `Cảnh ${sceneNum}`;
      let tagsRaw = '';
      let visualPrompt = '';
      let dialogueRaw = '';

      if (restParts.length >= 4) {
        sceneTitle = restParts[0] || sceneTitle;
        tagsRaw = restParts[1] || '';
        visualPrompt = restParts[2] || '';
        dialogueRaw = restParts.slice(3).join(' | ').trim();
      } else if (restParts.length === 3) {
        sceneTitle = restParts[0] || sceneTitle;
        visualPrompt = restParts[1] || '';
        dialogueRaw = restParts[2] || '';
      } else if (restParts.length === 2) {
        visualPrompt = restParts[0] || '';
        dialogueRaw = restParts[1] || '';
      } else {
        visualPrompt = restParts[0] || '';
      }

      const characterTags =
        !tagsRaw || /^none$/i.test(tagsRaw)
          ? []
          : tagsRaw
              .split(/[,;\s]+/)
              .map((t) => t.trim())
              .filter((t) => t && !/^none$/i.test(t))
              .map((t) => sanitizeCharacterTag(t));

      const cleanDialogue =
        !dialogueRaw || /^none$/i.test(dialogueRaw)
          ? ''
          : dialogueRaw
              .split(/\s+\/\s+/)
              .map((s) => s.trim())
              .filter(Boolean)
              .join('\n');

      if (visualPrompt) {
        scenes.push({
          sceneNumber: sceneNum,
          sceneTitle,
          characterTags,
          prompt: visualPrompt,
          dialogue: cleanDialogue
        });
      }
    }
  }

  return { extractedCharacters, scenes };
}

module.exports = {
  FILM_GENRES,
  CINEMA_VOICE_PRESETS,
  CINEMA_LIGHTING_PRESETS,
  MAX_FILM_CHARACTERS,
  MAX_CHAR_REF_IMAGES,
  sanitizeCharacterTag,
  getCinemaVoiceDirective,
  getCinemaLightingDirective,
  getFilmGenreInfo,
  createDefaultFilmConfig,
  normalizeFilmConfig,
  normalizeFilmCharacters,
  detectCharactersInSceneText,
  resolveSceneCharacters,
  parseSceneMultiSpeakerLines,
  buildSceneCastReferenceImages,
  buildFilmmakingPromptBlocks,
  buildCharacterPortraitPrompt,
  splitScriptIntoScenesLocally,
  buildAiStoryboardBreakdownPrompt,
  parseAiStoryboardBreakdownReply
};
