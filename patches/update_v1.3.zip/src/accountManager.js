const fs = require('fs');
const path = require('path');
const { parseProxyString } = require('./proxyBridge');
const {
  MAX_FILM_CHARACTERS,
  MAX_CHAR_REF_IMAGES,
  CINEMA_VOICE_PRESETS,
  sanitizeCharacterTag,
  getCinemaVoiceDirective,
  createDefaultFilmConfig,
  normalizeFilmConfig,
  normalizeFilmCharacters
} = require('./cinemaDirector');

const BASE_CDP_PORT = 9322;
const MAX_ROW_REF_IMAGES = 5;

const VALID_TRANSITIONS = new Set([
  'fade',
  'dissolve',
  'hblur',
  'smoothleft',
  'smoothright',
  'zoomin',
  'circleopen',
  'fadeblack',
  'fadewhite',
  'wipeleft',
  'random',
  'none'
]);

const VALID_CAMERA_MOTIONS = new Set([
  'Auto',
  'POV',
  'Consistency',
  'Cinematic Pan',
  'Slow Zoom In',
  'Slow Zoom Out',
  'Dynamic Tracking',
  'Orbit 360'
]);

const MIN_DURATION_SEC = 5;
const MAX_DURATION_SEC = 3600;

function cleanProjectDisplayName(rawName, fallbackIndex = 1) {
  const cleaned = String(rawName || '')
    .replace(/\s*\(Port\s*\d+\)/gi, '')
    .trim();
  return cleaned || `Bộ Phim #${fallbackIndex}`;
}

function parseDurationSeconds(rawVal, fallbackSec = 10) {
  if (rawVal === null || rawVal === undefined) return fallbackSec;
  const s = String(rawVal).trim().toLowerCase();
  if (!s) return fallbackSec;

  const colonMatch = s.match(/^(\d+)\s*:\s*(\d{1,2})$/);
  if (colonMatch) {
    const total = (Number(colonMatch[1]) || 0) * 60 + (Number(colonMatch[2]) || 0);
    if (total > 0) return Math.max(MIN_DURATION_SEC, Math.min(MAX_DURATION_SEC, Math.round(total)));
  }

  const comboMatch = s.match(/^(\d+(?:[.,]\d+)?)\s*(?:m|min|mins|p|phut|phút)\s*(\d+)?\s*(?:s|sec|giay|giây)?$/i);
  if (comboMatch) {
    const mins = parseFloat(comboMatch[1].replace(',', '.')) || 0;
    const extraSec = comboMatch[2] ? Number(comboMatch[2]) || 0 : 0;
    const total = mins * 60 + extraSec;
    if (total > 0) return Math.max(MIN_DURATION_SEC, Math.min(MAX_DURATION_SEC, Math.round(total)));
  }

  const secMatch = s.match(/^(\d+(?:[.,]\d+)?)\s*(?:s|sec|secs|giay|giây)?$/i);
  if (secMatch) {
    const val = parseFloat(secMatch[1].replace(',', '.'));
    if (Number.isFinite(val) && val > 0) {
      return Math.max(MIN_DURATION_SEC, Math.min(MAX_DURATION_SEC, Math.round(val)));
    }
  }

  const fallbackParsed = parseInt(s, 10);
  if (Number.isFinite(fallbackParsed) && fallbackParsed > 0) {
    return Math.max(MIN_DURATION_SEC, Math.min(MAX_DURATION_SEC, fallbackParsed));
  }
  return fallbackSec;
}

function normalizeDurationSetting(rawVal) {
  return `${parseDurationSeconds(rawVal, 10)}s`;
}

function normalizeRowReferenceImages(rawList) {
  if (!Array.isArray(rawList)) return [null];
  const valid = [];
  for (const item of rawList) {
    if (item && item.filePath && fs.existsSync(item.filePath)) {
      valid.push({
        ...item,
        slot: valid.length
      });
      if (valid.length >= MAX_ROW_REF_IMAGES) break;
    }
  }
  return valid.length > 0 ? valid : [null];
}

function createSceneRow(index, existing = null) {
  if (existing && typeof existing === 'object') {
    const isAvatarGarbage = existing.fileSize && Number(existing.fileSize) < 550000;
    const normalizedRefs = normalizeRowReferenceImages(existing.referenceImages);
    const cleanMsg = String(existing.statusMessage || '')
      .replace(/Sẵn sàng chờ lệnh CDP/gi, 'Sẵn sàng quay')
      .trim();
    return {
      id: existing.id || `scene_${index}_${Date.now().toString(36)}`,
      index,
      sceneTitle:
        typeof existing.sceneTitle === 'string' && existing.sceneTitle.trim()
          ? existing.sceneTitle.trim().slice(0, 100)
          : `Cảnh ${index}`,
      sceneCharacterIds: Array.isArray(existing.sceneCharacterIds)
        ? existing.sceneCharacterIds.filter((x) => typeof x === 'string' && x)
        : [],
      continueFromPrevScene: Boolean(existing.continueFromPrevScene),
      includeInExport: existing.includeInExport !== false,
      referenceImages: normalizedRefs,
      multiRefMode: 'auto',
      sampleVideo: null,
      prompt: typeof existing.prompt === 'string' ? existing.prompt : '',
      dialogue: typeof existing.dialogue === 'string' ? existing.dialogue : '',
      status: isAvatarGarbage ? 'idle' : existing.status || 'idle',
      statusMessage: isAvatarGarbage ? 'Sẵn sàng quay' : cleanMsg || 'Sẵn sàng quay',
      videoUrl: isAvatarGarbage ? null : existing.videoUrl || null,
      videoFilePath: isAvatarGarbage ? null : existing.videoFilePath || null,
      remoteVideoUrl: isAvatarGarbage ? null : existing.remoteVideoUrl || null,
      fileSize: isAvatarGarbage ? null : existing.fileSize || null,
      lastRunToken: typeof existing.lastRunToken === 'string' ? existing.lastRunToken : null,
      completedAt: existing.completedAt || null,
      error: existing.error || null
    };
  }

  return {
    id: `scene_${index}_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 5)}`,
    index,
    sceneTitle: `Cảnh ${index}`,
    sceneCharacterIds: [],
    continueFromPrevScene: false,
    includeInExport: true,
    referenceImages: [null],
    multiRefMode: 'auto',
    sampleVideo: null,
    prompt: '',
    dialogue: '',
    status: 'idle',
    statusMessage: 'Sẵn sàng quay',
    videoUrl: null,
    videoFilePath: null,
    remoteVideoUrl: null,
    fileSize: null,
    lastRunToken: null,
    completedAt: null,
    error: null
  };
}

function createDefaultRows(count = 6, existingRows = []) {
  const rows = [];
  for (let i = 1; i <= count; i++) {
    const prev = existingRows.find((r) => Number(r.index) === i) || existingRows[i - 1] || null;
    rows.push(createSceneRow(i, prev));
  }
  return rows;
}

function createDefaultProjectSettings() {
  const filmConfig = createDefaultFilmConfig();
  return {
    projectMode: 'filmmaking',
    filmConfig,
    duration: `${filmConfig.sceneDurationSeconds}s`,
    aspectRatio: filmConfig.aspectRatio,
    resolution: filmConfig.resolution,
    cameraMotion: 'Auto',
    transitionEffect: 'fade',
    bgmAudio: null,
    bgmVolume: 0.22,
    burnSubtitles: false,
    exportMovieTitle: '',
    lastMasterExport: null,
    cleanChatPerRow: true,
    nativeAudio: true,
    enableDialogue: true,
    voicePreset: filmConfig.narratorVoicePreset,
    voiceCustomNote: '',
    backgroundMode: true,
    concurrency: filmConfig.concurrency,
    rowCount: 6,
    targetUrl: 'https://muse.ai',
    injectParamsIntoPrompt: true,
    customSelectors: {
      fileInput: '',
      promptInput: '',
      submitButton: '',
      videoElement: ''
    }
  };
}

function syncSettingsWithFilmConfig(settings) {
  settings.projectMode = 'filmmaking';
  settings.filmConfig = normalizeFilmConfig(settings.filmConfig || {});
  const fc = settings.filmConfig;
  settings.aspectRatio = fc.aspectRatio;
  settings.resolution = fc.resolution;
  settings.duration = `${fc.sceneDurationSeconds}s`;
  settings.concurrency = fc.concurrency;
  settings.enableDialogue = fc.audioMode !== 'ambient_only';
  settings.voicePreset = fc.narratorVoicePreset || 'vi_storyteller_cinema';
  settings.voiceCustomNote = fc.narratorVoiceNote || '';
  settings.backgroundMode = true;
  settings.nativeAudio = true;
  settings.injectParamsIntoPrompt = true;
  return settings;
}

const RESERVED_WIN_FOLDER_NAMES = /^(con|prn|aux|nul|com[1-9]|lpt[1-9])$/i;

function sanitizeWindowsFolderSegment(raw) {
  let clean = String(raw || '')
    .replace(/[\x00-\x1f<>:"/\\|?*]+/g, '_')
    .replace(/\s+/g, ' ')
    .trim()
    .replace(/[. ]+$/g, '');
  if (!clean) return '';
  if (RESERVED_WIN_FOLDER_NAMES.test(clean)) {
    clean = `_${clean}`;
  }
  return clean.slice(0, 90).replace(/[. ]+$/g, '');
}

function moveDirContentsRecursive(srcDir, dstDir) {
  if (!fs.existsSync(srcDir)) return;
  if (!fs.existsSync(dstDir)) {
    fs.mkdirSync(dstDir, { recursive: true });
  }
  for (const ent of fs.readdirSync(srcDir, { withFileTypes: true })) {
    const s = path.join(srcDir, ent.name);
    const d = path.join(dstDir, ent.name);
    if (ent.isDirectory()) {
      moveDirContentsRecursive(s, d);
      try {
        if (fs.readdirSync(s).length === 0) fs.rmdirSync(s);
      } catch (_) {}
    } else if (ent.isFile()) {
      if (!fs.existsSync(d)) {
        try {
          fs.renameSync(s, d);
        } catch (_) {
          fs.copyFileSync(s, d);
          try {
            fs.unlinkSync(s);
          } catch (__) {}
        }
      }
    }
  }
  try {
    if (fs.readdirSync(srcDir).length === 0) fs.rmdirSync(srcDir);
  } catch (_) {}
}

class AccountManager {
  constructor(appRootDir) {
    this.appRootDir = appRootDir;
    this.dataDir = path.join(appRootDir, 'Project_Data');
    this.outputVideosRootDir = path.join(appRootDir, 'Output_Videos');
    this.stateFile = path.join(this.dataDir, 'cinema_projects_state.json');
    this.accounts = [];
    this.activeAccountId = `movie_${BASE_CDP_PORT}`;
    this._ensureLoaded();
    this.syncAllAccountOutputFolders();
  }

  _ensureLoaded() {
    if (!fs.existsSync(this.dataDir)) {
      fs.mkdirSync(this.dataDir, { recursive: true });
    }

    if (fs.existsSync(this.stateFile)) {
      try {
        const raw = fs.readFileSync(this.stateFile, 'utf8');
        const parsed = JSON.parse(raw);
        if (Array.isArray(parsed.accounts) && parsed.accounts.length > 0) {
          const usedPorts = new Set();
          this.accounts = parsed.accounts.map((acc, idx) => {
            const settings = syncSettingsWithFilmConfig({
              ...createDefaultProjectSettings(),
              ...(acc.settings || {})
            });
            if (!VALID_TRANSITIONS.has(settings.transitionEffect)) {
              settings.transitionEffect = 'fade';
            }
            if (!VALID_CAMERA_MOTIONS.has(settings.cameraMotion)) {
              settings.cameraMotion = 'Auto';
            }
            if (settings.bgmAudio && (!settings.bgmAudio.filePath || !fs.existsSync(settings.bgmAudio.filePath))) {
              settings.bgmAudio = null;
            }
            settings.bgmVolume = Math.max(0.02, Math.min(1.0, Number(settings.bgmVolume) || 0.22));
            settings.burnSubtitles = Boolean(settings.burnSubtitles);

            const existingRows = Array.isArray(acc.rows) ? acc.rows : [];
            const rowCount = Math.max(1, Math.min(200, existingRows.length || Number(settings.rowCount) || 6));
            settings.rowCount = rowCount;

            const characters = normalizeFilmCharacters(acc.characters || []).map((ch) => ({
              ...ch,
              referenceImages: (ch.referenceImages || []).filter((im) => im && im.filePath && fs.existsSync(im.filePath))
            }));

            const rows = createDefaultRows(rowCount, existingRows).map((r) => {
              if (
                ['queued', 'connecting', 'uploading', 'submitting', 'rendering', 'downloading'].includes(r.status) ||
                (r.status === 'error' &&
                  /Quá thời gian|Timeout|locator\.click|Đã dừng tiến trình/i.test(r.error || r.statusMessage || ''))
              ) {
                return {
                  ...r,
                  status: r.videoUrl ? 'completed' : 'idle',
                  statusMessage: r.videoUrl ? 'Hoàn tất' : 'Sẵn sàng quay',
                  error: null
                };
              }
              return r;
            });

            const cleanName = cleanProjectDisplayName(acc.name, idx + 1);
            const rawProxy = typeof acc.proxy === 'string' ? acc.proxy.trim() : '';
            let proxyLabel = '';
            try {
              const pInfo = parseProxyString(rawProxy);
              proxyLabel = pInfo ? pInfo.displayLabel : '';
            } catch (_) {}

            // Đảm bảo mỗi tài khoản / bộ phim sở hữu 1 Port & Profile Chrome độc lập 100% (giống MUSE FLOW STUDIO 3.8)
            let assignedPort = Number(acc.port) || BASE_CDP_PORT;
            let migratedPort = false;
            if (usedPorts.has(assignedPort)) {
              assignedPort = BASE_CDP_PORT;
              while (usedPorts.has(assignedPort)) {
                assignedPort++;
              }
              migratedPort = true;
            }
            usedPorts.add(assignedPort);
            const profileRelativePath =
              assignedPort === BASE_CDP_PORT ? './ChromeProfile_Data' : `./ChromeProfile_Data_Port_${assignedPort}`;

            return {
              ...acc,
              port: assignedPort,
              profileRelativePath,
              name: cleanName,
              proxy: rawProxy,
              proxyLabel,
              connected: false,
              loginVerified: migratedPort ? false : Boolean(acc.loginVerified),
              savedAccount: migratedPort ? false : Boolean(acc.savedAccount || acc.loginVerified),
              accountInfo: migratedPort
                ? {
                    displayName: cleanName,
                    loginName: 'Chưa đăng nhập',
                    customLoginName: '',
                    agentName: '',
                    viewerId: '',
                    tokenUsage: null,
                    emailOrHandle: 'Chưa đăng nhập',
                    avatarUrl: null,
                    pageTitle: '',
                    pageUrl: 'https://muse.ai',
                    cookieCount: 0,
                    browserVersion: '',
                    lastConnectedAt: null
                  }
                : {
                    displayName: acc.accountInfo?.displayName || cleanName,
                    loginName: acc.accountInfo?.loginName || (acc.loginVerified ? 'Đã đăng nhập' : 'Chưa đăng nhập'),
                    customLoginName: acc.accountInfo?.customLoginName || '',
                    agentName: acc.accountInfo?.agentName || '',
                    viewerId: acc.accountInfo?.viewerId || '',
                    tokenUsage: acc.accountInfo?.tokenUsage || null,
                    emailOrHandle: acc.accountInfo?.emailOrHandle || (acc.loginVerified ? 'Đã lưu phiên' : 'Chưa đăng nhập'),
                    avatarUrl: acc.accountInfo?.avatarUrl || null,
                    pageTitle: acc.accountInfo?.pageTitle || '',
                    pageUrl: acc.accountInfo?.pageUrl || 'https://muse.ai',
                    cookieCount: acc.accountInfo?.cookieCount || 0,
                    browserVersion: acc.accountInfo?.browserVersion || '',
                    lastConnectedAt: acc.accountInfo?.lastConnectedAt || null
                  },
              characters,
              settings,
              rows
            };
          });
          this.activeAccountId =
            this.accounts.find((a) => a.id === parsed.activeAccountId)?.id || this.accounts[0].id;
          this.save();
          return;
        }
      } catch (err) {
        console.error('Lỗi đọc trạng thái dự án phim, khởi tạo mặc định:', err.message);
      }
    }

    const defaultAccount = {
      id: `movie_${BASE_CDP_PORT}`,
      name: 'Bộ Phim #1',
      port: BASE_CDP_PORT,
      proxy: '',
      proxyLabel: '',
      profileRelativePath: './ChromeProfile_Data',
      connected: false,
      loginVerified: false,
      savedAccount: false,
      accountInfo: {
        displayName: 'Chưa kết nối',
        loginName: 'Chưa đăng nhập',
        customLoginName: '',
        agentName: '',
        viewerId: '',
        tokenUsage: null,
        emailOrHandle: 'Bấm Đăng nhập Muse.ai để sản xuất bộ phim riêng',
        avatarUrl: null,
        pageTitle: '',
        pageUrl: 'https://muse.ai',
        cookieCount: 0,
        browserVersion: '',
        lastConnectedAt: null
      },
      characters: [],
      settings: createDefaultProjectSettings(),
      rows: createDefaultRows(6),
      createdAt: new Date().toISOString()
    };

    this.accounts = [defaultAccount];
    this.activeAccountId = defaultAccount.id;
    this.save();
  }

  save() {
    try {
      const payload = {
        activeAccountId: this.activeAccountId,
        updatedAt: new Date().toISOString(),
        accounts: this.accounts
      };
      fs.writeFileSync(this.stateFile, JSON.stringify(payload, null, 2), 'utf8');
    } catch (err) {
      console.error('Không thể lưu trạng thái dự án phim:', err.message);
    }
  }

  getAllAccounts() {
    return this.accounts;
  }

  getAccount(accountId) {
    return this.accounts.find((a) => a.id === accountId) || null;
  }

  getActiveAccount() {
    return this.getAccount(this.activeAccountId) || this.accounts[0];
  }

  setActiveAccount(accountId) {
    const found = this.getAccount(accountId);
    if (!found) {
      throw new Error(`Không tìm thấy bộ phim: ${accountId}`);
    }
    this.activeAccountId = found.id;
    this.save();
    return found;
  }

  getAccountOutputFolderName(accOrId) {
    const acc = typeof accOrId === 'object' && accOrId ? accOrId : this.getAccount(accOrId);
    if (!acc) {
      return sanitizeWindowsFolderSegment(accOrId) || 'Bo_Phim_1';
    }
    const baseSeg = sanitizeWindowsFolderSegment(acc.name) || sanitizeWindowsFolderSegment(acc.id) || 'Bo_Phim';
    const duplicate = this.accounts.some(
      (other) =>
        other.id !== acc.id &&
        (sanitizeWindowsFolderSegment(other.name) || '').toLowerCase() === baseSeg.toLowerCase()
    );
    return duplicate ? `${baseSeg}_${acc.id.slice(-4)}` : baseSeg;
  }

  buildAccountOutputPublicUrl(accOrId, ...subSegments) {
    const folderName = this.getAccountOutputFolderName(accOrId);
    const parts = [folderName, ...subSegments]
      .filter((s) => s !== undefined && s !== null && String(s) !== '')
      .map((s) => encodeURIComponent(String(s)));
    return `/outputs/${parts.join('/')}`;
  }

  ensureAccountOutputDir(accOrId, { create = false } = {}) {
    const acc = typeof accOrId === 'object' && accOrId ? accOrId : this.getAccount(accOrId);
    if (!fs.existsSync(this.outputVideosRootDir)) {
      fs.mkdirSync(this.outputVideosRootDir, { recursive: true });
    }
    if (!acc) {
      const fallbackDir = path.join(this.outputVideosRootDir, sanitizeWindowsFolderSegment(accOrId) || 'Bo_Phim_1');
      if (create && !fs.existsSync(fallbackDir)) {
        fs.mkdirSync(fallbackDir, { recursive: true });
      }
      return fallbackDir;
    }

    const desiredFolder = this.getAccountOutputFolderName(acc);
    const targetDir = path.join(this.outputVideosRootDir, desiredFolder);

    if (acc.outputFolderName && acc.outputFolderName.toLowerCase() !== desiredFolder.toLowerCase()) {
      const oldDir = path.join(this.outputVideosRootDir, acc.outputFolderName);
      const otherUsesOld = this.accounts.some(
        (o) => o.id !== acc.id && this.getAccountOutputFolderName(o).toLowerCase() === acc.outputFolderName.toLowerCase()
      );
      if (!otherUsesOld && fs.existsSync(oldDir)) {
        try {
          moveDirContentsRecursive(oldDir, targetDir);
          for (const row of acc.rows || []) {
            if (row.videoFilePath && row.videoFilePath.toLowerCase().startsWith((oldDir + path.sep).toLowerCase())) {
              const rel = path.relative(oldDir, row.videoFilePath);
              const segs = rel.split(/[\\/]+/).filter(Boolean);
              row.videoFilePath = path.join(targetDir, ...segs);
              row.videoUrl = this.buildAccountOutputPublicUrl(acc, ...segs);
            }
          }
        } catch (_) {}
      }
    }

    if (acc.outputFolderName !== desiredFolder) {
      acc.outputFolderName = desiredFolder;
      this.save();
    }

    if (create && !fs.existsSync(targetDir)) {
      try {
        fs.mkdirSync(targetDir, { recursive: true });
      } catch (_) {}
    }
    return targetDir;
  }

  syncAllAccountOutputFolders() {
    for (const acc of this.accounts) {
      try {
        this.ensureAccountOutputDir(acc);
      } catch (_) {}
    }
  }

  syncSharedPortSessionInfo() {
    this.save();
  }

  /**
   * Đăng xuất riêng phiên Muse.ai của 1 Dự án (xóa sạch Cookie trên cổng đó để đổi nick khác nhưng giữ nguyên Kịch bản/Diễn viên/Video của bộ phim)
   */
  logoutAccountOnly(accountId) {
    const acc = this.getAccount(accountId);
    if (!acc) throw new Error('Không tìm thấy dự án phim.');

    const fullProfileDir = path.resolve(this.appRootDir, acc.profileRelativePath);
    if (fs.existsSync(fullProfileDir)) {
      try {
        fs.rmSync(fullProfileDir, { recursive: true, force: true });
      } catch (_) {}
    }
    fs.mkdirSync(fullProfileDir, { recursive: true });

    acc.connected = false;
    acc.loginVerified = false;
    acc.savedAccount = false;
    acc.accountInfo = {
      displayName: acc.name,
      loginName: 'Chưa đăng nhập',
      customLoginName: '',
      agentName: '',
      viewerId: '',
      tokenUsage: null,
      emailOrHandle: 'Đã đăng xuất — Sẵn sàng đăng nhập tài khoản mới',
      avatarUrl: null,
      pageTitle: '',
      pageUrl: 'https://muse.ai',
      cookieCount: 0,
      browserVersion: '',
      lastConnectedAt: null
    };
    this.save();
    return acc;
  }

  /**
   * Tạo Tài khoản Muse.ai mới kèm một Trang Dự Án Bộ Phim hoàn toàn riêng biệt (giống hệt MUSE FLOW STUDIO 3.8)
   */
  addAccount({ name, port, proxy } = {}) {
    const rawProxy = typeof proxy === 'string' ? proxy.trim() : '';
    let proxyLabel = '';
    if (rawProxy) {
      const parsedProxy = parseProxyString(rawProxy);
      proxyLabel = parsedProxy ? parsedProxy.displayLabel : '';
    }

    const usedPorts = new Set(this.accounts.map((a) => Number(a.port)));
    let assignedPort = Number(port);
    if (!assignedPort || assignedPort < 1024 || assignedPort > 65535 || usedPorts.has(assignedPort)) {
      assignedPort = BASE_CDP_PORT;
      while (usedPorts.has(assignedPort)) {
        assignedPort++;
      }
    }

    const profileRelativePath =
      assignedPort === BASE_CDP_PORT ? './ChromeProfile_Data' : `./ChromeProfile_Data_Port_${assignedPort}`;
    const fullProfileDir = path.resolve(this.appRootDir, profileRelativePath);
    if (!fs.existsSync(fullProfileDir)) {
      fs.mkdirSync(fullProfileDir, { recursive: true });
    }

    const movieNumber = this.accounts.length + 1;
    const cleanName = cleanProjectDisplayName(name, movieNumber);
    const id = `movie_${assignedPort}_${Date.now().toString(36)}`;

    const newAcc = {
      id,
      name: cleanName,
      port: assignedPort,
      proxy: rawProxy,
      proxyLabel,
      profileRelativePath,
      connected: false,
      loginVerified: false,
      savedAccount: false,
      accountInfo: {
        displayName: cleanName,
        loginName: 'Chưa đăng nhập',
        customLoginName: '',
        agentName: '',
        viewerId: '',
        tokenUsage: null,
        emailOrHandle: 'Chưa đăng nhập',
        avatarUrl: null,
        pageTitle: '',
        pageUrl: 'https://muse.ai',
        cookieCount: 0,
        browserVersion: '',
        lastConnectedAt: null
      },
      characters: [],
      settings: createDefaultProjectSettings(),
      rows: createDefaultRows(6),
      createdAt: new Date().toISOString()
    };

    this.accounts.push(newAcc);
    this.activeAccountId = newAcc.id;
    this.save();
    return newAcc;
  }

  /**
   * Nhân bản Bộ phim hiện tại sang Tập tiếp theo (Giữ 100% Đoàn Diễn Viên + Ảnh chân dung + Thể loại + Thế giới + Giọng đọc)
   */
  cloneProjectForNextEpisode(sourceAccountId, rawNewName = '') {
    const src = this.getAccount(sourceAccountId);
    if (!src) throw new Error('Không tìm thấy bộ phim gốc để tạo tập mới.');

    let suggestedName = String(rawNewName || '').trim();
    if (!suggestedName) {
      const epMatch = src.name.match(/^(.*?)(\s*[-–•]?\s*tập\s*)(\d+)$/i);
      if (epMatch) {
        suggestedName = `${epMatch[1]}${epMatch[2]}${Number(epMatch[3]) + 1}`;
      } else {
        suggestedName = `${src.name} - Tập 2`;
      }
    }

    const newAcc = this.addAccount({
      name: suggestedName,
      dedicatedAccount: false
    });

    // Sao chép toàn bộ cấu hình phim (trừ bản nháp kịch bản của tập cũ)
    const clonedSettings = JSON.parse(JSON.stringify(src.settings || createDefaultProjectSettings()));
    if (clonedSettings.filmConfig) {
      clonedSettings.filmConfig.storyDraft = '';
    }
    clonedSettings.lastMasterExport = null;
    clonedSettings.exportMovieTitle = suggestedName;
    clonedSettings.rowCount = 6;
    newAcc.settings = syncSettingsWithFilmConfig(clonedSettings);

    // Sao chép Đoàn Diễn Viên & tạo bản sao độc lập các file ảnh chân dung để xóa tập cũ không mất ảnh tập mới
    const uploadsDir = path.join(this.dataDir, 'uploads', newAcc.id, 'characters');
    fs.mkdirSync(uploadsDir, { recursive: true });

    const clonedChars = [];
    for (const ch of src.characters || []) {
      const copiedImgs = [];
      for (const im of ch.referenceImages || []) {
        if (im && im.filePath && fs.existsSync(im.filePath)) {
          const ext = path.extname(im.filePath) || '.png';
          const savedName = `cast_${ch.id}_s${copiedImgs.length}_${Date.now()}${ext}`;
          const destPath = path.join(uploadsDir, savedName);
          try {
            fs.copyFileSync(im.filePath, destPath);
            copiedImgs.push({
              ...im,
              filePath: destPath,
              savedName,
              publicUrl: `/uploads/${newAcc.id}/characters/${savedName}`,
              slot: copiedImgs.length
            });
          } catch (_) {}
        }
      }
      clonedChars.push({
        ...ch,
        referenceImages: copiedImgs
      });
    }

    newAcc.characters = normalizeFilmCharacters(clonedChars);
    newAcc.rows = createDefaultRows(6);
    this.save();
    return newAcc;
  }

  updateAccountName(accountId, rawName) {
    const acc = this.getAccount(accountId);
    if (!acc) throw new Error('Không tìm thấy bộ phim.');

    const cleanName = String(rawName || '')
      .replace(/\s+/g, ' ')
      .trim()
      .slice(0, 90);
    if (!cleanName) {
      throw new Error('Tên bộ phim không được để trống.');
    }

    acc.name = cleanName;
    this.ensureAccountOutputDir(acc);
    this.save();
    return acc;
  }

  updateAccountProxy(accountId, rawProxyInput) {
    const acc = this.getAccount(accountId);
    if (!acc) throw new Error('Không tìm thấy dự án.');

    const rawProxy = typeof rawProxyInput === 'string' ? rawProxyInput.trim() : '';
    let proxyLabel = '';
    if (rawProxy) {
      const parsed = parseProxyString(rawProxy);
      proxyLabel = parsed ? parsed.displayLabel : '';
    }

    const changed = (acc.proxy || '') !== rawProxy;
    acc.proxy = rawProxy;
    acc.proxyLabel = proxyLabel;
    if (changed) {
      acc._proxyChanged = true;
    }
    this.syncSharedPortSessionInfo(acc);
    this.save();
    return { account: acc, changed };
  }

  updateAccountCustomLoginName(accountId, rawLoginName) {
    const acc = this.getAccount(accountId);
    if (!acc) throw new Error('Không tìm thấy dự án.');

    const cleanCustom = typeof rawLoginName === 'string' ? rawLoginName.trim().slice(0, 120) : '';
    const agentName = typeof acc.accountInfo?.agentName === 'string' ? acc.accountInfo.agentName.trim() : '';
    const computedLoginName = cleanCustom
      ? cleanCustom
      : agentName || (acc.loginVerified ? 'Đã đăng nhập' : 'Chưa đăng nhập');

    acc.accountInfo = {
      ...(acc.accountInfo || {}),
      customLoginName: cleanCustom,
      loginName: computedLoginName,
      displayName: computedLoginName
    };
    this.syncSharedPortSessionInfo(acc);
    this.save();
    return acc;
  }

  updateAccountSettings(accountId, partialSettings = {}) {
    const acc = this.getAccount(accountId);
    if (!acc) throw new Error('Không tìm thấy bộ phim.');

    const mergedFilmConfig = partialSettings.filmConfig
      ? normalizeFilmConfig({
          ...(acc.settings?.filmConfig || createDefaultFilmConfig()),
          ...partialSettings.filmConfig
        })
      : normalizeFilmConfig(acc.settings?.filmConfig || createDefaultFilmConfig());

    // Đồng bộ hai chiều nếu frontend truyền trực tiếp aspectRatio, resolution, concurrency, duration
    if (partialSettings.aspectRatio && !partialSettings.filmConfig?.aspectRatio) {
      mergedFilmConfig.aspectRatio = partialSettings.aspectRatio;
    }
    if (partialSettings.resolution && !partialSettings.filmConfig?.resolution) {
      mergedFilmConfig.resolution = partialSettings.resolution;
    }
    if (partialSettings.concurrency !== undefined && partialSettings.filmConfig?.concurrency === undefined) {
      mergedFilmConfig.concurrency = Math.max(1, Math.min(16, Number(partialSettings.concurrency) || 4));
    }
    if (partialSettings.duration !== undefined && partialSettings.filmConfig?.sceneDurationSeconds === undefined) {
      mergedFilmConfig.sceneDurationSeconds = parseDurationSeconds(partialSettings.duration, 10);
    }

    acc.settings = syncSettingsWithFilmConfig({
      ...acc.settings,
      ...partialSettings,
      filmConfig: mergedFilmConfig,
      customSelectors: {
        ...(acc.settings.customSelectors || {}),
        ...(partialSettings.customSelectors || {})
      }
    });

    if (!VALID_TRANSITIONS.has(acc.settings.transitionEffect)) {
      acc.settings.transitionEffect = 'fade';
    }
    if (!VALID_CAMERA_MOTIONS.has(acc.settings.cameraMotion)) {
      acc.settings.cameraMotion = 'Auto';
    }
    if (partialSettings.bgmVolume !== undefined) {
      acc.settings.bgmVolume = Math.max(0.02, Math.min(1.0, Number(partialSettings.bgmVolume) || 0.22));
    }
    if (partialSettings.burnSubtitles !== undefined) {
      acc.settings.burnSubtitles = Boolean(partialSettings.burnSubtitles);
    }
    if (partialSettings.exportMovieTitle !== undefined) {
      acc.settings.exportMovieTitle = String(partialSettings.exportMovieTitle || '').trim().slice(0, 120);
    }

    if (partialSettings.rowCount !== undefined) {
      const targetCount = Math.max(1, Math.min(200, Number(partialSettings.rowCount) || acc.rows.length || 6));
      acc.settings.rowCount = targetCount;
      acc.rows = createDefaultRows(targetCount, acc.rows);
    }

    this.save();
    return acc;
  }

  setProjectBgm(accountId, bgmMeta) {
    const acc = this.getAccount(accountId);
    if (!acc) throw new Error('Không tìm thấy bộ phim.');
    const prev = acc.settings?.bgmAudio || null;
    if (prev && prev.filePath && (!bgmMeta || prev.filePath !== bgmMeta.filePath)) {
      if (fs.existsSync(prev.filePath)) {
        try {
          fs.unlinkSync(prev.filePath);
        } catch (_) {}
      }
    }
    acc.settings.bgmAudio = bgmMeta ? { ...bgmMeta } : null;
    this.save();
    return acc;
  }

  resetProjectRows(accountId) {
    const acc = this.getAccount(accountId);
    if (!acc) throw new Error('Không tìm thấy bộ phim cần làm mới.');

    for (const row of acc.rows || []) {
      if (Array.isArray(row.referenceImages)) {
        for (const img of row.referenceImages) {
          if (img && img.filePath && fs.existsSync(img.filePath)) {
            try {
              fs.unlinkSync(img.filePath);
            } catch (_) {}
          }
        }
      }
    }

    acc.rows = createDefaultRows(6, []);
    acc.settings.rowCount = 6;
    acc.lastProjectResetAt = Date.now();
    this.save();
    return acc;
  }

  deleteOrResetAccount(accountId, { wipeProfileDir = false } = {}) {
    const idx = this.accounts.findIndex((a) => a.id === accountId);
    if (idx === -1) {
      throw new Error('Không tìm thấy bộ phim cần xóa.');
    }

    const targetAcc = this.accounts[idx];
    const resolvedProfile = path.resolve(this.appRootDir, targetAcc.profileRelativePath);
    const otherSharesProfile = this.accounts.some(
      (o) => o.id !== targetAcc.id && path.resolve(this.appRootDir, o.profileRelativePath) === resolvedProfile
    );

    if (wipeProfileDir && !otherSharesProfile && fs.existsSync(resolvedProfile)) {
      try {
        fs.rmSync(resolvedProfile, { recursive: true, force: true });
      } catch (_) {}
    }

    // Dọn ảnh uploads riêng của dự án này
    const projectUploads = path.join(this.dataDir, 'uploads', targetAcc.id);
    if (fs.existsSync(projectUploads)) {
      try {
        fs.rmSync(projectUploads, { recursive: true, force: true });
      } catch (_) {}
    }

    if (this.accounts.length > 1) {
      this.accounts.splice(idx, 1);
      if (this.activeAccountId === accountId) {
        this.activeAccountId = this.accounts[0].id;
      }
    } else {
      targetAcc.name = 'Bộ Phim #1';
      targetAcc.characters = [];
      targetAcc.settings = createDefaultProjectSettings();
      targetAcc.rows = createDefaultRows(6);
      if (wipeProfileDir) {
        fs.mkdirSync(resolvedProfile, { recursive: true });
        targetAcc.connected = false;
        targetAcc.loginVerified = false;
        targetAcc.savedAccount = false;
        targetAcc.accountInfo = {
          displayName: 'Chưa kết nối',
          loginName: 'Chưa đăng nhập',
          customLoginName: '',
          agentName: '',
          viewerId: '',
          tokenUsage: null,
          emailOrHandle: 'Sẵn sàng đăng nhập tài khoản mới',
          avatarUrl: null,
          pageTitle: '',
          pageUrl: 'https://muse.ai',
          cookieCount: 0,
          browserVersion: '',
          lastConnectedAt: null
        };
      }
    }

    this.save();
    return this.getActiveAccount();
  }

  /* ================= ĐOÀN DIỄN VIÊN (CAST VAULT) ================= */

  upsertFilmCharacter(accountId, payload = {}) {
    const acc = this.getAccount(accountId);
    if (!acc) throw new Error('Không tìm thấy bộ phim.');
    if (!Array.isArray(acc.characters)) acc.characters = [];

    const existingIdx = payload.id ? acc.characters.findIndex((c) => c.id === payload.id) : -1;
    if (existingIdx >= 0) {
      const prev = acc.characters[existingIdx];
      const updated = {
        ...prev,
        name: payload.name !== undefined ? String(payload.name || '').trim() || prev.name : prev.name,
        tag:
          payload.tag !== undefined
            ? sanitizeCharacterTag(payload.tag || payload.name || prev.name, existingIdx + 1)
            : payload.name !== undefined && prev.tag === sanitizeCharacterTag(prev.name, existingIdx + 1)
            ? sanitizeCharacterTag(payload.name, existingIdx + 1)
            : prev.tag,
        roleType: payload.roleType !== undefined ? (payload.roleType === 'narrator' ? 'narrator' : 'character') : prev.roleType,
        appearanceDna:
          payload.appearanceDna !== undefined ? String(payload.appearanceDna || '').trim() : prev.appearanceDna,
        voicePreset: payload.voicePreset !== undefined ? payload.voicePreset : prev.voicePreset,
        voiceCustomNote:
          payload.voiceCustomNote !== undefined ? String(payload.voiceCustomNote || '').trim() : prev.voiceCustomNote
      };
      acc.characters[existingIdx] = updated;
      acc.characters = normalizeFilmCharacters(acc.characters);
      this.save();
      return acc.characters[existingIdx];
    }

    if (acc.characters.length >= MAX_FILM_CHARACTERS) {
      throw new Error(`Tối đa ${MAX_FILM_CHARACTERS} diễn viên cho mỗi bộ phim.`);
    }

    const nextNum = acc.characters.length + 1;
    const rawName = String(payload.name || `Diễn viên ${nextNum}`).trim();
    const newChar = {
      id: `char_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 5)}`,
      name: rawName,
      tag: sanitizeCharacterTag(payload.tag || rawName, nextNum),
      roleType: payload.roleType === 'narrator' ? 'narrator' : 'character',
      appearanceDna: String(payload.appearanceDna || '').trim(),
      voicePreset: payload.voicePreset || 'auto',
      voiceCustomNote: String(payload.voiceCustomNote || '').trim(),
      referenceImages: []
    };

    acc.characters.push(newChar);
    acc.characters = normalizeFilmCharacters(acc.characters);
    this.save();
    return acc.characters[acc.characters.length - 1];
  }

  deleteFilmCharacter(accountId, characterId) {
    const acc = this.getAccount(accountId);
    if (!acc) throw new Error('Không tìm thấy bộ phim.');
    const idx = (acc.characters || []).findIndex((c) => c.id === characterId);
    if (idx === -1) throw new Error('Không tìm thấy diễn viên.');

    const removed = acc.characters.splice(idx, 1)[0];
    for (const im of removed?.referenceImages || []) {
      if (im && im.filePath && fs.existsSync(im.filePath)) {
        try {
          fs.unlinkSync(im.filePath);
        } catch (_) {}
      }
    }

    for (const row of acc.rows || []) {
      if (Array.isArray(row.sceneCharacterIds)) {
        row.sceneCharacterIds = row.sceneCharacterIds.filter((id) => id !== characterId);
      }
    }

    this.save();
    return acc;
  }

  setFilmCharacterImage(accountId, characterId, slotIndex, imageMeta) {
    const acc = this.getAccount(accountId);
    if (!acc) throw new Error('Không tìm thấy bộ phim.');
    const charObj = (acc.characters || []).find((c) => c.id === characterId);
    if (!charObj) throw new Error('Không tìm thấy diễn viên.');

    const slot = Math.max(0, Math.min(MAX_CHAR_REF_IMAGES - 1, Number(slotIndex) || 0));
    const list = Array.isArray(charObj.referenceImages)
      ? charObj.referenceImages.filter((im) => im && im.filePath && fs.existsSync(im.filePath))
      : [];

    if (!imageMeta) {
      if (slot < list.length) {
        const old = list.splice(slot, 1)[0];
        if (old?.filePath && fs.existsSync(old.filePath)) {
          try {
            fs.unlinkSync(old.filePath);
          } catch (_) {}
        }
      }
    } else if (slot < list.length) {
      const prev = list[slot];
      if (prev?.filePath && prev.filePath !== imageMeta.filePath && fs.existsSync(prev.filePath)) {
        try {
          fs.unlinkSync(prev.filePath);
        } catch (_) {}
      }
      list[slot] = { ...imageMeta, slot };
    } else if (list.length < MAX_CHAR_REF_IMAGES) {
      list.push({ ...imageMeta, slot: list.length });
    } else {
      const prev = list[MAX_CHAR_REF_IMAGES - 1];
      if (prev?.filePath && prev.filePath !== imageMeta.filePath && fs.existsSync(prev.filePath)) {
        try {
          fs.unlinkSync(prev.filePath);
        } catch (_) {}
      }
      list[MAX_CHAR_REF_IMAGES - 1] = { ...imageMeta, slot: MAX_CHAR_REF_IMAGES - 1 };
    }

    charObj.referenceImages = list.map((im, i) => ({ ...im, slot: i }));
    this.save();
    return charObj;
  }

  mergeExtractedCharacters(accountId, extractedList = []) {
    const acc = this.getAccount(accountId);
    if (!acc) throw new Error('Không tìm thấy bộ phim.');
    if (!Array.isArray(acc.characters)) acc.characters = [];

    for (const ext of extractedList) {
      if (!ext || (!ext.name && !ext.tag)) continue;
      const candTag = sanitizeCharacterTag(ext.tag || ext.name, acc.characters.length + 1);
      const existing = acc.characters.find(
        (c) =>
          c.tag.toLowerCase() === candTag.toLowerCase() ||
          c.name.trim().toLowerCase() === String(ext.name || '').trim().toLowerCase()
      );
      if (existing) {
        if (!existing.appearanceDna && ext.appearanceDna) {
          existing.appearanceDna = String(ext.appearanceDna).trim().slice(0, 650);
        }
        if (existing.voicePreset === 'auto' && ext.voicePreset && ext.voicePreset !== 'auto') {
          existing.voicePreset = ext.voicePreset;
        }
      } else if (acc.characters.length < MAX_FILM_CHARACTERS) {
        acc.characters.push({
          id: `char_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 5)}`,
          name: String(ext.name || candTag.replace(/^@/, '')).trim(),
          tag: candTag,
          roleType: ext.roleType === 'narrator' ? 'narrator' : 'character',
          appearanceDna: String(ext.appearanceDna || '').trim().slice(0, 650),
          voicePreset: ext.voicePreset || 'auto',
          voiceCustomNote: '',
          referenceImages: []
        });
      }
    }

    acc.characters = normalizeFilmCharacters(acc.characters);
    this.save();
    return acc.characters;
  }

  /* ================= BẢNG PHÂN CẢNH (STORYBOARD SCENES) ================= */

  applyStoryboardScenesToRows(accountId, scenes = [], { append = false } = {}) {
    const acc = this.getAccount(accountId);
    if (!acc) throw new Error('Không tìm thấy bộ phim.');
    if (!Array.isArray(scenes) || scenes.length === 0) return acc;

    const tagToId = new Map();
    const nameToId = new Map();
    for (const ch of acc.characters || []) {
      tagToId.set(ch.tag.toLowerCase(), ch.id);
      nameToId.set(ch.name.trim().toLowerCase(), ch.id);
    }

    const baseRows = append
      ? (acc.rows || []).filter((r) => (r.prompt && r.prompt.trim()) || (r.dialogue && r.dialogue.trim()) || r.videoUrl)
      : [];

    const builtScenes = scenes.slice(0, 200).map((sc, idx) => {
      const rowNum = baseRows.length + idx + 1;
      const charIds = [];
      if (Array.isArray(sc.characterIds)) {
        for (const cid of sc.characterIds) {
          if (acc.characters.some((c) => c.id === cid) && !charIds.includes(cid)) {
            charIds.push(cid);
          }
        }
      }
      if (Array.isArray(sc.characterTags)) {
        for (const rawT of sc.characterTags) {
          const normT = sanitizeCharacterTag(rawT).toLowerCase();
          const cid = tagToId.get(normT) || nameToId.get(String(rawT || '').replace(/^@/, '').trim().toLowerCase());
          if (cid && !charIds.includes(cid)) {
            charIds.push(cid);
          }
        }
      }

      return createSceneRow(rowNum, {
        sceneTitle: sc.sceneTitle || `Cảnh ${rowNum}`,
        sceneCharacterIds: charIds,
        continueFromPrevScene: Boolean(sc.continueFromPrevScene),
        includeInExport: true,
        prompt: sc.prompt || '',
        dialogue: sc.dialogue || '',
        status: 'idle',
        statusMessage: 'Sẵn sàng quay'
      });
    });

    const combined = [...baseRows.map((r, i) => ({ ...r, index: i + 1 })), ...builtScenes];
    acc.rows = combined.slice(0, 200).map((r, i) => ({ ...r, index: i + 1 }));
    acc.settings.rowCount = acc.rows.length;
    this.save();
    return acc;
  }

  addScene(accountId, scenePatch = {}) {
    const acc = this.getAccount(accountId);
    if (!acc) throw new Error('Không tìm thấy bộ phim.');
    if ((acc.rows || []).length >= 200) {
      throw new Error('Mỗi tập phim hỗ trợ tối đa 200 phân cảnh.');
    }
    const nextIdx = (acc.rows || []).length + 1;
    const newRow = createSceneRow(nextIdx, {
      sceneTitle: scenePatch.sceneTitle || `Cảnh ${nextIdx}`,
      sceneCharacterIds: Array.isArray(scenePatch.sceneCharacterIds) ? scenePatch.sceneCharacterIds : [],
      continueFromPrevScene: Boolean(scenePatch.continueFromPrevScene),
      prompt: scenePatch.prompt || '',
      dialogue: scenePatch.dialogue || ''
    });
    acc.rows.push(newRow);
    acc.settings.rowCount = acc.rows.length;
    this.save();
    return newRow;
  }

  deleteScene(accountId, rowIndex) {
    const acc = this.getAccount(accountId);
    if (!acc) throw new Error('Không tìm thấy bộ phim.');
    const idx = (acc.rows || []).findIndex((r) => Number(r.index) === Number(rowIndex));
    if (idx === -1) throw new Error(`Không tìm thấy Phân cảnh #${rowIndex}.`);

    const removed = acc.rows[idx];
    for (const im of removed?.referenceImages || []) {
      if (im && im.filePath && fs.existsSync(im.filePath)) {
        try {
          fs.unlinkSync(im.filePath);
        } catch (_) {}
      }
    }

    if (acc.rows.length <= 1) {
      acc.rows = [createSceneRow(1)];
    } else {
      acc.rows.splice(idx, 1);
      acc.rows.forEach((r, i) => {
        const oldAutoTitle = `Cảnh ${r.index}`;
        r.index = i + 1;
        if (!r.sceneTitle || r.sceneTitle === oldAutoTitle) {
          r.sceneTitle = `Cảnh ${r.index}`;
        }
      });
    }
    acc.settings.rowCount = acc.rows.length;
    this.save();
    return acc;
  }

  updateRow(accountId, rowIndex, patch) {
    const acc = this.getAccount(accountId);
    if (!acc) throw new Error('Không tìm thấy bộ phim.');
    const row = acc.rows.find((r) => Number(r.index) === Number(rowIndex));
    if (!row) throw new Error(`Không tìm thấy Phân cảnh #${rowIndex}`);

    Object.assign(row, patch);
    if (patch.sceneCharacterIds !== undefined) {
      row.sceneCharacterIds = Array.isArray(patch.sceneCharacterIds)
        ? patch.sceneCharacterIds.filter((x) => typeof x === 'string' && x)
        : [];
    }
    if (patch.continueFromPrevScene !== undefined) {
      row.continueFromPrevScene = Boolean(patch.continueFromPrevScene);
    }
    if (patch.includeInExport !== undefined) {
      row.includeInExport = Boolean(patch.includeInExport);
    }
    this.save();
    return row;
  }

  setRowReferenceImage(accountId, rowIndex, slotIndex, imageMeta) {
    const acc = this.getAccount(accountId);
    if (!acc) throw new Error('Không tìm thấy bộ phim.');
    const row = acc.rows.find((r) => Number(r.index) === Number(rowIndex));
    if (!row) throw new Error(`Không tìm thấy Phân cảnh #${rowIndex}`);

    const slot = Math.max(0, Math.min(MAX_ROW_REF_IMAGES - 1, Number(slotIndex) || 0));
    const validList = Array.isArray(row.referenceImages)
      ? row.referenceImages.filter((img) => img && img.filePath && fs.existsSync(img.filePath))
      : [];

    if (!imageMeta) {
      if (slot < validList.length) {
        const removed = validList.splice(slot, 1)[0];
        if (removed?.filePath && fs.existsSync(removed.filePath)) {
          try {
            fs.unlinkSync(removed.filePath);
          } catch (_) {}
        }
      }
    } else if (slot < validList.length) {
      const prevImg = validList[slot];
      if (prevImg?.filePath && prevImg.filePath !== imageMeta.filePath && fs.existsSync(prevImg.filePath)) {
        try {
          fs.unlinkSync(prevImg.filePath);
        } catch (_) {}
      }
      validList[slot] = { ...imageMeta };
    } else if (validList.length < MAX_ROW_REF_IMAGES) {
      validList.push({ ...imageMeta });
    } else {
      const lastIdx = MAX_ROW_REF_IMAGES - 1;
      const prevImg = validList[lastIdx];
      if (prevImg?.filePath && prevImg.filePath !== imageMeta.filePath && fs.existsSync(prevImg.filePath)) {
        try {
          fs.unlinkSync(prevImg.filePath);
        } catch (_) {}
      }
      validList[lastIdx] = { ...imageMeta };
    }

    row.referenceImages = normalizeRowReferenceImages(validList);
    this.save();
    return row;
  }

  appendRowReferenceImages(accountId, rowIndex, imageMetas = [], { replaceAll = false } = {}) {
    const acc = this.getAccount(accountId);
    if (!acc) throw new Error('Không tìm thấy bộ phim.');
    const row = acc.rows.find((r) => Number(r.index) === Number(rowIndex));
    if (!row) throw new Error(`Không tìm thấy Phân cảnh #${rowIndex}`);

    let validList = Array.isArray(row.referenceImages)
      ? row.referenceImages.filter((img) => img && img.filePath && fs.existsSync(img.filePath))
      : [];

    const incomingPaths = new Set((imageMetas || []).map((m) => m && m.filePath).filter(Boolean));
    if (replaceAll) {
      for (const oldImg of validList) {
        if (oldImg?.filePath && !incomingPaths.has(oldImg.filePath) && fs.existsSync(oldImg.filePath)) {
          try {
            fs.unlinkSync(oldImg.filePath);
          } catch (_) {}
        }
      }
      validList = [];
    }

    let addedCount = 0;
    let skippedCount = 0;
    for (const meta of imageMetas || []) {
      if (!meta || !meta.filePath) continue;
      if (validList.length < MAX_ROW_REF_IMAGES) {
        validList.push({ ...meta });
        addedCount++;
      } else {
        skippedCount++;
        if (fs.existsSync(meta.filePath)) {
          try {
            fs.unlinkSync(meta.filePath);
          } catch (_) {}
        }
      }
    }

    row.referenceImages = normalizeRowReferenceImages(validList);
    this.save();
    return {
      row,
      addedCount,
      skippedCount,
      totalOnRow: validList.length,
      maxPerRow: MAX_ROW_REF_IMAGES
    };
  }
}

module.exports = {
  AccountManager,
  BASE_CDP_PORT,
  MAX_ROW_REF_IMAGES,
  VOICE_PRESETS: CINEMA_VOICE_PRESETS,
  VALID_CAMERA_MOTIONS,
  getVoicePresetDirective: getCinemaVoiceDirective,
  normalizeRowReferenceImages,
  createDefaultRows,
  createDefaultProjectSettings,
  parseDurationSeconds,
  normalizeDurationSetting
};
